# Army of Ukraine Package · MANIFEST

**Дата створення:** 2025-10-06 17:26:26  
**Автор:** Сергій Чеча (С.Ч.)  

## Файли в пакеті
- Army_of_Ukraine_Starter_Pack.pdf — повний документ
- Army_of_Ukraine_Short_Overview.pdf — короткий виклад (1 сторінка)
- Army_of_Ukraine_Starter_Pack_Title.png — візуал титульної сторінки

## Архів
- Назва: Army_of_Ukraine_Package.zip
- Розмір: 70845 байт
- SHA256: 7fa2d81085adff6bdeb0b33b64a40a07080362aee26f13ee0e92d45213bfa9fb

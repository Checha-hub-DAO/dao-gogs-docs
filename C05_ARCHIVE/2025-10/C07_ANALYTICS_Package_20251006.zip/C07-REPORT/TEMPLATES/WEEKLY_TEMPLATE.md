\# Weekly Report — {{WeekID}}



📅 Період: {{DateRange}}



\## 🔑 Hero KPI

\- Focus Completion %: ⬜

\- Rhythm Adherence %: ⬜

\- On-Time Reports %: ⬜



\## 📌 Highlights

\- ⬜ Подія / Прорив

\- ⬜ Досягнення / Рішення



\## ⚠️ Risks

\- ⬜ Ризик — Власник — Due — Статус



\## 📝 Decisions

\- ⬜ Рішення — Власник — Due — Source \[C03 LOG/C06 FOCUS]



\## 🔗 Sources

\- LOG: \[link]

\- FOCUS: \[link]

\- KPI: \[link]




# SKD CONTROL MAP · CORE LEVEL

**Дата формування:** 2025-10-06  
**Автор:** Сергій Чеча (С.Ч.)  

---

## Контрольні точки архівацій

### Модуль C07_ANALYTICS
- **Дата:** 2025-10-06  
- **Архів:** C07_ANALYTICS_Package_20251006.zip  
- **SHA256:** c2945bb5abcecf2a11181c86488c88bce9e283167ba6f29d18b9accaaf9c43ad  
- **Місце:** `D:\CHECHA_CORE\C05_ARCHIVE\2025-10\`  
- **Супровід:** README_ARCHIVE_C07.md, SKD_LOG_C07.md, SKD_STATUS_C07.md

---

## Правила ведення карти
- У CONTROL_MAP заносимо лише контрольні точки (ARCHIVE).  
- Для деталей користуватись відповідним `SKD_STATUS_xx.md`.  
- CONTROL_MAP є верхньорівневим оглядом для CORE.  

---

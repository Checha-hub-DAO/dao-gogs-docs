# SKD LOG · C07_ANALYTICS
Призначення: журнал подій (SERVICE / ARCHIVE / CONTROL / VOID / REAPPLY).

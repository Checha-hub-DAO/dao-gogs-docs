# SKD ENTRY — CONTROL PACKAGE

**Дата створення:** __YYYY-MM-DD HH:mm:ss__  
**Автор:** Сергій Чеча (С.Ч.)  

---

### [__YYYY-MM-DD HH:mm:ss__] CONTROL_PACKAGE
- **Модуль:** __CXX__  
- **Пакет:** __ARCHIVE_NAME.zip__  
- **SHA256:** __HASH__  
- **Місце:** `D:\CHECHA_CORE\C05_ARCHIVE\YYYY-MM\`  

---

## Правила
1. Один SKD-ENTRY для кожного контрольного пакета.  
2. Ім’я файлу: `SKD-ENTRY-CONTROL-<MODULE>-<DATE>.md`  
   - Приклад: `SKD-ENTRY-CONTROL-C07-20251006.md`  
   - Для загального ядра: `SKD-ENTRY-CONTROL-CORE-20251006.md`  
3. Лог завжди включає дату, модуль, архів, хеш і місце збереження.  
4. Паралельно запис заноситься у `SKD_CONTROL_MAP_CORE.md`.  

---

# C10_PROJECTS · Модуль проєктів
Роль: реєстр проєктів, статуси, плани, звіти.
Структура: TEMPLATES/, SKD_LOG/, REPORTS/, PORTFOLIO/

# SKD INDEX · C10_PROJECTS
- (посилання на останні записи з SKD_LOG)

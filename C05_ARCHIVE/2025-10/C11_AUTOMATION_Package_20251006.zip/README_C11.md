# C11_AUTOMATION · Модуль автоматизації
Роль: скрипти, пайплайни, плейбуки, автозвірки, CRON/Task Scheduler.
Структура: SCRIPTS/ (ps1, bat, py), PLAYBOOKS/ (покрокові дії), TEMPLATES/, SKD_LOG/

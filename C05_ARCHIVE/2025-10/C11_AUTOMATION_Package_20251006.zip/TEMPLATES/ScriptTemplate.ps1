# SCRIPT TEMPLATE · PowerShell
param([switch])
Write-Host ">>>  started. DryRun="
# TODO: основна логіка

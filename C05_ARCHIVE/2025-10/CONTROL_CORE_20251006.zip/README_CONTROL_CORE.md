# README · CONTROL CORE PACKAGE (2025-10-06)
Опис: централізований пакет із картою CORE.

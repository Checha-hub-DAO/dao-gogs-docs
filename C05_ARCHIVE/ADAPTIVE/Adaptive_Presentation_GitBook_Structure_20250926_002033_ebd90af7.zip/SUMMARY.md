# Summary

* [Adaptive Presentation](README.md)
  * [Diagram](diagram.md)

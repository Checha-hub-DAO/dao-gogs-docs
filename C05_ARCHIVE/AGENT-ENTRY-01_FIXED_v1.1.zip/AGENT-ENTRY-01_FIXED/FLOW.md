# FLOW — робота AGENT-ENTRY-01 (fixed)

1. Ввід ідеї через New-EntryIdea.ps1
2. Автокласифікація і швидка оцінка QACS
3. Запис у LOG/
4. Опціонально — Analyze-Idea.ps1 для другої думки

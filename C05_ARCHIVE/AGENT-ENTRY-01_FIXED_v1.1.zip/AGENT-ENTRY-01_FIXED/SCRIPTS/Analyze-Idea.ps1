Param(
    [Parameter(Mandatory=$true)]
    [string]$Path
)
if (!(Test-Path $Path)) { throw "Файл не знайдено: $Path" }
$content = Get-Content -Raw -LiteralPath $Path -Encoding UTF8
if ($content -match "Сумарно: (\d+)/12") {
    $sum = [int]$Matches[1]
    if ($sum -lt 4) { Write-Host "Сигнал → зберегти, повернутись пізніше" }
    elseif ($sum -lt 7) { Write-Host "Іскорка → оформити малу форму" }
    elseif ($sum -lt 10) { Write-Host "Ядро → винести у Майстерню/G-модуль" }
    else { Write-Host "Готово → запуск ROADMAP+KPI" }
} else {
    Write-Host "⚠ Не знайдено оцінку"
}

Param(
    [Parameter(Mandatory=$true)]
    [string]$Idea,
    [string]$Channel = "Unspecified",
    [string]$Tags = "",
    [ValidateSet("концепт","задача","технічна проблема","символ","медіа-ідея","стратегічна ініціатива","auto")]
    [string]$Type = "auto"
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $ScriptDir
$LogDir = Join-Path $Root "LOG"
$TplDir = Join-Path $Root "TEMPLATES"
$Tpl = Join-Path $TplDir "ENTRY_TEMPLATE.md"

if (!(Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir | Out-Null }

$now = Get-Date
$id = "ENTR-{0:yyyyMMdd-HHmmss}" -f $now
$dateStr = $now.ToString("yyyy-MM-dd HH:mm:ss")

# Template
$tplText = Get-Content -Raw -LiteralPath $Tpl -Encoding UTF8

$body = $tplText
$body = $body.Replace("${ID}", $id)
$body = $body.Replace("${DATE}", $dateStr)
$body = $body.Replace("${CHANNEL}", $Channel)
$body = $body.Replace("${RAW}", $Idea)
$body = $body.Replace("${TYPE}", $Type)
$body = $body.Replace("${TAGS}", $Tags)
$body = $body.Replace("${S_CLARITY}", "1")
$body = $body.Replace("${S_VALUE}", "2")
$body = $body.Replace("${S_FEAS}", "1")
$body = $body.Replace("${S_FIT}", "1")
$body = $body.Replace("${S_SUM}", "5")
$body = $body.Replace("${ROUTE1}", "Майстерня Творця → Чернетка концепту")
$body = $body.Replace("${ROUTE2}", "C12 Knowledge Vault → картка знання")
$body = $body.Replace("${NEXT1}", "Сформувати мінімальну форму (1 сторінка)")
$body = $body.Replace("${NEXT2}", "Визначити модуль/блок і перемістити туди")
$body = $body.Replace("${NEXT3}", "Поставити контрольну дату/KPI")
$body = $body.Replace("${LINKS}", "-")

$outPath = Join-Path $LogDir "$($id).md"
[IO.File]::WriteAllText($outPath, $body, (New-Object System.Text.UTF8Encoding($false)))

Write-Host "✅ Створено запис: $outPath"

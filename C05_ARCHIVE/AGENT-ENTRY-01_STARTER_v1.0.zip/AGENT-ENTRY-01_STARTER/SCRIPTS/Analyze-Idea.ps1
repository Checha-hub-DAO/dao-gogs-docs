Param(
    [Parameter(Mandatory=$true)]
    [string]$Path
)
$ErrorActionPreference = "Stop"
if (!(Test-Path $Path)) { throw "Не знайдено файл $Path" }

# Проста підсвітка: якщо сумарний бал < 4 — повернутись пізніше; 4–6 — мала форма; 7–9 — винести у майстерню; 10–12 — запуск.
$content = Get-Content -Raw -LiteralPath $Path -Encoding UTF8
if ($content -match r"\*\*Сумарно:\*\*\s+(\d+)\s*/\s*12") {
    $sum = [int]$Matches[1]
    if     ($sum -lt 4)  { $adv = "Рекомендація: зберегти як сигнал, повернутись після збору контексту." }
    elseif ($sum -lt 7)  { $adv = "Рекомендація: оформити *малу форму* (1 сторінка) і призначити ревʼю." }
    elseif ($sum -lt 10) { $adv = "Рекомендація: винести у *Майстерню/G‑модуль* з коротким ROADMAP." }
    else                 { $adv = "Рекомендація: *готово до запуску* — сформувати ROADMAP і KPI." }
    Write-Host ("Оцінка знайдена: {0}/12 → {1}" -f $sum,$adv)
} else {
    Write-Warning "Не знайдено рядок із сумарним балом."
}

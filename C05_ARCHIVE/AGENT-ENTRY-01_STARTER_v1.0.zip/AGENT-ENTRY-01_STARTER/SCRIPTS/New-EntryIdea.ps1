Param(
    [Parameter(Mandatory=$true)]
    [string]$Idea,
    [string]$Channel = "Unspecified",
    [string]$Tags = "",
    [ValidateSet("концепт","задача","технічна проблема","символ","медіа-ідея","стратегічна ініціатива","auto")]
    [string]$Type = "auto",
    [int]$Clarity = -1,
    [int]$Value = -1,
    [int]$Feasibility = -1,
    [int]$SystemFit = -1
)

$ErrorActionPreference = "Stop"

# Root = current script dir/..
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $ScriptDir
$LogDir = Join-Path $Root "LOG"
$TplDir = Join-Path $Root "TEMPLATES"
$Tpl = Join-Path $TplDir "ENTRY_TEMPLATE.md"

if (!(Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir | Out-Null }

# ID and date
$now = Get-Date
$id = "ENTR-{0:yyyyMMdd-HHmmss}" -f $now
$dateStr = $now.ToString("yyyy-MM-dd HH:mm:ss")

# Heuristic auto type if requested
function Guess-Type([string]$text) {
    $t = $text.ToLower()
    if ($t -match "скрипт|powershell|docker|gitbook|інтеграці") { return "технічна проблема" }
    if ($t -match "символ|герой|міф|лого|візуал") { return "символ" }
    if ($t -match "відео|пост|медіа|картка") { return "медіа-ідея" }
    if ($t -match "стратег|кампан|щит|модуль|g\d+") { return "стратегічна ініціатива" }
    if ($t -match "зробити|завдання|скласти|написати|налаштувати") { return "задача" }
    return "концепт"
}

if ($Type -eq "auto") { $Type = Guess-Type $Idea }

# Quick scoring defaults
function Clamp([int]$x) {
    if ($x -lt 0) { return -1 }
    if ($x -gt 3) { return 3 }
    return $x
}

$Clarity    = Clamp $Clarity
$Value      = Clamp $Value
$Feasibility= Clamp $Feasibility
$SystemFit  = Clamp $SystemFit

# Primitive heuristic to prefill scores if not provided
if ($Clarity -lt 0 -or $Value -lt 0 -or $Feasibility -lt 0 -or $SystemFit -lt 0) {
    $len = $Idea.Length
    $Clarity     = if ($Clarity -ge 0)     { $Clarity }     else { if ($len -gt 80) {2} else {1} }
    $Value       = if ($Value -ge 0)       { $Value }       else { 2 }
    $Feasibility = if ($Feasibility -ge 0) { $Feasibility } else { 1 }
    $SystemFit   = if ($SystemFit -ge 0)   { $SystemFit }   else { if ($Idea -match "G\d+|C\d+") {2} else {1} }
}
$Sum = $Clarity + $Value + $Feasibility + $SystemFit

# Route suggestions
$route1 = switch ($Type) {
    "технічна проблема"       { "C11_Automation → інструмент/скрипт (+ LOG у C03/C07)" }
    "символ"                  { "Світ Ч → MAP_SYMBOLS (додати ескіз/легенду)" }
    "медіа-ідея"              { "G35 DAO-Медіа → картка/пост + шаблон контенту" }
    "стратегічна ініціатива"  { "Відповідний G‑модуль (напр., G46/G43) → README + ROADMAP" }
    "задача"                  { "C06_FOCUS → To‑Do (2–3 кроки, дедлайн)" }
    default                   { "Майстерня Творця → Чернетка концепту" }
}
$route2 = switch ($Type) {
    "технічна проблема"       { "GitBook/GitHub issue або TECH_NOTES.md" }
    "символ"                  { "DAO‑Gallery або «Символи й міфологія» → етап 1" }
    "медіа-ідея"              { "Content Pipeline (відео/стаття) → KPI + дедлайн" }
    "стратегічна ініціатива"  { "C06_FOCUS → встановити KPI + дату ревʼю" }
    "задача"                  { "C03_LOG → короткий звіт після виконання" }
    default                   { "C12 Knowledge Vault → створити картку знання" }
}

# Load and render template
$tplText = Get-Content -Raw -LiteralPath $Tpl -Encoding UTF8
$body = $tplText.Replace("${ID}", $id) \
    .Replace("${DATE}", $dateStr) \
    .Replace("${CHANNEL}", $Channel) \
    .Replace("${RAW}", $Idea) \
    .Replace("${TYPE}", $Type) \
    .Replace("${TAGS}", $Tags) \
    .Replace("${S_CLARITY}", "$Clarity") \
    .Replace("${S_VALUE}", "$Value") \
    .Replace("${S_FEAS}", "$Feasibility") \
    .Replace("${S_FIT}", "$SystemFit") \
    .Replace("${S_SUM}", "$Sum") \
    .Replace("${ROUTE1}", $route1) \
    .Replace("${ROUTE2}", $route2) \
    .Replace("${NEXT1}", "Сформувати мінімальну форму (1 сторінка)") \
    .Replace("${NEXT2}", "Визначити модуль/блок і перемістити туди") \
    .Replace("${NEXT3}", "Поставити контрольну дату/KPI") \
    .Replace("${LINKS}", "-")

$outPath = Join-Path $LogDir "$($id).md"
[IO.File]::WriteAllText($outPath, $body, (New-Object System.Text.UTF8Encoding($false)))

Write-Host "✅ Створено запис: $outPath"

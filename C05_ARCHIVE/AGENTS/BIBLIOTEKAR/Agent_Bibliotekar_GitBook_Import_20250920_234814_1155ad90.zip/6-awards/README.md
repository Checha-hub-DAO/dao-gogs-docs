# 6-awards

## Файли

- `sertyfikat-svitla.pdf`

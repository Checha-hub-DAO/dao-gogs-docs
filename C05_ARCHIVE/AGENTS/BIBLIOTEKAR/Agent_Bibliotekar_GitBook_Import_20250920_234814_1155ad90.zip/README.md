# Agent Bibliotekar — Mythic Set (Structured)

**Версія:** v1.1  
**Дата:** 2025-09-20

## Overview
Цей пакет містить матеріали ініціативи *Agent Bibliotekar — Mythic Set* у структурованому вигляді.  
Файли організовані у тематичні папки, кожна має локальний README та набір контенту.

- Ліцензія: MIT (код) + CC BY-SA 4.0 (контент/медіа)
- Контроль цілісності: `MANIFEST.csv`, `CHECKSUMS.txt`, `SHA256SUMS.txt`
- Журнал змін: `CHANGELOG.md`, `RELEASE_NOTES.md`
- Навігація для GitBook: `SUMMARY.md`

## Release Info
- Поточна версія: **v1.1**
- Основні зміни: нормалізація назв, додавання ліцензії, індексація, контроль цілісності, створення дистрибутивного архіву

## Context Map
# Робоча мапа контексту — Agent Bibliotekar (Mythic Set)

```
- 2-path/
  - README.md
  - minikurs-shlyah-svitla.pdf
  - plan-pershogo-zanyattya.pdf
- 3-rituals/
  - README.md
  - klyatva-svitla.pdf
  - rytual-pershogo-svitla.pdf
- 4-song/
  - README.md
  - pisnya-svitla.pdf
- 5-methodics/
  - README.md
  - instruktsiya-batkiv-shlyah-svitla.pdf
  - posibnyk-vchytelya-svitla.pdf
- 6-awards/
  - README.md
  - sertyfikat-svitla.pdf
- 7-navigation/
  - README.md
  - readme-agent-bibliotekar-mythic-set.pdf
- 8-visuals/
  - README.md
  - zaproshennya-shlyah-svitla.pdf
- CHECKSUMS.txt
- LICENSE.md
- MANIFEST.csv
- RELEASE_NOTES.md
- SHA256SUMS.txt
- SUMMARY.md
- VERSION
- changelog.md
- manifest.csv
- readme.md
```


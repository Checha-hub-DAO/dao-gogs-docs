# 5-methodics

## Файли

- `instruktsiya-batkiv-shlyah-svitla.pdf`
- `posibnyk-vchytelya-svitla.pdf`

# Changelog

## 20250920_233321
- Додано `MANIFEST.csv` із SHA‑256 для всіх файлів
- Згенеровано `README.md` (GitBook‑ready)
- Підготовлено CLEAN+ архів для розповсюдження

Param(
    [ValidateSet('military','partners','community','public')]
    [string]$Audience = 'public',
    [string]$OutDir = '.\OUT',
    [switch]$Pdf,
    [switch]$Png
)

# --- Setup ---
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

$srcReadme = Join-Path $root 'README.md'
$srcStruct = Join-Path $root 'STRUCTURE.md'
$coverPng = Join-Path $root 'COVER.png'

if (!(Test-Path $srcReadme)) { throw "README.md не знайдено." }

# --- Read content ---
$md = Get-Content -Raw -LiteralPath $srcReadme

# --- Adaptive filter ---
# Keeps only blocks marked for the selected audience, removes others when explicitly tagged.
# Blocks syntax:
# <!--AUD:military--> ... <!--/AUD-->
function Select-AudienceBlocks {
    param([string]$Text,[string]$Audience)

    # Remove all explicitly tagged blocks that do NOT match current audience
    $pattern = '<!--AUD:(?<aud>[^>]+?)-->(?<body>[\s\S]*?)<!--/AUD-->'
    $out = [System.Text.RegularExpressions.Regex]::Replace($Text, $pattern, {
        param($m)
        $aud = $m.Groups['aud'].Value.Trim().ToLower()
        if ($aud -ne $Audience) { return '' } else { return $m.Groups['body'].Value }
    })
    return $out
}

$mdFiltered = Select-AudienceBlocks -Text $md -Audience $Audience

# --- Write One-Pager (same content, but can be further trimmed later) ---
$ts = (Get-Date).ToString('yyyyMMdd_HHmmss')
$outBase = Join-Path $OutDir ("Adaptive_{0}_{1}" -f $Audience, $ts)
$outMd = "$outBase.md"
$outHtml = "$outBase.html"
$outPdf = "$outBase.pdf"
$outPng = "$outBase.png"

# Header banner line
$banner = "# Adaptive Presentation — $Audience`n*Зібрано: $(Get-Date -Format 'yyyy-MM-dd HH:mm')*`n`n"
Set-Content -LiteralPath $outMd -Value ($banner + $mdFiltered) -Encoding UTF8

# --- Try to build HTML/PDF via Pandoc if available ---
function Test-Tool([string]$name){
    $old = $ErrorActionPreference; $ErrorActionPreference='SilentlyContinue'
    try { $null = & $name --version; return $LASTEXITCODE -eq 0 }
    catch { return $false }
    finally { $ErrorActionPreference=$old }
}

$hasPandoc = Test-Tool 'pandoc'

if ($hasPandoc) {
    Write-Host "[OK] Pandoc знайдено — генерую HTML та PDF..."
    & pandoc $outMd -f gfm -t html5 -s -o $outHtml --metadata title="Adaptive Presentation ($Audience)" --pdf-engine=wkhtmltopdf 2>$null
    if (Test-Path $outHtml) { Write-Host "[OK] HTML: $outHtml" }
    # Try PDF (requires pdf engine). If wkhtmltopdf not present, pandoc may still use another engine if configured.
    try {
        & pandoc $outMd -f gfm -o $outPdf 2>$null
        if (Test-Path $outPdf) { Write-Host "[OK] PDF: $outPdf" }
        else { Write-Warning "PDF не згенеровано (перевір wkhtmltopdf/LaTeX). Файл MD/HTML доступні." }
    } catch {
        Write-Warning "Помилка генерації PDF: $($_.Exception.Message)"
    }
} else {
    Write-Warning "Pandoc не знайдено. Залишаю Markdown ($outMd). Встанови Pandoc для автогенерації PDF/HTML: https://pandoc.org/"
}

# --- Copy cover
Copy-Item -LiteralPath $coverPng -Destination (Join-Path $OutDir "COVER.png") -Force

# --- Optional PNG note ---
if ($Png.IsPresent) {
    Write-Warning "Автоконвертація MD→PNG не увімкнена за замовчуванням. Рекомендовано конвертувати PDF→PNG (наприклад, через ImageMagick: `magick convert file.pdf file.png`)."
}

Write-Host "`n[DONE] Готово. Папка: $OutDir"

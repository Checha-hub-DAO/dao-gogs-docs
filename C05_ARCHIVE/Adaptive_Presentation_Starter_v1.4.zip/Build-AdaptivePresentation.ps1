Param(
    [ValidateSet('military','partners','community','public')]
    [string]$Audience = 'public',
    [string]$OutDir = '.\OUT',
    [switch]$Pdf,
    [switch]$AllOnePagers,     # зібрати всі 4 одразу
    [string]$Version = '1.3.0'
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

# BuildInfo.json
$buildInfo = @{
    version = $Version
    built_at = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    audience = $Audience
}
$buildInfoPath = Join-Path $OutDir 'BuildInfo.json'
$buildInfo | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $buildInfoPath -Encoding UTF8

function Write-OnePager([string]$aud){
    $src = Join-Path $root 'README.md'
    if (!(Test-Path $src)) { throw 'README.md не знайдено' }

    # Фільтрація блоків
    $text = Get-Content -Raw -LiteralPath $src
    $pattern = '<!--AUD:(?<aud>[^>]+?)-->(?<body>[\s\S]*?)<!--/AUD-->'
    $filtered = [System.Text.RegularExpressions.Regex]::Replace($text, $pattern, {
        param($m)
        $a = $m.Groups['aud'].Value.Trim().ToLower()
        if ($a -ne $aud) { return '' } else { return $m.Groups['body'].Value }
    })

    $ts = (Get-Date).ToString('yyyyMMdd_HHmmss')
    $outBase = Join-Path $OutDir ("Adaptive_ONEPAGER_{0}_v{1}_{2}" -f $aud,$Version,$ts)
    $outMd = "$outBase.md"
    Set-Content -LiteralPath $outMd -Value ("# Adaptive Presentation — {0}`n`n" -f $aud) -Encoding UTF8
    Add-Content -LiteralPath $outMd -Value $filtered -Encoding UTF8

    if ($Pdf.IsPresent){
        if (Get-Command pandoc -ErrorAction SilentlyContinue) {
            & pandoc $outMd -f gfm -o ($outBase + '.pdf') 2>$null
        } else {
            Write-Warning "Pandoc не знайдено — залишається MD. (опційно: wkhtmltopdf/LaTeX)"
        }
    }
}

if ($AllOnePagers){
    'military','partners','community','public' | ForEach-Object { Write-OnePager $_ }
} else {
    Write-OnePager $Audience
}

# Checksums
$sumFile = Join-Path $OutDir 'checksums.txt'
if (Test-Path $sumFile) { Remove-Item $sumFile -Force }
Get-ChildItem -Path $OutDir -File | ForEach-Object {
    $h = Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName
    "{0}  {1}" -f $h.Hash,$_.Name | Add-Content -LiteralPath $sumFile -Encoding UTF8
}

Write-Host "[DONE] v$Version — Готово. Перевір $OutDir"

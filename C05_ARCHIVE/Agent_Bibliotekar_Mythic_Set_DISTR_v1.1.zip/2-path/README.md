# 2-path

## Файли

- `minikurs-shlyah-svitla.pdf`
- `plan-pershogo-zanyattya.pdf`

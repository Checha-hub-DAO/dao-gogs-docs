# 8-visuals

## Файли

- `zaproshennya-shlyah-svitla.pdf`

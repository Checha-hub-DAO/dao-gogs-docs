# Release Notes — v1.1

**Date:** 2025-09-20 23:37:39

## Changes
- Normalized names (kebab-case, UA→ASCII transliteration)
- Added `LICENSE.md` (MIT for code, CC BY-SA 4.0 for content)
- Added `SUMMARY.md` for GitBook navigation
- Generated `README.md` files in subfolders (where missing)
- Added integrity files: `MANIFEST.csv`, `CHECKSUMS.txt`, `SHA256SUMS.txt`
- Created distributive package for public publishing

## Files included for release
- `README.md`, `SUMMARY.md`, `LICENSE.md`, `RELEASE_NOTES.md`, `VERSION`
- Content media (SVG/PNG/JPG/GIF/WEBP/PDF) and Markdown


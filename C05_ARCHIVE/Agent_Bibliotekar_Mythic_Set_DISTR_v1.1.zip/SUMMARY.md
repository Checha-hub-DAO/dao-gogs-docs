# Summary

* [Overview](README.md)
* [2-path](2-path/README.md)
* [3-rituals](3-rituals/README.md)
* [4-song](4-song/README.md)
* [5-methodics](5-methodics/README.md)
* [6-awards](6-awards/README.md)
* [7-navigation](7-navigation/README.md)
* [8-visuals](8-visuals/README.md)

<!-- Generated 2025-09-20 23:37:39 for GitBook import -->

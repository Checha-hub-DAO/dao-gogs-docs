# AudienceKits v1.6

**Дата релізу:** 25.09.2025  
**Автор:** Сергій Чеча (С.Ч.)  
**Статус:** Активна версія  

---

## 🔑 Нове у v1.6
- 🆕 **YouthKit** — додано як п’ятий повноцінний комплект (README, OnePager, Cover, QR).  
- 📲 **Інтерактивні QR** — усі посилання тепер мають короткі редіректи з UTM.  
- 📊 **Міні-аналітика (metrics)** — стартові лічильники у BuildInfo.json.  
- 🎨 **Візуальне оновлення** — усі Covers виконані у стилі *StyleGuide v1.0*, з підписом *«С.Ч.»*.  
- 🔗 **Інтеграція з CheCha-CORE** — файл `C06_LINKS.md` з дубльованими посиланнями.  

---

## 📦 Комплекти

### MilitaryKit
- README.md  
- OnePager_withQR.pdf (INTERNAL USE ONLY)  
- OnePager_bw.pdf (Print-ready)  
- COVER_withQR.png  
- QR.png (заглушка)  

### PartnersKit
- README.md  
- OnePager_withQR.pdf  
- OnePager_bw.pdf  
- COVER_withQR.png  
- QR.png (інтерактивний, з UTM)  

### CommunityKit
- README.md  
- OnePager_withQR.pdf  
- OnePager_bw.pdf  
- COVER_withQR.png  
- QR.png (інтерактивний, з UTM)  

### PublicKit
- README.md  
- OnePager_withQR.pdf  
- OnePager_bw.pdf  
- COVER_withQR.png  
- QR.png (інтерактивний, з UTM)  

### YouthKit
- README.md  
- OnePager_withQR.pdf  
- OnePager_bw.pdf  
- COVER_withQR.png  
- QR.png (інтерактивний, з UTM)  

---

## 📑 Додаткові файли
- BuildInfo.json (версія, release_notes, SHA-256)  
- checksums.txt (контрольні суми)  
- C06_LINKS.md (текстові посилання для CheCha-CORE)  
- Catalog_AudienceKits_v1.6_UA.pdf  
- Catalog_AudienceKits_v1.6_EN.pdf  
- CHANGELOG.md  
- Catalog.md  
- Banner_AudienceKits_v1.6.png  

---

## 📌 Наступні кроки
- Розширення **metrics**: інтеграція з трекінговою системою DAO-GOGS.  
- Можливе додавання **Specialized Kits** (MediaKit, EduKit).  
- Публічний реліз через GitBook і DAO-канали.  

---

**DAO-GOGS | Adaptive Presentation**  
*AudienceKits — v1.6*  
Автор: **С.Ч.**

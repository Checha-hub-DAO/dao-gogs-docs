# AudienceKits v1.6.0 — Посилання (C06_LINKS.md)

**Дата:** 2025-09-25 · **Версія:** v1.6.0 · **Автор:** Сергій Чеча (С.Ч.)

## MilitaryKit
QR: Internal Use Only (заглушка, без посилання)

## PartnersKit
https://gogs.link/partners?utm_source=partners&utm_medium=qr&utm_campaign=audiencekits_v1.6

## CommunityKit
https://gogs.link/community?utm_source=community&utm_medium=qr&utm_campaign=audiencekits_v1.6

## PublicKit
https://gogs.link/public?utm_source=public&utm_medium=qr&utm_campaign=audiencekits_v1.6

## YouthKit
https://gogs.link/youth?utm_source=youth&utm_medium=qr&utm_campaign=audiencekits_v1.6

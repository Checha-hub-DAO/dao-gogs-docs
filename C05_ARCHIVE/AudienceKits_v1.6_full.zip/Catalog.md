# AudienceKits v1.6 — Каталог

**Дата релізу:** 25.09.2025  
**Автор:** Сергій Чеча (С.Ч.)  
**Статус:** Активна версія

---

## 📦 Комплекти

### MilitaryKit
- README.md  
- OnePager_withQR.pdf (INTERNAL USE ONLY)  
- OnePager_bw.pdf (Print-ready)  
- COVER_withQR.png  
- QR.png (заглушка)  

### PartnersKit
- README.md  
- OnePager_withQR.pdf  
- OnePager_bw.pdf  
- COVER_withQR.png  
- QR.png (інтерактивний, з UTM)  

### CommunityKit
- README.md  
- OnePager_withQR.pdf  
- OnePager_bw.pdf  
- COVER_withQR.png  
- QR.png (інтерактивний, з UTM)  

### PublicKit
- README.md  
- OnePager_withQR.pdf  
- OnePager_bw.pdf  
- COVER_withQR.png  
- QR.png (інтерактивний, з UTM)  

### YouthKit
- README.md  
- OnePager_withQR.pdf  
- OnePager_bw.pdf  
- COVER_withQR.png  
- QR.png (інтерактивний, з UTM)  

---

## 📑 Додаткові файли
- BuildInfo.json (версія, release_notes, SHA-256)  
- checksums.txt (контрольні суми)  
- C06_LINKS.md (текстові посилання для CheCha-CORE)  
- Catalog_AudienceKits_v1.6_UA.pdf  
- Catalog_AudienceKits_v1.6_EN.pdf  
- Banner_AudienceKits_v1.6.png  
- CHANGELOG.md  

---

**DAO-GOGS | Adaptive Presentation**  
*AudienceKits — v1.6*  
Автор: **С.Ч.**

# C03 LOG TEMPLATES
## TRIAGE decision
- when: YYYY-MM-DD HH:MM
- item: <file/path>
- decision: KEEP/MERGE/PUBLISH/ARCHIVE/DROP
- route: <target>
- owner: initials
- note: …

## ALERT (dedup)
- when: YYYY-MM-DD HH:MM
- report: SCRIPTS/dedup_report.tsv
- duplicates: N

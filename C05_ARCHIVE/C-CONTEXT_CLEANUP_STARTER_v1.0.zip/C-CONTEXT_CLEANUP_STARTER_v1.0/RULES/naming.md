# Naming Standard (v1.0)
`YYYY-MM-DD__ContextSlug__vMAJOR.MINOR.ext`
- `ContextSlug`: латиниця, `-` замість пробілів
- Версійність: SemVer (1.2, 2.0.1)
- Приклади: `2025-09-09__G05-dao-values__v1.0.md`

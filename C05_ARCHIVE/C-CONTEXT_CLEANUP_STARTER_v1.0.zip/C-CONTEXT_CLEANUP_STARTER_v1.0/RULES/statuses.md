# Status Tags
KEEP • MERGE • PUBLISH • ARCHIVE • DROP
- KEEP — залишити як є (тимчасово)
- MERGE — об'єднати з основним документом
- PUBLISH — перенести в GitBook/офіційний репозиторій
- ARCHIVE — зафіксувати у ZIP (C05)
- DROP — видалити (після логування у C03)

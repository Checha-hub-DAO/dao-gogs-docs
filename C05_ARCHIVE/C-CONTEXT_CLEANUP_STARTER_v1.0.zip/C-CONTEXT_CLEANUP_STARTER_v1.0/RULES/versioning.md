# Versioning & Changelog
- SemVer: MAJOR.MINOR.PATCH
- Обов'язково: `CHANGELOG.md` у цільовому модулі
- Archive: ZIP+SHA256 у C05/ARCHIVE з `MANIFEST.json`

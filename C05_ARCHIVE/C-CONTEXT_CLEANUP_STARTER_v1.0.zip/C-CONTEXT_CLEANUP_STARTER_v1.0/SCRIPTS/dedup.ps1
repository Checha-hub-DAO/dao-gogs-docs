param([string]$Path="INBOX")
Write-Host "De-dup scan in $Path"
$hashes = @{}
Get-ChildItem -Recurse -Path $Path -File | ForEach-Object {
  $h = (Get-FileHash -Algorithm SHA256 -Path $_.FullName).Hash
  if ($hashes.ContainsKey($h)) {
    "{0}	DUPLICATE_OF	{1}" -f $_.FullName, $hashes[$h]
  } else {
    $hashes[$h] = $_.FullName
  }
} | Set-Content -Path "SCRIPTS/dedup_report.tsv"
Write-Host "Report: SCRIPTS/dedup_report.tsv"

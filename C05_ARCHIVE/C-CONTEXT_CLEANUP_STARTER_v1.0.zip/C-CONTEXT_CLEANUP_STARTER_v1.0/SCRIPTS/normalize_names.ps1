param([string]$Path="INBOX")
$now = Get-Date -Format "yyyy-MM-dd"
Get-ChildItem -Recurse -Path $Path -File | ForEach-Object {
  $ext = $_.Extension
  $name = [IO.Path]::GetFileNameWithoutExtension($_.Name)
  $slug = ($name -replace '\s+', '-' -replace '[^A-Za-z0-9\-\._]', '').ToLower()
  $target = Join-Path $_.Directory.FullName ("{0}__{1}__v1.0{2}" -f $now, $slug, $ext)
  if ($_.FullName -ne $target) { Rename-Item $_.FullName $target }
}

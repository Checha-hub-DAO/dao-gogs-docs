# C10_CORE — DAO-DNA Core

Сутність DAO-DNA.  
Містить першу спіраль (C08 + C09).  
Описує структуру DAO-DNA і Immunity System.


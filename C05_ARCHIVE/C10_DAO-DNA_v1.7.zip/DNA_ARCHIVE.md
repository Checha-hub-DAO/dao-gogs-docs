# DNA_ARCHIVE

Архів DAO-DNA.  
Фіксує Spiral_1, Spiral_2, Spiral_3 та наступні хвилі.  
Містить лог змін і перевірок.

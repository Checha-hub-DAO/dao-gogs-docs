# DNA_PROTOCOL

Процедури функціонування DAO-DNA.  
Описує Immunity Check, видачу License, запис в Archive, відображення у Dashboard.

# C11/AGENTS — v1.1 (health + notify)
## Нове
- JSON health-пінги у `C03/HEALTH/agents/*.json` (OK/WARN/FAIL)
- `Notify-IfDegraded` → пише в `C03/LOG/alerts.log` і консоль (hook під Telegram/e‑mail)
- Моніторинг: `monitoring/scan_health.ps1` для перевірки станів

## Quickstart
1) Покладіть теку в `C11/AGENTS`.
2) Заповніть `_config/agents.json` і `_config/secrets.json` (локально, у git ігнор).
3) Додайте `mc.exe` і `gh.exe` у PATH.
4) Smoke‑тест: `./hub/invoke.ps1 -Agent vault-bot -JsonPayload "{}"`
   - Спробуйте деградації: `./vault-bot/run.ps1 -ForceWarn` або `-ForceFail`
5) Перевірте `C03/HEALTH/agents/*.json` і `C03/LOG/alerts.log`.
6) Заплануйте `monitoring/scan_health.ps1` щогодини.

## Рекомендації
- Виносьте секрети у secrets manager (1Password CLI / HashiCorp Vault).
- Додавайте KPI з health у C09 (наприклад, % OK за 24h, mean TTR).

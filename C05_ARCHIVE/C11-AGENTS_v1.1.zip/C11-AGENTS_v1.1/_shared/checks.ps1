Write-Host "PS Version: $($PSVersionTable.PSVersion)"
if (-not (Get-Command gh -ErrorAction SilentlyContinue)) { Write-Warning "gh not found" }

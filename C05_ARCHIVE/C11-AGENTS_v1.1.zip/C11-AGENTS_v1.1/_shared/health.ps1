. "$PSScriptRoot/utils.ps1"
function Get-CoreRoot {
  # _shared → AGENTS → C11 → CHECHA_CORE root
  $agents = Split-Path -Path $PSScriptRoot -Parent        # .../AGENTS/_shared
  $c11    = Split-Path -Path $agents -Parent              # .../AGENTS
  $core   = Split-Path -Path $c11 -Parent                 # .../C11
  return Split-Path -Path $core -Parent                   # .../CHECHA_CORE
}
function Write-AgentHealth([string]$Agent,[string]$Status,[hashtable]$Extra=@{}) {
  $root = Get-CoreRoot
  $dir = Join-Path $root "C03/HEALTH/agents"
  Ensure-Dir $dir
  $obj = @{
    agent = $Agent
    status = $Status  # OK|WARN|FAIL
    ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    extra = $Extra
  }
  $json = ($obj | ConvertTo-Json -Depth 6)
  $path = Join-Path $dir ("{0}.json" -f $Agent)
  Set-Content -Path $path -Value $json -Encoding UTF8
  Write-Host (Log "Health updated → $Status" "INFO" $Agent)
}

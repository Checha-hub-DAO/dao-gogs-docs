. "$PSScriptRoot/utils.ps1"
function Get-CoreRoot {
  $agents = Split-Path -Path $PSScriptRoot -Parent
  $c11    = Split-Path -Path $agents -Parent
  $core   = Split-Path -Path $c11 -Parent
  return Split-Path -Path $core -Parent
}
function Notify-IfDegraded([string]$Agent,[string]$Status,[string]$Message="") {
  if ($Status -eq "OK") { return }
  $root = Get-CoreRoot
  $logDir = Join-Path $root "C03/LOG"
  Ensure-Dir $logDir
  $line = Log ("ALERT: $Agent → $Status :: $Message") "WARN" $Agent
  Add-Content -Path (Join-Path $logDir "alerts.log") -Value $line -Encoding UTF8
  Write-Host $line
  # 🔔 Hook point: інтеграція з Telegram/e-mail/webhook
}

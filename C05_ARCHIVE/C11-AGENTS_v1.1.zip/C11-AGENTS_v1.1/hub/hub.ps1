param([string]$Agent,[string]$PayloadPath)
. "$PSScriptRoot/../_shared/utils.ps1"
. "$PSScriptRoot/../_shared/health.ps1"
Write-Host (Log "Hub start → $Agent ($PayloadPath)" "INFO" $Agent)
$agentPath = Join-Path $PSScriptRoot ("..\{0}\run.ps1" -f $Agent)
if (-not (Test-Path $agentPath)) { throw "Agent not found: $Agent" }
try {
  & $agentPath -PayloadPath $PayloadPath
  Write-AgentHealth -Agent $Agent -Status "OK"
} catch {
  Write-AgentHealth -Agent $Agent -Status "FAIL" -Extra @{ error = $_.Exception.Message }
  throw
}

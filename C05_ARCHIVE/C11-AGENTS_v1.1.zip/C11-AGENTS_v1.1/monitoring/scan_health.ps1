. "$PSScriptRoot/../_shared/utils.ps1"
. "$PSScriptRoot/../_shared/notify.ps1"
$root = (Split-Path -Path $PSScriptRoot -Parent) | Split-Path | Split-Path
$healthDir = Join-Path $root "C03/HEALTH/agents"
if (-not (Test-Path $healthDir)) { Write-Host (Log "No health dir yet" "INFO" "monitor"); exit 0 }
Get-ChildItem $healthDir -Filter *.json | ForEach-Object {
  $obj = Get-Content $_.FullName | ConvertFrom-Json
  if ($obj.status -ne "OK") { Notify-IfDegraded $obj.agent $obj.status "from monitor scan" }
}
Write-Host (Log "Health scan complete" "INFO" "monitor")

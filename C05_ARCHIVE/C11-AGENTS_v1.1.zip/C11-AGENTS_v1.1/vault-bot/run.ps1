param([string]$PayloadPath,[switch]$ForceWarn,[switch]$ForceFail)
. "$PSScriptRoot/../_shared/utils.ps1"
. "$PSScriptRoot/../_shared/health.ps1"
. "$PSScriptRoot/../_shared/notify.ps1"
$Name = (Split-Path $PSScriptRoot -Leaf)
Write-Host (Log "$Name start")
try {
  # TODO: implement $Name logic
  if ($ForceFail) { throw "forced failure" }
  elseif ($ForceWarn) {
    Write-AgentHealth -Agent $Name -Status "WARN" -Extra @{ note="forced warn" }
    Notify-IfDegraded -Agent $Name -Status "WARN" -Message "forced warn"
  } else {
    Write-Host (Log "$Name work…")
  }
  Write-Host (Log "$Name done" "OK")
} catch {
  Write-AgentHealth -Agent $Name -Status "FAIL" -Extra @{ error = $_.Exception.Message }
  Notify-IfDegraded -Agent $Name -Status "FAIL" -Message $_.Exception.Message
  throw
}

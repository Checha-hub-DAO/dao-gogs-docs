# TASK-CheckList — Інтеграція ZIP (C11_AUTOMATION)

## Щоденна перевірка

- [ ] 1. Перевірити нові ZIP у `WORKSHOP\zip_inbox\`
- [ ] 2. Запустити `Add-ZipHistory.ps1` з відповідним пресетом (`C11`, `WORKSHOP-DRAFT`, `WORKSHOP-TEST`)
- [ ] 3. Визначити рівень зрілості (Draft / Beta / Release)
- [ ] 4. Оновити `ZIP_HISTORY.csv` та `ZIP_HISTORY.md`
- [ ] 5. Для Release — інтегрувати у `D:\CHECHA_CORE\C11_AUTOMATION\`
- [ ] 6. За потреби додати SHA256 (`-hash`)
- [ ] 7. Внести зміни у `FOCUS_OVERVIEW.md` та щотижневий звіт

---

🔑 Примітка: тільки **Release** пакети йдуть у ядро. Draft і Beta залишаються у WORKSHOP до дозрівання.

---

🏷️ #Focus

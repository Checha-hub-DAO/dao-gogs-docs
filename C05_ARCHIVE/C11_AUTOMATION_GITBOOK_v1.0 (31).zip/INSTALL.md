# INSTALL.md — C11_AUTOMATION_ZIPTOOLS

## Кроки встановлення

1. **Розпакуйте архів**
   ```
   C11_AUTOMATION_ZIPTOOLS_v1.0.zip
   ```

2. **Розмістіть файли:**
   - `Update-ZipHistory.ps1`, `Add-ZipHistory.ps1` → `D:\CHECHA_CORE\TOOLS\`
   - `ZIP_HISTORY.csv`, `ZIP_HISTORY.md` → `D:\CHECHA_CORE\C05_ARCHIVE\`
   - `TASK-CheckList.md`, `ZIP_Integration_Flow.md`, `README.md`, `INSTALL.md` → `D:\CHECHA_CORE\C06_FOCUS\`

3. **Перевірте політику виконання PowerShell**
   ```powershell
   Get-ExecutionPolicy
   ```
   Якщо виводить `Restricted`, тимчасово зніміть обмеження:
   ```powershell
   Set-ExecutionPolicy Bypass -Scope Process -Force
   ```

4. **Тестовий запуск**
   ```powershell
   pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
     -preset C11 -n "TEST_PACKAGE_20250926.zip" `
     -s Чернетка -m Draft
   ```

5. **Перевірте результати:**
   - У `C05_ARCHIVE\ZIP_HISTORY.csv` має з’явитися новий рядок.
   - У `C05_ARCHIVE\ZIP_HISTORY.md` — новий рядок у таблиці.

---

✅ Тепер система готова до щоденного використання.

---

🏷️ #UserGuide

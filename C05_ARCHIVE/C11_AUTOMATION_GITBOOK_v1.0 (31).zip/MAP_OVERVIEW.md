# MAP_OVERVIEW.md — C11_AUTOMATION

## 🎯 Стратегічний план
Орієнтири розвитку дивись у файлі: [ROADMAP](ROADMAP.md)

---

## 📊 Візуальна мапа
Вся структура блоків і файлів: [VISUAL_MAP](VISUAL_MAP.md)

### Вбудована схема
```mermaid
flowchart TD
    ROOT[ROOT]:::root --> TOOLS[TOOLS]
    ROOT --> ARCHIVE[ARCHIVE]
    ROOT --> FOCUS[FOCUS]

    TOOLS --> ADD[Add-ZipHistory.ps1]
    TOOLS --> UPDATE[Update-ZipHistory.ps1]
    TOOLS --> AUTO[AUTO-INBOX.ps1]

    ARCHIVE --> CSV[ZIP_HISTORY.csv]
    ARCHIVE --> MD[ZIP_HISTORY.md]

    FOCUS --> FLOW[FLOW-README.md]
    FOCUS --> AUTO_F[AUTO-INBOX_Flow.md]

    classDef root fill:#f6f7fb,stroke:#8a8a8a,stroke-width:1px;
```

---

## 📚 Повний зміст
Навігація по всіх файлах: [SUMMARY_FULL](SUMMARY_FULL.md)

---

📌 **MAP_OVERVIEW.md** — це точка входу для розуміння блоку:  
- де він зараз (ROADMAP),  
- як виглядає (VISUAL_MAP),  
- що містить (SUMMARY_FULL).  

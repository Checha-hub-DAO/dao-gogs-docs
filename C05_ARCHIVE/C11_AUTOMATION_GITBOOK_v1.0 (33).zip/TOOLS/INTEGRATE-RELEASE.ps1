Write-Host "=== ІНТЕГРАЦІЯ RELEASE ZIP ===" -ForegroundColor Cyan

$zipName = "C11_AUTOMATION_RELEASE_20250926.zip"
$inbox   = "D:\CHECHA_CORE\WORKSHOP\zip_inbox"
$core    = "D:\CHECHA_CORE\C11_AUTOMATION"
$tool    = "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1"

$zipFullPath = Join-Path $inbox $zipName

if (-not (Test-Path $zipFullPath)) {
    Write-Error "Не знайдено $zipFullPath. Переконайтеся, що архів скопійований у zip_inbox."
    exit 1
}

# Додаємо запис у історію (Release + hash)
pwsh -NoProfile -File $tool `
  -preset C11 `
  -n $zipName `
  -s Інтегровано `
  -m Release `
  -hash `
  -zf $zipFullPath

# Переносимо у ядро
$destPath = Join-Path $core $zipName
Move-Item -Path $zipFullPath -Destination $destPath -Force

Write-Host "[OK] Архів інтегровано у C11_AUTOMATION" -ForegroundColor Green
Write-Host "Перевірте ZIP_HISTORY.csv та ZIP_HISTORY.md" -ForegroundColor Yellow

---

🏷️ #Tools

# SUMMARY_FULL.md — C11_AUTOMATION

## 📂 Основні сторінки
- [README_MAIN](README_MAIN.md) — титульна сторінка (UA + EN)  
- [README_C11_AUTOMATION](README_C11_AUTOMATION.md) — детальна українська версія  
- [README_EN](README_EN.md) — детальна англомовна версія  
- [SUMMARY](SUMMARY.md) — зміст українською  
- [SUMMARY_EN](SUMMARY_EN.md) — зміст англійською  
- [README_RELEASE](README_RELEASE.md) — опис релізного пакета  
- [INSTALL](INSTALL.md) — інструкція з встановлення  
- [ROADMAP](ROADMAP.md) — план розвитку (v1.0 → v1.5 → v2.0)  
- [VISUAL_MAP](VISUAL_MAP.md) — повна мапа структури пакетів  
- [INDEX](INDEX.md) — оглавлення з короткими описами  
- [GITBOOK_IMPORT_GUIDE](GITBOOK_IMPORT_GUIDE.md) — гайд з імпорту у GitBook  
- [CHECKLIST_DEPLOY](CHECKLIST_DEPLOY.md) — чекліст перевірки після публікації  

---

## 🧰 TOOLS
- [Update-ZipHistory.ps1](TOOLS/Update-ZipHistory.ps1) — оновлення історії ZIP  
- [Add-ZipHistory.ps1](TOOLS/Add-ZipHistory.ps1) — швидке додавання записів  
- [START-DEMO.ps1](TOOLS/START-DEMO.ps1) — тестова інтеграція  
- [INTEGRATE-RELEASE.ps1](TOOLS/INTEGRATE-RELEASE.ps1) — інтеграція Release ZIP одним кліком  
- [AUTO-INBOX.ps1](TOOLS/AUTO-INBOX.ps1) — пакетна обробка inbox  

---

## 📜 ARCHIVE
- [ZIP_HISTORY.csv](ARCHIVE/ZIP_HISTORY.csv) — журнал інтеграцій (технічна база)  
- [ZIP_HISTORY.md](ARCHIVE/ZIP_HISTORY.md) — журнал інтеграцій (Markdown-версія для GitBook)  

---

## 🎯 FOCUS
- [TASK-CheckList.md](FOCUS/TASK-CheckList.md) — щоденний чекліст інтеграції  
- [FLOW-README.md](FOCUS/FLOW-README.md) — опис схеми інтеграції ZIP  
- [AUTO-INBOX_Flow.md](FOCUS/AUTO-INBOX_Flow.md) — візуалізація AUTO-INBOX процесу  

---

📌 Цей файл служить повною картою-навігатором для GitBook, де можна швидко перейти до будь-якого документу.  

# C11_AUTOMATION — Автоматизація ZIP (UA + EN)

---

## 🇺🇦 Українська версія

### 📌 Опис
Блок **C11_AUTOMATION** відповідає за технічну автоматизацію роботи з ZIP-пакетами у системі CHECHA_CORE.  
Він забезпечує контроль історії, інтеграцію Release-версій, тестування Beta, збереження Draft, візуалізацію процесів та AUTO-INBOX режим.  

Докладно дивись: [README_C11_AUTOMATION.md](README_C11_AUTOMATION.md)  

---

## 🇬🇧 English Version

### 📌 Overview
The **C11_AUTOMATION** block is responsible for technical automation of ZIP package workflows inside the **CHECHA_CORE** system.  
It provides tracking, Release integration, Beta testing, Draft storage, visualization, and AUTO-INBOX automation.  

See details: [README_EN.md](README_EN.md)  

---

📌 Така структура дозволяє:  
- мати короткий титульний README з подвійною мовною навігацією,  
- окремо підтримувати докладні UA та EN файли,  
- легко масштабувати для інших блоків.

---

## 📊 Visual Mini-Map

```mermaid
flowchart TD
    ROOT[ROOT]:::root --> TOOLS[TOOLS]
    ROOT --> ARCHIVE[ARCHIVE]
    ROOT --> FOCUS[FOCUS]

    TOOLS --> ADD[Add-ZipHistory.ps1]
    TOOLS --> UPDATE[Update-ZipHistory.ps1]
    TOOLS --> AUTO[AUTO-INBOX.ps1]

    ARCHIVE --> CSV[ZIP_HISTORY.csv]
    ARCHIVE --> MD[ZIP_HISTORY.md]

    FOCUS --> FLOW[FLOW-README.md]
    FOCUS --> AUTO_F[AUTO-INBOX_Flow.md]

    classDef root fill:#f6f7fb,stroke:#8a8a8a,stroke-width:1px;
```

---

🔗 Go to [Navigation HUB](Navigation_HUB.md)

---

🔗 See also: [HUB_Dashboard (Integrated Panel)](HUB_Dashboard.md)

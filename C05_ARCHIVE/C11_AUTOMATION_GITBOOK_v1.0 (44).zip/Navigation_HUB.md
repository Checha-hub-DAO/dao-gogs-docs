# Navigation_HUB — C11_AUTOMATION

Ласкаво просимо до центральної панелі навігації блоку **C11_AUTOMATION**.  
Тут зібрані три головні "входи" в документацію: карта, теги та короткий зміст.

---

## 🗺️ Карта (Overview)
- **MAP_OVERVIEW** → інтегрована карта (Roadmap + Visual Map + Summary Full)  
  → [Відкрити MAP_OVERVIEW](MAP_OVERVIEW.md)

---

## 🏷️ Теги (Categories)
- **TAGS_OVERVIEW** → повний список тегів і привʼязок до файлів  
  → [Відкрити TAGS_OVERVIEW](TAGS_OVERVIEW.md)
- **TAGS_Flow** → Mermaid-діаграма "Теги → Файли"  
  → [Відкрити TAGS_Flow](TAGS_Flow.md)

---

## 📚 Короткий зміст (Overview Summary)
- **SUMMARY_OVERVIEW** → три ключові точки входу  
  → [Відкрити SUMMARY_OVERVIEW](SUMMARY_OVERVIEW.md)

---

## 🔎 Швидкі лінки
- **Main README** → [README_MAIN.md](README_MAIN.md)  
- **UA README** → [README_C11_AUTOMATION.md](README_C11_AUTOMATION.md)  
- **EN README** → [README_EN.md](README_EN.md)  
- **Повний зміст** → [SUMMARY_FULL.md](SUMMARY_FULL.md)

---

📌 Використовуйте цей HUB як стартову панель, коли потрібно швидко зорієнтуватися та перейти в потрібний розділ.

---

🔗 See also: [HUB_Flow (Mermaid Diagram)](HUB_Flow.md)

---

🔗 See also: [HUB_Dashboard (Integrated Panel)](HUB_Dashboard.md)

---

🛠️ Docs: [TOOLS README (Zip History Guide)](TOOLS/README.md)

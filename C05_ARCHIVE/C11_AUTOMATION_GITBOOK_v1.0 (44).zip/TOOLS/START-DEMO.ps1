Write-Host "=== DEMO: Перевірка C11_AUTOMATION_ZIPTOOLS ===" -ForegroundColor Cyan

$demoZip = "TEST_DEMO_PACKAGE_20250926.zip"
$toolPath = "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1"

if (-not (Test-Path $toolPath)) {
    Write-Error "Не знайдено $toolPath. Перевірте, чи файли розміщені правильно."
    exit 1
}

# Виклик скрипта для додавання тестового ZIP
pwsh -NoProfile -File $toolPath `
    -preset C11 `
    -n $demoZip `
    -s Чернетка `
    -m Draft

Write-Host "`n[OK] Тестовий запис додано у ZIP_HISTORY.csv та ZIP_HISTORY.md" -ForegroundColor Green
Write-Host "Перевірте файли у: D:\CHECHA_CORE\C05_ARCHIVE\" -ForegroundColor Yellow

---

🏷️ #Tools

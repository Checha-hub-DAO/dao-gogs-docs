# C11_AUTOMATION — Автоматизація ZIP-процесів

## 📌 Опис
Блок **C11_AUTOMATION** відповідає за технічну автоматизацію роботи з ZIP-пакетами у системі CHECHA_CORE.  
Цей модуль забезпечує:  
- контроль історії пакетів (CSV + Markdown),  
- інтеграцію Release-версій у ядро,  
- тестування Beta-пакетів,  
- збереження Draft-пакетів,  
- візуалізацію та щоденні чеклісти,  
- автоматизовану обробку всіх архівів у `zip_inbox`.  

---

## 📂 Основні компоненти

### 1. Історія ZIP-пакетів
- `ZIP_HISTORY.csv` — журнал інтеграцій (технічна база).  
- `ZIP_HISTORY.md` — Markdown-версія для GitBook.  

### 2. Скрипти
- `Update-ZipHistory.ps1` — додавання записів у історію.  
- `Add-ZipHistory.ps1` — обгортка з короткими ключами та пресетами.  
- `START-DEMO.ps1` — швидкий тест роботи системи.  
- `INTEGRATE-RELEASE.ps1` — інтеграція Release ZIP одним кліком.  
- `AUTO-INBOX.ps1` — обробка всіх ZIP-ів у `zip_inbox` з автоматичною класифікацією.

### 3. Документи
- `TASK-CheckList.md` — щоденний чекліст інтеграції.  
- `FLOW-README.md` — опис схеми інтеграції ZIP (Draft → Beta → Release).  
- `AUTO-INBOX_Flow.md` — візуалізація автоматичної обробки.  
- `INSTALL.md` — інструкція з встановлення.  
- `README_RELEASE.md` — опис релізного пакета.

---

## ⚙️ Робочий процес

1. **Отримання ZIP** → `WORKSHOP/zip_inbox/`  
2. **Перевірка та класифікація** → Draft / Beta / Release  
3. **Інтеграція**:  
   - Draft → `WORKSHOP/drafts`  
   - Beta → `WORKSHOP/testing` (+ `TEST_REPORT.md`)  
   - Release → `C11_AUTOMATION/` (+ запис у `ZIP_HISTORY`)  
4. **Відображення результатів** у щотижневих звітах і GitBook.  

---

## 📊 Схеми

### Інтеграція ZIP
```mermaid
flowchart TD
    A[Отримання ZIP] --> B{Перевірка структури}
    B -->|OK| C[Класифікація зрілості]
    B -->|Невірно| X[Позначити як Draft]

    C -->|Draft| D[WORKSHOP\drafts]
    C -->|Beta| E[WORKSHOP\testing]
    C -->|Release| F[Інтеграція у C11_AUTOMATION]

    D --> H[Очікування доробки]
    E --> I[TEST_REPORT.md · доопрацювання]
    F --> G[ZIP_HISTORY.csv & ZIP_HISTORY.md]

    G --> J[Оновити FOCUS_OVERVIEW.md]
    G --> K[Додати у щотижневий звіт]

    X --> D
```

### AUTO-INBOX Flow
```mermaid
flowchart LR
    INBOX[[zip_inbox]] --> SCAN[Сканування *.zip]
    SCAN --> DECIDE{Класифікація}

    DECIDE -->|RELEASE| REL[Release → C11_AUTOMATION]
    DECIDE -->|BETA| BET[Beta → WORKSHOP/testing]
    DECIDE -->|Інше| DRF[Draft → WORKSHOP/drafts]
```

---

## 🚀 Використання

### Тестування
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\START-DEMO.ps1"
```

### Інтеграція Release
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\INTEGRATE-RELEASE.ps1"
```

### Пакетна обробка (AUTO-INBOX)
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\AUTO-INBOX.ps1"
```

---

✍ Автор: **С.Ч.**  
Версія документа: **v1.0 (26.09.2025)**

---

## 📊 Міні-мапа структури

```mermaid
flowchart TD
    ROOT[ROOT]:::root --> TOOLS[TOOLS]
    ROOT --> ARCHIVE[ARCHIVE]
    ROOT --> FOCUS[FOCUS]

    TOOLS --> ADD[Add-ZipHistory.ps1]
    TOOLS --> UPDATE[Update-ZipHistory.ps1]
    TOOLS --> AUTO[AUTO-INBOX.ps1]

    ARCHIVE --> CSV[ZIP_HISTORY.csv]
    ARCHIVE --> MD[ZIP_HISTORY.md]

    FOCUS --> FLOW[FLOW-README.md]
    FOCUS --> AUTO_F[AUTO-INBOX_Flow.md]

    classDef root fill:#f6f7fb,stroke:#8a8a8a,stroke-width:1px;
```

---

🔗 Go to [Navigation HUB](Navigation_HUB.md)

---

🔗 See also: [HUB_Dashboard (Integrated Panel)](HUB_Dashboard.md)

---

## 📦 Zip History: Quick Start

Швидкі приклади для роботи з історією ZIP-релізів:

**Release із SHA256 та пресетом C11**
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "HUB_RELEASE_v1.0.zip" `
  -s Опубліковано `
  -m Release `
  -zf "D:\CHECHA_CORE\C05_ARCHIVE\HUB_RELEASE_v1.0.zip" `
  -hash `
  -preset C11
```

**Beta без хешу (WORKSHOP-TEST)**
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "C11_AUTOMATION_BETA_20251001.zip" `
  -s Тестування `
  -m Beta `
  -preset WORKSHOP-TEST
```

**Draft у чернетки з власними шляхами**
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "C11_AUTOMATION_DRAFT_20251001.zip" `
  -s Чернетка `
  -m Draft `
  -csv "D:\CHECHA_CORE\WORKSHOP\drafts\ZIP_HISTORY.csv" `
  -md  "D:\CHECHA_CORE\WORKSHOP\drafts\ZIP_HISTORY.md"
```

---

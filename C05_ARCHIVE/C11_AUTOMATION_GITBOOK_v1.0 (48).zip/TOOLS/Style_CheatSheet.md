# Style_CheatSheet.md — Шпаргалка по стилю (C11_AUTOMATION)

Короткі приклади для UA/EN, щоб швидко перевіряти стиль перед написанням документації.

---

## 🇺🇦 Українська (UA)
- ✅ Використовувати: **Опубліковано**
- ❌ Не використовувати: Інтегровано
- Заголовки:
  - `## 📦 Швидкий старт Zip History`
  - `## 📦 Процес: Zip History Flow`
- Дати у форматі: `2025-09-26`

---

## 🇬🇧 English (EN)
- ✅ Use: **Published**
- ❌ Don’t use: Integrated
- Headers:
  - `## 📦 Zip History — Quick Start Guide`
  - `## 📦 Process: Zip History Flow`
- Dates in format: `2025-09-26`

---

## 📦 Іконки
- Використовувати **📦** для всіх тем, що стосуються Zip History.
- Інші іконки можна застосовувати лише для підрозділів (📈, 🧩, 📌).

---

📖 See also: [Language Style Guide](TOOLS/Language_Style_Guide.md)

# Table of Contents

- [C11_AUTOMATION](README_EN.md)
  - [ZIP History](ARCHIVE/ZIP_HISTORY.md)
  - [Integration Checklist](FOCUS/TASK-CheckList.md)
  - [ZIP Integration Flow](FOCUS/FLOW-README.md)
  - [AUTO-INBOX Flow](FOCUS/AUTO-INBOX_Flow.md)
  - [Installation Guide](INSTALL.md)
  - [Release README](README_RELEASE.md)

param(
    [Parameter(Mandatory=$true)][string]$Name,          # ім'я архіву, напр. C11_AUTOMATION_GITBOOK_v1.0.zip
    [string]$Date = (Get-Date -Format 'yyyy-MM-dd'),    # дата запису
    [string]$Status = "Інтегровано",                    # Статус: Інтегровано / Тестування / Чернетка
    [ValidateSet("Release","Beta","Draft")][string]$Mode = "Release",
    [string]$ZipFilePath,                               # шлях до фактичного ZIP (для хешу)
    [switch]$Hash,                                      # рахувати SHA256 (потрібен $ZipFilePath)
    [string]$CsvPath = "D:\CHECHA_CORE\C05_ARCHIVE\ZIP_HISTORY.csv",
    [string]$MdPath  = "D:\CHECHA_CORE\C05_ARCHIVE\ZIP_HISTORY.md",
    [string]$Preset                                  # C11 | WORKSHOP-TEST | WORKSHOP-DRAFT (за потреби може підмінити шляхи)
)

function Resolve-Presets {
    param([string]$preset, [ref]$csv, [ref]$md)
    switch ($preset) {
        "C11"           { $csv.Value = "D:\CHECHA_CORE\C05_ARCHIVE\ZIP_HISTORY.csv"
                          $md.Value  = "D:\CHECHA_CORE\C05_ARCHIVE\ZIP_HISTORY.md" }
        "WORKSHOP-TEST" { $csv.Value = "D:\CHECHA_CORE\WORKSHOP\testing\ZIP_HISTORY.csv"
                          $md.Value  = "D:\CHECHA_CORE\WORKSHOP\testing\ZIP_HISTORY.md" }
        "WORKSHOP-DRAFT"{ $csv.Value = "D:\CHECHA_CORE\WORKSHOP\drafts\ZIP_HISTORY.csv"
                          $md.Value  = "D:\CHECHA_CORE\WORKSHOP\drafts\ZIP_HISTORY.md" }
        default { }
    }
}

# Підміняємо шляхи за пресетом
if ($Preset) {
    Resolve-Presets -preset $Preset -csv ([ref]$CsvPath) -md ([ref]$MdPath)
}

# Обчислюємо SHA256 за потреби
$sha = ""
if ($Hash.IsPresent) {
    if (-not $ZipFilePath) { Write-Error "Для -Hash необхідно вказати -ZipFilePath"; exit 1 }
    if (-not (Test-Path $ZipFilePath)) { Write-Error "Файл не знайдено: $ZipFilePath"; exit 1 }
    try {
        $sha = (Get-FileHash -Path $ZipFilePath -Algorithm SHA256).Hash.ToLower()
    } catch {
        Write-Error "Не вдалося обчислити SHA256: $($_.Exception.Message)"; exit 1
    }
}

# Готуємо CSV-рядок
$csvDir = Split-Path $CsvPath -Parent
$mdDir  = Split-Path $MdPath -Parent
foreach ($d in @($csvDir,$mdDir)) {
    if ($d -and -not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}

$csvHeaders = "Release,Date,SHA256,Status,Mode,ZipFilePath"
if (-not (Test-Path $CsvPath)) {
    $csvHeaders | Out-File -FilePath $CsvPath -Encoding UTF8
}
$csvLine = ('"{0}","{1}","{2}","{3}","{4}","{5}"' -f $Name,$Date,$sha,$Status,$Mode,($ZipFilePath ?? ""))
Add-Content -LiteralPath $CsvPath -Value $csvLine

# Оновлюємо/створюємо Markdown
if (-not (Test-Path $MdPath)) {
    @(
        "# ZIP_HISTORY.md — C11_AUTOMATION",
        "",
        "## 📦 Релізи"
    ) | Set-Content -LiteralPath $MdPath -Encoding UTF8
}

$mdBlock = @()
$mdBlock += ""
$mdBlock += "### $Name"
$mdBlock += ("- **Дата:** {0}  " -f $Date)
$mdBlock += ("- **Статус:** {0}  " -f $Status)
$mdBlock += ("- **Режим:** {0}  " -f $Mode)
if ($ZipFilePath) { $mdBlock += ("- **Файл:** `{0}`  " -f $ZipFilePath) }
if ($sha)        { $mdBlock += ("- **SHA256:** `{0}`  " -f $sha) }
$mdBlock += "`---`"

Add-Content -LiteralPath $MdPath -Value ($mdBlock -join "`r`n")

Write-Host "[OK] Додано запис:" -ForegroundColor Green
Write-Host ("  CSV  → {0}" -f $CsvPath) -ForegroundColor Yellow
Write-Host ("  MD   → {0}" -f $MdPath) -ForegroundColor Yellow
if ($sha) { Write-Host ("  SHA256: {0}" -f $sha) -ForegroundColor Cyan }

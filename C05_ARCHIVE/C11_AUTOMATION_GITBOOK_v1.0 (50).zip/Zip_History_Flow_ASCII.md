# Zip_History_Flow_ASCII — Текстова схема процесу (C11_AUTOMATION)

```
ZIP (zip_inbox / archive)
           |
           v
     [Режим?]-------------------------------
      |           |             |          |
      v           v             v          v
   Release       Beta         Draft     (інші)
      \           |             /
       \          |            /
        v         v           v
        Add-ZipHistory.ps1  (обгортка)
                    |
                    v
             Update-ZipHistory.ps1
                    |
            +-------+-------+
            |               |
            v               v
        [SHA256?]         (ні)
          |            так    \__________
          |                          v                 v
     Обчислити SHA256     Записати журнали
               \           /
                v         v
             Запис у CSV і MD
            /                          v                 v
 ARCHIVE/ZIP_HISTORY.csv   ARCHIVE/ZIP_HISTORY.md
           |                 |
           v                 v
     Звіти/Аналітика       GitBook Docs
```

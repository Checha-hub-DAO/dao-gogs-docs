param(
    [Parameter(Mandatory=$true)][string]$Name,
    [string]$Date = (Get-Date -Format 'yyyy-MM-dd'),
    [string]$Status = "Інтегровано",
    [ValidateSet("Release","Beta","Draft")][string]$Mode = "Release",
    [string]$ZipFilePath,
    [switch]$Hash,
    [string]$CsvPath = "D:\CHECHA_CORE\C05_ARCHIVE\ZIP_HISTORY.csv",
    [string]$MdPath  = "D:\CHECHA_CORE\C05_ARCHIVE\ZIP_HISTORY.md",
    [string]$Preset,
    [string]$ChangelogPath                              # НЕОБОВ'ЯЗКОВО: шлях до CHANGELOG.md
)

function Resolve-Presets {
    param([string]$preset, [ref]$csv, [ref]$md, [ref]$chlog)
    switch ($preset) {
        "C11"           { $csv.Value = "D:\CHECHA_CORE\C05_ARCHIVE\ZIP_HISTORY.csv"
                          $md.Value  = "D:\CHECHA_CORE\C05_ARCHIVE\ZIP_HISTORY.md"
                          if (-not $chlog.Value) { $chlog.Value = "D:\CHECHA_CORE\C05_ARCHIVE\CHANGELOG.md" } }
        "WORKSHOP-TEST" { $csv.Value = "D:\CHECHA_CORE\WORKSHOP\testing\ZIP_HISTORY.csv"
                          $md.Value  = "D:\CHECHA_CORE\WORKSHOP\testing\ZIP_HISTORY.md"
                          if (-not $chlog.Value) { $chlog.Value = "D:\CHECHA_CORE\WORKSHOP\testing\CHANGELOG.md" } }
        "WORKSHOP-DRAFT"{ $csv.Value = "D:\CHECHA_CORE\WORKSHOP\drafts\ZIP_HISTORY.csv"
                          $md.Value  = "D:\CHECHA_CORE\WORKSHOP\drafts\ZIP_HISTORY.md"
                          if (-not $chlog.Value) { $chlog.Value = "D:\CHECHA_CORE\WORKSHOP\drafts\CHANGELOG.md" } }
        default { }
    }
}

if ($Preset) {
    Resolve-Presets -preset $Preset -csv ([ref]$CsvPath) -md ([ref]$MdPath) -chlog ([ref]$ChangelogPath)
}

$sha = ""
if ($Hash.IsPresent) {
    if (-not $ZipFilePath) { Write-Error "Для -Hash необхідно вказати -ZipFilePath"; exit 1 }
    if (-not (Test-Path $ZipFilePath)) { Write-Error "Файл не знайдено: $ZipFilePath"; exit 1 }
    try {
        $sha = (Get-FileHash -Path $ZipFilePath -Algorithm SHA256).Hash.ToLower()
    } catch {
        Write-Error "Не вдалося обчислити SHA256: $($_.Exception.Message)"; exit 1
    }
}

$csvDir = Split-Path $CsvPath -Parent
$mdDir  = Split-Path $MdPath -Parent
foreach ($d in @($csvDir,$mdDir)) {
    if ($d -and -not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}

$csvHeaders = "Release,Date,SHA256,Status,Mode,ZipFilePath"
if (-not (Test-Path $CsvPath)) {
    $csvHeaders | Out-File -FilePath $CsvPath -Encoding UTF8
}
$csvLine = ('"{0}","{1}","{2}","{3}","{4}","{5}"' -f $Name,$Date,$sha,$Status,$Mode,($ZipFilePath ?? ""))
Add-Content -LiteralPath $CsvPath -Value $csvLine

if (-not (Test-Path $MdPath)) {
    @(
        "# ZIP_HISTORY.md — C11_AUTOMATION",
        "",
        "## 📦 Релізи"
    ) | Set-Content -LiteralPath $MdPath -Encoding UTF8
}

$mdBlock = @()
$mdBlock += ""
$mdBlock += "### $Name"
$mdBlock += ("- **Дата:** {0}  " -f $Date)
$mdBlock += ("- **Статус:** {0}  " -f $Status)
$mdBlock += ("- **Режим:** {0}  " -f $Mode)
if ($ZipFilePath) { $mdBlock += ("- **Файл:** `{0}`  " -f $ZipFilePath) }
if ($sha)        { $mdBlock += ("- **SHA256:** `{0}`  " -f $sha) }
$mdBlock += "`---`"
Add-Content -LiteralPath $MdPath -Value ($mdBlock -join "`r`n")

# === CHANGELOG (необов'язково) ===
if ($ChangelogPath) {
    $chDir = Split-Path $ChangelogPath -Parent
    if ($chDir -and -not (Test-Path $chDir)) { New-Item -ItemType Directory -Path $chDir -Force | Out-Null }
    if (-not (Test-Path $ChangelogPath)) {
        "# CHANGELOG — C11_AUTOMATION`n" | Out-File -FilePath $ChangelogPath -Encoding UTF8
    }
    $chEntry = @()
    $chEntry += ""
    $chEntry += "## [$Date] — $Name"
    $chEntry += ("- Статус: {0}" -f $Status)
    $chEntry += ("- Режим: {0}" -f $Mode)
    if ($ZipFilePath) { $chEntry += ("- Файл: `{0}`" -f $ZipFilePath) }
    if ($sha)        { $chEntry += ("- SHA256: `{0}`" -f $sha) }
    $chEntry += ""
    Add-Content -LiteralPath $ChangelogPath -Value ($chEntry -join "`r`n")
}

Write-Host "[OK] Додано запис у CSV/MD" -ForegroundColor Green
if ($ChangelogPath) { Write-Host ("[OK] CHANGELOG → {0}" -f $ChangelogPath) -ForegroundColor Yellow }
if ($sha) { Write-Host ("SHA256: {0}" -f $sha) -ForegroundColor Cyan }

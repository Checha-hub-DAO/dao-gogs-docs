# TAGS_Flow.md — Теги та відповідні файли (C11_AUTOMATION)

```mermaid
flowchart LR

    %% Вузли-теги
    NAV[#Navigation]:::tag
    TECH[#TechDocs]:::tag
    USER[#UserGuide]:::tag
    HIST[#History]:::tag
    FOC[#Focus]:::tag
    TLS[#Tools]:::tag

    %% Navigation файли
    NAV --> MAP[MAP_OVERVIEW.md]
    NAV --> SOV[SUMMARY_OVERVIEW.md]
    NAV --> IDX[INDEX.md]

    %% TechDocs файли
    TECH --> RMAP[ROADMAP.md]
    TECH --> VMAP[VISUAL_MAP.md]
    TECH --> DEP[CHECKLIST_DEPLOY.md]

    %% UserGuide файли
    USER --> INST[INSTALL.md]
    USER --> GIMP[GITBOOK_IMPORT_GUIDE.md]

    %% History файли
    HIST --> HCSV[ARCHIVE/ZIP_HISTORY.csv]
    HIST --> HMD[ARCHIVE/ZIP_HISTORY.md]

    %% Focus файли
    FOC --> TCHK[FOCUS/TASK-CheckList.md]
    FOC --> FREAD[FOCUS/FLOW-README.md]
    FOC --> AIFL[FOCUS/AUTO-INBOX_Flow.md]

    %% Tools файли
    TLS --> UZ[TOOLS/Update-ZipHistory.ps1]
    TLS --> AZ[TOOLS/Add-ZipHistory.ps1]
    TLS --> SD[TOOLS/START-DEMO.ps1]
    TLS --> IR[TOOLS/INTEGRATE-RELEASE.ps1]
    TLS --> AI[TOOLS/AUTO-INBOX.ps1]

    classDef tag fill:#fff5d6,stroke:#ffb100,stroke-width:1px;
```

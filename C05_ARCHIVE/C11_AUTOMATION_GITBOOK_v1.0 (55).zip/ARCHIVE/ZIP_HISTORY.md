# ZIP_HISTORY.md — C11_AUTOMATION

## 📦 Релізи

### HUB_RELEASE_v1.0.zip
- **Дата:** 26.09.2025  
- **Вміст:** Navigation_HUB.md, HUB_Flow.md, HUB_Dashboard.md, HUB_Dashboard_ASCII.md  
- **Призначення:** Окремий пакет для роботи з навігаційною системою HUB  
- **SHA256:** `fea7c0183cbe015b9dc5f6fd9215aee6489052f756e8f95b708acb665cb66559`  

---

### C11_AUTOMATION_GITBOOK_v1.0.zip
- **Дата:** 26.09.2025  
- **Вміст:** Повний GitBook-набір (MAP, SUMMARY, README, TAGS, HUB, TOOLS, ARCHIVE)  
- **Призначення:** Основний пакет для GitBook-публікації та внутрішнього використання  
- **SHA256:** `b6355b888f355d427ff7e6fd5355d06d849a9602fdfa57f46d1f0462fb44984e`  

---

📌 Надалі кожен новий реліз (v1.1, v2.0 тощо) буде додаватися у цей журнал.

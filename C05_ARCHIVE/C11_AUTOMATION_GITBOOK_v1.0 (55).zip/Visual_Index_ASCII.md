# Visual_Index_ASCII.md — Текстовий індекс візуалів

```
/Visuals (TOOLS/visuals)
├─ Style_System_Map.png
├─ Style_System_Map.svg
├─ Icons_Terms_Board.png
└─ Icons_Terms_Board.svg

References
└─ TOOLS/README.md → розділи:
   • 🎨 Visuals (PNG)
   • 🖼️ Visuals (SVG scalable)
```

---

📌 Використовуйте цей текстовий індекс, коли рендер зображень недоступний.

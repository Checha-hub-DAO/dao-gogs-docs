# HUB_Flow.md — Навігаційна схема HUB (C11_AUTOMATION)

```mermaid
flowchart TB

    %% Вершини верхнього рівня
    MAP[MAP_OVERVIEW.md]:::top --> HUB[Navigation_HUB.md]:::hub
    TAGS[TAGS_OVERVIEW.md]:::top --> HUB
    SOV[SUMMARY_OVERVIEW.md]:::top --> HUB

    %% Виходи з HUB
    HUB --> MAIN[README_MAIN.md]:::readme
    HUB --> UA[README_C11_AUTOMATION.md]:::readme
    HUB --> EN[README_EN.md]:::readme
    HUB --> FULL[SUMMARY_FULL.md]:::index
    HUB --> FLOW[TAGS_Flow.md]:::index
    HUB --> MAP2[VISUAL_MAP.md]:::index
    HUB --> ROAD[ROADMAP.md]:::index

    classDef top fill:#eef8ff,stroke:#4aa3ff,stroke-width:1px;
    classDef hub fill:#fff5d6,stroke:#ffb100,stroke-width:1.2px;
    classDef readme fill:#eafaf1,stroke:#2ecc71,stroke-width:1px;
    classDef index fill:#f6f7fb,stroke:#8a8a8a,stroke-width:1px;
```

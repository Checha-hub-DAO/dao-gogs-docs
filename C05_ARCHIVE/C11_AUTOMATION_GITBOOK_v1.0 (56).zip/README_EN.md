# C11_AUTOMATION — ZIP Automation Module (EN Mirror)

## 📌 Overview
The **C11_AUTOMATION** block is responsible for technical automation of ZIP package workflows inside the **CHECHA_CORE** system.  
This module provides:  
- Tracking ZIP history (CSV + Markdown)  
- Release integration into the core  
- Beta testing workflow  
- Draft storage and iteration  
- Daily checklists and process visualization  
- Automatic batch processing of all archives from `zip_inbox`  

---

## 📂 Core Components

### 1. ZIP History
- `ZIP_HISTORY.csv` — technical log of integrations  
- `ZIP_HISTORY.md` — GitBook version of the log  

### 2. Scripts
- `Update-ZipHistory.ps1` — add new records to history  
- `Add-ZipHistory.ps1` — wrapper with presets and short keys  
- `START-DEMO.ps1` — quick test of the system  
- `INTEGRATE-RELEASE.ps1` — one-click Release integration  
- `AUTO-INBOX.ps1` — automatic classification and processing of all ZIPs in `zip_inbox`  

### 3. Docs
- `TASK-CheckList.md` — daily checklist  
- `FLOW-README.md` — integration scheme (Draft → Beta → Release)  
- `AUTO-INBOX_Flow.md` — auto-processing flow visualization  
- `INSTALL.md` — installation guide  
- `README_RELEASE.md` — release package description  

---

## ⚙️ Workflow

1. **Receive ZIP** → `WORKSHOP/zip_inbox/`  
2. **Check and classify** → Draft / Beta / Release  
3. **Integration path**:  
   - Draft → `WORKSHOP/drafts`  
   - Beta → `WORKSHOP/testing` (+ `TEST_REPORT.md`)  
   - Release → `C11_AUTOMATION/` (+ record in `ZIP_HISTORY`)  
4. **Results reflected** in weekly reports and GitBook pages  

---

## 📊 Diagrams

### ZIP Integration
```mermaid
flowchart TD
    A[Receive ZIP] --> B{Check structure}
    B -->|OK| C[Classify maturity]
    B -->|Invalid| X[Mark as Draft]

    C -->|Draft| D[WORKSHOP\\drafts]
    C -->|Beta| E[WORKSHOP\\testing]
    C -->|Release| F[Integrate into C11_AUTOMATION]

    D --> H[Waiting for completion]
    E --> I[TEST_REPORT.md · improvements]
    F --> G[ZIP_HISTORY.csv & ZIP_HISTORY.md]

    G --> J[Update FOCUS_OVERVIEW.md]
    G --> K[Add to weekly report]

    X --> D
```

### AUTO-INBOX Flow
```mermaid
flowchart LR
    INBOX[[zip_inbox]] --> SCAN[Scan *.zip]
    SCAN --> DECIDE{Classify}

    DECIDE -->|RELEASE| REL[Release → C11_AUTOMATION]
    DECIDE -->|BETA| BET[Beta → WORKSHOP/testing]
    DECIDE -->|Else| DRF[Draft → WORKSHOP/drafts]
```

---

## 🚀 Usage

### Quick Test
```powershell
pwsh -NoProfile -File "D:\\CHECHA_CORE\\TOOLS\\START-DEMO.ps1"
```

### One-click Release Integration
```powershell
pwsh -NoProfile -File "D:\\CHECHA_CORE\\TOOLS\\INTEGRATE-RELEASE.ps1"
```

### Batch Processing (AUTO-INBOX)
```powershell
pwsh -NoProfile -File "D:\\CHECHA_CORE\\TOOLS\\AUTO-INBOX.ps1"
```

---

✍ Author: **S.Ch.**  
Doc version: **v1.0 (26.09.2025)**

---

## 📊 Visual Mini-Map

```mermaid
flowchart TD
    ROOT[ROOT]:::root --> TOOLS[TOOLS]
    ROOT --> ARCHIVE[ARCHIVE]
    ROOT --> FOCUS[FOCUS]

    TOOLS --> ADD[Add-ZipHistory.ps1]
    TOOLS --> UPDATE[Update-ZipHistory.ps1]
    TOOLS --> AUTO[AUTO-INBOX.ps1]

    ARCHIVE --> CSV[ZIP_HISTORY.csv]
    ARCHIVE --> MD[ZIP_HISTORY.md]

    FOCUS --> FLOW[FLOW-README.md]
    FOCUS --> AUTO_F[AUTO-INBOX_Flow.md]

    classDef root fill:#f6f7fb,stroke:#8a8a8a,stroke-width:1px;
```

---

🔗 Go to [Navigation HUB](Navigation_HUB.md)

---

🔗 See also: [HUB_Dashboard (Published Panel)](HUB_Dashboard.md)

---

## 📦 Zip History: Quick Start

Quick examples for managing ZIP release history:

**Release with SHA256 and C11 preset**
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "HUB_RELEASE_v1.0.zip" `
  -s Published `
  -m Release `
  -zf "D:\CHECHA_CORE\C05_ARCHIVE\HUB_RELEASE_v1.0.zip" `
  -hash `
  -preset C11
```

**Beta without hash (WORKSHOP-TEST)**
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "C11_AUTOMATION_BETA_20251001.zip" `
  -s Testing `
  -m Beta `
  -preset WORKSHOP-TEST
```

**Draft into drafts folder with custom paths**
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "C11_AUTOMATION_DRAFT_20251001.zip" `
  -s Draft `
  -m Draft `
  -csv "D:\CHECHA_CORE\WORKSHOP\drafts\ZIP_HISTORY.csv" `
  -md  "D:\CHECHA_CORE\WORKSHOP\drafts\ZIP_HISTORY.md"
```

---

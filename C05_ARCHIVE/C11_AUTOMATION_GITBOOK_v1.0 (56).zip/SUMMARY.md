# Зміст

- [C11_AUTOMATION](README_C11_AUTOMATION.md)
  - [Історія ZIP-пакетів](ARCHIVE/ZIP_HISTORY.md)
  - [Чекліст інтеграції](FOCUS/TASK-CheckList.md)
  - [Схема інтеграції ZIP](FOCUS/FLOW-README.md)
  - [AUTO-INBOX схема](FOCUS/AUTO-INBOX_Flow.md)
  - [Інструкція встановлення](INSTALL.md)
  - [README Release](README_RELEASE.md)

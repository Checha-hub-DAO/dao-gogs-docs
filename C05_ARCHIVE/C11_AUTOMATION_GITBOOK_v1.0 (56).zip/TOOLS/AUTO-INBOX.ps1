Write-Host "=== AUTO-INBOX: Обробка черги ZIP ===" -ForegroundColor Cyan

$inbox   = "D:\CHECHA_CORE\WORKSHOP\zip_inbox"
$core    = "D:\CHECHA_CORE\C11_AUTOMATION"
$drafts  = "D:\CHECHA_CORE\WORKSHOP\drafts"
$testing = "D:\CHECHA_CORE\WORKSHOP\testing"
$tools   = "D:\CHECHA_CORE\TOOLS"
$adder   = Join-Path $tools "Add-ZipHistory.ps1"

# Переконаймось, що каталоги існують
foreach ($d in @($inbox,$core,$drafts,$testing,$tools)) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}
if (-not (Test-Path $adder)) {
    Write-Error "Не знайдено $adder. Розмістіть Add-ZipHistory.ps1 у D:\CHECHA_CORE\TOOLS\"
    exit 1
}

# Хелпер: класифікація файлу за назвою
function Get-MaturityFromName([string]$name) {
    if ($name -match '(?i)RELEASE') { return 'Release' }
    if ($name -match '(?i)BETA')    { return 'Beta' }
    return 'Draft'
}

# Обробка кожного ZIP
$zips = Get-ChildItem -LiteralPath $inbox -Filter *.zip -File -ErrorAction SilentlyContinue
if (-not $zips) {
    Write-Host "[Порожньо] Немає ZIP-файлів у $inbox" -ForegroundColor Yellow
    exit 0
}

foreach ($z in $zips) {
    try {
        $name = $z.Name
        $full = $z.FullName
        $maturity = Get-MaturityFromName $name

        switch ($maturity) {
            'Release' {
                Write-Host ("[Release] {0}" -f $name) -ForegroundColor Green
                # 1) Додаємо запис у історію як Інтегровано+Release із хешем
                pwsh -NoProfile -File $adder `
                    -preset C11 `
                    -n $name `
                    -s Інтегровано `
                    -m Release `
                    -hash `
                    -zf $full
                # 2) Переносимо у ядро
                Move-Item -LiteralPath $full -Destination (Join-Path $core $name) -Force
            }
            'Beta' {
                Write-Host ("[Beta] {0}" -f $name) -ForegroundColor Cyan
                # 1) Додаємо запис як Тестування+Beta
                pwsh -NoProfile -File $adder `
                    -preset WORKSHOP-TEST `
                    -n $name `
                    -s Тестування `
                    -m Beta `
                    -zf $full
                # 2) Переносимо у testing та створюємо/оновлюємо TEST_REPORT.md
                $dest = Join-Path $testing $name
                Move-Item -LiteralPath $full -Destination $dest -Force
                $report = Join-Path $testing "TEST_REPORT.md"
                $line = ("- {0} · {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm'), $name)
                if (Test-Path $report) {
                    Add-Content -LiteralPath $report -Value $line
                } else {
                    @(
                        "# TEST_REPORT.md",
                        "",
                        "Список бета-пакетів, що потребують перевірки:",
                        $line
                    ) | Set-Content -LiteralPath $report -Encoding UTF8
                }
            }
            'Draft' {
                Write-Host ("[Draft] {0}" -f $name) -ForegroundColor DarkYellow
                # 1) Додаємо запис як Чернетка+Draft
                pwsh -NoProfile -File $adder `
                    -preset WORKSHOP-DRAFT `
                    -n $name `
                    -s Чернетка `
                    -m Draft `
                    -zf $full
                # 2) Переносимо у drafts
                Move-Item -LiteralPath $full -Destination (Join-Path $drafts $name) -Force
            }
        }
    } catch {
        Write-Warning ("Помилка обробки {0}: {1}" -f $z.Name, $_.Exception.Message)
    }
}

Write-Host "`n[OK] Обробку черги завершено." -ForegroundColor Green
Write-Host "Перевірте: C05_ARCHIVE\\ZIP_HISTORY.csv · ZIP_HISTORY.md" -ForegroundColor Yellow

---

🏷️ #Tools

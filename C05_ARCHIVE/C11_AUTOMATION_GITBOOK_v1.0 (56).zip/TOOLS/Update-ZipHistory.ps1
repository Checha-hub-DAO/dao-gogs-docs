param(
    [Parameter(Mandatory=$true)][string]$ZipName,
    [Parameter(Mandatory=$true)][string]$Status,            # Напр.: "Інтегровано", "Чернетка", "Тестування"
    [Parameter(Mandatory=$true)][string]$Maturity,          # Напр.: "Draft" | "Beta" | "Release"
    [Parameter(Mandatory=$true)][string]$PathValue,         # Напр.: "D:\CHECHA_CORE\C11_AUTOMATION\"
    [string]$CsvPath = "D:\CHECHA_CORE\C05_ARCHIVE\ZIP_HISTORY.csv",
    [string]$MdPath  = "D:\CHECHA_CORE\C05_ARCHIVE\ZIP_HISTORY.md",
    [switch]$ComputeHash,
    [string]$ZipFullPath,        # Якщо вказано, хеш рахується саме для цього файлу
    [ValidateSet("utf8","utf8BOM","utf16")][string]$Encoding = "utf8BOM"
)

function Resolve-Encoding {
    param([string]$Enc)
    switch ($Enc) {
        "utf8"   { return [System.Text.UTF8Encoding]::new($false) } # без BOM
        "utf8BOM"{ return [System.Text.UTF8Encoding]::new($true)  } # з BOM
        "utf16"  { return [System.Text.UnicodeEncoding]::new($false, $true) }
        default  { return [System.Text.UTF8Encoding]::new($true) }
    }
}

$validStatuses = @("Інтегровано","Чернетка","Тестування","Відхилено","Архівовано")
$validMaturity = @("Draft","Beta","Release")

if (-not ($validStatuses -contains $Status)) {
    Write-Error "Некоректний Статус. Дозволено: $($validStatuses -join ', ')"
    exit 1
}
if (-not ($validMaturity -contains $Maturity)) {
    Write-Error "Некоректний Рівень зрілості. Дозволено: $($validMaturity -join ', ')"
    exit 1
}

$today = (Get-Date).ToString('yyyy-MM-dd')
$encObj = Resolve-Encoding -Enc $Encoding

# --- Ensure dirs
$csvDir = Split-Path -Path $CsvPath -Parent
$mdDir  = Split-Path -Path $MdPath  -Parent
if (-not (Test-Path $csvDir)) { New-Item -ItemType Directory -Path $csvDir -Force | Out-Null }
if (-not (Test-Path $mdDir))  { New-Item -ItemType Directory -Path $mdDir  -Force | Out-Null }

# --- CSV: create header if not exists
if (-not (Test-Path $CsvPath)) {
    $header = "Дата,Назва ZIP,Статус,Рівень зрілості,Шлях"
    [System.IO.File]::WriteAllText($CsvPath, $header + [Environment]::NewLine, $encObj)
}

# --- Optional SHA256
$shaLine = $null
if ($ComputeHash.IsPresent) {
    if (-not $ZipFullPath) {
        $ZipFullPath = Join-Path -Path $PathValue -ChildPath $ZipName
    }
    if (-not (Test-Path $ZipFullPath)) {
        Write-Warning "Файл для обчислення хешу не знайдено: $ZipFullPath"
    } else {
        try {
            $hash = Get-FileHash -Path $ZipFullPath -Algorithm SHA256
            $shaLine = "$($hash.Hash)  $ZipName"
            $shaPath = [System.IO.Path]::ChangeExtension($ZipFullPath, ".sha256")
            # Записуємо .sha256 у UTF8 без BOM (звично для checksum-файлів)
            [System.IO.File]::WriteAllText($shaPath, $shaLine, [System.Text.UTF8Encoding]::new($false))
        } catch {
            Write-Warning "Не вдалося обчислити SHA256: $($_.Exception.Message)"
        }
    }
}

# --- Append CSV line
$csvLine = "$today,$ZipName,$Status,$Maturity,$PathValue"
Add-Content -LiteralPath $CsvPath -Value $csvLine -Encoding Byte -Force
# Примітка: -Encoding Byte дозволяє не ламати обрану кодування BOM; header вже записано з обраною кодуванням.

# --- Markdown: create header if not exists
if (-not (Test-Path $MdPath)) {
    $md = @(
        "# Історія ZIP-пакетів (C11_AUTOMATION)",
        "",
        "| Дата       | Назва ZIP | Статус | Рівень зрілості | Шлях |",
        "|------------|-----------|--------|-----------------|------|"
    ) -join [Environment]::NewLine
    [System.IO.File]::WriteAllText($MdPath, $md + [Environment]::NewLine, $encObj)
}

# --- Append Markdown row
$mdRow = "| {0} | {1} | {2} | {3} | {4} |" -f $today, $ZipName, $Status, $Maturity, ($PathValue -replace '\|','\|')
Add-Content -LiteralPath $MdPath -Value $mdRow -Encoding Byte -Force

# --- Console summary
Write-Host ("[OK] Додано запис: {0} | {1} | {2} | {3}" -f $today,$ZipName,$Status,$Maturity) -ForegroundColor Green
if ($shaLine) {
    Write-Host ("SHA256: {0}" -f $shaLine) -ForegroundColor DarkCyan
}

---

🏷️ #Tools

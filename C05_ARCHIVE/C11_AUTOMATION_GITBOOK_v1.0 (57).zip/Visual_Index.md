# Visual_Index.md — Каталог візуалів (C11_AUTOMATION)

Зведений перелік усіх візуальних матеріалів (PNG + SVG).

---

## 📦 Style System Map
- [PNG](visuals/Style_System_Map.png)
- [SVG](visuals/Style_System_Map.svg)

## 🏷 Icons & Terms Board
- [PNG](visuals/Icons_Terms_Board.png)
- [SVG](visuals/Icons_Terms_Board.svg)

---

📖 See also: [TOOLS README](TOOLS/README.md)

---

🧩 Fallback: [Visual Index (Text Only)](Visual_Index_ASCII.md)

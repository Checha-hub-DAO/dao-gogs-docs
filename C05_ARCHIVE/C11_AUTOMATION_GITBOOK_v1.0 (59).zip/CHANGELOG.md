# CHANGELOG — C11_AUTOMATION

---
## [2025-09-26] — C11_AUTOMATION Updates

- Створено `ZIP_HISTORY.md` і `ZIP_HISTORY.csv` (MD + CSV журнали).
- Додано скрипти `Update-ZipHistory.ps1` та `Add-ZipHistory.ps1`.
- Додано блок **📦 Zip History: Quick Start** у всі README (MAIN, EN, UA).
- Створено `TOOLS/README.md` з технічною довідкою.
- Посилання на TOOLS README додано у HUB, Dashboard, MAIN, SUMMARY.
- Створено Mermaid-схему `Zip_History_Flow.md` + інтеграція в HUB, MAIN, TOOLS.
- Сформовано реліз-нотс `RELEASE_NOTES_20250926.md`.

🔗 Див. також: [RELEASE_NOTES_20250926.md](RELEASE_NOTES_20250926.md)

# TAGS_OVERVIEW.md — C11_AUTOMATION

## 🏷️ #Navigation
- MAP_OVERVIEW.md  
- SUMMARY_OVERVIEW.md  
- INDEX.md  

---

## 🏷️ #TechDocs
- ROADMAP.md  
- VISUAL_MAP.md  
- CHECKLIST_DEPLOY.md  

---

## 🏷️ #UserGuide
- INSTALL.md  
- GITBOOK_IMPORT_GUIDE.md  

---

## 🏷️ #History
- ARCHIVE/ZIP_HISTORY.csv  
- ARCHIVE/ZIP_HISTORY.md  

---

## 🏷️ #Focus
- FOCUS/TASK-CheckList.md  
- FOCUS/FLOW-README.md  
- FOCUS/AUTO-INBOX_Flow.md  

---

## 🏷️ #Tools
- TOOLS/Update-ZipHistory.ps1  
- TOOLS/Add-ZipHistory.ps1  
- TOOLS/START-DEMO.ps1  
- TOOLS/INTEGRATE-RELEASE.ps1  
- TOOLS/AUTO-INBOX.ps1  

---

📌 Цей файл — головна довідка по тегах. Він допомагає бачити структуру пакета не тільки по змісту, але й по категоріях.

---

🔗 See also: [TAGS Flow (Mermaid Diagram)](TAGS_Flow.md)

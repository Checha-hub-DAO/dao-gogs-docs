param(
    [Alias("n")][Parameter(Mandatory=$true)][string]$Name,
    [Alias("d")][string]$Date = (Get-Date -Format 'yyyy-MM-dd'),
    [Alias("s")][string]$Status = "Інтегровано",
    [Alias("m")][ValidateSet("Release","Beta","Draft")][string]$Mode = "Release",
    [Alias("zf")][string]$ZipFilePath,
    [switch]$Hash,
    [Alias("csv")][string]$CsvPath,
    [Alias("md")][string]$MdPath,
    [Alias("preset")][string]$Preset,
    [Alias("cl")][string]$ChangelogPath   # новий короткий ключ: -cl
)

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$update = Join-Path $scriptDir "Update-ZipHistory.ps1"
if (-not (Test-Path $update)) {
    $update = "D:\CHECHA_CORE\TOOLS\Update-ZipHistory.ps1"
}
if (-not (Test-Path $update)) {
    Write-Error "Не знайдено Update-ZipHistory.ps1. Переконайтеся, що він у тій самій теці TOOLS."
    exit 1
}

$cmd = @(
    "-File", $update,
    "-Name", $Name,
    "-Date", $Date,
    "-Status", $Status,
    "-Mode", $Mode
)

if ($ZipFilePath) { $cmd += @("-ZipFilePath", $ZipFilePath) }
if ($Hash)        { $cmd += "-Hash" }
if ($CsvPath)     { $cmd += @("-CsvPath", $CsvPath) }
if ($MdPath)      { $cmd += @("-MdPath", $MdPath) }
if ($Preset)      { $cmd += @("-Preset", $Preset) }
if ($ChangelogPath) { $cmd += @("-ChangelogPath", $ChangelogPath) }

& pwsh -NoProfile @cmd
$exitCode = $LASTEXITCODE

if ($exitCode -ne 0) {
    Write-Error "Помилка виконання Update-ZipHistory.ps1 (код $exitCode)"
    exit $exitCode
} else {
    Write-Host "[OK] Add-ZipHistory завершено (CSV/MD" -NoNewline
    if ($ChangelogPath) { Write-Host " + CHANGELOG)" } else { Write-Host ")" }
}

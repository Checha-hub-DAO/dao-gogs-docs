param(
    [Alias("n")][Parameter(Mandatory=$true)][string]$Name,          # -n  : ім'я архіву
    [Alias("d")][string]$Date = (Get-Date -Format 'yyyy-MM-dd'),    # -d  : дата
    [Alias("s")][string]$Status = "Інтегровано",                    # -s  : статус
    [Alias("m")][ValidateSet("Release","Beta","Draft")][string]$Mode = "Release",  # -m : режим
    [Alias("zf")][string]$ZipFilePath,                               # -zf : шлях до ZIP
    [switch]$Hash,                                                   # -hash : рахувати SHA256
    [Alias("csv")][string]$CsvPath,                                  # -csv : свій CSV
    [Alias("md")][string]$MdPath,                                    # -md  : свій MD
    [Alias("preset")][string]$Preset                                  # -preset : C11 | WORKSHOP-TEST | WORKSHOP-DRAFT
)

# Знаходимо Update-ZipHistory.ps1 поруч у TOOLS (або в PATH)
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$update = Join-Path $scriptDir "Update-ZipHistory.ps1"
if (-not (Test-Path $update)) {
    # fallback: спробуємо знайти у стандартній теці
    $update = "D:\CHECHA_CORE\TOOLS\Update-ZipHistory.ps1"
}
if (-not (Test-Path $update)) {
    Write-Error "Не знайдено Update-ZipHistory.ps1. Переконайтеся, що він у тій самій теці TOOLS."
    exit 1
}

# Проксі-виклик з відповідним мапінгом ключів
$cmd = @(
    "-File", $update,
    "-Name", $Name,
    "-Date", $Date,
    "-Status", $Status,
    "-Mode", $Mode
)

if ($ZipFilePath) { $cmd += @("-ZipFilePath", $ZipFilePath) }
if ($Hash)        { $cmd += "-Hash" }
if ($CsvPath)     { $cmd += @("-CsvPath", $CsvPath) }
if ($MdPath)      { $cmd += @("-MdPath", $MdPath) }
if ($Preset)      { $cmd += @("-Preset", $Preset) }

# Виконуємо через pwsh (збережемо чисте оточення)
& pwsh -NoProfile @cmd
$exitCode = $LASTEXITCODE

if ($exitCode -ne 0) {
    Write-Error "Помилка виконання Update-ZipHistory.ps1 (код $exitCode)"
    exit $exitCode
} else {
    Write-Host "[OK] Add-ZipHistory завершено" -ForegroundColor Green
}

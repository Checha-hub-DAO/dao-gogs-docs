# Zip_History_Flow — Процес фіксації історії ZIP (C11_AUTOMATION)

Нижче показано спрощений ланцюжок оновлення журналів історії ZIP-релізів.

```mermaid
flowchart LR
    INBOX[ZIP файл у zip_inbox / archive] --> DECIDE{Режим?}
    DECIDE -->|Release| ADD[Add-ZipHistory.ps1]
    DECIDE -->|Beta| ADD
    DECIDE -->|Draft| ADD

    ADD --> UPD[Update-ZipHistory.ps1]
    UPD --> HASH{SHA256?}
    HASH -->|Так (-Hash)| SHA[Обчислити SHA256]
    HASH -->|Ні| WRITE
    SHA --> WRITE[Записати журнали]

    WRITE --> CSV[(ARCHIVE/ZIP_HISTORY.csv)]
    WRITE --> MD[(ARCHIVE/ZIP_HISTORY.md)]

    CSV --> REPORT[Звіти / Аналітика]
    MD --> GITBOOK[GitBook Docs]

    classDef node fill:#eef8ff,stroke:#4aa3ff,stroke-width:1px;
    classDef store fill:#f6f7fb,stroke:#8a8a8a,stroke-width:1px;
    class ADD fill:#fff5d6,stroke:#ffb100,stroke-width:1px;
    class INBOX,DECIDE,SHA,WRITE,REPORT,GITBOOK,UPD,HASH node;
    class CSV,MD store;
```

---

🔗 Див. також: [TOOLS README (Zip History Guide)](TOOLS/README.md) · [ZIP_HISTORY.md](ARCHIVE/ZIP_HISTORY.md) · [ZIP_HISTORY.csv](ARCHIVE/ZIP_HISTORY.csv)

---

🧩 Fallback: [Zip_History_Flow_ASCII (Text Diagram)](Zip_History_Flow_ASCII.md)

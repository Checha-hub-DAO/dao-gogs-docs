# HUB_Dashboard — Integrated Navigation Panel (C11_AUTOMATION)

Ця панель об'єднує дві ключові діаграми для швидкої навігації:
- **TAGS_Flow** — взаємозв'язки тегів і документів
- **HUB_Flow** — маршрути від оглядових сторінок до ключових розділів

---

## 🏷️ TAGS_Flow (Tags → Files)

```mermaid
flowchart LR

    %% Вузли-теги
    NAV[#Navigation]:::tag
    TECH[#TechDocs]:::tag
    USER[#UserGuide]:::tag
    HIST[#History]:::tag
    FOC[#Focus]:::tag
    TLS[#Tools]:::tag

    %% Navigation файли
    NAV --> MAP[MAP_OVERVIEW.md]
    NAV --> SOV[SUMMARY_OVERVIEW.md]
    NAV --> IDX[INDEX.md]

    %% TechDocs файли
    TECH --> RMAP[ROADMAP.md]
    TECH --> VMAP[VISUAL_MAP.md]
    TECH --> DEP[CHECKLIST_DEPLOY.md]

    %% UserGuide файли
    USER --> INST[INSTALL.md]
    USER --> GIMP[GITBOOK_IMPORT_GUIDE.md]

    %% History файли
    HIST --> HCSV[ARCHIVE/ZIP_HISTORY.csv]
    HIST --> HMD[ARCHIVE/ZIP_HISTORY.md]

    %% Focus файли
    FOC --> TCHK[FOCUS/TASK-CheckList.md]
    FOC --> FREAD[FOCUS/FLOW-README.md]
    FOC --> AIFL[FOCUS/AUTO-INBOX_Flow.md]

    %% Tools файли
    TLS --> UZ[TOOLS/Update-ZipHistory.ps1]
    TLS --> AZ[TOOLS/Add-ZipHistory.ps1]
    TLS --> SD[TOOLS/START-DEMO.ps1]
    TLS --> IR[TOOLS/INTEGRATE-RELEASE.ps1]
    TLS --> AI[TOOLS/AUTO-INBOX.ps1]

    classDef tag fill:#fff5d6,stroke:#ffb100,stroke-width:1px;
```

---

## 🧭 HUB_Flow (Overview/Tags/Summary → HUB → README/Docs)

```mermaid
flowchart TB

    %% Вершини верхнього рівня
    MAP[MAP_OVERVIEW.md]:::top --> HUB[Navigation_HUB.md]:::hub
    TAGS[TAGS_OVERVIEW.md]:::top --> HUB
    SOV[SUMMARY_OVERVIEW.md]:::top --> HUB

    %% Виходи з HUB
    HUB --> MAIN[README_MAIN.md]:::readme
    HUB --> UA[README_C11_AUTOMATION.md]:::readme
    HUB --> EN[README_EN.md]:::readme
    HUB --> FULL[SUMMARY_FULL.md]:::index
    HUB --> FLOW[TAGS_Flow.md]:::index
    HUB --> MAP2[VISUAL_MAP.md]:::index
    HUB --> ROAD[ROADMAP.md]:::index

    classDef top fill:#eef8ff,stroke:#4aa3ff,stroke-width:1px;
    classDef hub fill:#fff5d6,stroke:#ffb100,stroke-width:1.2px;
    classDef readme fill:#eafaf1,stroke:#2ecc71,stroke-width:1px;
    classDef index fill:#f6f7fb,stroke:#8a8a8a,stroke-width:1px;
```

---

🔗 Корисні посилання: [MAP_OVERVIEW](MAP_OVERVIEW.md) · [Navigation HUB](Navigation_HUB.md) · [TAGS_OVERVIEW](TAGS_OVERVIEW.md)

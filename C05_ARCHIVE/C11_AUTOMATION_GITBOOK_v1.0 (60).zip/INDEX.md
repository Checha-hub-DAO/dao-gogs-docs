# INDEX.md — C11_AUTOMATION

## 📂 ROOT
- **README_MAIN.md** — титульна сторінка (UA + EN)  
- **README_C11_AUTOMATION.md** — детальна українська версія  
- **README_EN.md** — детальна англомовна версія  
- **SUMMARY.md** — зміст українською  
- **SUMMARY_EN.md** — зміст англійською  
- **README_RELEASE.md** — опис релізного пакета  
- **INSTALL.md** — інструкція з встановлення  
- **ROADMAP.md** — план розвитку (v1.0 → v1.5 → v2.0)  
- **VISUAL_MAP.md** — повна мапа структури пакетів  
- **GITBOOK_IMPORT_GUIDE.md** — гайд з імпорту у GitBook  
- **CHECKLIST_DEPLOY.md** — чекліст перевірки після публікації  

---

## 🧰 TOOLS
- **Update-ZipHistory.ps1** — оновлення історії ZIP  
- **Add-ZipHistory.ps1** — швидке додавання записів  
- **START-DEMO.ps1** — тестова інтеграція  
- **INTEGRATE-RELEASE.ps1** — інтеграція Release ZIP одним кліком  
- **AUTO-INBOX.ps1** — пакетна обробка inbox  

---

## 📜 ARCHIVE
- **ZIP_HISTORY.csv** — журнал інтеграцій (технічна база)  
- **ZIP_HISTORY.md** — журнал інтеграцій (Markdown-версія для GitBook)  

---

## 🎯 FOCUS
- **TASK-CheckList.md** — щоденний чекліст інтеграції  
- **FLOW-README.md** — опис схеми інтеграції ZIP  
- **AUTO-INBOX_Flow.md** — візуалізація AUTO-INBOX процесу  

---

📌 Цей файл служить швидким довідником, щоб одразу бачити склад і роль усіх документів у пакеті.  

# MASTER_Style_Map.md — Єдина карта стилю та візуалів (C11_AUTOMATION)

```mermaid
flowchart TB
    %% Ядро
    CORE[📚 STYLE SYSTEM
(C11_AUTOMATION)]:::core

    %% Документи
    GUIDE[Language Style Guide
TOOLS/Language_Style_Guide.md]:::doc
    CHEAT[Style CheatSheet
TOOLS/Style_CheatSheet.md]:::doc

    %% Карти стилю
    ASCII_MAP[Style_Map_ASCII.md]:::map
    MERM_MAP[Style_Map_Mermaid.md]:::map

    %% Візуали
    VIDX[Visual Index
Visual_Index.md]:::index
    VIDX_ASCII[Visual Index ASCII
Visual_Index_ASCII.md]:::index
    V1PNG[Style_System_Map.png
TOOLS/visuals]:::png
    V1SVG[Style_System_Map.svg
TOOLS/visuals]:::svg
    V2PNG[Icons_Terms_Board.png
TOOLS/visuals]:::png
    V2SVG[Icons_Terms_Board.svg
TOOLS/visuals]:::svg

    %% Інтеграція
    TOOLS_README[TOOLS/README.md]:::doc
    SUMMARY[SUMMARY.md]:::index
    HUB[Navigation_HUB.md]:::doc

    %% Зв'язки
    CORE --> GUIDE
    CORE --> CHEAT

    GUIDE --> ASCII_MAP
    GUIDE --> MERM_MAP
    CHEAT --> ASCII_MAP
    CHEAT --> MERM_MAP

    ASCII_MAP --> TOOLS_README
    MERM_MAP --> TOOLS_README

    CORE --> VIDX
    VIDX --> VIDX_ASCII
    VIDX --> V1PNG
    VIDX --> V1SVG
    VIDX --> V2PNG
    VIDX --> V2SVG

    TOOLS_README --> VIDX
    HUB --> VIDX
    SUMMARY --> VIDX

    classDef core fill:#1a1a1a,stroke:#fff,stroke-width:2px,color:#fff;
    classDef doc fill:#0f5132,stroke:#fff,stroke-width:1px,color:#fff;
    classDef map fill:#084298,stroke:#fff,stroke-width:1px,color:#fff;
    classDef png fill:#2d6a4f,stroke:#fff,color:#fff;
    classDef svg fill:#6a1b9a,stroke:#fff,color:#fff;
    classDef index fill:#333,stroke:#fff,color:#fff;
```

---

🔗 Корисні точки доступу: [TOOLS README](TOOLS/README.md) · [Visual Index](Visual_Index.md) · [Language Style Guide](TOOLS/Language_Style_Guide.md) · [Style CheatSheet](TOOLS/Style_CheatSheet.md)

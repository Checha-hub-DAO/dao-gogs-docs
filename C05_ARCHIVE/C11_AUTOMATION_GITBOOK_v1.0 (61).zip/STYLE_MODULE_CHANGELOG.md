# 📑 CHANGELOG — STYLE_MODULE

## v1.1 (план)
**Дата релізу:** ⏳ (буде визначено)

### ✨ Додано
- Новий блок у Language Style Guide: **тон комунікації** (офіційний / публічний / внутрішній).
- Розширено приклади EN у Language Style Guide (UA/EN паралельні приклади).
- Нові таблиці у Style CheatSheet (правильне/неправильне + приклади з GitBook та PDF).
- Розширення MASTER Style Map: додано MEDIA STYLE, інтеграція з C02_GLOSSARY.
- Інтерактивна версія Visual Index (Mermaid, клікабельні посилання).
- Альтернативні кольорові теми для Main Media Visual (світла/темна).
- Нові іконки у Icons Board (+10 для публікацій, аналітики, DAO, GitBook).
- Набір обкладинок Style Covers Pack для PDF/GitBook.

### ♻️ Змінено
- ASCII fallback оновлено (включає нові іконки та правила).
- PDF-збірка: інтегровані візуали напряму у текст.
- Navigation HUB: додано окремий розділ “Styling Rules”.
- Зв’язок із C02_GLOSSARY (терміни уніфіковані).

### 🗑️ Вилучено
- Дублюючі приклади з попередніх версій CheatSheet.
- Тимчасові схеми (Draft Style Maps) — перенесено в архів.

---

## v1.0 (26.09.2025)
**Дата релізу:** 26.09.2025

### ✨ Додано
- Language Style Guide (UA/EN правила, шрифти, терміни).
- Style CheatSheet (шпаргалка з прикладами).
- Карти: Style_Map_ASCII, Style_Map_Mermaid, MASTER Style Map.
- Visual Index + ASCII fallback.
- Візуали: Style System Map, Icons & Terms Board, Main Media Visual (C11 Automation).
- Збірки: STYLE_RELEASE_v1.0.zip, STYLE_RELEASE_v1.2.pdf, обкладинка.

### ♻️ Змінено
- —

### 🗑️ Вилучено
- —

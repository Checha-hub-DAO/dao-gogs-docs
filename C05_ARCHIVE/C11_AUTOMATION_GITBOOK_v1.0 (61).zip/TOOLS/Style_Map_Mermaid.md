# Style_Map_Mermaid.md — Mermaid-схема стилю

```mermaid
flowchart TD
    A[📚 STYLE SYSTEM] --> B[Language Style Guide]
    A[📚 STYLE SYSTEM] --> C[Style CheatSheet]

    B --> D[README Files (UA/EN)]
    C --> D[README Files (UA/EN)]

    D --> D1[README_MAIN.md]
    D --> D2[README_C11_AUTOMATION.md]
    D --> D3[README_EN.md]
    D --> D4[TOOLS/README.md]

    style A fill:#1a1a1a,stroke:#fff,stroke-width:2px,color:#fff
    style B fill:#0f5132,stroke:#fff,stroke-width:1px,color:#fff
    style C fill:#084298,stroke:#fff,stroke-width:1px,color:#fff
    style D fill:#5a189a,stroke:#fff,stroke-width:1px,color:#fff
```

---

📌 **Пояснення:**  
- **Language Style Guide** → стратегія (повні правила).  
- **Style CheatSheet** → тактика (швидкі приклади).  
- Обидва формують єдиний стиль README (UA/EN).

# Zip_History_CheatSheet.md — Шпаргалка по роботі з історією ZIP

Швидкі команди для найчастіших сценаріїв.

---

## 🚀 Release (з SHA256 і CHANGELOG)
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "HUB_RELEASE_v1.0.zip" `
  -s Інтегровано `
  -m Release `
  -zf "D:\CHECHA_CORE\C05_ARCHIVE\HUB_RELEASE_v1.0.zip" `
  -hash `
  -preset C11 `
  -cl "D:\CHECHA_CORE\C05_ARCHIVE\CHANGELOG.md"
```

## 🧪 Beta (без SHA256, тільки WORKSHOP)
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "C11_AUTOMATION_BETA_20251001.zip" `
  -s Тестування `
  -m Beta `
  -preset WORKSHOP-TEST
```

## ✍️ Draft (чернетка у власну теку)
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "C11_AUTOMATION_DRAFT_20251001.zip" `
  -s Чернетка `
  -m Draft `
  -csv "D:\CHECHA_CORE\WORKSHOP\drafts\ZIP_HISTORY.csv" `
  -md  "D:\CHECHA_CORE\WORKSHOP\drafts\ZIP_HISTORY.md" `
  -cl  "D:\CHECHA_CORE\WORKSHOP\drafts\CHANGELOG.md"
```

---

📜 Додатково:  
- [TOOLS README (повна довідка)](TOOLS/README.md)  
- [Zip_History_Flow.md](Zip_History_Flow.md) · [ASCII fallback](Zip_History_Flow_ASCII.md)  
- [CHANGELOG.md](CHANGELOG.md)

# FLOW-README — Інтеграція ZIP у C11_AUTOMATION

Цей документ описує логіку проходження пакета через етапи **Draft → Beta → Release** з точками контролю та артефактами.

---

## 1) Вхід і первинна перевірка
- **Отримання ZIP** → `WORKSHOP/zip_inbox/`
- **Перевірка структури**: має бути базовий каркас (`README.md`, `tools/`, `docs/` за наявності)
- Якщо структура неповна → маркуємо як **Draft** (не інтегруємо в ядро)

## 2) Класифікація зрілості
- **Draft** — чорновий пакет: працюємо у `WORKSHOP/drafts/`
- **Beta** — базова працездатність, є помилки: `WORKSHOP/testing/` + `TEST_REPORT.md`
- **Release** — готово до інтеграції: переносимо у `C11_AUTOMATION`

## 3) Інтеграція та фіксація
- Для **Release** обовʼязково:
  - Додати запис у `ZIP_HISTORY.csv` та `ZIP_HISTORY.md`
  - За потреби — `SHA256` (`-hash`)
  - Оновити `FOCUS_OVERVIEW.md` та щотижневий звіт

---

## Mermaid-схема
```mermaid
flowchart TD

    A[Отримання ZIP] --> B{Перевірка структури}
    B -->|OK| C[Класифікація зрілості]
    B -->|Невірно| X[Позначити як Draft · WORKSHOP\drafts]

    C -->|Draft| D[WORKSHOP\drafts]
    C -->|Beta| E[WORKSHOP\testing]
    C -->|Release| F[Інтеграція у C11_AUTOMATION]

    D --> H[Очікування доробки]
    E --> I[TEST_REPORT.md · доопрацювання]
    F --> G[ZIP_HISTORY.csv & ZIP_HISTORY.md]

    G --> J[Оновити FOCUS_OVERVIEW.md]
    G --> K[Додати у щотижневий звіт]

    X --> D
```

---

## 4) Командний мінімум
- Запис у історію: `Add-ZipHistory.ps1 -preset C11 -n <NAME>.zip -s Інтегровано -m Release -hash`
- Чернетка: `Add-ZipHistory.ps1 -preset WORKSHOP-DRAFT -n <NAME>.zip -s Чернетка -m Draft`

## 5) Типові помилки та як уникнути
- **Ламається кодування CSV/MD** → використовуйте вбудовані скрипти, не редагуйте вручну у нестандартних редакторах.
- **Помилки PowerShell here-string (`@"`/`"@`)** → у наданих скриптах вони не використовуються.
- **Неправильні шляхи** → застосовуйте пресети `C11`, `WORKSHOP-DRAFT`, `WORKSHOP-TEST`.

---

✍ Автор: С.Ч. · Версія: v1.0

---

## 6) AUTO-INBOX режим

Для пакетної обробки всіх ZIP-файлів у `WORKSHOP\zip_inbox` використовуйте:

```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\AUTO-INBOX.ps1"
```

### Логіка AUTO-INBOX:
- **Release** → інтегрується у `C11_AUTOMATION`, додається запис (*Інтегровано + Release + SHA256*).
- **Beta** → переноситься у `WORKSHOP\testing`, додається запис (*Тестування + Beta*), створюється/оновлюється `TEST_REPORT.md`.
- **Draft** → переноситься у `WORKSHOP\drafts`, додається запис (*Чернетка + Draft*).

✅ Це дозволяє одним викликом обробляти всю чергу, не запускаючи команди для кожного ZIP окремо.

---

🏷️ #Focus

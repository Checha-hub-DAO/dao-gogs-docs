# TOOLS/README.md — Technical Guide (C11_AUTOMATION)

Ця довідка пояснює використання інструментів для роботи з історією ZIP-релізів.

---

## 🛠️ Update-ZipHistory.ps1
- Оновлює **CSV** і **MD** журнали одночасно.
- Може рахувати SHA256 для вказаного ZIP-файлу.
- Підтримує **пресети шляхів**: `C11`, `WORKSHOP-TEST`, `WORKSHOP-DRAFT`.
- Створює файли/теки, якщо їх ще нема.

### Приклад:
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Update-ZipHistory.ps1" `
  -Name "C11_AUTOMATION_GITBOOK_v1.0.zip" `
  -Status Опубліковано `
  -Mode Release `
  -ZipFilePath "D:\CHECHA_CORE\C05_ARCHIVE\C11_AUTOMATION_GITBOOK_v1.0.zip" `
  -Hash `
  -Preset C11
```

---

## 🛠️ Add-ZipHistory.ps1
- Обгортка над Update-ZipHistory.ps1 з короткими ключами.
- Автоматично знаходить Update-ZipHistory.ps1 у теці `TOOLS` або стандартному шляху.

### Швидкі приклади:

**Release із SHA256 та пресетом C11**
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "HUB_RELEASE_v1.0.zip" `
  -s Опубліковано `
  -m Release `
  -zf "D:\CHECHA_CORE\C05_ARCHIVE\HUB_RELEASE_v1.0.zip" `
  -hash `
  -preset C11
```

**Beta без хешу (WORKSHOP-TEST)**
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "C11_AUTOMATION_BETA_20251001.zip" `
  -s Тестування `
  -m Beta `
  -preset WORKSHOP-TEST
```

**Draft у чернетки з власними шляхами**
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "C11_AUTOMATION_DRAFT_20251001.zip" `
  -s Чернетка `
  -m Draft `
  -csv "D:\CHECHA_CORE\WORKSHOP\drafts\ZIP_HISTORY.csv" `
  -md  "D:\CHECHA_CORE\WORKSHOP\drafts\ZIP_HISTORY.md"
```

---

📌 Рекомендація: для основних релізів використовуй `Add-ZipHistory.ps1` з ключами `-preset C11 -hash`.

---

📈 Process: [Zip History Flow](../Zip_History_Flow.md)

---

## 📜 CHANGELOG integration

Оновлені скрипти дозволяють автоматично вести CHANGELOG.md.

### Приклад з інтеграцією у CHANGELOG
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "HUB_RELEASE_v1.0.zip" `
  -s Опубліковано `
  -m Release `
  -zf "D:\CHECHA_CORE\C05_ARCHIVE\HUB_RELEASE_v1.0.zip" `
  -hash `
  -preset C11 `
  -cl "D:\CHECHA_CORE\C05_ARCHIVE\CHANGELOG.md"
```

### Приклад без CHANGELOG
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "C11_AUTOMATION_BETA_20251001.zip" `
  -s Тестування `
  -m Beta `
  -preset WORKSHOP-TEST
```

---

🧩 Fallback: [Zip_History_Flow_ASCII (Text Diagram)](../Zip_History_Flow_ASCII.md)

---

📌 Quick Access: [Zip History Cheat Sheet](../Zip_History_CheatSheet.md)


---

📝 *Для PDF-експорту використовуй шрифт **DejaVu Sans**, щоб уникнути проблем з кирилицею.*

---

📖 See also: [Language Style Guide](Language_Style_Guide.md)

📌 Quick Ref: [Style CheatSheet](Style_CheatSheet.md)
# C11_AUTOMATION — Main Readme

**Package Version: v1.0 (26.09.2025)**

# C11_AUTOMATION — Автоматизація ZIP (UA + EN)

---

## 🇺🇦 Українська версія

### 📌 Опис
Блок **C11_AUTOMATION** відповідає за технічну автоматизацію роботи з ZIP-пакетами у системі CHECHA_CORE.  
Він забезпечує контроль історії, інтеграцію Release-версій, тестування Beta, збереження Draft, візуалізацію процесів та AUTO-INBOX режим.  

Докладно дивись: [README_C11_AUTOMATION.md](README_C11_AUTOMATION.md)  

---

## 🇬🇧 English Version

### 📌 Overview
The **C11_AUTOMATION** block is responsible for technical automation of ZIP package workflows inside the **CHECHA_CORE** system.  
It provides tracking, Release integration, Beta testing, Draft storage, visualization, and AUTO-INBOX automation.  

See details: [README_EN.md](README_EN.md)  

---

📌 Така структура дозволяє:  
- мати короткий титульний README з подвійною мовною навігацією,  
- окремо підтримувати докладні UA та EN файли,  
- легко масштабувати для інших блоків.

---

## 📊 Visual Mini-Map

```mermaid
flowchart TD
    ROOT[ROOT]:::root --> TOOLS[TOOLS]
    ROOT --> ARCHIVE[ARCHIVE]
    ROOT --> FOCUS[FOCUS]

    TOOLS --> ADD[Add-ZipHistory.ps1]
    TOOLS --> UPDATE[Update-ZipHistory.ps1]
    TOOLS --> AUTO[AUTO-INBOX.ps1]

    ARCHIVE --> CSV[ZIP_HISTORY.csv]
    ARCHIVE --> MD[ZIP_HISTORY.md]

    FOCUS --> FLOW[FLOW-README.md]
    FOCUS --> AUTO_F[AUTO-INBOX_Flow.md]

    classDef root fill:#f6f7fb,stroke:#8a8a8a,stroke-width:1px;
```

---

🔗 Go to [Navigation HUB](Navigation_HUB.md)

---

🔗 See also: [HUB_Dashboard (Integrated Panel)](HUB_Dashboard.md)

---

## 📦 Zip History: Quick Start

Швидкі приклади для роботи з історією ZIP-релізів:

**Release із SHA256 та пресетом C11**
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "HUB_RELEASE_v1.0.zip" `
  -s Інтегровано `
  -m Release `
  -zf "D:\CHECHA_CORE\C05_ARCHIVE\HUB_RELEASE_v1.0.zip" `
  -hash `
  -preset C11
```

**Beta без хешу (WORKSHOP-TEST)**
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "C11_AUTOMATION_BETA_20251001.zip" `
  -s Тестування `
  -m Beta `
  -preset WORKSHOP-TEST
```

**Draft у чернетки з власними шляхами**
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Add-ZipHistory.ps1" `
  -n "C11_AUTOMATION_DRAFT_20251001.zip" `
  -s Чернетка `
  -m Draft `
  -csv "D:\CHECHA_CORE\WORKSHOP\drafts\ZIP_HISTORY.csv" `
  -md  "D:\CHECHA_CORE\WORKSHOP\drafts\ZIP_HISTORY.md"
```

---

---

🛠️ Docs: [TOOLS README (Zip History Guide)](TOOLS/README.md)

---

📈 Process: [Zip History Flow](Zip_History_Flow.md)

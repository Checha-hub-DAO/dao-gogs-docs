# 🗺️ STYLE_MODULE_MAP

Mermaid-діаграма структури **C11_AUTOMATION GitBook** та STYLE_MODULE v1.0.

```mermaid
flowchart TD

    A[📖 C11_AUTOMATION_GITBOOK] --> B1[INDEX.md]
    A --> B2[SUMMARY.md]

    A --> C1[README_MAIN.md]
    A --> C2[Navigation_HUB.md]

    A --> D[🎨 STYLE_MODULE]

    D --> D1[STYLE_MODULE_README.md]
    D --> D2[STYLE_MODULE_GITBOOK.md]
    D --> D3[STYLE_MODULE_CHANGELOG.md]

    D --> E[TOOLS]
    E --> E1[Language_Style_Guide.md]
    E --> E2[Style_CheatSheet.md]

    D --> F[MAPS]
    F --> F1[Style_Map_ASCII.md]
    F --> F2[Style_Map_Mermaid.md]
    F --> F3[MASTER_Style_Map.md]

    D --> G[VISUALS]
    G --> G1[Style_System_Map.png/svg]
    G --> G2[Icons_Terms_Board.png/svg]
    G --> G3[Visual_Index.md]
    G --> G4[Visual_Index_ASCII.md]

    D --> H[RELEASES]
    H --> H1[STYLE_RELEASE_v1.0.zip]
    H --> H2[STYLE_RELEASE_v1.2.pdf]
    H --> H3[STYLE_RELEASE_Cover.png]

    D --> I[MEDIA]
    I --> I1[C11_Automation_MainVisual.png]

    A --> J[ARCHIVE]
    J --> J1[STYLE_MODULE_v0.x]
```

---

🧩 Fallback: [STYLE_MODULE_MAP_ASCII](STYLE_MODULE_MAP_ASCII.md)

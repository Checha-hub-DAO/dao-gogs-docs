# ZIP Integration Flow (C11_AUTOMATION)

```mermaid
flowchart TD

    A[Отримання ZIP] --> B{Перевірка структури}
    B -->|OK| C[Класифікація зрілості]
    B -->|Невірно| X[Позначити як Draft · WORKSHOP\drafts]

    C -->|Draft| D[WORKSHOP\drafts]
    C -->|Beta| E[WORKSHOP\testing]
    C -->|Release| F[Інтеграція у C11_AUTOMATION]

    D --> H[Очікування доробки]
    E --> I[TEST_REPORT.md · доопрацювання]
    F --> G[ZIP_HISTORY.csv & ZIP_HISTORY.md]

    G --> J[Оновити FOCUS_OVERVIEW.md]
    G --> K[Додати у щотижневий звіт]

    X --> D
```

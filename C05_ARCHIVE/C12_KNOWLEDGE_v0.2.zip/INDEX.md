# C12 Knowledge Cards — v0.2

**Дата контрольної точки:** 20.09.2025  
**Опис:** Завершені 5 карт знань (draft, 70–80%).  
**Ціль:** ≥ 80% прогресу, інтеграція в систему C12.

---

## 📑 Список карт

1. [KNOWLEDGE_CARD_Frankl.md](KNOWLEDGE_CARD_Frankl.md) — Віктор Франкл | *Людина в пошуках справжнього сенсу*  
   - Статус: ✅ Основні тези + цитати  
   - Пов’язано: G21, G37

2. [KNOWLEDGE_CARD_Rosling.md](KNOWLEDGE_CARD_Rosling.md) — Ганс Рослінг | *Factfulness*  
   - Статус: ✅ Тези готові  
   - Пов’язано: G35, G43

3. [KNOWLEDGE_CARD_Berne.md](KNOWLEDGE_CARD_Berne.md) — Ерік Берн | *Ігри, в які грають люди*  
   - Статус: ⚡ Чернетка + тези  
   - Пов’язано: G15, G11, G25, G28

4. [KNOWLEDGE_CARD_Bostrom.md](KNOWLEDGE_CARD_Bostrom.md) — Нік Бостром | *Superintelligence*  
   - Статус: ⚡ Каркас, потребує доопрацювання  
   - Пов’язано: G43, G45

5. [KNOWLEDGE_CARD_Krishnamurti.md](KNOWLEDGE_CARD_Krishnamurti.md) — Джідду Крішнамурті | *Свобода від відомого*  
   - Статус: ⚡ Основні тези, потребує доповнення  
   - Пов’язано: G21, DAO-META

---

## 🔗 Наступні кроки
- [ ] Інтегрувати всі карти в головний INDEX C12.  
- [ ] Використати у відповідних DAO-модулях.  
- [ ] Створити архів `C12_KNOWLEDGE_v0.2.zip` у C05/ARCHIVE.  

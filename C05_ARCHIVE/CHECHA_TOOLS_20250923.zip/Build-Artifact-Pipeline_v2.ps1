param(
  [Parameter(Mandatory=$true)] [string]$Name,
  [Parameter(Mandatory=$true)] [string]$Date,
  [string]$WorkRoot = "D:\CHECHA_CORE\WORKSHOP\MAPS",
  [string[]]$Inputs = @(),
  [string]$GitBookRelPath = "",
  [string]$LogPath = "D:\CHECHA_CORE\C03_LOG\LOG.md",
  [string]$Author = "Сергій Чеча (С.Ч.)",
  [switch]$AutoArtifacts,
  [switch]$NoLog
)
# Normalize
$Name = ($Name ?? "").Trim().Trim('"')
$Date = ($Date ?? "").Trim().Trim('"')
$WorkRoot = ($WorkRoot ?? "").Trim().Trim('"')
if ($Inputs.Count -eq 1 -and $Inputs[0] -match ',') { $Inputs = $Inputs[0].Split(',') | ForEach-Object { $_.Trim().Trim('"') } }
else { $Inputs = @($Inputs | ForEach-Object { ($_+"").Trim().Trim('"') }) }
if ([System.IO.File]::Exists($WorkRoot)) { $WorkRoot = Split-Path -Parent $WorkRoot }
if (-not (Test-Path $WorkRoot)) { try { $WorkRoot = Split-Path -Parent $WorkRoot } catch {} }
try { $WorkRoot = [System.IO.Path]::GetFullPath($WorkRoot) } catch {}

function Ensure-Dir($p){ if ([string]::IsNullOrWhiteSpace($p)) { throw "Ensure-Dir: пустий шлях" }; if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p | Out-Null } }
function Write-Utf8Bom($path,$text){ $enc = [System.Text.UTF8Encoding]::new($true); [System.IO.File]::WriteAllText($path,$text,$enc) }
function Sha256($f){ (Get-FileHash -Algorithm SHA256 -Path $f).Hash.ToLower() }

if ([string]::IsNullOrWhiteSpace($Name)) { throw "Не задано -Name" }
if ([string]::IsNullOrWhiteSpace($Date)) { throw "Не задано -Date (YYYY-MM-DD)" }
if ([string]::IsNullOrWhiteSpace($WorkRoot)) { throw "Не задано -WorkRoot" }

$Missing = @(); $AbsInputs = @()
foreach($i in $Inputs){ try { $abs = [System.IO.Path]::GetFullPath($i) } catch { $abs = $i }; if(-not (Test-Path $abs -PathType Leaf)){ $Missing += $abs } else { $AbsInputs += $abs } }
Write-Host "[CHECK] WorkRoot : $WorkRoot"
Write-Host "[CHECK] Inputs   :"
foreach($i in $AbsInputs){ Write-Host "  - OK  $i" -ForegroundColor Green }
foreach($m in $Missing){   Write-Host "  - MISS $m" -ForegroundColor Yellow }
if($Missing.Count -gt 0){ throw "Зупинка: відсутні файли в -Inputs" }

$SafeName = ($Name -replace '[^\p{L}\p{Nd}\-_]+','_').Trim('_').ToUpper()
$DateTag  = $Date.Replace('-','')
$WorkDir = Join-Path $WorkRoot ("{0}_{1}" -f $SafeName, $DateTag); Ensure-Dir $WorkDir
$ZipName = ("{0}_ARTIFACTS_{1}_FULL.zip" -f $SafeName, $DateTag)
$OutZip  = Join-Path $WorkRoot $ZipName

Write-Host "[INFO] WorkDir : $WorkDir"
Write-Host "[INFO] OutZip  : $OutZip"

$Copied = @()
foreach($src in $AbsInputs){ $dst = Join-Path $WorkDir (Split-Path $src -Leaf); Copy-Item $src -Destination $dst -Force; $Copied += $dst }
Write-Host "[INFO] Скопійовано $($Copied.Count) файл(и/ів) у $WorkDir"

$ArtifactsPath = Join-Path $WorkDir "ARTIFACTS.md"
if (-not (Test-Path $ArtifactsPath) -and $AutoArtifacts) {
$pngName = ($Copied | Where-Object { $_.ToLower().EndsWith('.png') } | ForEach-Object { Split-Path $_ -Leaf } | Select-Object -First 1)
$pdfName = ($Copied | Where-Object { $_.ToLower().EndsWith('.pdf') } | ForEach-Object { Split-Path $_ -Leaf } | Select-Object -First 1)
$art = @"
# 🎨 Артефакти: $Name

Дата: $Date  
Автор: $Author

## 📊 Опис
Короткий опис артефакту: мета, контекст, як читати.

## 📂 Файли
$(if($pngName){"- ![PNG версія]($pngName)"})
$(if($pdfName){"- [📑 PDF версія]($pdfName)"})

## 🔑 Призначення
- Для GitBook (наочний огляд), презентацій і фіксації стану системи.

С.Ч.
"@
Write-Utf8Bom $ArtifactsPath $art
Write-Host "[INFO] Створено ARTIFACTS.md (auto)"
}

$ReadmePath = Join-Path $WorkDir "README.md"
$readme = @"
# 📘 README: Інтеграція артефактів у GitBook
Дата: $Date  
Автор: $Author

## 📦 Склад пакету
$(($Copied | ForEach-Object { "- " + (Split-Path $_ -Leaf) }) -join "`r`n")

## 🚀 Інтеграція
1) Завантажити у GitBook: $GitBookRelPath
2) Вставити PNG у сторінку та дати посилання на PDF (за наявності).
3) Додати ARTIFACTS.md у навігацію.

С.Ч.
"@
Write-Utf8Bom $ReadmePath $readme

if(Test-Path $OutZip){ Remove-Item $OutZip -Force }
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($WorkDir, $OutZip)

$sha = @("SHA-256")
foreach($f in (Get-ChildItem -Path $WorkDir -File)){ $sha += ("{0}  {1}" -f (Sha256 $f.FullName), $f.Name) }
$sha += ("{0}  {1}" -f (Sha256 $OutZip), (Split-Path $OutZip -Leaf))
Write-Utf8Bom (Join-Path $WorkDir "CHECKSUMS.sha256.txt") ($sha -join "`r`n")

Write-Host "[OK] Пакет зібрано: $OutZip" -ForegroundColor Green

if (-not $NoLog) {
  $LogScript = "D:\CHECHA_CORE\TOOLS\Write-ArtifactLog.ps1"
  if (Test-Path $LogScript) {
    pwsh -NoProfile -ExecutionPolicy Bypass -File $LogScript `
      -LogPath $LogPath `
      -PackagePath $OutZip `
      -Files $Copied `
      -Title ("Артефакт — {0}" -f $Name) `
      -GitBookRelPath $GitBookRelPath `
      -Author $Author
  } else {
    Write-Host "[WARN] Не знайдено $LogScript — пропускаю логування." -ForegroundColor Yellow
  }
}

$tools = @(
  "D:\CHECHA_CORE\TOOLS\Build-Artifact-Pipeline_v2.ps1",
  "D:\CHECHA_CORE\TOOLS\Write-ArtifactLog.ps1"
)
foreach($t in $tools){
  if(Test-Path $t){ Write-Host "[OK] $t" -ForegroundColor Green } else { Write-Host "[MISS] $t" -ForegroundColor Yellow }
}
# CHECHA Tools Bundle (2025-09-23)

## Files
- Build-Artifact-Pipeline_v2.ps1
- Write-ArtifactLog.ps1
- Check-Tools.ps1

## Quick start
1) Copy *.ps1 to `D:\CHECHA_CORE\TOOLS\`
2) Verify:
```powershell
pwsh -NoProfile -ExecutionPolicy Bypass -File "D:\CHECHA_CORE\TOOLS\Check-Tools.ps1"
```
3) Run pipeline:
```powershell
$n = 'Багаторівнева діаграма структури'
& "D:\CHECHA_CORE\TOOLS\Build-Artifact-Pipeline_v2.ps1" @{
  Name='Багаторівнева діаграма структури';
  Date='2025-09-22';
  WorkRoot='D:\CHECHA_CORE\WORKSHOP\MAPS';
  Inputs=@('D:\CHECHA_CORE\WORKSHOP\MAPS\structure_map_20250922.png','D:\CHECHA_CORE\WORKSHOP\MAPS\structure_map_20250922.pdf','D:\CHECHA_CORE\WORKSHOP\MAPS\ARTIFACTS.md');
  GitBookRelPath='dao-architecture/artifacts/2025-09-22/';
  LogPath='D:\CHECHA_CORE\C03_LOG\LOG.md';
}
```

param(
  [Parameter(Mandatory=$true)] [string]$LogPath,
  [Parameter(Mandatory=$true)] [string]$PackagePath,
  [Parameter(Mandatory=$true)] [string[]]$Files,
  [Parameter(Mandatory=$true)] [string]$Title,
  [string]$GitBookRelPath = "",
  [string]$Author = "Сергій Чеча (С.Ч.)"
)
function Sha256($p) { (Get-FileHash -Algorithm SHA256 -Path $p).Hash.ToLower() }
$enc = [System.Text.UTF8Encoding]::new($true)

if (-not (Test-Path -LiteralPath $PackagePath -PathType Leaf)) { throw "Не знайдено ZIP пакет: $PackagePath" }

$missing = @(); foreach ($f in $Files) { if (-not (Test-Path -LiteralPath $f -PathType Leaf)) { $missing += $f } }
foreach ($m in $missing) { Write-Host "[WARN] Відсутній файл: $m" -ForegroundColor Yellow }

$dt      = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
$pkgName = Split-Path -Leaf $PackagePath
$pkgHash = Sha256 $PackagePath

$rows = @()
$rows += "| Файл | SHA-256 | Стан |"
$rows += "|------|---------|------|"
foreach ($f in $Files) {
  $fname = Split-Path -Leaf $f
  if (Test-Path -LiteralPath $f -PathType Leaf) { $rows += "| $fname | `$(Sha256 $f)` | OK |" }
  else { $rows += "| $fname | (missing) | Відсутній |" }
}
$rowsMd = $rows -join "`r`n"
$gitLine = if ($GitBookRelPath) { "- **GitBook:** `"$GitBookRelPath`"" } else { "" }

$entry = @"
## $Title

- **Дата:** $dt
- **Автор:** $Author
$gitLine

### Пакет

| Файл | SHA-256 |
|------|---------|
| $pkgName | `$pkgHash` |

### Вміст

$rowsMd

---
"@

if (-not (Test-Path -LiteralPath $LogPath)) { [System.IO.File]::WriteAllText($LogPath, "# LOG`r`n`r`n", $enc) }
[System.IO.File]::AppendAllText($LogPath, $entry + "`r`n", $enc)
Write-Host "[OK] Запис додано у $LogPath" -ForegroundColor Green

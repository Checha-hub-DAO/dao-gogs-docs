
# Start-of-Day.ps1 — Ранковий тех-цикл (С.Ч.)

## Призначення
- Перевіряє пакет пам’яток у `CHECHA_CORE_SYNC\DOCS` (SHA256 → sync → датована копія опційно).
- Збирає `TECH_TOOLS_PACK` із `CHECHA_CORE` і синхронізує у `SYNC\TOOLS`.
- Веде лог у `D:\CHECHA_CORE_SYNC\DOCS\SOD_LOG.md`.

## Запуск
```powershell
pwsh -NoProfile -ExecutionPolicy Bypass `
  -File "D:\CHECHA_CORE\TOOLS\Start-of-Day.ps1" `
  -CoreRoot "D:\CHECHA_CORE" `
  -SyncRoot "D:\CHECHA_CORE_SYNC" `
  -ArchiveDir "D:\CHECHA_CORE\ARCHIVE" `
  -BuildDatedCopy -OpenAfter
```

## Планувальник (щодня о 08:30)
```powershell
schtasks /Create /TN "CHECHA_StartOfDay" /TR "pwsh -NoProfile -ExecutionPolicy Bypass -File D:\CHECHA_CORE\TOOLS\Start-of-Day.ps1 -BuildDatedCopy" /SC DAILY /ST 08:30
```
> За потреби заміни шлях до `pwsh.exe` і часу старту.

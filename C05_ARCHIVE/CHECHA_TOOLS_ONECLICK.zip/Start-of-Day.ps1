
<#
.SYNOPSIS
  Start-of-Day.ps1 — ранковий технічний цикл С.Ч.
  1) Перевіряє та синхронізує пакет пам’яток (DOCS)
  2) Збирає TECH_TOOLS_PACK (TOOLS) з CHECHA_CORE
  3) Веде журнали у SYNC\DOCS

.PARAMETER CoreRoot
  Корінь CHECHA_CORE (типово D:\CHECHA_CORE)

.PARAMETER SyncRoot
  Корінь синхронізації (типово D:\CHECHA_CORE_SYNC)

.PARAMETER ArchiveDir
  Папка архівів (типово D:\CHECHA_CORE\ARCHIVE)

.PARAMETER DocsZip
  Ім'я ZIP з пам’ятками у SYNC\DOCS (типово SCRIPT_WORKFLOW_PACK.zip)

.PARAMETER DocsSha
  Ім'я SHA256 у SYNC\DOCS (типово SCRIPT_WORKFLOW_PACK.sha256)

.PARAMETER BuildDatedCopy
  Робити датовану копію обох кроків

.PARAMETER WhatIf
  Сухий прогін (без змін)

.PARAMETER OpenAfter
  Відкрити папку архіву після збірки
#>

[CmdletBinding(SupportsShouldProcess=$true)]
param(
  [string]$CoreRoot   = "D:\CHECHA_CORE",
  [string]$SyncRoot   = "D:\CHECHA_CORE_SYNC",
  [string]$ArchiveDir = "D:\CHECHA_CORE\ARCHIVE",
  [string]$DocsZip    = "SCRIPT_WORKFLOW_PACK.zip",
  [string]$DocsSha    = "SCRIPT_WORKFLOW_PACK.sha256",
  [switch]$BuildDatedCopy,
  [switch]$WhatIf,
  [switch]$OpenAfter
)

function Write-Head($msg){ Write-Host "=== $msg ===" -ForegroundColor Yellow }
function Write-Info($msg){ Write-Host "[INFO] $msg" -ForegroundColor Cyan }
function Write-Ok  ($msg){ Write-Host "[ OK ] $msg" -ForegroundColor Green }
function Write-Err ($msg){ Write-Host "[ERR ] $msg" -ForegroundColor Red }

$ErrorActionPreference = "Stop"
$ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$logDir = Join-Path $SyncRoot "DOCS"
if (-not (Test-Path -LiteralPath $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
$dailyLog = Join-Path $logDir "SOD_LOG.md"

Add-Content -LiteralPath $dailyLog -Value "`n## $ts — Start-of-Day"

try {
  # 0) Переконаємось, що допоміжні скрипти доступні
  $toolsDir = Join-Path $CoreRoot "TOOLS"
  $verifySync = Join-Path $toolsDir "Verify-AndSync-WorkflowPack.ps1"
  $buildPack  = Join-Path $toolsDir "Build-TechZip.ps1"

  if (-not (Test-Path -LiteralPath $verifySync)) {
    Write-Err "Немає Verify-AndSync-WorkflowPack.ps1 у $toolsDir — крок 1 буде пропущено."
    Add-Content -LiteralPath $dailyLog -Value "- WARN: Verify-AndSync-WorkflowPack.ps1 не знайдено."
  }

  if (-not (Test-Path -LiteralPath $buildPack)) {
    throw "Не знайдено Build-TechZip.ps1 у $toolsDir"
  }

  # 1) Перевірка/синк DOCS пакета пам’яток
  Write-Head "Крок 1: Перевірка пам’яток (DOCS)"
  $docsDir = Join-Path $SyncRoot "DOCS"
  $zipPath = Join-Path $docsDir $DocsZip
  $shaPath = Join-Path $docsDir $DocsSha

  if (Test-Path -LiteralPath $verifySync -and (Test-Path -LiteralPath $zipPath) -and (Test-Path -LiteralPath $shaPath)) {
    $args = @(
      "-ZipPath `"$zipPath`"",
      "-ShaFile `"$shaPath`"",
      "-SyncRoot `"$SyncRoot`"",
      "-SubFolder DOCS"
    )
    if ($BuildDatedCopy) { $args += "-CreateDatedCopy" }
    if ($WhatIf) { Write-Info "WhatIf: перевірив би та синхронізував пам’ятки DOCS" }
    else {
      Write-Info "Запуск Verify-AndSync-WorkflowPack.ps1 $($args -join ' ')"
      & $verifySync @args
      if ($LASTEXITCODE -eq 0) {
        Write-Ok "DOCS пакет перевірено й синхронізовано"
        Add-Content -LiteralPath $dailyLog -Value "- DOCS: hash ok, synced"
      } elseif ($LASTEXITCODE -eq 2) {
        Write-Err "DOCS: Хеш НЕ збігся — синк не виконано."
        Add-Content -LiteralPath $dailyLog -Value "- DOCS: hash mismatch (sync skipped)"
      } else {
        Write-Err "DOCS: Помилка під час перевірки/синку (код $LASTEXITCODE)"
        Add-Content -LiteralPath $dailyLog -Value "- DOCS: error (code $LASTEXITCODE)"
      }
    }
  } else {
    Write-Info "DOCS пакет або скрипт перевірки не знайдені — пропускаю крок."
    Add-Content -LiteralPath $dailyLog -Value "- DOCS: skipped (no files or verifier)"
  }

  # 2) Збірка TECH_TOOLS_PACK
  Write-Head "Крок 2: Збірка TECH_TOOLS_PACK (TOOLS)"
  $args2 = @(
    "-Root `"$CoreRoot`"",
    "-OutArchive `"$ArchiveDir`"",
    "-SyncRoot `"$SyncRoot`"",
    "-SyncSubFolder TOOLS"
  )
  if ($BuildDatedCopy) { $args2 += "-CreateDatedCopy" }
  if ($OpenAfter) { $args2 += "-OpenAfter" }

  if ($WhatIf) {
    Write-Info "WhatIf: зібрав би TECH_TOOLS_PACK та синхронізував у SYNC\TOOLS"
    Add-Content -LiteralPath $dailyLog -Value "- TOOLS: WhatIf build"
  } else {
    Write-Info "Запуск Build-TechZip.ps1 $($args2 -join ' ')"
    & $buildPack @args2
    if ($LASTEXITCODE -eq $null -or $LASTEXITCODE -eq 0) {
      Write-Ok "TOOLS пакет зібрано й синхронізовано"
      Add-Content -LiteralPath $dailyLog -Value "- TOOLS: built & synced"
    } else {
      Write-Err "TOOLS: Помилка під час збірки (код $LASTEXITCODE)"
      Add-Content -LiteralPath $dailyLog -Value "- TOOLS: error (code $LASTEXITCODE)"
    }
  }

  Write-Ok "Start-of-Day завершено"
  Add-Content -LiteralPath $dailyLog -Value "- DONE: Start-of-Day complete"

} catch {
  Write-Err "Фатальна помилка: $($_.Exception.Message)"
  Add-Content -LiteralPath $dailyLog -Value "- ERROR: $($_.Exception.Message)"
  exit 1
}
exit 0

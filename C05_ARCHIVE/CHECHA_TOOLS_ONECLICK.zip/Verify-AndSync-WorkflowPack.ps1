
param (
    [Parameter(Mandatory=$false)]
    [string]$ZipPath = "SCRIPT_WORKFLOW_PACK.zip",

    [Parameter(Mandatory=$false)]
    [string]$ShaFile = "SCRIPT_WORKFLOW_PACK.sha256",

    [Parameter(Mandatory=$false)]
    [string]$SyncRoot = "D:\CHECHA_CORE_SYNC",

    [Parameter(Mandatory=$false)]
    [string]$SubFolder = "DOCS",

    [switch]$CreateDatedCopy  # додатково робити копію в підпапку з датою
)

function Fail($msg, $code=1) {
    Write-Host "❌ $msg"
    exit $code
}

# 1) Перевірки наявності файлів
if (-not (Test-Path -LiteralPath $ZipPath)) { Fail "Архів не знайдено: $ZipPath" }
if (-not (Test-Path -LiteralPath $ShaFile)) { Fail "Файл SHA256 не знайдено: $ShaFile" }

# 2) Обчислення хешу
try {
    $computedHash = (Get-FileHash -Path $ZipPath -Algorithm SHA256).Hash.ToLower()
} catch {
    Fail "Помилка при обчисленні SHA256: $($_.Exception.Message)"
}

# 3) Зчитування еталонного значення з .sha256 (перший токен у рядку)
try {
    $line = (Get-Content -LiteralPath $ShaFile -TotalCount 1).Trim()
    if (-not $line) { Fail "Файл SHA256 порожній або некоректний: $ShaFile" }
    $expectedHash = ($line -split '\s+')[0].ToLower()
} catch {
    Fail "Не вдалось прочитати SHA256: $($_.Exception.Message)"
}

# 4) Порівняння
if ($computedHash -ne $expectedHash) {
    Write-Host "❌ Хеш НЕ збігається!"
    Write-Host "Очікувано: $expectedHash"
    Write-Host "Отримано : $computedHash"
    exit 2
}

Write-Host "✅ Хеш збігається. Файл цілісний."

# 5) Підготовка цільового каталогу синхронізації
$targetDir = Join-Path $SyncRoot $SubFolder
if (-not (Test-Path -LiteralPath $targetDir)) {
    New-Item -ItemType Directory -Path $targetDir | Out-Null
}

# 6) (Опційно) створення датованої підпапки
$datedDir = $null
if ($CreateDatedCopy.IsPresent) {
    $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $datedDir = Join-Path $targetDir $stamp
    New-Item -ItemType Directory -Path $datedDir | Out-Null
}

# 7) Копіювання у ціль
$destZip = Join-Path $targetDir (Split-Path $ZipPath -Leaf)
$destSha = Join-Path $targetDir (Split-Path $ShaFile -Leaf)

Copy-Item -LiteralPath $ZipPath -Destination $destZip -Force
Copy-Item -LiteralPath $ShaFile -Destination $destSha -Force

# 7b) Додаткова датована копія (за вимогою)
if ($datedDir) {
    Copy-Item -LiteralPath $ZipPath -Destination (Join-Path $datedDir (Split-Path $ZipPath -Leaf)) -Force
    Copy-Item -LiteralPath $ShaFile -Destination (Join-Path $datedDir (Split-Path $ShaFile -Leaf)) -Force
}

# 8) Запис у лог DOCS\SCRIPT_LOG.md
$logFile = Join-Path $targetDir "SCRIPT_LOG.md"
$ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$entry = @"
- $ts | Synced: $(Split-Path $ZipPath -Leaf) + SHA256 → $targetDir (hash ok)
"@
Add-Content -LiteralPath $logFile -Value $entry

Write-Host "📤 Синхронізація виконана: $targetDir"
if ($datedDir) { Write-Host "🗂 Датована копія: $datedDir" }
exit 0

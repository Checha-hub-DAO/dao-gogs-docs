
<#
.SYNOPSIS
  Build-TechZip.ps1 — збірка TECH_TOOLS_PACK (С.Ч.)

.DESCRIPTION
  - Збирає технічний пакет (ZIP) із CHECHA_CORE
  - Фільтрує файли за розширеннями
  - Обчислює SHA256
  - Синхронізує у SYNC\TOOLS
  - Веде лог TOOLS_LOG.md і CHANGELOG
  - Додає VERSION.txt у пакет
  - Опційно: HOT-режим (мінімальний набір)
  - Опційно: PSScriptAnalyzer-рев’ю (якщо встановлено)
#>

[CmdletBinding(SupportsShouldProcess=$true)]
param(
  [string]$Root        = "D:\CHECHA_CORE",
  [string]$OutArchive  = "D:\CHECHA_CORE\ARCHIVE",
  [string]$SyncRoot    = "D:\CHECHA_CORE_SYNC",
  [string]$SyncSubFolder = "TOOLS",
  [switch]$CreateDatedCopy,
  [switch]$OpenAfter,
  [switch]$Hot,
  [switch]$RunPSAnalysis
)

function Write-Head($msg){ Write-Host "=== $msg ===" -ForegroundColor Yellow }
function Write-Info($msg){ Write-Host "[INFO] $msg" -ForegroundColor Cyan }
function Write-Ok  ($msg){ Write-Host "[ OK ] $msg" -ForegroundColor Green }
function Write-Err ($msg){ Write-Host "[ERR ] $msg" -ForegroundColor Red }

$ErrorActionPreference = "Stop"
$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$archiveName = "TECH_TOOLS_PACK_$ts.zip"
$zipPath = Join-Path $OutArchive $archiveName

# --- Вибірка файлів
if ($Hot) {
  $IncludeSubfolders = @("TOOLS","C11_AUTOMATION","CONFIG")
  $IncludeExt        = @("*.ps1","*.psm1","*.psd1","*.json","*.yaml","*.yml")
  Write-Info "HOT-режим: мінімальний набір каталогів і розширень"
} else {
  $IncludeSubfolders = @("TOOLS","CONFIG","C11_AUTOMATION","C06_FOCUS\TEMPLATES")
  $IncludeExt        = @("*.ps1","*.psm1","*.psd1","*.bat","*.cmd","*.py","*.json","*.yaml","*.yml","*.ini","*.md","*.txt","*.csv","*.ps1xml")
}

$files = foreach ($sub in $IncludeSubfolders) {
  $dir = Join-Path $Root $sub
  if (Test-Path $dir) {
    Get-ChildItem -Path $dir -Recurse -Include $IncludeExt -File -ErrorAction SilentlyContinue
  }
}

if (-not $files) { Write-Err "Файлів не знайдено для архівування."; exit 1 }

# --- Префлайт статистика
$byExt = $files | Group-Object Extension | Sort-Object Count -Descending
$bytes = ($files | Measure-Object Length -Sum).Sum
Write-Head "Префлайт-звіт"
Write-Info ("Файлів: {0} | Розмір: {1:N0} байт" -f $files.Count, $bytes)
foreach ($g in $byExt) { Write-Host ("  - {0}: {1}" -f $g.Name, $g.Count) }

# --- Аналіз PowerShell (якщо запитано)
if ($RunPSAnalysis) {
  if (Get-Module -ListAvailable -Name PSScriptAnalyzer) {
    Write-Info "PSScriptAnalyzer: перевірка *.ps1/*.psm1"
    $psFiles = $files | Where-Object { $_.Extension -in ".ps1",".psm1" } | Select-Object -Expand FullName
    if ($psFiles) {
      $findings = Invoke-ScriptAnalyzer -Path $psFiles -Recurse -Severity @("Error","Warning") -ErrorAction SilentlyContinue
      if ($findings) {
        Write-Host "[WARN] Зауваження:" -ForegroundColor Yellow
        $findings | Select RuleName, Severity, ScriptName, Line, Message | Format-Table -AutoSize | Out-String | Write-Host
      } else {
        Write-Ok "PSScriptAnalyzer: без помилок"
      }
    }
  } else {
    Write-Info "PSScriptAnalyzer не встановлено — пропущено"
  }
}

# --- Створюємо staging
$stage = Join-Path $env:TEMP ("TECH_STAGE_" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $stage -Force | Out-Null

# Копіюємо файли
foreach ($f in $files) {
  $rel = $f.FullName.Substring($Root.Length).TrimStart('\')
  $dest = Join-Path $stage $rel
  $destDir = Split-Path $dest -Parent
  if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
  Copy-Item -LiteralPath $f.FullName -Destination $dest -Force
}

# --- VERSION.txt
$versionFile = Join-Path $stage "VERSION.txt"
$versionStamp = Get-Date -Format "yyyy.MM.dd-HHmmss"
"TECH_TOOLS_PACK build: $versionStamp`r`nHost: $env:COMPUTERNAME`r`nUser: $env:USERNAME`r`nFiles: $($files.Count)`r`nSize: $([math]::Round($bytes/1KB,1)) KB`r`nHot: $($Hot.IsPresent)`r`nAnalysis: $($RunPSAnalysis.IsPresent)" |
  Out-File -LiteralPath $versionFile -Encoding utf8 -Force

# --- Створюємо ZIP
if (-not (Test-Path $OutArchive)) { New-Item -ItemType Directory -Path $OutArchive -Force | Out-Null }
if ($PSCmdlet.ShouldProcess($zipPath, "Create archive")) {
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [System.IO.Compression.ZipFile]::CreateFromDirectory($stage, $zipPath)
  Write-Ok "ZIP створено: $zipPath"
}

# --- SHA256
$sha = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash
$shaFile = $zipPath + ".sha256"
"$sha  $archiveName" | Out-File -LiteralPath $shaFile -Encoding ascii -Force
Write-Ok "SHA256: $sha"

# --- Синхронізація
$targetDir = Join-Path $SyncRoot $SyncSubFolder
if (-not (Test-Path $targetDir)) { New-Item -ItemType Directory -Path $targetDir -Force | Out-Null }
Copy-Item -LiteralPath $zipPath -Destination $targetDir -Force
Copy-Item -LiteralPath $shaFile -Destination $targetDir -Force
Write-Ok "Синхронізовано у $targetDir"

if ($CreateDatedCopy) {
  $dated = Join-Path $targetDir ("HISTORY_" + (Get-Date -Format "yyyyMMdd"))
  if (-not (Test-Path $dated)) { New-Item -ItemType Directory -Path $dated -Force | Out-Null }
  Copy-Item -LiteralPath $zipPath -Destination $dated -Force
  Copy-Item -LiteralPath $shaFile -Destination $dated -Force
  Write-Ok "Датована копія: $dated"
}

# --- CHANGELOG
$changelog = Join-Path $targetDir "TOOLS_CHANGELOG.md"
$ts2 = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$entry = "- $ts2 | $archiveName | files=$($files.Count) size=$([math]::Round($bytes/1KB,1))KB | hot=$($Hot.IsPresent) analyze=$($RunPSAnalysis.IsPresent)"
Add-Content -LiteralPath $changelog -Value $entry

# --- Лог
$log = Join-Path $targetDir "TOOLS_LOG.md"
Add-Content -LiteralPath $log -Value "[$(Get-Date -Format "yyyy-MM-dd HH:mm:ss")] Built $archiveName (files=$($files.Count), hot=$($Hot.IsPresent))"

# --- Прибираємо staging
Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue

if ($OpenAfter) { Invoke-Item $OutArchive }

exit 0

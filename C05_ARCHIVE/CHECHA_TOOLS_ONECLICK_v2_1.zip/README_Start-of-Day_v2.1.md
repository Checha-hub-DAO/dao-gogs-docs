
# Start-of-Day_v2.1 — із перевіркою Evening Backup

## Що нового
- Перевіряє наявність учорашнього бекапу в `D:\CHECHA_BACKUP\DAILY\YYYYMMDD`.
- Якщо каталогу нема → жовте попередження в консолі та `SOD_LOG.md`.
- Прапорець `-StrictBackupCheck` зупиняє цикл (код 10), якщо бекап відсутній.

## Запуск
```powershell
pwsh -NoProfile -ExecutionPolicy Bypass `
  -File "D:\CHECHA_CORE\TOOLS\Start-of-Day_v2.1.ps1" `
  -CoreRoot "D:\CHECHA_CORE" -SyncRoot "D:\CHECHA_CORE_SYNC" `
  -ArchiveDir "D:\CHECHA_CORE\ARCHIVE" -BackupDailyRoot "D:\CHECHA_BACKUP\DAILY" `
  -BuildDatedCopy -Hot -RunPSAnalysis
```

## Строгий режим
```powershell
pwsh -NoProfile -ExecutionPolicy Bypass `
  -File "D:\CHECHA_CORE\TOOLS\Start-of-Day_v2.1.ps1" `
  -StrictBackupCheck
```
> Якщо учорашній резерв відсутній — цикл зупиниться з кодом `10`.

---
С.Ч.

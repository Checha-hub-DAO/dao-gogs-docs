
<#
.SYNOPSIS
  Start-of-Day_v2.1.ps1 — ранковий технічний цикл С.Ч. (із перевіркою Evening Backup)
  1) Перевіряє наявність учорашнього резерву (EVENING_BACKUP)
  2) Перевіряє та синхронізує пакет пам’яток (DOCS)
  3) Збирає TECH_TOOLS_PACK (TOOLS) з CHECHA_CORE (Build-TechZip_v2.ps1)
  4) Веде журнали у SYNC\DOCS

.PARAMETER CoreRoot
  Корінь CHECHA_CORE (типово D:\CHECHA_CORE)

.PARAMETER SyncRoot
  Корінь синхронізації (типово D:\CHECHA_CORE_SYNC)

.PARAMETER ArchiveDir
  Папка архівів (типово D:\CHECHA_CORE\ARCHIVE)

.PARAMETER BackupDailyRoot
  Корінь щоденних вечірніх бекапів (типово D:\CHECHA_BACKUP\DAILY)

.PARAMETER DocsZip
  Ім'я ZIP з пам’ятками у SYNC\DOCS (типово SCRIPT_WORKFLOW_PACK.zip)

.PARAMETER DocsSha
  Ім'я SHA256 у SYNC\DOCS (типово SCRIPT_WORKFLOW_PACK.sha256)

.PARAMETER BuildDatedCopy
  Робити датовану копію обох кроків

.PARAMETER Hot
  Зібрати мінімальний HOT-пакет

.PARAMETER RunPSAnalysis
  Запустити PSScriptAnalyzer перед архівом

.PARAMETER StrictBackupCheck
  Якщо учорашній бекап відсутній — завершити з кодом 10 (провести ручну перевірку)

.PARAMETER WhatIf
  Сухий прогін (без змін)

.PARAMETER OpenAfter
  Відкрити папку архіву після збірки
#>

[CmdletBinding(SupportsShouldProcess=$true)]
param(
  [string]$CoreRoot        = "D:\CHECHA_CORE",
  [string]$SyncRoot        = "D:\CHECHA_CORE_SYNC",
  [string]$ArchiveDir      = "D:\CHECHA_CORE\ARCHIVE",
  [string]$BackupDailyRoot = "D:\CHECHA_BACKUP\DAILY",
  [string]$DocsZip         = "SCRIPT_WORKFLOW_PACK.zip",
  [string]$DocsSha         = "SCRIPT_WORKFLOW_PACK.sha256",
  [switch]$BuildDatedCopy,
  [switch]$Hot,
  [switch]$RunPSAnalysis,
  [switch]$StrictBackupCheck,
  [switch]$WhatIf,
  [switch]$OpenAfter
)

function Write-Head($msg){ Write-Host "=== $msg ===" -ForegroundColor Yellow }
function Write-Info($msg){ Write-Host "[INFO] $msg" -ForegroundColor Cyan }
function Write-Ok  ($msg){ Write-Host "[ OK ] $msg" -ForegroundColor Green }
function Write-Warn($msg){ Write-Host "[WARN] $msg" -ForegroundColor DarkYellow }
function Write-Err ($msg){ Write-Host "[ERR ] $msg" -ForegroundColor Red }

$ErrorActionPreference = "Stop"
$ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$logDir = Join-Path $SyncRoot "DOCS"
if (-not (Test-Path -LiteralPath $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
$dailyLog = Join-Path $logDir "SOD_LOG.md"
Add-Content -LiteralPath $dailyLog -Value "`n## $ts — Start-of-Day_v2.1"

try {
  # --- 0) Перевірка учорашнього Evening Backup
  Write-Head "Крок 0: Evening Backup (учора)"
  $y = (Get-Date).AddDays(-1).ToString("yyyyMMdd")
  $yDir = Join-Path $BackupDailyRoot $y
  if (Test-Path -LiteralPath $yDir) {
    Write-Ok "Виявлено резерв: $yDir"
    Add-Content -LiteralPath $dailyLog -Value "- EveningBackup: OK ($yDir)"
  } else {
    $msg = "EveningBackup ($y) not found in $BackupDailyRoot"
    Write-Warn $msg
    Add-Content -LiteralPath $dailyLog -Value "- EveningBackup: MISSING ($y)"
    if ($StrictBackupCheck) {
      Write-Err "Strict mode: зупинка циклу (код 10)"
      exit 10
    }
  }

  # --- 1) Перевірка/синк DOCS
  Write-Head "Крок 1: Перевірка пам’яток (DOCS)"
  $toolsDir = Join-Path $CoreRoot "TOOLS"
  $verifySync = Join-Path $toolsDir "Verify-AndSync-WorkflowPack.ps1"
  $buildPack  = Join-Path $toolsDir "Build-TechZip_v2.ps1"

  if (-not (Test-Path -LiteralPath $buildPack)) {
    throw "Не знайдено Build-TechZip_v2.ps1 у $toolsDir"
  }

  $docsDir = Join-Path $SyncRoot "DOCS"
  $zipPath = Join-Path $docsDir $DocsZip
  $shaPath = Join-Path $docsDir $DocsSha

  if (Test-Path -LiteralPath $verifySync -and (Test-Path -LiteralPath $zipPath) -and (Test-Path -LiteralPath $shaPath)) {
    $args = @(
      "-ZipPath `"$zipPath`"",
      "-ShaFile `"$shaPath`"",
      "-SyncRoot `"$SyncRoot`"",
      "-SubFolder DOCS"
    )
    if ($BuildDatedCopy) { $args += "-CreateDatedCopy" }
    if ($WhatIf) { Write-Info "WhatIf: перевірив би та синхронізував пам’ятки DOCS" }
    else {
      & $verifySync @args
      if ($LASTEXITCODE -eq 0) {
        Write-Ok "DOCS: hash ok, synced"
        Add-Content -LiteralPath $dailyLog -Value "- DOCS: hash ok, synced"
      } elseif ($LASTEXITCODE -eq 2) {
        Write-Warn "DOCS: hash mismatch"
        Add-Content -LiteralPath $dailyLog -Value "- DOCS: hash mismatch (sync skipped)"
      } else {
        Write-Err "DOCS: error (code $LASTEXITCODE)"
        Add-Content -LiteralPath $dailyLog -Value "- DOCS: error (code $LASTEXITCODE)"
      }
    }
  } else {
    Write-Info "DOCS: пакет або скрипт не знайдені — пропуск"
    Add-Content -LiteralPath $dailyLog -Value "- DOCS: skipped"
  }

  # --- 2) Збірка TECH_TOOLS_PACK
  Write-Head "Крок 2: Збірка TECH_TOOLS_PACK (TOOLS)"
  $args2 = @(
    "-Root `"$CoreRoot`"",
    "-OutArchive `"$ArchiveDir`"",
    "-SyncRoot `"$SyncRoot`"",
    "-SyncSubFolder TOOLS"
  )
  if ($BuildDatedCopy) { $args2 += "-CreateDatedCopy" }
  if ($Hot) { $args2 += "-Hot" }
  if ($RunPSAnalysis) { $args2 += "-RunPSAnalysis" }
  if ($OpenAfter) { $args2 += "-OpenAfter" }

  if ($WhatIf) {
    Write-Info "WhatIf: зібрав би TECH_TOOLS_PACK (HOT=$Hot, Analyze=$RunPSAnalysis)"
    Add-Content -LiteralPath $dailyLog -Value "- TOOLS: WhatIf build"
  } else {
    & (Join-Path $toolsDir "Build-TechZip_v2.ps1") @args2
    if ($LASTEXITCODE -eq $null -or $LASTEXITCODE -eq 0) {
      Write-Ok "TOOLS: built & synced"
      Add-Content -LiteralPath $dailyLog -Value "- TOOLS: built & synced"
    } else {
      Write-Err "TOOLS: error (code $LASTEXITCODE)"
      Add-Content -LiteralPath $dailyLog -Value "- TOOLS: error (code $LASTEXITCODE)"
    }
  }

  Write-Ok "Start-of-Day_v2.1 завершено"
  Add-Content -LiteralPath $dailyLog -Value "- DONE: Start-of-Day_v2.1 complete"

} catch {
  Write-Err "Фатальна помилка: $($_.Exception.Message)"
  Add-Content -LiteralPath $dailyLog -Value "- ERROR: $($_.Exception.Message)"
  exit 1
}
exit 0

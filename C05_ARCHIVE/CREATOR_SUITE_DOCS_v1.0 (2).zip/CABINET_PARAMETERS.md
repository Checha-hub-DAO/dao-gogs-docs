# 🏛️ CABINET_CREATOR — Параметри Кабінету Творця

Цей документ описує основні параметри та налаштування модуля **CABINET_CREATOR**.

---

## 1. Загальні
- **CabinetRoot** — головний шлях до директорії кабінету (наприклад: `D:\CHECHA_CORE\CABINET_CREATOR`).
- **RoomsPath** — опис кімнат і зон (`rooms/` або `ROOMS.md`).
- **RolesPath** — список ролей (`ROLES.md`).
- **ProtocolsPath** — протоколи роботи (`PROTOCOLS.md`).
- **CouncilPath** — рада/керівний орган (`COUNCIL.md`).
- **VisualsPath** — візуали, карти (`visuals/`).

---

## 2. Ролі та права
- **Role.ID** — ідентифікатор ролі.
- **Role.Title** — назва (Майстер, Оглядач, Хранитель, Посередник, тощо).
- **Role.Responsibilities** — список обов’язків.
- **Role.Permissions** — дозволи (створювати, переглядати, затверджувати, архівувати).

---

## 3. Протоколи
- **DecisionProtocol** — порядок прийняття рішень (одноголосно, більшістю, за вагою ролей).
- **ReviewProtocol** — як розглядати артефакти, що надійшли з WORKSHOP.
- **CouncilProtocol** — як скликається рада, які є кворуми.
- **ArchiveProtocol** — що робити з відхиленими або завершеними артефактами.

---

## 4. Автоматизація
- **OpenScript** — шлях до `Open-Cabinet.ps1` (запуск кабінету).
- **SyncScript** — шлях до `Sync-WorkshopCabinet.ps1` (спільний реєстр).
- **Pipeline** — інтегрований запуск `pipeline.ps1`.
- **RegistryCsv** — єдиний CSV-реєстр артефактів (спільний із WORKSHOP).

---

## 5. Візуалізація
- **CabinetMap.png** — карта кабінету.
- **CouncilBoard.html** (майбутнє) — інтерактивна дошка рішень ради.

---

## 📌 Приклад конфігурації (YAML)

```yaml
CabinetRoot: D:\CHECHA_CORE\CABINET_CREATOR
RoomsPath: ROOMS.md
RolesPath: ROLES.md
ProtocolsPath: PROTOCOLS.md
CouncilPath: COUNCIL.md
VisualsPath: visuals

RegistryCsv: D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\ArtifactsRegistry.csv

OpenScript: D:\CHECHA_CORE\CABINET_CREATOR\Open-Cabinet.ps1
SyncScript: D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\Sync-WorkshopCabinet.ps1
Pipeline:   D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\pipeline.ps1

DecisionProtocol: majority-vote
ReviewProtocol: council-review
CouncilProtocol: scheduled-meeting
ArchiveProtocol: archive-or-reject
```

---

© Кабінет Творця | v1.0 | С.Ч.

# 🌌 MASTER_PARAMETERS — Інтегровані параметри Майстерні та Кабінету Творця

Цей документ об’єднує параметри двох ключових модулів **CREATOR_SUITE**:  
- 🛠️ WORKSHOP_CREATOR (Майстерня Творця)  
- 🏛️ CABINET_CREATOR (Кабінет Творця)  

---

## 1. Загальні шляхи
- **WorkshopRoot** — `D:\CHECHA_CORE\WORKSHOP_CREATOR`
- **CabinetRoot** — `D:\CHECHA_CORE\CABINET_CREATOR`
- **IntegrationRoot** — `D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION`

---

## 2. WORKSHOP_CREATOR — Параметри
- **ArtifactsPath** — `artifacts/`
- **VisualsPath** — `visuals/`
- **DocsPath** — `docs/`
- **ScriptsPath** — `scripts/`

### Артефакти
- **Artifact.ID** — унікальний ідентифікатор (ART-YYYYMMDD-XXX)
- **Artifact.Title** — назва
- **Artifact.Type** — Ідея / Концепт / Документ / Візуал / Код / Мультимедіа
- **Artifact.Owner** — відповідальний творець
- **Artifact.Stage** — Workshop → Cabinet → Release
- **Artifact.Status** — Draft / InProgress / Review / ReadyForRelease / Released
- **Artifact.Files** — файли з SHA-256
- **Artifact.History** — історія змін

### Процеси
- **CreationProtocol** — шаблон створення
- **ReviewProtocol** — надсилання до Cabinet
- **ReleaseProtocol** — теги релізу
- **ArchivePolicy** — архівація завершених

---

## 3. CABINET_CREATOR — Параметри
- **RoomsPath** — `ROOMS.md`
- **RolesPath** — `ROLES.md`
- **ProtocolsPath** — `PROTOCOLS.md`
- **CouncilPath** — `COUNCIL.md`
- **VisualsPath** — `visuals/`

### Ролі та права
- **Role.ID** — ідентифікатор
- **Role.Title** — назва
- **Role.Responsibilities** — обов’язки
- **Role.Permissions** — дозволи (create/review/approve/archive)

### Протоколи
- **DecisionProtocol** — спосіб голосування (unanimous / majority / weighted)
- **ReviewProtocol** — порядок огляду артефактів
- **CouncilProtocol** — кворум і регламент
- **ArchiveProtocol** — правила архівації або відхилення

---

## 4. Інтеграція та автоматизація
- **SyncScript** — `Sync-WorkshopCabinet.ps1`
- **FixScript** — `Fix-Manifests.ps1`
- **Pipeline** — `pipeline.ps1`
- **RegistryCsv** — єдиний реєстр артефактів
- **ValidationCsv** — звіт перевірки
- **FixReportCsv** — звіт виправлень

---

## 5. Візуалізація
- **WorkshopMap.png** — карта майстерні
- **CabinetMap.png** — карта кабінету
- **ArtifactsDashboard.html** — майбутній дашборд артефактів
- **CouncilBoard.html** — майбутня інтерактивна дошка рішень

---

## 📌 Приклад інтегрованої конфігурації (YAML)

```yaml
WorkshopRoot: D:\CHECHA_CORE\WORKSHOP_CREATOR
CabinetRoot:  D:\CHECHA_CORE\CABINET_CREATOR
IntegrationRoot: D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION

RegistryCsv:   D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\ArtifactsRegistry.csv
ValidationCsv: D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\validation.csv
FixReportCsv:  D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\fix_report.csv

SyncScript: D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\Sync-WorkshopCabinet.ps1
FixScript:  D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\Fix-Manifests.ps1
Pipeline:   D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\pipeline.ps1

# WORKSHOP протоколи
CreationProtocol: basic-template.yaml
ReviewProtocol: send-to-cabinet
ReleaseProtocol: tag-and-publish
ArchivePolicy: zip-and-store

# CABINET протоколи
DecisionProtocol: majority-vote
ReviewProtocol: council-review
CouncilProtocol: scheduled-meeting
ArchiveProtocol: archive-or-reject
```

---

© Інтегрована Майстерня + Кабінет Творця | v1.0 | С.Ч.

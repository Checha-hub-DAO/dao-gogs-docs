# ⚙️ WORKSHOP_CREATOR — Параметри Майстерні Творця

Цей документ описує основні параметри та налаштування модуля **WORKSHOP_CREATOR**.

---

## 1. Загальні
- **WorkshopRoot** — головний шлях до директорії майстерні (наприклад: `D:\CHECHA_CORE\WORKSHOP_CREATOR`).
- **ArtifactsPath** — папка з артефактами (`artifacts/`).
- **VisualsPath** — папка для візуалів (`visuals/`).
- **DocsPath** — документація, README, протоколи (`docs/`).
- **ScriptsPath** — утиліти (`scripts/`).

---

## 2. Артефакти
- **Artifact.ID** — унікальний ідентифікатор (формат: `ART-YYYYMMDD-XXX`).
- **Artifact.Title** — назва артефакту.
- **Artifact.Type** — тип (Ідея, Концепт, Документ, Візуал, Код, Мультимедіа).
- **Artifact.Owner** — відповідальний творець.
- **Artifact.Stage** — стадія: `Workshop` → `Cabinet` → `Release`.
- **Artifact.Status** — стан: `Draft`, `InProgress`, `Review`, `ReadyForRelease`, `Released`.
- **Artifact.Files** — список файлів з SHA-256.
- **Artifact.History** — масив змін (дата, дія, автор).

---

## 3. Процес
- **CreationProtocol** — правила створення нових артефактів (мінімальні поля, шаблон YAML).
- **ReviewProtocol** — як відправляти на розгляд у CABINET.
- **ReleaseProtocol** — коли й як маркувати артефакт як `Released`.
- **ArchivePolicy** — що робити з завершеними артефактами (архів/копія).

---

## 4. Автоматизація
- **SyncScript** — шлях до `Sync-WorkshopCabinet.ps1`.
- **FixScript** — шлях до `Fix-Manifests.ps1`.
- **Pipeline** — інтегрований запуск `pipeline.ps1`.
- **RegistryCsv** — єдиний CSV-реєстр артефактів.
- **ValidationCsv** — звіт перевірки.
- **FixReportCsv** — звіт виправлень SHA-256.

---

## 5. Візуалізація
- **WorkshopMap.png** — карта майстерні.
- **ArtifactsDashboard.html** (майбутнє) — дашборд для швидкого перегляду статусів артефактів.

---

## 📌 Приклад конфігурації (YAML)

```yaml
WorkshopRoot: D:\CHECHA_CORE\WORKSHOP_CREATOR
ArtifactsPath: artifacts
VisualsPath: visuals
DocsPath: docs
ScriptsPath: scripts

RegistryCsv: D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\ArtifactsRegistry.csv
ValidationCsv: D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\validation.csv
FixReportCsv: D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\fix_report.csv

SyncScript: D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\Sync-WorkshopCabinet.ps1
FixScript: D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\Fix-Manifests.ps1
Pipeline:   D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\pipeline.ps1

CreationProtocol: basic-template.yaml
ReviewProtocol: send-to-cabinet
ReleaseProtocol: tag-and-publish
ArchivePolicy: zip-and-store
```

---

© Майстерня Творця | v1.0 | С.Ч.

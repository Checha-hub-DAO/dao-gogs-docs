# 🧭 CREATOR_SUITE — Навігаційна мапа документів

Ця діаграма показує як пов’язані основні документи пакета документації.

```mermaid
flowchart LR
    A[INDEX.md<br/>Стартова сторінка] --> B[MASTER_PARAMETERS.md<br/>Інтегровані параметри]
    A --> C[WORKSHOP_PARAMETERS.md]
    A --> D[CABINET_PARAMETERS.md]
    A --> E[ARTIFACTS_FLOW.md]
    A --> F[WORKSHOP_TOOLS_OVERVIEW.md]
    A --> G[CABINET_TOOLS_OVERVIEW.md]
    A --> H[MASTER_TOOLS_OVERVIEW.md]

    B --> C
    B --> D
    B --> E
    B --> H

    C --> E
    D --> E

    F --> C
    G --> D

    subgraph WORKSHOP
      C
      F
    end

    subgraph CABINET
      D
      G
    end

    subgraph MASTER
      B
      H
    end
```

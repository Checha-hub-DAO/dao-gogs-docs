<#
.SYNOPSIS
  Sync-WorkshopCabinet.ps1 — синхронізація маніфестів у реєстр із валідацією.

.DESCRIPTION
  Мінімально-робоча версія:
  - читає всі *.yml/*.yaml у -ManifestsPath;
  - перевіряє ключові поля (Id, Title) та файли у секції Files[*].Path;
  - формує ValidationReportCsv (CSV зі списком помилок);
  - якщо немає критичних помилок і НЕ вказано -DryRun — оновлює/створює RegistryCsv:
      Id, Title, Stage, Status, Owner, LastUpdated, ManifestPath.
  - якщо задано -Strict і є помилки — процес завершується з кодом 1 без оновлення реєстру.

.PARAMETER ManifestsPath
  Папка з YAML-маніфестами (Artifact.Manifest.yml/.yaml).

.PARAMETER RegistryCsv
  Шлях до CSV-реєстру артефактів.

.PARAMETER FilesBasePath
  База для відносних шляхів файлів з маніфестів (Files[*].Path).

.PARAMETER ValidationReportCsv
  Куди зберегти CSV зі знайденими помилками.

.PARAMETER Strict
  Якщо помилки знайдено — не оновлювати реєстр і завершити з помилкою.

.PARAMETER DryRun
  Нічого не змінювати (тільки репорти у консоль та ValidationReportCsv).

.EXAMPLES
  pwsh -NoProfile -File .\Sync-WorkshopCabinet.ps1 `
    -ManifestsPath "D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\manifests" `
    -RegistryCsv   "D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\ArtifactsRegistry.csv" `
    -FilesBasePath "D:\CHECHA_CORE" `
    -ValidationReportCsv "D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\validation.csv" `
    -Strict
#>

[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$ManifestsPath,
  [Parameter(Mandatory=$true)][string]$RegistryCsv,
  [Parameter(Mandatory=$true)][string]$FilesBasePath,
  [Parameter(Mandatory=$true)][string]$ValidationReportCsv,
  [switch]$Strict,
  [switch]$DryRun
)

$ErrorActionPreference = "Stop"

function Try-ConvertFromYaml {
  param([string]$Text)
  try {
    if (Get-Command ConvertFrom-Yaml -ErrorAction SilentlyContinue) {
      return $Text | ConvertFrom-Yaml
    } else {
      Write-Verbose "ConvertFrom-Yaml не знайдено — спрощений парсинг тільки ключових полів."
      # Дуже грубий запасний варіант: витягнемо кілька ключів регулярками
      $obj = [ordered]@{}
      if ($Text -match '(?m)^\s*Id\s*:\s*(.+)$')    { $obj.Id    = $Matches[1].Trim() }
      if ($Text -match '(?m)^\s*Title\s*:\s*(.+)$') { $obj.Title = $Matches[1].Trim() }
      # Stage/Status/Owner (опційно)
      if ($Text -match '(?m)^\s*Stage\s*:\s*(.+)$')  { $obj.Stage  = $Matches[1].Trim() }
      if ($Text -match '(?m)^\s*Status\s*:\s*(.+)$') { $obj.Status = $Matches[1].Trim() }
      if ($Text -match '(?m)^\s*Owner\s*:\s*(.+)$')  { $obj.Owner  = $Matches[1].Trim() }
      # Files — не розбираємо без YAML-модуля; просто порожній список
      $obj.Files = @()
      return [pscustomobject]$obj
    }
  } catch {
    Write-Verbose "Помилка ConvertFrom-Yaml: $($_.Exception.Message)"
    return $null
  }
}

function New-ValidationRow {
  param($ManifestPath, $Id, $Title, $Issue, $Severity="Error")
  return [pscustomobject]@{
    ManifestPath = $ManifestPath
    Id           = $Id
    Title        = $Title
    Issue        = $Issue
    Severity     = $Severity
  }
}

# --- Перевірки вхідних шляхів
if (-not (Test-Path -LiteralPath $ManifestsPath)) { throw "ManifestsPath не знайдено: $ManifestsPath" }
$manifestFiles = Get-ChildItem -LiteralPath $ManifestsPath -Filter *.yml -Recurse -ErrorAction SilentlyContinue
$manifestFiles += Get-ChildItem -LiteralPath $ManifestsPath -Filter *.yaml -Recurse -ErrorAction SilentlyContinue
if ($manifestFiles.Count -eq 0) { Write-Warning "Маніфести (*.yml, *.yaml) не знайдено у $ManifestsPath" }

$results   = @()
$errors    = @()

foreach ($mf in $manifestFiles) {
  $raw = Get-Content -LiteralPath $mf.FullName -Raw -Encoding UTF8
  $y = Try-ConvertFromYaml -Text $raw

  if (-not $y) {
    $errors += (New-ValidationRow -ManifestPath $mf.FullName -Id '' -Title '' -Issue "Неможливо розпарсити YAML")
    continue
  }

  $id    = $y.Id
  $title = $y.Title
  $stage = $y.Stage
  $status= $y.Status
  $owner = $y.Owner

  if ([string]::IsNullOrWhiteSpace($id))    { $errors += (New-ValidationRow $mf.FullName $id $title "Відсутній Id") }
  if ([string]::IsNullOrWhiteSpace($title)) { $errors += (New-ValidationRow $mf.FullName $id $title "Відсутній Title") }

  # Перевіримо Files[*].Path (якщо вдалося отримати список)
  $fileList = @()
  if ($y.PSObject.Properties.Name -contains 'Files') {
    $fileList = $y.Files
  }
  foreach ($f in $fileList) {
    $rel = $f.Path
    if ([string]::IsNullOrWhiteSpace($rel)) {
      $errors += (New-ValidationRow $mf.FullName $id $title "Є запис Files[*] без Path")
      continue
    }
    $abs = Join-Path $FilesBasePath $rel
    if (-not (Test-Path -LiteralPath $abs)) {
      $errors += (New-ValidationRow $mf.FullName $id $title "Файл не знайдено: $rel")
    }
    # Якщо прописаний sha256 — можемо перевірити (не обов'язково)
    if ($f.PSObject.Properties.Name -contains 'sha256') {
      try {
        if (Test-Path -LiteralPath $abs) {
          $hash = (Get-FileHash -LiteralPath $abs -Algorithm SHA256).Hash.ToLower()
          if ($hash -ne "$($f.sha256)".ToLower()) {
            $errors += (New-ValidationRow $mf.FullName $id $title "Невірний sha256 для $rel (очікувався $($f.sha256), отримано $hash)")
          }
        }
      } catch { $errors += (New-ValidationRow $mf.FullName $id $title "Не вдалося порахувати sha256 для $rel: $($_.Exception.Message)") }
    }
  }

  $results += [pscustomobject]@{
    Id           = $id
    Title        = $title
    Stage        = $stage
    Status       = $status
    Owner        = $owner
    LastUpdated  = (Get-Item $mf.FullName).LastWriteTimeUtc.ToString("s")
    ManifestPath = $mf.FullName
  }
}

# --- Пишемо звіт валідації
$errors | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath $ValidationReportCsv

if ($errors.Count -gt 0) {
  Write-Warning ("Знайдено {0} проблем(и). Дивись: {1}" -f $errors.Count, $ValidationReportCsv)
  if ($Strict) {
    Write-Error "Strict: синхронізація скасована через помилки валідації."
    exit 1
  }
}

if ($DryRun) {
  Write-Host "DryRun: реєстр НЕ оновлено. Було б додано/оновлено: $($results.Count) запис(ів)."
  $results | Format-Table -AutoSize | Out-Host
  exit 0
}

# --- Оновлюємо/створюємо RegistryCsv
$registry = @()
if (Test-Path -LiteralPath $RegistryCsv) {
  try   { $registry = Import-Csv -LiteralPath $RegistryCsv -Encoding UTF8 }
  catch { Write-Warning "Не вдалося прочитати існуючий RegistryCsv: $($_.Exception.Message)" }
}

# Перетворимо до хеш-таблиці за Id для швидкого оновлення
$byId = @{}
foreach ($row in $registry) { $byId[$row.Id] = $row }

foreach ($r in $results) {
  if ($null -eq $r.Id -or [string]::IsNullOrWhiteSpace($r.Id)) { continue }
  if ($byId.ContainsKey($r.Id)) {
    # Оновити поля
    $byId[$r.Id].Title        = $r.Title
    $byId[$r.Id].Stage        = $r.Stage
    $byId[$r.Id].Status       = $r.Status
    $byId[$r.Id].Owner        = $r.Owner
    $byId[$r.Id].LastUpdated  = $r.LastUpdated
    $byId[$r.Id].ManifestPath = $r.ManifestPath
  } else {
    # Додати новий
    $byId[$r.Id] = [pscustomobject]@{
      Id           = $r.Id
      Title        = $r.Title
      Stage        = $r.Stage
      Status       = $r.Status
      Owner        = $r.Owner
      LastUpdated  = $r.LastUpdated
      ManifestPath = $r.ManifestPath
    }
  }
}

# Повернемо до масиву та запишемо
$final = $byId.GetEnumerator() | ForEach-Object { $_.Value }
$final | Sort-Object Id | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath $RegistryCsv

Write-Host ("✅ Синхронізація завершена. Записів у реєстрі: {0}" -f ($final.Count))
Write-Host (" - RegistryCsv        : {0}" -f $RegistryCsv)
Write-Host (" - ValidationReportCsv: {0}" -f $ValidationReportCsv)

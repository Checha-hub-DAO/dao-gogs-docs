# ⚙️ AUTO_START_MANAGER — Керування автозапуском Master-Agent

Цей документ описує, як додати, прибрати та перевірити автозапуск **Master-Agent** у Windows.

## 📍 Розташування скриптів
```
D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\MASTER_AGENT  ├─ AUTO_START.ps1
  ├─ REMOVE_AUTO_START.ps1
  └─ CHECK_AUTO_START.ps1
```

---

## ➕ Додати в автозапуск
Запускає агента при вході в Windows (створює ярлик у папці Startup):
```powershell
cd D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\MASTER_AGENT
.\AUTO_START.ps1
```
Очікуваний результат: `✅ Master-Agent додано в автозапуск Windows.`

---

## ➖ Прибрати з автозапуску
Видаляє ярлик зі Startup:
```powershell
cd D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\MASTER_AGENT
.\REMOVE_AUTO_START.ps1
```
Очікуваний результат: `🗑️ Master-Agent видалено з автозапуску.`

---

## 🔎 Перевірити статус
Показує, чи є ярлик у Startup:
```powershell
cd D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\MASTER_AGENT
.\CHECK_AUTO_START.ps1
```
Очікуваний результат:
- `✅ Master-Agent є в автозапуску: ...` **або**
- `❌ Master-Agent не доданий у автозапуск.`

---

## 🛡️ Поради безпеки
- Залишайте `-ExecutionPolicy Bypass` тільки для ваших власних скриптів у довірених директоріях.
- Перевіряйте вміст `.ps1` перед запуском (правою кнопкою → "Edit").
- За потреби використовуйте **Windows Defender SmartScreen** та **RestrictedLanguageMode** політики.

---

© CREATOR_SUITE — Master-Agent

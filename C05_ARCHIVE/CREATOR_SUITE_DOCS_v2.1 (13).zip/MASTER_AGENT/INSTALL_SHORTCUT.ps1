# INSTALL_SHORTCUT.ps1 — створення ярлика Master-Agent на робочому столі

$WshShell = New-Object -ComObject WScript.Shell

$Desktop = [Environment]::GetFolderPath("Desktop")
$Shortcut = $WshShell.CreateShortcut("$Desktop\Master-Agent.lnk")

$Shortcut.TargetPath = "pwsh.exe"
$Shortcut.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\MASTER_AGENT\master-agent.ps1"'
$Shortcut.WorkingDirectory = "D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\MASTER_AGENT"
$Shortcut.WindowStyle = 1
$Shortcut.IconLocation = "pwsh.exe,0"
$Shortcut.Description = "Запуск Master-Agent (CREATOR_SUITE)"

$Shortcut.Save()

Write-Host "✅ Ярлик Master-Agent створено на робочому столі."

# QUICKSTART.ps1 — меню швидкого запуску Master-Agent інтентів
param(
  [string]$ExecutionPolicy = "Bypass"
)

$ErrorActionPreference = "Stop"

$agentRoot = "D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\MASTER_AGENT"
$agentExe  = "pwsh"
$agentPath = Join-Path $agentRoot "master-agent.ps1"

if (-not (Test-Path $agentPath)) {
  Write-Host "❌ Не знайдено Master-Agent: $agentPath" -ForegroundColor Red
  exit 1
}

function Run-Intent($name) {
  & $agentExe -NoProfile -ExecutionPolicy $ExecutionPolicy -File $agentPath -Intent $name
}

while ($true) {
  Clear-Host
  Write-Host "🚀 Master-Agent — QUICKSTART меню" -ForegroundColor Cyan
  Write-Host "Розташування: $agentRoot"
  Write-Host ""
  Write-Host " 1) sync_registry_dryrun      — Суха перевірка синхронізації"
  Write-Host " 2) run_pipeline_then_kpi     — Pipeline (Strict) → KPI → відкрити дашборд"
  Write-Host " 3) build_agent_kpi           — Побудувати KPI й відкрити інлайн-дашборд"
  Write-Host " 4) fix_manifests_dryrun      — Перевірка SHA256 без змін"
  Write-Host " 5) fix_manifests             — Оновити SHA256 (InPlace)"
  Write-Host " 6) sync_registry             — Синхронізація (Strict)"
  Write-Host " 7) run_pipeline              — Запуск конвеєра (Strict)"
  Write-Host " 0) Вихід"
  Write-Host ""
  $sel = Read-Host "Обери номер"

  switch ($sel) {
    '1' { Run-Intent "sync_registry_dryrun" ; Pause }
    '2' { Run-Intent "run_pipeline_then_kpi"; Pause }
    '3' { Run-Intent "build_agent_kpi"      ; Pause }
    '4' { Run-Intent "fix_manifests_dryrun" ; Pause }
    '5' { Run-Intent "fix_manifests"        ; Pause }
    '6' { Run-Intent "sync_registry"        ; Pause }
    '7' { Run-Intent "run_pipeline"         ; Pause }
    '0' { break }
    default { Write-Host "Невірний вибір." -ForegroundColor Yellow; Start-Sleep -Seconds 1 }
  }
}

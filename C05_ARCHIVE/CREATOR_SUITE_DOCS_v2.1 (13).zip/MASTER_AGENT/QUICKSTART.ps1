# QUICKSTART.ps1 — меню швидкого запуску Master-Agent
param()

Write-Host "🚀 Master-Agent QUICKSTART" -ForegroundColor Cyan
Write-Host "Оберіть дію:"
Write-Host " 1. sync_registry_dryrun — Сухий прогін синхронізації (валідація без запису)"
Write-Host " 2. run_pipeline_then_kpi — Запустити pipeline (Strict) + KPI"
Write-Host " 3. build_agent_kpi — Побудувати KPI і відкрити дашборд"

$choice = Read-Host "Введіть номер або назву інтенту"

switch ($choice) {
  "1" { $intent = "sync_registry_dryrun" }
  "2" { $intent = "run_pipeline_then_kpi" }
  "3" { $intent = "build_agent_kpi" }
  default { $intent = $choice }
}

Write-Host "→ Запуск інтенту: $intent" -ForegroundColor Yellow

pwsh -NoProfile -ExecutionPolicy Bypass -File ".\master-agent.ps1" -Intent $intent

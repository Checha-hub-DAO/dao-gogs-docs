<#
 .SYNOPSIS
   Master-Agent консоль для CREATOR_SUITE (друг і гід Майстерні)

 .USAGE
   pwsh -NoProfile -ExecutionPolicy Bypass -File ".\master-agent.ps1" [-Intent <name>] [-DryRun] [-Strict] [-Confirm]
   або просто запустити без параметрів — з'явиться інтерактивне меню.

 .NOTES
   Потребує PowerShell 7+ (для ConvertFrom-Yaml) та доступ до файлів у цій же теці.
#>

[CmdletBinding()]
param(
  [string]$Intent,        # capture_idea | fix_manifests | sync_registry | run_pipeline | report_kpi | guide_docs | plan_next | weekly_digest
  [switch]$DryRun,        # якщо можливо — виконати у безпечному режимі
  [switch]$Strict,        # якщо можливо — вмикати сувору валідацію
  [switch]$Confirm        # вимагати підтвердження перед виконанням дії
)

$ErrorActionPreference = "Stop"
$PSStyle.OutputRendering = "Ansi"

# --- Шляхи ---
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ToolsYaml  = Join-Path $ScriptRoot "MASTER_AGENT_TOOLS.yaml"
$MemoryJson = Join-Path $ScriptRoot "memory.json"
$PromptTxt  = Join-Path $ScriptRoot "MASTER_AGENT_PROMPT.txt"
$LogFile    = Join-Path $ScriptRoot "master-agent.log"

function Write-Log($msg) {
  $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $msg
  Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
}
function Note($text, $tags=@()) {
  try {
    if (-not (Test-Path -LiteralPath $MemoryJson)) {
      '{"notes":[],"goals":[],"rituals":[],"milestones":[]}' | Out-File -LiteralPath $MemoryJson -Encoding UTF8
    }
    $mem = Get-Content -LiteralPath $MemoryJson -Raw -Encoding UTF8 | ConvertFrom-Json
    $mem.notes += [pscustomobject]@{
      timestamp = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssK")
      text      = $text
      tags      = $tags
    }
    ($mem | ConvertTo-Json -Depth 10 -Compress:$false) | Out-File -LiteralPath $MemoryJson -Encoding UTF8
  } catch {
    Write-Warning "Не вдалося оновити memory.json: $($_.Exception.Message)"
  }
}

function Read-Tools {
  if (-not (Test-Path -LiteralPath $ToolsYaml)) {
    throw "Не знайдено MASTER_AGENT_TOOLS.yaml ($ToolsYaml)"
  }
  $yaml = Get-Content -LiteralPath $ToolsYaml -Raw -Encoding UTF8 | ConvertFrom-Yaml
  return $yaml.intents
}

function Show-Menu($intents) {
  Write-Host ""
  Write-Host "🤝 Master-Agent (CREATOR_SUITE)" -ForegroundColor Cyan
  Write-Host "Оберіть дію:"
  for ($i=0; $i -lt $intents.Count; $i++) {
    "{0,2}. {1}  — {2}" -f ($i+1), $intents[$i].name, $intents[$i].description | Write-Host
  }
  Write-Host ""
  $sel = Read-Host "Введіть номер або ім'я інтенту"
  if ($sel -match '^\d+$') {
    $idx = [int]$sel - 1
    if ($idx -ge 0 -and $idx -lt $intents.Count) { return $intents[$idx].name }
    else { return $null }
  }
  return $sel
}

function Prepare-Command($intentObj) {
  if ($null -eq $intentObj.command) { return $null }

  $cmd = [string]$intentObj.command

  # Обробка прапорів Strict/DryRun якщо вони доречні
  if ($PSBoundParameters.ContainsKey('Strict') -and $Strict) {
    # якщо у команді немає -Strict, додамо в кінець
    if ($cmd -notmatch '(\s|-|`)Strict(\s|$)') {
      $cmd = $cmd.Trim() + " `n  -Strict"
    }
  }
  if ($PSBoundParameters.ContainsKey('DryRun') -and $DryRun) {
    if ($cmd -match 'Sync-WorkshopCabinet\.ps1' -and $cmd -notmatch '(\s|-|`)DryRun(\s|$)') {
      $cmd = $cmd.Trim() + " `n  -DryRun"
    }
    if ($cmd -match 'pipeline\.ps1' -and $cmd -notmatch '(\s|-|`)DryRun(\s|$)') {
      $cmd = $cmd.Trim() + " `n  -DryRun"
    }
  }
  return $cmd
}

function Execute-Intent($intentName, $intents) {
  $obj = $intents | Where-Object { $_.name -eq $intentName } | Select-Object -First 1
  if (-not $obj) { throw "Невідомий інтент: $intentName" }

  Write-Host ""
  Write-Host ("→ {0}: {1}" -f $obj.name, $obj.description) -ForegroundColor Green

  $cmd = Prepare-Command -intentObj $obj
  if ($null -eq $cmd) {
    # без прямої команди — просто покажемо кроки/посилання
    if ($obj.steps) {
      Write-Host "Кроки:" -ForegroundColor Yellow
      $obj.steps | ForEach-Object { " - $_" | Write-Host }
    }
    if ($obj.links) {
      Write-Host "Корисні документи:" -ForegroundColor Yellow
      $obj.links | ForEach-Object { " - $_" | Write-Host }
    }
    Note ("Запущено намір: $($obj.name)") @("intent",$obj.name)
    return
  }

  Write-Host ""
  Write-Host "Команда до виконання:" -ForegroundColor Yellow
  Write-Host $cmd

  if ($Confirm) {
    $ans = Read-Host "Виконати? (Y/N)"
    if ($ans -notin @("Y","y","Так","так","T","t")) {
      Write-Host "Скасовано."
      Note ("Скасовано намір: $($obj.name)") @("intent","cancel")
      return
    }
  }

  Write-Log ("RUN {0}" -f ($obj.name))
  try {
    # Виконаємо у поточному процесі PowerShell
    # Використовуємо -Command, щоб розумів переноси з бектиками
    $exec = pwsh -NoProfile -NonInteractive -Command $cmd 2>&1
    Write-Host ""
    Write-Host "Вивід команди:" -ForegroundColor Yellow
    $exec | ForEach-Object { $_ | Write-Host }

    Note ("Виконано намір: {0}" -f $obj.name) @("intent","run",$obj.name)
    Write-Log ("OK  {0}" -f ($obj.name))
  }
  catch {
    $msg = $_.Exception.Message
    Write-Host "Помилка: $msg" -ForegroundColor Red
    Write-Log ("ERR {0} -> {1}" -f ($obj.name), $msg)
    Note ("Помилка наміру: {0}: {1}" -f $obj.name, $msg) @("intent","error",$obj.name)
  }
}

# --- Головний потік ---
try {
  $intents = Read-Tools

  if (-not $Intent -or [string]::IsNullOrWhiteSpace($Intent)) {
    $Intent = Show-Menu -intents $intents
  }

  if (-not $Intent) { Write-Host "Не обрано інтент. Вихід." ; exit 0 }

  Execute-Intent -intentName $Intent -intents $intents
}
catch {
  Write-Host "Фатальна помилка: $($_.Exception.Message)" -ForegroundColor Red
  Write-Log ("FATAL " + $_.Exception.Message)
  exit 1
}

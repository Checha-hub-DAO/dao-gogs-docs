
# CREATOR SUITE — Майстерня + Кабінет (Світ Ч)

## Структура після розпакування в `D:\CHECHA_CORE\`
```
D:\CHECHA_CORE\
 ├─ WORKSHOP_CREATOR\
 └─ CABINET_CREATOR\
```

## Перехід між просторами
- З Майстерні в Кабінет: посилання у `WORKSHOP.md` → **Кабінет Творця (Інститут Світу)**
- Із Кабінету назад у Майстерню: портал у `CABINET.md` → `../WORKSHOP_CREATOR/WORKSHOP.md`

## Запуск із прапорцем Кабінету
```powershell
.\WORKSHOP_CREATOR\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -EnterCabinet
```

## Рекомендований стартовий профіль
```powershell
.\WORKSHOP_CREATOR\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -Profile DailyStart -EnterCabinet
```

**Підпис:** С.Ч.

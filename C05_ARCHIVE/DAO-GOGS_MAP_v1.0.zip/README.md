# DAO-GOGS_MAP v1.0 — README

## 📦 Склад пакета
- `DAO-GOGS_MAP.md` — текстова легенда зв’язків DAO-GOGS.
- `DAO-GOGS_MAP_with_image.md` — легенда + вбудована карта (зображення).
- `DAO-GOGS_MAP.png` — візуальна схема у високій якості.
- `CHECKSUMS.txt` — контрольні суми SHA256 для перевірки цілісності.
- `Validate-DAO-GOGS_MAP.ps1` — PowerShell-скрипт для автоматичної перевірки.

## 🧪 Перевірка архіву
Для перевірки контрольних сум та (опційного) розпакування використовуйте скрипт:

```powershell
# Лише перевірка цілісності
pwsh -NoProfile -File "Validate-DAO-GOGS_MAP.ps1" `
  -ZipPath "C:\CHECHA_CORE\C12\Vault\ARCHIVE\DAO-GOGS_MAP_v1.0.zip"

# Перевірка + розпакування у цільову теку
pwsh -NoProfile -File "Validate-DAO-GOGS_MAP.ps1" `
  -ZipPath "C:\CHECHA_CORE\C12\Vault\ARCHIVE\DAO-GOGS_MAP_v1.0.zip" `
  -TargetDir "C:\CHECHA_CORE\C12\Vault\DAO-GOGS_MAP\v1.0"
```

## 🔑 Exit codes
- `0` — OK (успішна перевірка, якщо TargetDir вказано — також успішне розпаковування)
- `1` — ZIP не знайдено
- `2` — CHECKSUMS.txt відсутній у ZIP
- `3` — Помилка читання CHECKSUMS.txt
- `4` — Файл із CHECKSUMS.txt відсутній у ZIP
- `5` — SHA256 не співпав
- `6` — Помилка розпаковування

## 📂 Інтеграція
Скрипт `Validate-DAO-GOGS_MAP.ps1` можна викликати з вашого основного `Validate-Releases.ps1`, 
додавши блок для архівів виду `DAO-GOGS_MAP_v*.zip`.

---
© DAO-GOGS | С.Ч.

# Архів + SHA256

Кожен реліз DAO-MEDIA архівується у форматі zip.  
До кожного додається контрольна сума SHA256.

## Приклад
- `DAO-MEDIA_FACADE_v1.0.zip`  
  SHA256: `8f6a2a9c1b3e4...`
- `DAO-MEDIA_FACADE_v1.1.zip`  
  SHA256: `2c1b4e95a9d11...`

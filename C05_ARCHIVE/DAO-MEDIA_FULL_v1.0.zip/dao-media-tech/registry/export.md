# export.yaml (DAO-MEDIA)

```yaml
module: G35
exports:
  - id: g35-campaigns
    targets: [dao-media]
  - id: g35-digest
    targets: [dao-media]
  - id: g35-feedback
    targets: [dao-media]
```

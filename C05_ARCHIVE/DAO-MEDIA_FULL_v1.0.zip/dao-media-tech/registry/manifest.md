# MANIFEST.yml (DAO-MEDIA)

```yaml
module: G35
name: "DAO-MEDIA"
role: "Медіа-кампанії, дайджести, фідбек"
status: active
exports:
  - id: g35-campaigns
    title: "Кампанії"
    path: dao-media/campaigns/_index.md
  - id: g35-digest
    title: "Дайджести"
    path: dao-media/digest/_index.md
  - id: g35-feedback
    title: "Медіа-фідбек"
    path: dao-media/feedback/_index.md
```

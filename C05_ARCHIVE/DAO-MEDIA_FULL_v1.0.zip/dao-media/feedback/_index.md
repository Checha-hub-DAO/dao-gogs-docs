# Медіа-фідбек

✍️ [Залишити відгук](https://docs.google.com/forms/d/e/1FAIpQLScxyZCxVCaN2TDivUlyZAqPZB2JN1PK4ME6H3_XlN8zinCyIg/viewform?usp=header)  
📊 [Переглянути метрики](https://lookerstudio.google.com/reporting/09a80032-aa5a-4388-a511-9139781439e4)

## Як працює система
- Форма збирає відгуки (коментарі, ідеї, зауваження).  
- Дашборд аналізує динаміку (позитив/негатив, охоплення).  
- Команда DAO-MEDIA відповідає у межах **72 год**.  

➡️ Повернутись до [DAO-MEDIA](../_index.md)

# Summary (EN)

* [Adaptive Presentation](adaptive_presentation/README.md)
  * [Diagram](adaptive_presentation/diagram.md)
* [StyleGuide](styleguide/README.md)
* [Report](report/README.md)

---
📌 English mirror for DAO-MEDIA Root navigation.

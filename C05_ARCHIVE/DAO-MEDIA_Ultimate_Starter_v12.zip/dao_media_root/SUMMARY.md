# Summary

* [Adaptive Presentation](adaptive_presentation/README.md)
* [StyleGuide](styleguide/README.md)
* [Report](report/README.md)
  * [Report 2025-09-26](report/REPORT_2025-09-26_UA.md)

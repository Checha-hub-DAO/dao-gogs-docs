# 🗺️ Лінія часу — DAO-MEDIA Report

> Шаблон тижневого звіту: [WEEKLY_REPORT_TEMPLATE_UA.md](templates/WEEKLY_REPORT_TEMPLATE_UA.md)  
> Шаблон місячного звіту: [MONTHLY_REPORT_TEMPLATE_UA.md](templates/MONTHLY_REPORT_TEMPLATE_UA.md)

```mermaid
timeline
  title DAO-MEDIA Report Timeline (UA)
  2025-09-26 : Report 2025-09-26 (старт публікацій)
  2025-10-03 : Weekly Report (план) — див. шаблон
  2025-10-10 : Weekly Report (план) — див. шаблон
  2025-10-31 : Monthly Report (жовтень 2025, план) — див. шаблон
```

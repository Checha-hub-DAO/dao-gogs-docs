```mermaid
flowchart TD
  Root([DAO-MEDIA Root EN])
  AP_EN[Adaptive Presentation EN]
  Style_EN[StyleGuide EN]
  Report_EN[Report EN]

  Root --> AP_EN
  Root --> Style_EN
  Root --> Report_EN

  AP_EN --> PDF_EN[PDF (EN)]
  AP_EN --> Cover_EN[Cover (EN)]
  AP_EN --> Diagram_EN[Diagram (EN)]
```
# 🗺️ Лінія часу — DAO-MEDIA Report

> Шаблон тижневого звіту: [WEEKLY_REPORT_TEMPLATE_UA.md](templates/WEEKLY_REPORT_TEMPLATE_UA.md)  
> Шаблон місячного звіту: [MONTHLY_REPORT_TEMPLATE_UA.md](templates/MONTHLY_REPORT_TEMPLATE_UA.md)

```mermaid
timeline
  title DAO-MEDIA Report Timeline (UA)
  2025-09-26 : Report 2025-09-26 (старт публікацій)
  2025-10-03 : Weekly Report (готовий)
  2025-10-10 : Weekly Report (чернетка)
  2025-10-17 : Weekly Report (чернетка)
  2025-10-24 : Weekly Report (чернетка)
  2025-10-31 : Monthly Report (жовтень 2025, план)
  2025-11-07 : Weekly Report (чернетка)
  2025-11-14 : Weekly Report (чернетка)
  2025-11-21 : Weekly Report (чернетка)
  2025-11-28 : Weekly Report (чернетка)
  2025-12-05 : Weekly Report (чернетка)
  2025-12-12 : Weekly Report (чернетка)
  2025-12-19 : Weekly Report (чернетка)
  2025-12-26 : Weekly Report (чернетка)
  2025-12-31 : Monthly Report (грудень 2025, план)
  2026-01-02 : Weekly Report (чернетка)
  2026-01-09 : Weekly Report (чернетка)
  2026-01-16 : Weekly Report (чернетка)
  2026-01-23 : Weekly Report (чернетка)
  2026-01-30 : Weekly Report (чернетка)
  2026-01-31 : Monthly Report (січень 2026, план)
```

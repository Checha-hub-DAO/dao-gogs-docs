# DAO-MEDIA GitBook Install Package

Цей пакет містить повну структуру DAO-MEDIA Root для імпорту в GitBook.

## Вміст
- `dao_media_root/` — модулі DAO-MEDIA
  - `adaptive_presentation/` (README, PDF, cover, diagram)
  - `styleguide/` (README)
  - `report/` (README)
- `SUMMARY.md` — головна навігація GitBook
- `GitBook_SpaceSettings.json` — налаштування простору (назва, опис, теги, обкладинка)

## Інструкція з імпорту
1. Увійди у свій GitBook.
2. Створи новий **Space** (наприклад: `DAO-MEDIA Root`).
3. В меню **Import** обери **Markdown (.zip)**.
4. Завантаж цей архів.
5. GitBook автоматично підтягне:
   - `SUMMARY.md` для побудови навігації
   - `GitBook_SpaceSettings.json` для налаштувань (назва, опис, видимість, cover).

## Примітка
Після імпорту можна додавати нові модулі в `dao_media_root/` та оновлювати `SUMMARY.md` для розширення DAO-MEDIA.

---
Автор: Сергій Чеча (С.Ч.)

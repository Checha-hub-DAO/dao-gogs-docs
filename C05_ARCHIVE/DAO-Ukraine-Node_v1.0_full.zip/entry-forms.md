# DAO-Ukraine Node | Entry Forms

🧭 **Лідери**
- Форма: DAO-FORM-LEADER-2025-UA  
- Таблиця: Leader Responses  

🤝 **Партнери**
- Форма: DAO-FORM-PARTNER-2025-UA  
- Таблиця: Partner Responses  

🌱 **Молодь**
- Форма: DAO-FORM-YOUTH-2025-UA  
- Таблиця: Youth Responses  

⚙️ **Інтеграція**
- Всі відповіді автоматично зберігаються у Google Sheets.  
- Дані синхронізуються з DAO-JOURNAL.  
- План: підключення авто-сповіщень у Telegram-бот DAO-G13.  

✍️ С.Ч. | DAO-GOGS


# 📥 HOWTO_IMPORT.md — Інструкція імпорту в GitBook

Цей документ описує кроки, як завантажити та правильно розмістити пакет **DAO-GOGS Summaries 2025** у GitBook.

---

## 1. Підготовка
1. Завантаж архів: `DAO_GOGS_GITBOOK_READY_2025_FINAL_FULL.zip`
2. Розпакуй його у робочу директорію.
3. Переконайся, що маєш доступ до GitBook workspace (`dao-gogs-main` або інший проєкт).

---

## 2. Імпорт в GitBook
1. У GitBook натисни **New Space** (або відкрий існуючий).
2. Обери **Import → Markdown**.
3. Завантаж увесь архів або основні файли.

GitBook автоматично:
- зчитає `SUMMARY.md` → побудує меню (**TOC**).
- підключить `README.md` як титульну сторінку.

---

## 3. Структура після імпорту
- 📂 Reports → Q3-2025, YEAR-2025, PDF
- 📂 ARCH → README, SUMMARY, Index-и, Maps, ASCII
- 📂 PNG_EXPORTS → резервні картинки

---

## 4. Налаштування
- Встанови `README.md` як **Home page**.
- Mermaid-карти (`MERMAID_MAP_2025.md`, `MEGA_MERMAID_MAP_2024_2025.md`) GitBook рендерить напряму.
- PNG-резерви можна вставити у сторінки або тримати як fallback.
- PDF додай у розділ **Downloads**.

---

## 5. Рекомендації
- Додай логотип DAO-GOGS у верхню частину простору GitBook.
- Використовуй Mermaid-карти для інтерактивної навігації.
- Використовуй PNG та ASCII fallback для архівів і офлайн.

---

✍️ Автор: Сергій Чеча (С.Ч.)
📅 Версія: 2025-Q3 + YEAR

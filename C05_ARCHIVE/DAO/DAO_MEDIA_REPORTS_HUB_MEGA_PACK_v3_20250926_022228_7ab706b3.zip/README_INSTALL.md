# 🚀 DAO-MEDIA Reports Hub | Інструкція інтеграції в GitBook

## 1. Розміщення файлів
З архіву `DAO_MEDIA_REPORTS_HUB_MEGA_PACK.zip` потрібно додати у GitBook:

```
dao_media_root/
  reports/
    REPORTS_HUB.md
    REPORTS_HUB_EN.md
  SUMMARY.md
  SUMMARY_DAO.md
  SUMMARY_EN.md
  analytics/
    ANALYTICS_BANNER.png
    ANALYTICS_BANNER_EN.png
    ANALYTICS_ICON.png
    MONTHLY_BANNER.png
    MONTHLY_BANNER_EN.png
    MONTHLY_ICON.png
```

---

## 2. Навігація
- Використовуй `SUMMARY.md` (базова), `SUMMARY_DAO.md` (DAO-стиль) або `SUMMARY_EN.md` (EN).  
- У GitBook залиш лише один активний SUMMARY.

---

## 3. Reports Hub
1. Додай `REPORTS_HUB.md` (UA) та `REPORTS_HUB_EN.md` (EN) у `reports/`.  
2. У SUMMARY додай посилання:
   ```markdown
   * [📊 Reports Hub](reports/REPORTS_HUB.md)
   * [📊 Reports Hub (EN)](reports/REPORTS_HUB_EN.md)
   ```

---

## 4. Візуали
- Банери можна використати як **обкладинки сторінок**.  
- Іконку (`ANALYTICS_ICON.png`) — як **favicon** або маркер у підрозділах.

---

## 5. Автоматичне оновлення
- Використовуй `Run-Reports.ps1 -PushToGitBook`.  
- Звіти (`REPORT_weekly_AUTO_*.md`, `REPORT_monthly_AUTO_*.md`) будуть генеруватись і пушитись автоматично.  
- Reports Hub підтягне їх через відносні посилання.

---

## ✅ Практика
- 📅 Щотижня: Weekly Report.  
- 🗓 Щомісяця: Monthly Report.  
- 🌐 Після генерації — пуш у GitBook.

---

🔮 *Reports Hub — це живий портал прозорості DAO-MEDIA.*  

_S.Ч._
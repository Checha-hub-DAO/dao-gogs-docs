# ✅ DAO-MEDIA Reports Hub | CheckList оновлення

## 1. Підготовка даних
- [ ] Експортувати `weekly_metrics.csv` із Looker Studio (щотижня).  
- [ ] Експортувати `monthly_summary.csv` (на початку місяця).  
- [ ] (Опційно) оновити `kpi_dashboard.csv`.  
- [ ] Скопіювати CSV у папку:  
  ```
  dao_media_root/report/analytics/
  ```

---

## 2. Генерація звітів
- [ ] Запустити **Weekly Report**:
  ```powershell
  python D:\CHECHA_CORE\TOOLS\GenerateWeeklyReport.py --analytics-dir ... --locale ua
  python D:\CHECHA_CORE\TOOLS\GenerateWeeklyReport.py --analytics-dir ... --locale en
  ```
- [ ] Запустити **Monthly Report**:
  ```powershell
  python D:\CHECHA_CORE\TOOLS\GenerateMonthlyReport.py --analytics-dir ... --locale ua
  python D:\CHECHA_CORE\TOOLS\GenerateMonthlyReport.py --analytics-dir ... --locale en
  ```
- [ ] Перевірити наявність файлів:
  - `REPORT_weekly_AUTO_UA.md`, `REPORT_weekly_AUTO_EN.md`
  - `REPORT_monthly_AUTO_UA.md`, `REPORT_monthly_AUTO_EN.md`
  - Графіки PNG (UA/EN).

---

## 3. Автоматизація (опція)
- [ ] Запустити:
  ```powershell
  .\Run-Reports.ps1 -Config "D:\CHECHA_CORE\reports.config.json" -PushToGitBook
  ```
- [ ] Переконатися, що логи (`reports_YYYYMMDD_HHMMSS.log`) не містять помилок.

---

## 4. Оновлення GitBook
- [ ] Reports Hub (UA/EN) підтягнув нові звіти.  
- [ ] Графіки відображаються коректно.  
- [ ] Візуали (банери/іконки) доступні у сторінках.  
- [ ] SUMMARY.md/DAO/EN ведуть у правильні розділи.  

---

## 5. Фінальна перевірка
- [ ] Weekly і Monthly сторінки відкриваються.  
- [ ] Charts читаються.  
- [ ] KPI блок оновився.  
- [ ] Reports Hub синхронізований з останніми даними.  

---

🔮 *CheckList допомагає утримувати ритм: дані → звіт → публікація → довіра.*  

_S.Ч._
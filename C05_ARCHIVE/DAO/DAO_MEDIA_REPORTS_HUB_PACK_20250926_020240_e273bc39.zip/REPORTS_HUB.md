# 📊 DAO-MEDIA | Reports Hub

*Центральний вузол прозорості DAO-MEDIA. Тут зібрані всі щотижневі та щомісячні звіти, KPI та візуальні матеріали.*  

---

## 🌐 Призначення
- Забезпечення **прозорості** для учасників і партнерів.  
- Відображення **динаміки зростання та охоплення**.  
- Формування **довіри та ритму розвитку** спільноти.  

---

## 📅 Щотижневі звіти
- [REPORT_weekly_AUTO_UA.md](../report/REPORT_weekly_AUTO_UA.md) 🇺🇦  
- [REPORT_weekly_AUTO_EN.md](../report/REPORT_weekly_AUTO_EN.md) 🇬🇧  

📈 Графіки:  
- ![](../report/analytics/weekly_reach_UA.png)  
- ![](../report/analytics/weekly_reach_EN.png)  

---

## 🗓 Щомісячні звіти
- [REPORT_monthly_AUTO_UA.md](../report/REPORT_monthly_AUTO_UA.md) 🇺🇦  
- [REPORT_monthly_AUTO_EN.md](../report/REPORT_monthly_AUTO_EN.md) 🇬🇧  

📊 Графіки:  
- ![](../report/analytics/monthly_reach_UA.png)  
- ![](../report/analytics/monthly_reach_EN.png)  

---

## 📂 Джерела даних
- `weekly_metrics.csv` — тижневі дані.  
- `monthly_summary.csv` — місячні зрізи.  
- `kpi_dashboard.csv` — KPI-дашборд (опційно).  

🔗 *Дані надходять із Looker Studio, експортуються у CSV та підвантажуються у систему.*  

---

## 🎨 Візуали
- ![](../report/analytics/ANALYTICS_BANNER.png)  
- ![](../report/analytics/MONTHLY_BANNER.png)  

📦 Повні комплекти:  
- [DAO_MEDIA_ALL_VISUALS.zip](../report/analytics/DAO_MEDIA_ALL_VISUALS.zip)  
- [DAO_MEDIA_ALL_VISUALS_SVG.zip](../report/analytics/DAO_MEDIA_ALL_VISUALS_SVG.zip)  
- [DAO_MEDIA_ALL_VISUALS.pdf](../report/analytics/DAO_MEDIA_ALL_VISUALS.pdf)  
- [DAO_MEDIA_ALL_VISUALS.pptx](../report/analytics/DAO_MEDIA_ALL_VISUALS.pptx)  

---

## ✅ Практика DAO-MEDIA
- Щонеділі — Weekly Report.  
- На початку місяця — Monthly Report.  
- Візуали DAO-MEDIA роблять звіти **легкими для сприйняття й поширення**.  

---

🔮 *Reports Hub — це портал довіри, де дані стають історією розвитку.*  

_S.Ч._
# 🗂️ INDEX_2025 — Каталог звітів (W/M/Q/Y)

```mermaid
flowchart TB
  subgraph YEAR_2025[2025]
    direction TB

    subgraph QUARTERS[Квартали]
      Q1[QUARTER_SUMMARY_2025-Q1.md]
      Q2[QUARTER_SUMMARY_2025-Q2.md]
      Q3[QUARTER_SUMMARY_2025-Q3.md]
      Q4[QUARTER_SUMMARY_2025-Q4.md]
    end

    subgraph MONTHS[Місяці]
      M01[MONTH_SUMMARY_2025-M01.md]; M02[MONTH_SUMMARY_2025-M02.md]; M03[MONTH_SUMMARY_2025-M03.md]; M04[MONTH_SUMMARY_2025-M04.md]; M05[MONTH_SUMMARY_2025-M05.md]; M06[MONTH_SUMMARY_2025-M06.md]; M07[MONTH_SUMMARY_2025-M07.md]; M08[MONTH_SUMMARY_2025-M08.md]; M09[MONTH_SUMMARY_2025-M09.md]; M10[MONTH_SUMMARY_2025-M10.md]; M11[MONTH_SUMMARY_2025-M11.md]; M12[MONTH_SUMMARY_2025-M12.md]
    end

    subgraph WEEKS[Тижні]
      
    end
  end

  Q1:::q --> M01 & M02 & M03
  Q2:::q --> M04 & M05 & M06
  Q3:::q --> M07 & M08 & M09
  Q4:::q --> M10 & M11 & M12
```

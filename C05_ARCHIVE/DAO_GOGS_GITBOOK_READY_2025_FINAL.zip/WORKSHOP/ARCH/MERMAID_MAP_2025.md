# 🗂️ MERMAID_MAP_2025 — Ключові вузли (Q3 + YEAR)

```mermaid
flowchart TB
  subgraph YEAR_2025[2025]
    direction TB

    Q1[QUARTER_SUMMARY_2025-Q1.md]
    Q2[QUARTER_SUMMARY_2025-Q2.md]
    Q3[**QUARTER_SUMMARY_2025-Q3.md**]
    Q4[QUARTER_SUMMARY_2025-Q4.md]

    Y2025[**YEAR_SUMMARY_2025.md**]
  end

  Q1 --> Q2 --> Q3 --> Q4 --> Y2025
  Q3 ==> Y2025
```

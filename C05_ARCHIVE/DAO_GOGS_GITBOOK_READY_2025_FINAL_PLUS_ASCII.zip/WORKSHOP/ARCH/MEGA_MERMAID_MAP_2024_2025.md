# 🗂️ MEGA_MERMAID_MAP — 2024–2025 (активні вузли: Q3-2025, YEAR-2025)

```mermaid
flowchart TB
  %% ===== 2024 =====
  subgraph YEAR_2024[2024]
    direction TB
    Q24_1[QUARTER_SUMMARY_2024-Q1.md]
    Q24_2[QUARTER_SUMMARY_2024-Q2.md]
    Q24_3[QUARTER_SUMMARY_2024-Q3.md]
    Q24_4[QUARTER_SUMMARY_2024-Q4.md]
    Y2024[YEAR_SUMMARY_2024.md]
  end

  %% ===== 2025 =====
  subgraph YEAR_2025[2025]
    direction TB
    Q25_1[QUARTER_SUMMARY_2025-Q1.md]
    Q25_2[QUARTER_SUMMARY_2025-Q2.md]
    Q25_3[**QUARTER_SUMMARY_2025-Q3.md**]
    Q25_4[QUARTER_SUMMARY_2025-Q4.md]
    Y2025[**YEAR_SUMMARY_2025.md**]
  end

  %% ===== Flows =====
  YEAR_2024 --> YEAR_2025
  Q24_4 --> Q25_1
  Q25_1 --> Q25_2 --> Q25_3 --> Q25_4 --> Y2025
  Q25_3 ==> Y2025
  Y2024 -. контекст .-> Y2025

  %% Legend
  classDef active stroke-width:3px,stroke-dasharray: 0,stroke:#000,fill-opacity:0.1;
  class Q25_3,Y2025 active;
```

# 📊 DAO-MEDIA | Reports Hub (EN)

*The central transparency hub of DAO-MEDIA. Here you will find all weekly and monthly reports, KPIs, and visual materials.*  

---

## 🌐 Purpose
- Ensure **transparency** for members and partners.  
- Display the **growth and reach dynamics**.  
- Build **trust and rhythm of development** within the community.  

---

## 📅 Weekly Reports
- [REPORT_weekly_AUTO_UA.md](../report/REPORT_weekly_AUTO_UA.md) 🇺🇦  
- [REPORT_weekly_AUTO_EN.md](../report/REPORT_weekly_AUTO_EN.md) 🇬🇧  

📈 Charts:  
- ![](../report/analytics/weekly_reach_UA.png)  
- ![](../report/analytics/weekly_reach_EN.png)  

---

## 🗓 Monthly Reports
- [REPORT_monthly_AUTO_UA.md](../report/REPORT_monthly_AUTO_UA.md) 🇺🇦  
- [REPORT_monthly_AUTO_EN.md](../report/REPORT_monthly_AUTO_EN.md) 🇬🇧  

📊 Charts:  
- ![](../report/analytics/monthly_reach_UA.png)  
- ![](../report/analytics/monthly_reach_EN.png)  

---

## 📂 Data Sources
- `weekly_metrics.csv` — weekly metrics.  
- `monthly_summary.csv` — monthly snapshots.  
- `kpi_dashboard.csv` — KPI dashboard (optional).  

🔗 *Data is sourced from Looker Studio, exported as CSV, and loaded into the system.*  

---

## 🎨 Visuals
- ![](../report/analytics/ANALYTICS_BANNER_EN.png)  
- ![](../report/analytics/MONTHLY_BANNER_EN.png)  

📦 Full packages:  
- [DAO_MEDIA_ALL_VISUALS.zip](../report/analytics/DAO_MEDIA_ALL_VISUALS.zip)  
- [DAO_MEDIA_ALL_VISUALS_SVG.zip](../report/analytics/DAO_MEDIA_ALL_VISUALS_SVG.zip)  
- [DAO_MEDIA_ALL_VISUALS.pdf](../report/analytics/DAO_MEDIA_ALL_VISUALS.pdf)  
- [DAO_MEDIA_ALL_VISUALS.pptx](../report/analytics/DAO_MEDIA_ALL_VISUALS.pptx)  

---

## ✅ DAO-MEDIA Practice
- Every Sunday — Weekly Report.  
- At the beginning of each month — Monthly Report.  
- DAO-MEDIA visuals make reports **easy to read and share**.  

---

🔮 *Reports Hub is the portal of trust, where data becomes the story of growth.*  

_S.Ч._
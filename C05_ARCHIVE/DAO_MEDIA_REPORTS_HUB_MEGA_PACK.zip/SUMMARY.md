# Table of Contents

* [🏠 Home](README.md)
* [📊 Reports Hub](reports/REPORTS_HUB.md)
  * [Weekly Report (UA)](report/REPORT_weekly_AUTO_UA.md)
  * [Weekly Report (EN)](report/REPORT_weekly_AUTO_EN.md)
  * [Monthly Report (UA)](report/REPORT_monthly_AUTO_UA.md)
  * [Monthly Report (EN)](report/REPORT_monthly_AUTO_EN.md)
# Summary

* [G35 — DAO-Медіа](README.md)

## Публічний фасад
* [Огляд](dao-media/_index.md)
* [Кампанії](dao-media/campaigns/_index.md)
* [Дайджести](dao-media/digest/_index.md)
* [Медіа-фідбек](dao-media/feedback/_index.md)
* [Media-kit](dao-media/kit/_index.md)

## Робочі документи
* [Контент-календар](docs/dao-media-calendar.md)
* [Шаблон поста](docs/dao-post-template.md)
* [Форма фідбеку](docs/dao-media-feedback-2025-06.md)
* [Медіа-трекер](docs/dao-media-tracker.md)
* [Візуали](docs/dao-media-visuals.md)
* [Media-kit набір](docs/dao-media-kit.md)
* [Процес публікацій](docs/dao-media-process.md)

## MEDIA-BLOCK-CORE
* [PACK-1](dao-media-block/pack-1.md)
* [PACK-2](dao-media-block/pack-2.md)
* [PACK-3](dao-media-block/pack-3.md)
* [PACK-4](dao-media-block/pack-4.md)
* [PACK-5](dao-media-block/pack-5.md)

## DAO-MEDIA-REFERENCE
* [Zolkin](dao-media-reference/zolkin.md)
* [Tygr](dao-media-reference/tygr.md)
* [Ragulivna](dao-media-reference/ragulivna.md)
* [Sternenko](dao-media-reference/sternenko.md)
* [Gordon](dao-media-reference/gordon.md)
* [Perun](dao-media-reference/perun.md)
* [Bihus.Info](dao-media-reference/bihus.md)
* [Ukraїner](dao-media-reference/ukrainer.md)
* [Denys Davydov](dao-media-reference/denys-davydov.md)

## Feedback & Visuals
* [Фідбек](feedback/index.md)
* [Візуальна карта CORE-15](visuals/media-core-15.svg)
* [Мапа референсів](visuals/reference-map.png)

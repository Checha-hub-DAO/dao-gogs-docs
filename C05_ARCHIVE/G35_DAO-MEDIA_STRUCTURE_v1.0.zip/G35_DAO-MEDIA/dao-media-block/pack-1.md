# PACK-1 — Фактчекінг та безпека
- VoxCheck, StopFake, Detector Media
Фокус: боротьба з пропагандою та фейками.

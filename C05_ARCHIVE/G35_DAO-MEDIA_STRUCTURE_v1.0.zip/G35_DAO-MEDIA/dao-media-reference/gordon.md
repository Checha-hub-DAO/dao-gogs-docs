# DAO-MEDIA-REFERENCE — Gordon
Довгі інтерв’ю з ключовими особами; спірна репутація.

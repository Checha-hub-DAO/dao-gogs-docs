# DAO-MEDIA-REFERENCE — Ragulivna
Культурна іронія, критика ілюзій, резонанс у соцмережах.

# DAO-MEDIA-REFERENCE — Zolkin
Документування війни, свідчення, висока довіра.

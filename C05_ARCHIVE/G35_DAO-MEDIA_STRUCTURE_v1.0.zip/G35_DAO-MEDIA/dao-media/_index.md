# DAO-MEDIA — публічний фасад

DAO-MEDIA — це комунікаційна система ГОГС.
Фокус: **кампанії, дайджести, фідбек, медіа-набір**.

➡️ [Кампанії](./campaigns/_index.md)
➡️ [Дайджести](./digest/_index.md)
➡️ [Медіа-фідбек](./feedback/_index.md)
➡️ [Media-kit](./kit/_index.md)

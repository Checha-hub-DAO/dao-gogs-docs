# G45 SHIELD — Quick Start
**Модуль:** G45 — Код Захисту  
**Статус:** Активовано · Версія: v1.3.1 (2025-09-25)  

---

## 🎯 Мета
SHIELD забезпечує **перевірку цілісності релізних архівів G45** за допомогою SHA‑256.  
Мета: уникнення підробок, помилок і втрати довіри.

## 📦 Файли
- `SHIELD/verify_sha256.sh` — скрипт для Linux/macOS.  
- `SHIELD/verify_sha256.ps1` — скрипт для Windows (PowerShell).  
- `SHIELD/POLICY.md` — політика перевірки цілісності.  
- `CHECKSUMS.txt` — контрольні суми для релізів.

## 🚀 Використання
### Linux/macOS
```bash
cd /шлях/до/архіву
bash SHIELD/verify_sha256.sh G45_KodZakhystu_FullBranch_v1.3.1.zip
```

### Windows (PowerShell)
```powershell
Set-Location "C:\path\to\archive"
.\SHIELD\verify_sha256.ps1 -Archive G45_KodZakhystu_FullBranch_v1.3.1.zip
```

## 🔑 Принципи
- Алгоритм: SHA‑256 (публічний, перевіряється локально).  
- PoLP: мінімально необхідні права доступу.  
- Журналювання: дії користувача фіксуються локально.  
- Відсутність секретів: усі перевірки базуються лише на публічних файлах.

## ⚠️ Важливо
- SHIELD **не містить секретних ключів чи даних**.  
- У випадку інцидентів публікується нова версія архіву (vX.Y.Z) із оновленими CHECKSUMS.  

---
DAO-GOGS · G45 SHIELD · С.Ч.

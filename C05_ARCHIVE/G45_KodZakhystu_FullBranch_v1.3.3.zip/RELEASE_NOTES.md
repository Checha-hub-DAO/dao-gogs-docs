# Release Notes — G45 Код Захисту Full Branch
**Version:** g45-fullbranch-v1.3.2  
**Date:** 2025-09-25  
**Author:** С.Ч.  

## Зміни v1.3.2
- Додано `README_SHIELD.md` у корінь архіву (швидкий старт для перевірки).  
- Оновлено VERSION / CHECKSUMS під нову збірку.  

## Історія
### v1.3.1
- Додано модуль **SHIELD** (verify_sha256.sh / verify_sha256.ps1 / POLICY.md).  
- Вирівняно VERSION до v1.3.1, виправлено невідповідність v1.1.  
- CHECKSUMS оновлено під новий архів.  

### v1.3
- Додано структурну карту (PDF/PNG) у корінь архіву.

### v1.2
- Інтегровані релізні файли (VERSION / RELEASE_NOTES / CHECKSUMS) у корінь архіву.

### v1.1
- Початкове публічне складання гілки G45 (AOT + Ecosystem).

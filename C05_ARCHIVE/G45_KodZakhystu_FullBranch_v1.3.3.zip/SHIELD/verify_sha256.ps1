# G45 SHIELD: verify SHA-256 for an archive against CHECKSUMS.txt
param(
  [Parameter(Mandatory=$true)][string]$Archive
)
$sumFile = "CHECKSUMS.txt"
if (!(Test-Path $sumFile)) { Write-Error "CHECKSUMS.txt not found in current directory"; exit 2 }
if (!(Test-Path $Archive)) { Write-Error "Archive not found: $Archive"; exit 3 }
$declaredLine = (Select-String -Path $sumFile -Pattern ("  " + (Split-Path $Archive -Leaf) + "$")).Line
if (-not $declaredLine) { Write-Error "No declared checksum for $(Split-Path $Archive -Leaf)"; exit 4 }
$declared = $declaredLine.Split(" ", [System.StringSplitOptions]::RemoveEmptyEntries)[0]
$sha = [System.Security.Cryptography.SHA256]::Create()
$fs = [System.IO.File]::OpenRead($Archive)
try {
  $hashBytes = $sha.ComputeHash($fs)
} finally { $fs.Close() }
$calculated = -join ($hashBytes | ForEach-Object { $_.ToString("x2") })
if ($calculated -eq $declared) {
  Write-Host "OK: SHA-256 matches ($calculated)"
  exit 0
} else {
  Write-Error "MISMATCH: calculated=$calculated declared=$declared"
  exit 5
}

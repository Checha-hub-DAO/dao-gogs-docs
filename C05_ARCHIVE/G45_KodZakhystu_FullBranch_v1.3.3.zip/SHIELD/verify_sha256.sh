#!/usr/bin/env bash
# G45 SHIELD: verify SHA-256 for an archive against CHECKSUMS.txt
set -euo pipefail
if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <archive.zip>"
  exit 1
fi
ARCHIVE="$1"
SUM_FILE="CHECKSUMS.txt"
if [[ ! -f "$SUM_FILE" ]]; then
  echo "ERROR: $SUM_FILE not found in current directory"
  exit 2
fi
if command -v sha256sum >/dev/null 2>&1; then
  CALC=$(sha256sum "$ARCHIVE" | awk '{print $1}')
elif command -v shasum >/dev/null 2>&1; then
  CALC=$(shasum -a 256 "$ARCHIVE" | awk '{print $1}')
else
  echo "ERROR: sha256sum or shasum not found"
  exit 3
fi
DECL=$(grep "  $(basename "$ARCHIVE")$" "$SUM_FILE" | awk '{print $1}')
if [[ -z "$DECL" ]]; then
  echo "❌ No declared checksum for $(basename "$ARCHIVE") in $SUM_FILE"
  exit 4
fi
if [[ "$CALC" == "$DECL" ]]; then
  echo "✅ OK: SHA-256 matches ($CALC)"
  exit 0
else
  echo "❌ MISMATCH: calculated=$CALC declared=$DECL"
  exit 5
fi

# G45.1 — Anti-FPV Shield

## SOP
- Виявлення → сигнал → перехоплення

## KPI
- Реакція ≤ 15 с, успішність ≥ 60%


## Схема

![Anti-FPV Scheme](images/g45-1-sop.svg)

# G45.5a — Interceptor Stations

## SOP
- Енергія + сенсори + док-майданчик

## KPI
- Автопідйом ≤ 15 с, готовність ≥ 80%


## Схема

![Interceptor Stations Scheme](images/g45-5a-sop.svg)

# G45.5 — Swarm Air-Defense

## SOP
- Рій 5–10 дронів, ролі: атака/блок

## KPI
- Перехоплення ≥ 60%, автономія ≥ 10 хв


## Схема

![Swarm Air-Defense Scheme](images/g45-5-sop.svg)

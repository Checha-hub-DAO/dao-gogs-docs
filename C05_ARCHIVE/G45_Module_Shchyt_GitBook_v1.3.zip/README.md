# G45 — Модуль ЩИТ

![Main](images/G45_Final_Main_Dark.png)

**Модуль ЩИТ (G45)** — це багаторівнева система оборони, що виросла з ідеї Народного ППО.
Він охоплює дев’ять підмодулів, які разом формують повний щит: техніка, боєць, громада, енергетика, дані, медицина та право.

## Підмодулі
- [G45.1 — Anti-FPV Shield](g45-1-anti-fpv.md)
- [G45.2 — Psychological Shield](g45-2-psychological.md)
- [G45.3 — Community Defense](g45-3-community.md)
- [G45.4 — Digital & Cyber Shield](g45-4-digital-cyber.md)
- [G45.5 — Swarm Air-Defense](g45-5-swarm.md)
- [G45.5a — Interceptor Stations](g45-5a-interceptor-stations.md)
- [G45.6 — Energy Shield](g45-6-energy.md)
- [G45.7 — Training Shield](g45-7-training.md)
- [G45.8 — Medical Protection](g45-8-medical.md)
- [G45.9 — Ethical-Legal Shield](g45-9-ethical.md)
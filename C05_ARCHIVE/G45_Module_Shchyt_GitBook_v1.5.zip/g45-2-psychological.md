# G45.2 — Psychological Shield

## SOP
- Дихання 4-4-4-4, самоконтроль

## KPI
- 80% бійців знижують паніку


## Схема

![Psychological Scheme](images/g45-2-sop.svg)

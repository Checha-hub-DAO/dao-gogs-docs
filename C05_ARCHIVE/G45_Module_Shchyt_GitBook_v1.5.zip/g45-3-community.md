# G45.3 — Community Defense

## SOP
- Сигнал → укриття → сітки

## KPI
- Евакуація ≤ 3 хв, реакція ≤ 20 с


## Схема

![Community Defense Scheme](images/g45-3-sop.svg)

# G45.6 — Energy Shield

## SOP
- АКБ ≥ 80%, “тихі вікна”, EMP-бокс

## KPI
- Нуль відмов енергоживлення


## Схема

![Energy Shield Scheme](images/g45-6-sop.svg)

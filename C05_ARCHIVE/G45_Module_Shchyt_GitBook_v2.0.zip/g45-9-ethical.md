# G45.9 — Ethical-Legal Shield

## SOP
- Етичний чек-лист, журнал ризиків

## KPI
- 100% SOP-картки, 0 інцидентів


## Схема

![Ethical-Legal Scheme](images/g45-9-sop.svg)

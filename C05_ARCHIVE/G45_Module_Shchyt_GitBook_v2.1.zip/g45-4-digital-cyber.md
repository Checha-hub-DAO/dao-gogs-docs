# G45.4 — Digital & Cyber Shield

## SOP
- VPN, короткий ефір, кодові слова

## KPI
- 100% чисті пристрої, перехід ≤ 2 хв


## Схема

![Digital & Cyber Scheme](images/g45-4-sop.svg)

# G45.7 — Training Shield

## SOP
- Щоденні 5 хв дрилі, щотижневі тести

## KPI
- 80% вкладаються в 3 с, 1× VR/місяць


## Схема

![Training Shield Scheme](images/g45-7-sop.svg)

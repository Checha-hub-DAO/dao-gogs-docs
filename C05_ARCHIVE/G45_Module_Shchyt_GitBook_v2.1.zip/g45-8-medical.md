# G45.8 — Medical Protection

## SOP
- Self-aid → buddy-aid → evac

## KPI
- Турнікет ≤ 30 с, евакуація ≤ 2 хв


## Схема

![Medical Protection Scheme](images/g45-8-sop.svg)

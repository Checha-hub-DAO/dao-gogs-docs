# RELEASE_NOTES — G45 Package v2.2 (2025-09-08)

- Додано SOP + SVG для G45.3–G45.9.
- Додано розширення G45.5a Interceptor Stations (Народне ППО) з SOP + SVG.
- У складі: Anti-FPV Shield v1.1 (ZIP), карта G45_v2_Triangle.svg, README ядра v2.2.

Сумісність: GitBook / CHECHA_CORE Vault.

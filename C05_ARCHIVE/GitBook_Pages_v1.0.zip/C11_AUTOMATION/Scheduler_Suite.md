# Scheduler Suite — Автоматизація перевірки DAO-GOGS_MAP

**Автор:** С.Ч.  
**Дата:** 10.09.2025  
**Версія:** 1.0

---

## 🔎 Мета
Scheduler Suite забезпечує:
- регулярну (щотижневу та щомісячну) перевірку релізів `DAO-GOGS_MAP_v*.zip`,
- контроль цілісності через `CHECKSUMS.txt (SHA256)`,
- автоматичний запис у лог `C03\LOG\releases_validate.log`.

Це гарантує **надійність та відтворюваність системи DAO-GOGS**.

---

## 📦 Пакети
- **WeeklyScheduler_kit.zip**  
  Містить:
  - `Register-DAO-GOGS_MAP-Weekly.ps1` — реєстрація задачі.  
  - `Run-DAO-GOGS_MAP-Validation.ps1` — запуск перевірки.  
  - `Unregister-DAO-GOGS_MAP-Weekly.ps1` — видалення задачі.  
  - `INSTALL.md` — інструкція.  

- **MonthlyScheduler_kit.zip**  
  Містить:
  - `Register-DAO-GOGS_MAP-Monthly.ps1` — реєстрація задачі.  
  - `Unregister-DAO-GOGS_MAP-Monthly.ps1` — видалення задачі.  
  - `INSTALL.md` — інструкція.  
  - (*використовує той самий* `Run-DAO-GOGS_MAP-Validation.ps1` з Weekly).  

---

## ⚙️ Інсталяція

### 1. Розмістіть файли
- `Validate-DAO-GOGS_MAP.ps1` → `C:\CHECHA_CORE\C12\Vault\ARCHIVE\`  
- `Run-DAO-GOGS_MAP-Validation.ps1` → `C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\`  
- решта скриптів (`Register…`, `Unregister…`) → `C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\`

### 2. Реєстрація задач

#### Щотижнева (неділя 09:00)
```powershell
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Register-DAO-GOGS_MAP-Weekly.ps1"
```

Кастомні дні/час:
```powershell
pwsh -NoProfile -File "...\Register-DAO-GOGS_MAP-Weekly.ps1" `
  -DaysOfWeek Monday,Thursday -Hour 10 -Minute 30
```

#### Щомісячна (1-го числа 09:00)
```powershell
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Register-DAO-GOGS_MAP-Monthly.ps1"
```

Кастомний день/час:
```powershell
pwsh -NoProfile -File "...\Register-DAO-GOGS_MAP-Monthly.ps1" `
  -Day 1 -Hour 9 -Minute 0
```

---

## 🧪 Запуск вручну
```powershell
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Run-DAO-GOGS_MAP-Validation.ps1"
```

---

## 🗑 Видалення задач
```powershell
# Weekly
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Unregister-DAO-GOGS_MAP-Weekly.ps1"

# Monthly
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Unregister-DAO-GOGS_MAP-Monthly.ps1"
```

---

## 📂 Логування
Усі результати пишуться у:
```
C:\CHECHA_CORE\C03\LOG\releases_validate.log
```

Формат:  
`YYYY-MM-DD HH:MM:SS [INFO|WARN|ERROR] Повідомлення`

---

## 🔑 Переваги
- Автоматичний аудит релізів DAO-GOGS.  
- Просте керування (Register / Unregister).  
- Уніфікований лог для всієї системи.  
- Гнучкий розклад (DaysOfWeek / Day, Hour, Minute).  

---

© DAO-GOGS | С.Ч.

# DAO-GOGS — Карта системи та валідація релізів

**Версія:** v1.0  
**Автор:** С.Ч.  
**Дата:** 10.09.2025

## Огляд
Ця сторінка містить:
- візуальну **карту головних блоків** (C-ядро + G-модулі + ЩИТ-вузли),
- **легенду зв’язків**,
- інструкції з **перевірки цілісності релізів** (SHA256),
- **автоматизацію** щотижневої і щомісячної перевірки через Планувальник Windows.

---

## 1) Візуальна карта

> Якщо вже завантажив у GitBook — встав зображення з медіатеки.  
> Тимчасові файли (для завантаження і локальної роботи):
- **PNG схема:** `DAO-GOGS_MAP.png`  
- **Markdown з легендою + вбудованою схемою:** `DAO-GOGS_MAP_with_image.md`

**Структура:**
- **C-блоки (C01–C12)** — внутрішня логіка та смисли (ядро CHECHA_CORE).
- **G-модулі (DAO-GOGS)** — напрямки розвитку та дії (G01–G12 базові; G23 Молодь; G35 Медіа; G37 Віднови Життя; G42 GPT-Щит; G45 Код Захисту).
- **ЩИТ-вузли** — реальні точки дії: Могилів-Подільський, Подільськ, Глеваха, Одеса.

**Ключові зв’язки (скорочено):**
- C → G01–G12 — **Фундамент**
- C → G23 — **Освіта / Активація**
- C → G35 — **Комунікація**
- C → G37 — **Соціум**
- C → G42 — **Технології**
- C → G45 — **Оборона**
- G23 → Одеса — **Студенти**
- G35 → Одеса — **Публічність**
- G37 → Глеваха — **Підтримка**
- G42 → Подільськ — **Досвід**
- G45 → Могилів-Под. — **Захист**

Повна легенда — у файлі `DAO-GOGS_MAP.md`.

---

## 2) Пакети для завантаження

- **Карта + легенда:**
  - 📦 `DAO-GOGS_MAP_v1.0.zip`

- **Планувальник (щотижнева перевірка):**
  - 📦 `WeeklyScheduler_kit.zip`

- **Планувальник (щомісячна перевірка):**
  - 📦 `MonthlyScheduler_kit.zip`

> У GitBook додай ці файли як вкладення або посилання на внутрішнє сховище.

---

## 3) Перевірка цілісності (SHA256)

```powershell
# Перевірка архіву
pwsh -NoProfile -File "C:\CHECHA_CORE\C12\Vault\ARCHIVE\Validate-DAO-GOGS_MAP.ps1" `
  -ZipPath "C:\CHECHA_CORE\C12\Vault\ARCHIVE\DAO-GOGS_MAP_v1.0.zip"

# Перевірка + розпаковування
pwsh -NoProfile -File "C:\CHECHA_CORE\C12\Vault\ARCHIVE\Validate-DAO-GOGS_MAP.ps1" `
  -ZipPath "C:\CHECHA_CORE\C12\Vault\ARCHIVE\DAO-GOGS_MAP_v1.0.zip" `
  -TargetDir "C:\CHECHA_CORE\C12\Vault\DAO-GOGS_MAP\v1.0"
```

> Логи: `C:\CHECHA_CORE\C03\LOG\releases_validate.log`  
> Exit-codes: `0` OK, `1` ZIP не знайдено, `2` немає CHECKSUMS, `3` помилка читання, `4` файл відсутній у ZIP, `5` хеш не співпав, `6` помилка розпакування.

---

## 4) Автоматизація перевірок

### Щотижнева (неділя 09:00 за замовчуванням)
```powershell
# Реєстрація
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Register-DAO-GOGS_MAP-Weekly.ps1"

# Кастомний розклад
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Register-DAO-GOGS_MAP-Weekly.ps1" `
  -DaysOfWeek Monday,Thursday -Hour 9 -Minute 30

# Видалення
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Unregister-DAO-GOGS_MAP-Weekly.ps1"
```

### Щомісячна (1-го числа 09:00 за замовчуванням)
```powershell
# Реєстрація
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Register-DAO-GOGS_MAP-Monthly.ps1"

# Кастомний розклад
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Register-DAO-GOGS_MAP-Monthly.ps1" `
  -Day 1 -Hour 9 -Minute 0

# Видалення
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Unregister-DAO-GOGS_MAP-Monthly.ps1"
```

---

## 5) Інтеграція у Validate-Releases.ps1
Додай блок перевірки архівів `DAO-GOGS_MAP_v*.zip` з автологуванням у `C03\LOG\releases_validate.log`.

---

## 6) Версійність і архів
- Зберігай релізи карти у `C12\Vault\ARCHIVE`.
- Для кожного релізу — оновлюй `CHECKSUMS.txt` і лог валідації.
- Використовуй тригери (щотижневий і щомісячний) для постійного аудиту.

---

© DAO-GOGS | С.Ч.

# Summary

## C11 — Automation
- [Scheduler Suite — Автоматизація перевірки](C11_AUTOMATION/Scheduler_Suite.md)

## C12 — Knowledge Vault
- [DAO-GOGS Map — Карта системи та валідація](C12_KNOWLEDGE_VAULT/DAO-GOGS_MAP_README_GITBOOK.md)
- [Digest — DAO-GOGS Scheduler Suite v1.0](C12_KNOWLEDGE_VAULT/DIGEST.md)

# 📘 Як додати новий G-модуль у монорепо DAO-GOGS

## 1. Створити репозиторій модуля
- Назва: `gXX-<short-name>`  
- Мінімальна структура:
  ```
  README.md
  VERSION.txt
  MANIFEST.yaml
  export.yaml
  docs/_index.md
  ```
- Приклад `VERSION.txt`:
  ```yaml
  module: GXX
  name: MODULE-NAME
  version: 1.0.0
  build: init
  date: YYYY-MM-DD
  ```

## 2. Підключити як сабмодуль у монорепо
```bash
mods="dao-g/dao-g-mods"
git submodule add https://github.com/dao-gogs/gXX-<short-name> "$mods/gXX-<short-name>"
git submodule update --init
git add .gitmodules "$mods/gXX-<short-name>"
git commit -m "chore(GXX): add new module"
git push
```

## 3. Додати в `MODULES_REGISTRY.yaml`
```yaml
- id: GXX
  name: MODULE-NAME
  path: dao-g/dao-g-mods/gXX-<short-name>
  repo: https://github.com/dao-gogs/gXX-<short-name>
  version: 1.0.0
  summary: "Короткий опис"
  status: active
  public_page: dao-<name>/README.md   # опц.
  exports:
    - id: gxx-overview
      title: "Огляд"
      source: ./docs/_index.md
```

## 4. Створити публічну сторінку (опц.)
- У монорепо додати:  
  `dao-<name>/README.md` з навігацією на файли сабмодулю.
- Прокинути у `SUMMARY.md`:
  ```markdown
  - [DAO-<NAME>](dao-<name>/README.md)
  - [GXX — MODULE-NAME](dao-g/dao-g-mods/SUMMARY-GXX.md)
  ```

## 5. Запустити локальну перевірку
```powershell
pwsh -NoProfile -File tools/Validate-Registry.ps1 -CheckManifest -CheckExportsPaths
```
(опц.) для релізу:  
```powershell
pwsh -NoProfile -File tools/Validate-Registry.ps1 -CheckChecksums -CheckGitTag
```

## 6. Закомітити зміни в монорепо
```bash
git add dao-g/MODULES_REGISTRY.yaml dao-<name>/README.md dao-g/dao-g-mods/SUMMARY-GXX.md
git commit -m "docs(GXX): register module + public page"
git push
```

## 7. CI перевірка
- GitHub Actions → `Registry Validate` має пройти зеленим.
- Якщо є помилки — дивись лог, виправ `version`, `exports.source`, або додай відсутні файли.

## 8. Реліз
- Створити тег у сабмодулі:
  ```bash
  git tag -a v1.0.0 -m "GXX v1.0.0"
  git push origin v1.0.0
  ```
- (опц.) Створити GitHub Release.

---

⚡ **Правила:**
- `registry.version` = `VERSION.txt` = `MANIFEST.yaml`.
- `exports.source` завжди має вказувати на існуючі файли.
- Для релізів — обов’язковий тег `vX.Y.Z`.

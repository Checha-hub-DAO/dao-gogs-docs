param(
    # Каталог, куди ви розпакували Heroes_Organization_MegaPackage.zip
    [string]$PackageDir = "."
)

$ErrorActionPreference = 'Stop'

function Get-ChecksumMap {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        throw "CHECKSUMS.txt не знайдено в: $Path"
    }
    $map = @{}
    Get-Content -LiteralPath $Path | ForEach-Object {
        $line = $_.Trim()
        if ($line -and -not $line.StartsWith("#")) {
            $parts = $line.Split(":", 2)
            if ($parts.Count -eq 2) {
                $file = $parts[0].Trim()
                $hash = $parts[1].Trim().ToLower()
                $map[$file] = $hash
            }
        }
    }
    return $map
}

# Нормалізуємо шлях
$PackageDir = (Resolve-Path -LiteralPath $PackageDir).Path
Write-Host "📦 Перевірка розпакованого пакета у: $PackageDir" -ForegroundColor Cyan

$checksumPath = Join-Path $PackageDir "CHECKSUMS.txt"
$checks = Get-ChecksumMap -Path $checksumPath

$ok = 0; $fail = 0; $miss = 0

foreach ($name in $checks.Keys) {
    $filePath = Join-Path $PackageDir $name
    if (-not (Test-Path -LiteralPath $filePath)) {
        Write-Host "❌ Відсутній файл: $name" -ForegroundColor Red
        $miss++
        continue
    }
    try {
        $hash = (Get-FileHash -LiteralPath $filePath -Algorithm SHA256).Hash.ToLower()
        if ($hash -eq $checks[$name]) {
            Write-Host "✅ $name OK" -ForegroundColor Green
            $ok++
        } else {
            Write-Host "❌ $name FAIL" -ForegroundColor Red
            Write-Host "   Очікувано: $($checks[$name])"
            Write-Host "   Отримано : $hash"
            $fail++
        }
    } catch {
        Write-Host "❌ Помилка читання: $name — $($_.Exception.Message)" -ForegroundColor Red
        $fail++
    }
}

# Попередження про зайві файли (яких немає в CHECKSUMS.txt)
$allFiles = Get-ChildItem -LiteralPath $PackageDir -File | Select-Object -ExpandProperty Name
$extra = $allFiles | Where-Object { $_ -ne "CHECKSUMS.txt" -and -not $checks.ContainsKey($_) }
if ($extra) {
    Write-Host "`n⚠️ Файли поза контролем хешів:" -ForegroundColor Yellow
    $extra | ForEach-Object { Write-Host "   • $_" -ForegroundColor Yellow }
}

Write-Host "`n—— ПІДСУМОК ——" -ForegroundColor Cyan
Write-Host "OK: $ok  FAIL: $fail  MISSING: $miss"
if ($fail -eq 0 -and $miss -eq 0) {
    Write-Host "✅ Усі перевірки пройдено" -ForegroundColor Green
    exit 0
} else {
    Write-Host "❌ Є проблеми з цілісністю" -ForegroundColor Red
    exit 1
}

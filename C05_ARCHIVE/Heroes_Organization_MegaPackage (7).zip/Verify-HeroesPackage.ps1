param(
    [string]$ZipPath = "D:\CHECHA_CORE\Heroes_Organization_MegaPackage.zip"
)

Write-Host "🔎 Перевірка SHA256 для пакета: $ZipPath" -ForegroundColor Cyan

# 1. Витягнути CHECKSUMS.txt
$checksumFile = Join-Path $env:TEMP "CHECKSUMS.txt"
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::ExtractToDirectory($ZipPath, $env:TEMP) -ErrorAction SilentlyContinue

$checksums = Get-Content $checksumFile | Where-Object {$_ -notmatch '^#' -and $_ -ne ""}

# 2. Перевірка хешів
$zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)

foreach ($entry in $zip.Entries) {
    $fileName = $entry.FullName
    $expected = ($checksums | Where-Object {$_ -like "$fileName*"}).Split(":")[1].Trim()

    $ms = New-Object IO.MemoryStream
    $entry.Open().CopyTo($ms)
    $ms.Position = 0

    $hash = (Get-FileHash -InputStream $ms -Algorithm SHA256).Hash.ToLower()

    if ($hash -eq $expected) {
        Write-Host "✅ $fileName OK" -ForegroundColor Green
    } else {
        Write-Host "❌ $fileName FAIL" -ForegroundColor Red
        Write-Host "   Очікувано: $expected"
        Write-Host "   Отримано : $hash"
    }
}

$zip.Dispose()

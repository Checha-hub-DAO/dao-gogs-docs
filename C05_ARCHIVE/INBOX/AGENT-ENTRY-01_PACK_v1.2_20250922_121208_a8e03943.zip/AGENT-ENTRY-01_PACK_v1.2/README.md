# AGENT-ENTRY-01 — Пакет v1.2 (стабільний)
Це стабільний пакет «Агент-Аналізатор першої зустрічі ідей» із:
- узгодженим шаблоном `ENTRY_TEMPLATE.md`,
- толерантним `New-EntryIdea.ps1` (Replace-IfPresent),
- «всеядним» `Analyze-Idea.ps1` (гнучка регулярка + підрахунок QACS),
- швидким лаунчером `Quick-IdeaCheck.ps1` (створити+проаналізувати).

## Швидкий старт
1) Розпакуй у: `D:\CHECHA_CORE\CREATOR_SUITE\AGENTS\AGENT-ENTRY-01\`
2) Запусти приклад:
```
pwsh -NoProfile -ExecutionPolicy Bypass `
  -File "D:\CHECHA_CORE\CREATOR_SUITE\AGENTS\AGENT-ENTRY-01\SCRIPTS\Quick-IdeaCheck.ps1" `
  -Idea "Карта світла для молоді" `
  -Channel "G23 Youth Activation" `
  -Tags "світло, молодь, карта"
```

Param(
  [Parameter(Mandatory=$true)]
  [string]$Path
)

$ErrorActionPreference = "Stop"
if (!(Test-Path $Path)) { throw "Файл не знайдено: $Path" }
$content = Get-Content -Raw -LiteralPath $Path -Encoding UTF8

function Show-Advice([int]$sum) {
    if     ($sum -lt 4)  { $adv = "Рекомендація: сигнал → зберегти, повернутись пізніше." }
    elseif ($sum -lt 7)  { $adv = "Рекомендація: іскорка → оформити малу форму." }
    elseif ($sum -lt 10) { $adv = "Рекомендація: ядро → винести у Майстерню/G-модуль." }
    else                 { $adv = "Рекомендація: готово → запуск ROADMAP + KPI." }
    Write-Host ("Оцінка знайдена: {0}/12 → {1}" -f $sum,$adv)
}

# 1) Пошук за «Сумарно … N/12» (гнучко, з урахуванням **, пробілів тощо)
$regexes = @(
    'Сумарно.*?(\d{1,2})\s*[\/\\]\s*12',
    '\*\*Сумарно:\*\*.*?(\d{1,2})\s*[\/\\]\s*12',
    'Сумарно:\s*(\d{1,2})\s*[\/\\]\s*12'
)
foreach ($rx in $regexes) {
    if ($content -match $rx) {
        $sum = [int]$Matches[1]
        Show-Advice $sum
        exit 0
    }
}

# 2) Підрахунок з рядків QACS (fallback)
$names = @('Ясність','Цінність','Здійсненність','Відповідність')
$sum = 0; $found = 0
foreach ($n in $names) {
    $m = Select-String -InputObject $content -Pattern ("{0}.*?(\d+)" -f [regex]::Escape($n)) -AllMatches
    if ($m.Matches.Count -gt 0) {
        $val = [int]$m.Matches[0].Groups[1].Value
        $sum += $val; $found++
    }
}
if ($found -ge 3) {
    Show-Advice $sum
    exit 0
}

# 3) Діагностика
Write-Host "⚠ Не знайдено оцінку. Діагностика довкола 'Сумарно':"
$ctx = Select-String -InputObject $content -Pattern "Сумарно" -Context 1,1
if ($ctx) {
    $ctx | ForEach-Object {
        Write-Host (">> {0}" -f $_.Line)
        if ($_.Context) {
            if ($_.Context.PreContext) { $_.Context.PreContext | ForEach-Object { Write-Host (".. {0}" -f $_) } }
            if ($_.Context.PostContext){ $_.Context.PostContext| ForEach-Object { Write-Host (".. {0}" -f $_) } }
        }
    }
} else {
    Write-Host "⦿ Взагалі не знайдено слова 'Сумарно' у файлі."
}
exit 1

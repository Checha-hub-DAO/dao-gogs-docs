Param(
    [Parameter(Mandatory=$true)]
    [string]$Idea,
    [string]$Channel = "Unspecified",
    [string]$Tags = "",
    [ValidateSet("концепт","задача","технічна проблема","символ","медіа-ідея","стратегічна ініціатива","auto")]
    [string]$Type = "auto",
    [int]$Clarity = -1,
    [int]$Value = -1,
    [int]$Feasibility = -1,
    [int]$SystemFit = -1
)

$ErrorActionPreference = "Stop"

# Шляхи
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $ScriptDir
$LogDir = Join-Path $Root "LOG"
$TplDir = Join-Path $Root "TEMPLATES"
$Tpl = Join-Path $TplDir "ENTRY_TEMPLATE.md"

if (!(Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir | Out-Null }

# ID і дата
$now = Get-Date
$id = "ENTR-{0:yyyyMMdd-HHmmss}" -f $now
$dateStr = $now.ToString("yyyy-MM-dd HH:mm:ss")

# Тип (авто)
function Guess-Type([string]$text) {
    $t = $text.ToLower()
    if ($t -match "скрипт|powershell|docker|gitbook|інтеграці") { return "технічна проблема" }
    if ($t -match "символ|герой|міф|лого|візуал") { return "символ" }
    if ($t -match "відео|пост|медіа|картка") { return "медіа-ідея" }
    if ($t -match "стратег|кампан|щит|модуль|g\d+") { return "стратегічна ініціатива" }
    if ($t -match "зробити|завдання|скласти|написати|налаштувати") { return "задача" }
    return "концепт"
}
if ($Type -eq "auto") { $Type = Guess-Type $Idea }

# QACS: дефолтні значення якщо не задані
function Clamp([int]$x) {
    if ($x -lt 0) { return -1 }
    if ($x -gt 3) { return 3 }
    return $x
}
$Clarity     = Clamp $Clarity
$Value       = Clamp $Value
$Feasibility = Clamp $Feasibility
$SystemFit   = Clamp $SystemFit

if ($Clarity -lt 0 -or $Value -lt 0 -or $Feasibility -lt 0 -or $SystemFit -lt 0) {
    $len = $Idea.Length
    if ($Clarity -lt 0)     { $Clarity = if ($len -gt 80) {2} else {1} }
    if ($Value -lt 0)       { $Value = 2 }
    if ($Feasibility -lt 0) { $Feasibility = 1 }
    if ($SystemFit -lt 0)   { $SystemFit = if ($Idea -match "G\d+|C\d+") {2} else {1} }
}
$Sum = $Clarity + $Value + $Feasibility + $SystemFit

# Маршрути
switch ($Type) {
    "технічна проблема"       { $route1 = "C11_Automation → інструмент/скрипт (+ LOG у C03/C07)"; $route2 = "GitBook/GitHub issue або TECH_NOTES.md"; break }
    "символ"                  { $route1 = "Світ Ч → MAP_SYMBOLS (додати ескіз/легенду)"; $route2 = "DAO-Gallery або «Символи й міфологія» → етап 1"; break }
    "медіа-ідея"              { $route1 = "G35 DAO-Медіа → картка/пост + шаблон контенту"; $route2 = "Content Pipeline (відео/стаття) → KPI + дедлайн"; break }
    "стратегічна ініціатива"  { $route1 = "Відповідний G-модуль (напр., G46/G43) → README + ROADMAP"; $route2 = "C06_FOCUS → встановити KPI + дату ревʼю"; break }
    "задача"                  { $route1 = "C06_FOCUS → To-Do (2–3 кроки, дедлайн)"; $route2 = "C03_LOG → короткий звіт після виконання"; break }
    default                   { $route1 = "Майстерня Творця → Чернетка концепту"; $route2 = "C12 Knowledge Vault → створити картку знання" }
}

# Шаблон
$tplText = Get-Content -Raw -LiteralPath $Tpl -Encoding UTF8

function Replace-IfPresent([string]$text, [string]$old, [string]$new) {
    if ([string]::IsNullOrEmpty($old)) { return $text }
    if ($null -ne $text -and $text.Contains($old)) { return $text.Replace($old,$new) }
    return $text
}

$body = $tplText
$body = Replace-IfPresent $body "${ID}" $id
$body = Replace-IfPresent $body "${DATE}" $dateStr
$body = Replace-IfPresent $body "${CHANNEL}" $Channel
$body = Replace-IfPresent $body "${RAW}" $Idea
$body = Replace-IfPresent $body "${TYPE}" $Type
$body = Replace-IfPresent $body "${TAGS}" $Tags
$body = Replace-IfPresent $body "${S_CLARITY}" "$Clarity"
$body = Replace-IfPresent $body "${S_VALUE}" "$Value"
$body = Replace-IfPresent $body "${S_FEAS}" "$Feasibility"
$body = Replace-IfPresent $body "${S_FIT}" "$SystemFit"
$body = Replace-IfPresent $body "${S_SUM}" "$Sum"
$body = Replace-IfPresent $body "${ROUTE1}" $route1
$body = Replace-IfPresent $body "${ROUTE2}" $route2
$body = Replace-IfPresent $body "${NEXT1}" "Сформувати мінімальну форму (1 сторінка)"
$body = Replace-IfPresent $body "${NEXT2}" "Визначити модуль/блок і перемістити туди"
$body = Replace-IfPresent $body "${NEXT3}" "Поставити контрольну дату/KPI"
$body = Replace-IfPresent $body "${LINKS}" "-"

# Запис
$outPath = Join-Path $LogDir "$($id).md"
[IO.File]::WriteAllText($outPath, $body, (New-Object System.Text.UTF8Encoding($false)))
Write-Host "✅ Створено запис: $outPath"

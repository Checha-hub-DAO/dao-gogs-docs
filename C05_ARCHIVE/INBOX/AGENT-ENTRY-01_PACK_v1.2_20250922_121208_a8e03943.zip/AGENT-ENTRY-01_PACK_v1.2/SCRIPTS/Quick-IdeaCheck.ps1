Param(
    [Parameter(Mandatory=$true)]
    [string]$Idea,
    [string]$Channel = "Unspecified",
    [string]$Tags = ""
)
$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $ScriptDir
$LogDir = Join-Path $Root "LOG"
$NewIdea   = Join-Path $ScriptDir "New-EntryIdea.ps1"
$Analyzer  = Join-Path $ScriptDir "Analyze-Idea.ps1"

# 1) створити
& pwsh -NoProfile -ExecutionPolicy Bypass -File $NewIdea -Idea $Idea -Channel $Channel -Tags $Tags

# 2) останній файл
$last = Get-ChildItem -Path $LogDir -Filter "ENTR-*.md" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $last) { throw "Не знайдено створений файл у LOG: $LogDir" }
Write-Host "`n--- Аналіз: $($last.Name) ---`n"

# 3) проаналізувати
& pwsh -NoProfile -ExecutionPolicy Bypass -File $Analyzer -Path $last.FullName

# 📘 DAO-GOGS Onboarding Cards

Це серія мобільних карток (формат 1080x1920) для швидкого онбордингу нових учасників.  
Кожна картка містить один крок, а також доступний повний PDF-набір.  

---

## 🖼 Картки

### Крок 1
![Крок 1](DAO-Onboarding_Card_1.png)

### Крок 2
![Крок 2](DAO-Onboarding_Card_2.png)

### Крок 3
![Крок 3](DAO-Onboarding_Card_3.png)

### Крок 4
![Крок 4](DAO-Onboarding_Card_4.png)

### Крок 5
![Крок 5](DAO-Onboarding_Card_5.png)

---

## 📄 Повний пакет
[Завантажити PDF-набір](DAO-OnboardingCards.pdf)  
[Завантажити ZIP-пакет (PNG + PDF)](DAO-OnboardingCards_Pack.zip)

---

📌 Використання: картки зручно поширювати у чатах, соцмережах або як сторіс; PDF і ZIP підходять для архівів і офіційного онбордингу.

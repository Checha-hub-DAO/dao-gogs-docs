# 📘 DAO-GOGS Onboarding Guide (English)

## 🎯 Goal
- Help new members quickly understand **how the DAO-GOGS system works**.  
- Explain the difference between **C-blocks, G-blocks, and Strategic blocks**.  
- Provide a simple first-steps scenario.  

---

## 1️⃣ DAO Structure
- **C-blocks (C01–C12)** = **Core** (parameters, log, focus, knowledge vault).  
- **G-blocks (G01–G45)** = **Functional modules** (leadership, media, defense, education, etc.).  
- **Strategic blocks** = **Overstructure** (MEDIA, GRUPS, GLOBAL, GUIDES).  

---

## 2️⃣ Roles
- **C-blocks** keep order and stability.  
- **G-blocks** create projects, products, and initiatives.  
- **Strategic blocks** unite and coordinate everything at the system level.  

---

## 3️⃣ First Steps for a New Member
1. Check **C06 FOCUS** → understand the main priorities of the week/month.  
2. Explore the relevant **G-modules** → find your place (e.g., G11 Leadership, G35 Media).  
3. Look at **DAO-GUIDES** → instructions and standards.  
4. Join a group in **DAO-GRUPS** → find your circle of interaction.  
5. Follow **DAO-MEDIA** → stay updated on DAO messages.  

---

## 4️⃣ Orientation
- **Vault (C12)** — all documents are stored here.  
- **MasterKits** — ready-to-use packages for quick start.  
- **GitBook** — DAO’s public showcase.  

---

# 🗺 Visual Map
Shows the three-level system:  
- In the center → **C-blocks (Core)**.  
- Around → **G-blocks (Modules)**.  
- Outer ring → **Strategic blocks (MEDIA, GRUPS, GLOBAL, GUIDES)**.  

👉 [DAO-CORE_FrameMap.svg](DAO-CORE_FrameMap.svg)

---

📌 Conclusion: The onboarding guide + visual map make the system clear even for newcomers and reduce the load on the team.  

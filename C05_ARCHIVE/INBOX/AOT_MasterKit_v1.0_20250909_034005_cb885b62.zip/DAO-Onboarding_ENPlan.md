# 🌍 DAO Onboarding MediaPack — English Version Plan

## 🎯 Goal
Make DAO-GOGS onboarding materials accessible for global partners and DAO-GLOBAL community.  
Deliver a full English-language MediaPack: guides, posters, cards, storyboard, storyline.

---

## 📘 Materials to Translate
1. **DAO-OnboardingGuide.md / PDF**  
   - Full onboarding guide (text).

2. **Visuals**  
   - DAO-CORE FrameMap (SVG/PNG).  
   - Posters (PDF/PNG + Mobile).

3. **Cards**  
   - 5 Onboarding Cards (PNG + PDF).  
   - Cards Pack (ZIP).

4. **Video Materials**  
   - Storyboard (PDF).  
   - Storyline (SVG/PNG).

5. **GitBook Pages**  
   - Onboarding Guide.  
   - Onboarding Cards.  
   - Onboarding MediaPack.  

---

## 🛠 Steps
1. Translate all textual content (guides, posters, cards, storyboard).  
2. Re-create visuals with English text (SVG/PNG/Poster).  
3. Generate English PDF versions (Guide, Poster, Cards, Storyboard).  
4. Update GitBook with English pages (parallel structure).  
5. Add English MediaPack to MasterKit.  

---

## 📅 Timeline
- **Week 1:** Translation of textual guides + cards.  
- **Week 2:** Visual adaptation (posters, maps, storyline).  
- **Week 3:** PDF & package assembly (EN MediaPack).  
- **Week 4:** GitBook integration + release.  

---

## 📌 Notes
- Keep design identical, change only language.  
- Ensure accessibility for both Ukrainian and English audiences.  
- Maintain versioning: `DAO-Onboarding_EN_v1.0`.  

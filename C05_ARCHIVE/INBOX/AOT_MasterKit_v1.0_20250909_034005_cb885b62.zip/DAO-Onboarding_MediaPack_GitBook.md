# 📦 DAO-GOGS Onboarding MediaPack

Медіа-комплект для швидкого і повного онбордингу учасників DAO-GOGS.  
Включає гіди, постери, мобільні картки та сценарії для відео.

---

## 📘 Основні матеріали
- [DAO-OnboardingGuide.pdf](DAO-OnboardingGuide.pdf) — повний гід.  
- [DAO-OnboardingGuide_Poster.pdf](DAO-OnboardingGuide_Poster.pdf) — постер A4.  
- [DAO-OnboardingGuide_Poster.png](DAO-OnboardingGuide_Poster.png) — постер PNG.  
- [DAO-OnboardingGuide_Poster_Mobile.png](DAO-OnboardingGuide_Poster_Mobile.png) — мобільний формат (1080x1920).  

---

## 📱 Картки
- DAO-Onboarding_Card_1 … DAO-Onboarding_Card_5 (PNG).  
- [DAO-OnboardingCards.pdf](DAO-OnboardingCards.pdf) — усі картки в одному PDF.  
- [DAO-OnboardingCards_Pack.zip](DAO-OnboardingCards_Pack.zip) — архів (PNG + PDF).  

---

## 🎬 Відео-матеріали
- [DAO-GOGS_Onboarding_Storyboard.pdf](DAO-GOGS_Onboarding_Storyboard.pdf) — сценарій (6 кадрів).  
- [DAO-GOGS_Onboarding_Storyline.svg](DAO-GOGS_Onboarding_Storyline.svg) — storyline (SVG).  
- [DAO-GOGS_Onboarding_Storyline.png](DAO-GOGS_Onboarding_Storyline.png) — storyline (PNG).  

---

## 🗺 Структурна мапа
Візуалізація зв’язку між усіма елементами онбордингу:  

![Onboarding Media Map](DAO-Onboarding_MediaMap.svg)

---

## 🗂 Використання
1. **Швидкий старт** — картки або постер.  
2. **Детальне ознайомлення** — гід (PDF).  
3. **Соцмережі** — мобільний постер, картки, storyline.  
4. **Відео** — storyboard + storyline.  

---

📌 Цей пакет створений для того, щоб зробити вхід у DAO-GOGS простим, зрозумілим і багаторівневим.

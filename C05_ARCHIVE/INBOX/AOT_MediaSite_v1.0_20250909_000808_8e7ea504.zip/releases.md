# RELEASES — лог і архіви

## ZIP‑патерн
`45.1_AOT_YYYY-MM-DD_build.zip`

## Файли в релізі
- `VERSION.txt`
- `RELEASE_NOTES.md`
- `CHECKSUMS.txt` (SHA‑256)

## Теги
`g45-1-aot-vX.Y`

## Історія
- 2025‑09‑06 — v1.0 (пілот): README + 3 аватари (G42 інтеграція)


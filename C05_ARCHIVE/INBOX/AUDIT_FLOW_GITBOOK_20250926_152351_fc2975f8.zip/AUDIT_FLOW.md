
# AUDIT FLOW — CheChaCore

Єдина карта трьох рівнів контролю системи.

---

## 🔹 Daily
- Завантаження ZIP → `_INBOX`
- Запуск `Apply-Update`
- Логи + SHA256
- Архівування

---

## 🔹 Weekly
- Перевірка архівів / SHA256
- Контроль логів
- CHANGELOG & пакети
- Task Scheduler

---

## 🔹 Monthly
- Інвентаризація блоків
- Аналіз об’ємів
- Перевірка автоматизації
- План оптимізації
- Повний резерв (**TECH_TOOLS_PACK**)

---

## 📊 Візуальна схема

![Audit Flow Diagram](AUDIT_FLOW_DIAGRAM.png)

---

## 📎 Візуальні шпаргалки

- ![Daily/Weekly/Monthly — кольоровий](AUDIT_FLOW_STICKER.png)
- ![Daily/Weekly/Monthly — ч/б](AUDIT_FLOW_STICKER_BW.png)

---

**С.Ч. — стандарт контролю**


# AUTO-SCHEDULE — профілі Планувальника (CHECHA)

## Вміст
- `CHECHA_StartOfDay_v2.xml` — щоденний запуск **HOT-режиму** (08:30).  
- `CHECHA_StartOfDay_v2_FULL.xml` — щоденний запуск **FULL-режиму** (09:00).  

## Як імпортувати
1. Відкрити **Task Scheduler** (Планувальник завдань).  
2. У меню **Action → Import Task…** вибрати потрібний `.xml`.  
3. Перевірити шлях до `pwsh.exe` (PowerShell 7).  
4. Зберегти задачу.  

## Пояснення
- **HOT (08:30)** — легкий цикл: перевірка пам’яток + збірка мінімального TECH_TOOLS_PACK (TOOLS + C11_AUTOMATION + CONFIG).  
- **FULL (09:00)** — повний цикл: перевірка пам’яток + збірка всіх інструментів з аналізом PSScriptAnalyzer.  

## Логи
- `D:\CHECHA_CORE_SYNC\DOCS\SOD_LOG.md` — результат ранкових циклів.  
- `D:\CHECHA_CORE_SYNC\TOOLS\TOOLS_LOG.md` — лог збірок.  
- `D:\CHECHA_CORE_SYNC\TOOLS\TOOLS_CHANGELOG.md` — історія версій пакетів.  

---
С.Ч.

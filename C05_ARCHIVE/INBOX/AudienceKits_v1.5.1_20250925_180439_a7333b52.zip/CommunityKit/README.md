## CommunityKit
Для долучення громади та молодіжної ініціативи. QR веде на Contribution Form + Youth Form.
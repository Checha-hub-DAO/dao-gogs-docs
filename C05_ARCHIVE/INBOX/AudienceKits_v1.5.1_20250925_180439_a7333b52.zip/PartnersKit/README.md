## PartnersKit
Для співпраці та партнерських заявок. QR веде на DAO-GOGS Partner Form.
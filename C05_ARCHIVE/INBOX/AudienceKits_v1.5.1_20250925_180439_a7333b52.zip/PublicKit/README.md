## PublicKit
Для публічної презентації. QR веде на GitBook DAO-GOGS Main.
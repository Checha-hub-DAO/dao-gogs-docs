## MilitaryKit
Внутрішній комплект для військових контактів. QR — заглушка «Internal Use Only».

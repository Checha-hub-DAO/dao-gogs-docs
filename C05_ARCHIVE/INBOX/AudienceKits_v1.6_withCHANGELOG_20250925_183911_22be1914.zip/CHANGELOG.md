# AudienceKits v1.6 — Changelog

**Дата релізу:** 25.09.2025  
**Автор:** Сергій Чеча (С.Ч.)  
**Статус:** Активна версія

---

## 🔑 Нове у v1.6
- 🆕 **YouthKit** — додано як п’ятий повноцінний комплект (README, OnePager, Cover, QR).  
- 📲 **Інтерактивні QR** — усі посилання тепер мають короткі редіректи з UTM.  
- 📊 **Міні-аналітика (metrics)** — стартові лічильники у BuildInfo.json.  
- 🎨 **Візуальне оновлення** — усі Covers виконані у стилі *StyleGuide v1.0*, з підписом *«С.Ч.»*.  
- 🔗 **Інтеграція з CheCha-CORE** — файл `C06_LINKS.md` з дубльованими посиланнями.  

---

## 📦 Структура пакета
```
AudienceKits_v1.6/
 ├─ MilitaryKit/
 ├─ PartnersKit/
 ├─ CommunityKit/
 ├─ PublicKit/
 ├─ YouthKit/
 ├─ BuildInfo.json
 ├─ checksums.txt
 ├─ C06_LINKS.md
 ├─ Catalog_AudienceKits_v1.6_UA.pdf
 ├─ Catalog_AudienceKits_v1.6_EN.pdf
 └─ Banner_AudienceKits_v1.6.png
```

---

## 📌 Наступні кроки
- Розширення **metrics**: інтеграція з трекінговою системою DAO-GOGS.  
- Можливе додавання **Specialized Kits** (наприклад, MediaKit, EduKit).  
- Публічний реліз через GitBook і DAO-канали.  

---

**DAO-GOGS | Adaptive Presentation**  
*AudienceKits — v1.6*  
Автор: **С.Ч.**

## CommunityKit
Комплект для громади. QR → Contribution Form (коротке посилання з UTM).

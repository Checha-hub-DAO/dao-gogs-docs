## PartnersKit
Комплект для партнерів. QR → Partner Form (коротке посилання з UTM).

# C-CATALOG — CORE (C01–C12)
Станом на 2025-09-09 • v1.0 • Єдина стартова точка ядра CHECHA_CORE

## Блоки
- C01 — Parameters
- C02 — Glossary
- C03 — Log
- C04 — Passports
- C05 — Archive
- C06 — Focus
- C07 — Report / (Аналітика: див. C07.N011 у C07-ANALYTICS)
- C08 — Init Map (Щит‑X)
- C09 — Metrics
- C10 — DNA Core
- C11 — Automation (Runtime/Оркестрація, AGENTS)
- C12 — Knowledge Vault (Описи/Звіти)

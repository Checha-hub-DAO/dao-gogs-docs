C04_PASSPORTS — система стандартів і шаблонів C‑модулів (v2.0)

Призначення: уніфікувати паспортну форму для всіх C‑модулів; єдині правила, шаблони, процес версіонування.

Структура мінімум:
C04_PASSPORTS/ ├─ README.md ├─ SPEC.md ├─ /assets └─ /templates

RACI: R/A — С.Ч.; C — GPT‑5 Thinking; I — команда GOGS

Інтерфейси: входи — C01, C02, C03, правила GitBook; виходи — усі C‑модулі, C05, GitBook/Drive.

Версіонування: MAJOR.MINOR.PATCH; історія — CHANGELOG; CORE_VERSION.json.

Ризики/контролі: дрейф шаблонів, дублювання у GitBook, несинхронність версій. KPI: % модулів на v2.0; TTM ≤ 30 хв.

DoD: README, SPEC, templates створено; чеклист v2.0 пройдений; зв’язки в CORE_VERSION.json.

Next: оновити C01–C12 до v2.0; додати CHANGELOG_TEMPLATE; щотижневий аудит відповідності.

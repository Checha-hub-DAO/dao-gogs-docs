# C06 — Focus
Див. `passport.md`. Статус: 🟡 У роботі • v2.0

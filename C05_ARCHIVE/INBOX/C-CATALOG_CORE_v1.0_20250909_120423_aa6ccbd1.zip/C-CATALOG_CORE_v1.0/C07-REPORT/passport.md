C07 — REPORT (v2.0)

Принципи: єдина форма на період; трасованість (LOG/FOCUS/KPI посилання); мінімальна довжина (W≤1, M≤3, Q≤5, Y≤10); дедлайни у C01.

Структура: TEMPLATES/ (Weekly/Monthly/Quarterly/Yearly), PERIODS/, DASHBOARD/spec.md.

Зв’язки: входить — C01, C03, C06, C02, KPI‑джерела; вихід — C05, C12, G‑модулі (G11, G25).

Next: створити WEEKLY_TEMPLATE.md і 2025‑W34; MONTHLY_TEMPLATE.md і серпень‑2025; DASHBOARD/spec.md; дедлайн Weekly (нд, 19:30 Kyiv); посилання на джерела у кожному звіті.

Статус: v2.0 (2025‑08‑22).

🔵 C08_INIT_MAP (Щит‑X)

REGISTRY: REGISTRY/regions/<region>/cities/<city>/cells/<CELL-ID>/CELL_PASSPORT.md (CELL‑ID випадковий; публічно — лише агрегати).
TEMPLATES/, POLICY/ (доступ/карти), OPS/PLAYBOOKS/. Пілот: Одеса (анонімізований).

Cadence & Звіти: щотижнева синхронізація (нд 18:00) без PII; інтеграція з C07‑REPORT; снапшоти у C05 (ZIP + SHA256); терміни — C02.

Next: 2–3 регіони з ID; ACCESS_POLICY (Owner/Editor/Viewer); k‑анонімність (≥5), відкладена публікація; агрегація у Weekly/ KPI покриття (C09); снапшоти з MANIFEST/SHA256.

Changelog: 2025‑08‑22 — ONE‑PAGE SAFE.

Зв’язки: C01 • C02 • C03 • C05 • C07 • C09 • C11 • C12.

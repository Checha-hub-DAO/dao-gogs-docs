C09 — METRICS (v2.0)

Входи: C03 LOG/HEALTH, C06 FOCUS, C07 REPORT, C02 GLOSSARY, C12 VAULT.
Виходи: C07 REPORT (Hero KPI), C05 ARCHIVE (щомісячні снапшоти), G‑модулі (G11, G25).

Сильні: об’єктивність, ранні сигнали, трасованість KPI↔формула↔джерела↔власник.
Слабкі: якість даних; «ручні KPI»; гейміфікація без контролів.

Рекомендації: Acceptance Criteria для KPI; обмежити Core KPI і зробити публічними; playbook WARN/FAIL.

Next (Top‑7 Core KPI):
K01 Focus Completion %, K02 Rhythm Adherence %, K03 On‑Time Reports %, K04 Health OK Ratio, K05 Knowledge Additions/wk, K06 Restore Drill Pass %, K07 Initiative Coverage Level.

Структура: CATALOG/KPI_CATALOG.md, DASHBOARD/spec.md, ALERTS/thresholds.yaml.
Статус: v2.0 (2025‑08‑22).

# C09 — Metrics
Див. `passport.md`. Статус: 🟡 У роботі • v2.0

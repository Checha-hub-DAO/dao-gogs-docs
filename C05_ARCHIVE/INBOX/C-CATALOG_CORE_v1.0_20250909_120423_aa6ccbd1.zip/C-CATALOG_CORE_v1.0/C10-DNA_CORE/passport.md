C10 — DNA_CORE (v2.0)

Структура:
VALUES/ (values.md), PRINCIPLES/ (principles.md), BEHAVIOR/ (code_of_conduct.md),
DECISION_FILTER/ (df7.md), RITUALS/ (rituals.md, identity.md), TEMPLATES/ (RFC_VALUE_CHANGE.md, DECISION_RECORD.md, INCIDENT_ETHICS_REPORT.md),
C10-DNA-README.md.

Принципи: незмінне ядро (зміни через RFC/консенсус), перевірюваність (фільтр DF7), єдність мови (C02), законність/безпека, гідність/нульова толерантність до зловживань.

Зв’язки: входить — C02, C12; виходить — C01, C06, C07, C09, G11.

Сильні: рейки для рішень; зниження конфліктів; довіра/стійкість.
Слабкі: ризик формалізму; потреба в освіті; висока ціна помилок.

Next: df7.md з прикладами; Decision Record у C07; code_of_conduct + навчання (G11); ритуали; етичні KPI у C09.

Статус: v2.0 (2025‑08‑22).

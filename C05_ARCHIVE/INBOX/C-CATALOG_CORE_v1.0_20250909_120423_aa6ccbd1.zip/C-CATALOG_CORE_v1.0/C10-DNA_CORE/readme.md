# C10 — DNA_CORE
Див. `passport.md`. Статус: 🟡 У роботі • v2.0

Чек‑лист середовища: PS 7.4+, gh, mc, MinIO, GitHub PAT.
AGENTS_HEALTH.md (snapshot), RHYTHM_DASHBOARD.md + update_dashboard.ps1 (фрагмент).
Пов’язування з C12: у кожного агента в C12 є паспорт; Agent.meta.json має runtime_path "C11/AGENTS/<ID>"; vault-bot оновлює C12/_index/AGENTS.json.

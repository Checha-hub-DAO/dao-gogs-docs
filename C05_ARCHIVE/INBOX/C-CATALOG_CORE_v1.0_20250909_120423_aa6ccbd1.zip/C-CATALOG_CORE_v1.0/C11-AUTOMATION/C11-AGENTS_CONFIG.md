Приклади:
_config/agents.json → registry.source: C12/_index/AGENTS.json; runtime_root: C11/AGENTS; logging.dir: C03/LOG.
_config/secrets.sample.json → GITHUB_TOKEN, MINIO_*.
policies.json → scopes/deny (exec_in_C12: true).

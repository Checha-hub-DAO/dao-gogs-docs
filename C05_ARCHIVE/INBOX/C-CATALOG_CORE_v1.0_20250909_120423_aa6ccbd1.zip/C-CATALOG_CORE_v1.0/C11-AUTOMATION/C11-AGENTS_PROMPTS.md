Системні промпти:
- system_vault.md — vault-bot (індексація C12, лінт, CHECKSUMS).
- system_release.md — release-checker (активи, checksums, RN).
- system_media.md — media-agent (медіа‑активи → чернетка).
Тон: фактологічний, лаконічний.

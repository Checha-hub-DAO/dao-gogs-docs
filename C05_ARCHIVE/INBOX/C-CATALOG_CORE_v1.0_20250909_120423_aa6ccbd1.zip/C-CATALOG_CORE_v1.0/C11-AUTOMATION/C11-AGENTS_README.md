Мета: автономні агенти (мінімум ручних дій). Базовий набір: vault-bot, release-checker, media-agent.
Швидкий старт: створити C11/AGENTS; додати mc.exe, gh.exe; заповнити _config/agents.json, secrets.json; запуск run.ps1; перевірити звіти в out/ і записи у C03/LOG; додати планувальник.
Навігація: C11-AGENTS_STRUCTURE.md • C11-AGENTS_ROLES.md • C11-AGENTS_CONFIG.md • C11-AGENTS_UTILS.md • C11-AGENTS_PROMPTS.md • C11-AGENTS_APPENDICES.md

vault-bot — скан C12/; індекси; лінт агентів; контроль CHECKSUMS. Тригери: щогодини/коміти. Виходи: out/, C12/_index. Health: System/Health/vault-bot.json.
release-checker — перевірка GitHub релізів, assets, CHECKSUMS. 09:00/21:00. Виходи: out/+C03/LOG.
media-agent — медіа‑конвеєр (збір, перевірка, чернетки). За контент‑календарем. Health JSON.
KPI для всіх: success_rate, ttr_ms, retries, fail_reasons, drift_score.

Дерево директорій (рекомендоване):
C11/AGENTS/_config/{agents.json,secrets.sample.json,policies.json}
C11/AGENTS/_shared/{utils.ps1,checks.ps1}
C11/AGENTS/_queue/queue.jsonl
C11/AGENTS/_scheduler/tasks.json
C11/AGENTS/hub/{hub.ps1,invoke.ps1}
C11/AGENTS/vault-bot/{run.ps1,out/,prompts/}
C11/AGENTS/release-checker/{run.ps1,out/}
C11/AGENTS/media-agent/{run.ps1,out/}
C11/AGENTS/C12G10/{run.ps1,prompts/,out/}
.gitignore фрагмент додано.

Utils (фрагменти PowerShell): Log(), Ensure-MCAlias(), SHA256-File(), S3-Sync().
Тест‑блок для агентів: smoke‑test через utils.ps1.

C11 — AUTOMATION (v2.0)

Входи: C01, C03/HEALTH, C05, C06, C07, C09, C10, C12.
Виходи: C05 (архіви), C07 (звіти), C09 (KPI), C03 (логи/алерти).

Сильні: знімає рутини; гарантує ритм; прозорі розклади; recipes/шаблони.
Слабкі: секрети/доступи; конфіг‑ризики (cron/TZ); потреба у dry‑run.

Рекомендації: secrets_policy.md; schedule_template (Europe/Kyiv); observability (OK/WARN/FAIL) + алерти.

Next (Weekly): 18:30 focus_bot; 19:00 health_bot + metrics_job; 19:20 report_job; 19:30 нагадування.
Monthly: архіви ZIP+SHA256 у C05. Restore_drill weekly (лог у C03, KPI K06 у C09).

Політика: «конфіги як код»; історія — CHANGELOG.

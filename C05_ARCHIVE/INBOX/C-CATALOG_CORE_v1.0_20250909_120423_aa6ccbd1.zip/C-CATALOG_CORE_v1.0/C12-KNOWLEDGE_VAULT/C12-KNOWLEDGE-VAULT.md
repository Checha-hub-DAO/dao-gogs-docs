Головний документ (смисли, ядро). Версія: v2.1 FirstBuild (2025‑08‑22). Статус: ✅ закріплений фундамент.

Категорії: 📘 Книги • 📄 Документи • 🎥 Відео • 🧭 Концепти
Артефакти: ReleaseBundle (ZIP + SHA256), INDEX (40 items).

Зв’язки: C02 Glossary • C03 Log • C05 Archive • C06 Focus • C07 Report • C11 Automation (vault_bot) • C09 Metrics.

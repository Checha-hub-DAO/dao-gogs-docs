# C12 — Knowledge Vault (огляд і навігація)

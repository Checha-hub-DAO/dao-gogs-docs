# C-CATALOG — CORE (C01–C12)
Станом на 2025-09-09 • v1.1 • Єдина стартова точка CHECHA_CORE
Update v1.1: додано C11 AGENTS v1.1 та розширені KPI (C09 v2.1).

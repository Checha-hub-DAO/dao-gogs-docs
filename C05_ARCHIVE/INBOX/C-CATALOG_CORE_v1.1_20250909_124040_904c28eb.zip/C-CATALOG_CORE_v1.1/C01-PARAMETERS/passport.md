C01-STRUCTURE — PARAMETERS
Основний документ: C01-PARAMETERS.md (мова/тон, звіти, принципи).
Підсистеми: C01-LOG-README.md, C01-LOG-TEMPLATE.md, REPORT/MONTHLY/QUARTERLY/YEARLY.
CALENDAR: README, TEMPLATE, 2025–2027.
Висновок: задає стиль, ритм і фіксацію.

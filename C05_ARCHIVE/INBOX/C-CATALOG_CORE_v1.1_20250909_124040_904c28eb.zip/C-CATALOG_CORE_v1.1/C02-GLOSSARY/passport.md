C02-STRUCTURE — GLOSSARY (v2.0). Основний документ: C02-GLOSSARY.md.
Підсистеми: GLOSSARY.md, C02-GLOSSARY_CHANGELOG.md. Зв’язки: C01, C06, C12.

# C02 — GLOSSARY
Див. `passport.md`. Статус: 🟡 У роботі • v2.0

C03-STRUCTURE — LOG (v2.0). Живий щоденник + HEALTH (OK/WARN/FAIL).
Архіви: DAILY/WEEKLY/MONTHLY. Синхронізація з REPORT/ARCHIVE.

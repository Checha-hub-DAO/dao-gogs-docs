C05 — ARCHIVE (v2.0). Бекап + архів + restore drill. ZIP + SHA256. Retention/доступи/журнали.

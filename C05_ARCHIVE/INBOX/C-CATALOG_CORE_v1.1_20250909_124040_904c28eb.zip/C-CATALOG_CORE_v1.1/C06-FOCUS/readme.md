# C06 — FOCUS
Див. `passport.md`. Статус: 🟡 У роботі • v2.0

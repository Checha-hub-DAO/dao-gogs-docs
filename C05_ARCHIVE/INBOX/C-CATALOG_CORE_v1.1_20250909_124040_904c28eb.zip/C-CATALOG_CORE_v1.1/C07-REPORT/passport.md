C07 — REPORT (v2.0). Єдина форма на період; трасованість (LOG/FOCUS/KPI).
Структура: TEMPLATES/, PERIODS/, DASHBOARD/. Дедлайн Weekly (нд, 19:30 Kyiv).

C08_INIT_MAP (Щит‑X). REGISTRY/regions/.../CELL_PASSPORT.md (анон ID). POLICY/, TEMPLATES/, OPS/PLAYBOOKS/. Пілот: Одеса.
Синхронізація: нд 18:00; снапшоти в C05; KPI покриття у C09.

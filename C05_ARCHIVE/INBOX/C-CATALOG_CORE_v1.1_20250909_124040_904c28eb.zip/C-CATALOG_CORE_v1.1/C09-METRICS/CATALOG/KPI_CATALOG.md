# KPI_CATALOG — Core KPI (v2.1)

| Code | Name                         | Formula / Source                                     | Owner   | Refresh | WARN / FAIL |
|-----:|------------------------------|------------------------------------------------------|---------|---------|-------------|
| K01  | Focus Completion %           | Done/Planned (C06.BOARD/WEEKLY)                      | C06 Lead| weekly  | <70 / <50   |
| K02  | Rhythm Adherence %           | On-time rituals (C01,C07) / total                    | C01 Lead| weekly  | <80 / <60   |
| K03  | On-Time Reports %            | On-time (C07) / total                                | C07 Lead| weekly  | <90 / <75   |
| K04  | Health OK Ratio              | OK/(OK+WARN+FAIL) from C03/HEALTH                    | C03 Lead| hourly  | <0.9 / <0.75|
| K05  | Knowledge Additions / wk     | Δ INDEX items (C12)                                  | C12 Lead| weekly  | <5 / <2     |
| K06  | Restore Drill Pass %         | Passed drills / planned (C05)                        | C05 Lead| weekly  | <90 / <70   |
| K07  | Initiative Coverage Level    | Anon coverage metric from C08 (k-anon≥5)             | C08 Lead| monthly | <0.5 / <0.3 |
| K08  | Agents OK % (24h)            | OK agents / total (C03/HEALTH/agents/*.json)         | C11 Lead| hourly  | <0.9 / <0.75|
| K09  | Mean TTR (hrs)               | Mean time to recovery from WARN/FAIL (C03 LOG/HEALTH)| C11 Lead| hourly  | >4h / >12h  |
| K10  | Alert Count (24h)            | Count of WARN/FAIL in C03/LOG/alerts.log             | C11 Lead| hourly  | ≥3 / ≥7     |

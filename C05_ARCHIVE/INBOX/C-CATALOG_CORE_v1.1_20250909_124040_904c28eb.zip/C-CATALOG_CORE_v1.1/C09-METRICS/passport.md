C09 — METRICS (v2.1). Core KPI + дашборд + alerts.
Update v2.1: додано K08–K10 (агенти/health), thresholds.yaml, refresh_window Sun 19:15.

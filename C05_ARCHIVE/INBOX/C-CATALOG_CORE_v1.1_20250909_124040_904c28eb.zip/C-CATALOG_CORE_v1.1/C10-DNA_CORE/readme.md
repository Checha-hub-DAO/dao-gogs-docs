# C10 — DNA CORE
Див. `passport.md`. Статус: 🟡 У роботі • v2.0

# Розкласти `AGENTS-SKELETON_v1.1/` у робоче `C11/AGENTS` і слідувати README всередині.

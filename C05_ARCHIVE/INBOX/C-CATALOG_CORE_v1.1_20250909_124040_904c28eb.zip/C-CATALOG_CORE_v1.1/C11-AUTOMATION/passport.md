C11 — AUTOMATION (v2.0). Runtime/оркестрація. Weekly/Monthly цикли, jobs/recipes/secrets/monitoring.
Включає AGENTS-SKELETON v1.1 (health + notify + monitor).

Правила внесення → Класифікація → Сенс → INDEX → Реліз → LOG → REPORT → KPI → vault_bot

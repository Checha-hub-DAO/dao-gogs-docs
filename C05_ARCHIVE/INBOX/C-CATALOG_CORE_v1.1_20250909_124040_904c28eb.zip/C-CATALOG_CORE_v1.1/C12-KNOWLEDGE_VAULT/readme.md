# C12 — KNOWLEDGE VAULT
Див. `passport.md`. Статус: 🟡 У роботі • v2.0

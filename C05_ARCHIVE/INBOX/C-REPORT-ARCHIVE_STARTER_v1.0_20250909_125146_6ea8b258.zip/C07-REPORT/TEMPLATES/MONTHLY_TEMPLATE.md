# Monthly Report — {{Month YYYY}}

📅 Період: {{DateRange}}

## 🔑 Hero KPI
- K01 Focus Completion %: ⬜
- K02 Rhythm Adherence %: ⬜
- K03 On-Time Reports %: ⬜
- K04 Health OK Ratio: ⬜

## 📌 Highlights
- Стратегічні зміни
- Прогрес за фокусами
- Ключові рішення

## ⚠️ Risks & Alerts
- ⬜ WARN/FAIL (з C03 HEALTH + C09 KPI)

## 📝 Decisions
- ⬜ Decision Record → [df7]

## 🔗 Sources
- LOG: [link]
- FOCUS: [link]
- KPI: [link]
- ARCHIVE: [zip]

param([string]$PayloadPath)
. "$PSScriptRoot/../_shared/utils.ps1"
Write-Host (Log "C12G10 start")
# TODO: implement C12G10 logic
Write-Host (Log "C12G10 done" "OK")

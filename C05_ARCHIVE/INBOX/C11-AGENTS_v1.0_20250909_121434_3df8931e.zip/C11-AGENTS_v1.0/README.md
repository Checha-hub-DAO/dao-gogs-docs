# C11/AGENTS — Quickstart
1) Покладіть теку в `C11/AGENTS`.
2) Заповніть `_config/agents.json` і створіть `_config/secrets.json` за зразком.
3) Додайте `mc.exe` і `gh.exe` у PATH.
4) Спробуйте: `./hub/invoke.ps1 -Agent vault-bot -JsonPayload "{}"`
5) Перевірте `*/out` і `C03/LOG`.
6) Додайте розклади з `_scheduler/tasks.json` у планувальник.

# Basic health/env checks
Write-Host "PS Version: $($PSVersionTable.PSVersion)"
if (-not (Get-Command gh -ErrorAction SilentlyContinue)) { Write-Error "gh not found" }

function Log($Msg, $Level='INFO') {
  $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
  "$ts [$Level] $Msg"
}
function Ensure-MCAlias {
  if (-not (Get-Command mc -ErrorAction SilentlyContinue)) {
    $mc = Join-Path $PSScriptRoot 'mc.exe'
    if (Test-Path $mc) { Set-Alias mc $mc -Scope Global } else { throw 'mc not found' }
  }
}
function SHA256-File([string]$Path) {
  if (-not (Test-Path $Path)) { throw "No file: $Path" }
  (Get-FileHash -Algorithm SHA256 -Path $Path).Hash.ToLower()
}
function S3-Sync([string]$Src, [string]$Dst, [switch]$DryRun) {
  Ensure-MCAlias
  $args = @('mirror', $Src, $Dst)
  if ($DryRun) { $args += '--dry-run' }
  & mc @args
}

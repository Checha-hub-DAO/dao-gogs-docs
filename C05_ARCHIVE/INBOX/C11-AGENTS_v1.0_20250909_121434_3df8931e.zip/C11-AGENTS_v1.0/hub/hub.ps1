param([string]$Agent,[string]$PayloadPath)
. "$PSScriptRoot/../_shared/utils.ps1"
Write-Host (Log "Hub start → $Agent ($PayloadPath)")
$agentPath = Join-Path $PSScriptRoot "..\$Agent\run.ps1"
if (-not (Test-Path $agentPath)) { throw "Agent not found: $Agent" }
& $agentPath -PayloadPath $PayloadPath

param([string]$Agent,[string]$JsonPayload="{}")
$temp = New-TemporaryFile
$JsonPayload | Set-Content -Path $temp -Encoding UTF8
& "$PSScriptRoot/hub.ps1" -Agent $Agent -PayloadPath $temp.FullName
Remove-Item $temp -Force

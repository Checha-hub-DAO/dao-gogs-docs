param([string]$PayloadPath)
. "$PSScriptRoot/../_shared/utils.ps1"
Write-Host (Log "media-agent start")
# TODO: implement media-agent logic
Write-Host (Log "media-agent done" "OK")

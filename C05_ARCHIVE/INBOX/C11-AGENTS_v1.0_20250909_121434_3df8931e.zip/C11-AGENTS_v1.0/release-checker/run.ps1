param([string]$PayloadPath)
. "$PSScriptRoot/../_shared/utils.ps1"
Write-Host (Log "release-checker start")
# TODO: implement release-checker logic
Write-Host (Log "release-checker done" "OK")

param([string]$PayloadPath)
. "$PSScriptRoot/../_shared/utils.ps1"
Write-Host (Log "vault-bot start")
# TODO: implement vault-bot logic
Write-Host (Log "vault-bot done" "OK")

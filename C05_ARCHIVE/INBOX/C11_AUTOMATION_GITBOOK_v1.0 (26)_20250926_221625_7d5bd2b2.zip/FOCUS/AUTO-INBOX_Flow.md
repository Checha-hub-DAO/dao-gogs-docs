# AUTO-INBOX Flow (C11_AUTOMATION)

```mermaid
flowchart LR
    INBOX[[zip_inbox]] --> SCAN[Сканування *.zip]
    SCAN --> DECIDE{Класифікація за назвою
(RELEASE/BETA/інше)}

    DECIDE -->|RELEASE| REL[Release]
    DECIDE -->|BETA| BET[Beta]
    DECIDE -->|Інше| DRF[Draft]

    REL --> H1[Додати запис:
Інтегровано · Release · SHA256]
    H1 --> MOVE_REL[Move → C11_AUTOMATION]
    MOVE_REL --> DONE1[Готово]

    BET --> H2[Додати запис:
Тестування · Beta]
    H2 --> MOVE_BET[Move → WORKSHOP/testing]
    MOVE_BET --> REPORT[Append → TEST_REPORT.md]
    REPORT --> DONE2[Очікує перевірки]

    DRF --> H3[Додати запис:
Чернетка · Draft]
    H3 --> MOVE_DRF[Move → WORKSHOP/drafts]
    MOVE_DRF --> DONE3[Очікує доробки]
```

**Пояснення класифікації:**  
- Назва містить `RELEASE` → **Release**  
- Назва містить `BETA` → **Beta**  
- Інакше → **Draft**

---

🏷️ #Focus

# VISUAL_MAP — C11_AUTOMATION Packages

Нижче — візуальна мапа структури двох основних пакетів:
- **Release пакет**: `C11_AUTOMATION_RELEASE_20250926.zip`
- **GitBook пакет**: `C11_AUTOMATION_GITBOOK_v1.0.zip`

```mermaid
flowchart TD
    ROOT[ROOT / Корінь]:::root
    TOOLS[TOOLS]:::dir
    ARCHIVE[ARCHIVE]:::dir
    FOCUS[FOCUS]:::dir

    ROOT --> README_RELEASE[README_RELEASE.md]
    ROOT --> README_MAIN[README_MAIN.md (UA+EN титульний, у GitBook пакеті)]
    ROOT --> README_UA[README_C11_AUTOMATION.md]
    ROOT --> README_EN[README_EN.md]
    ROOT --> README_TOOLS[README.md (опис ziptools)]
    ROOT --> INSTALL[INSTALL.md]
    ROOT --> SUMMARY_UA[SUMMARY.md]
    ROOT --> SUMMARY_EN[SUMMARY_EN.md]
    ROOT --> ROADMAP[ROADMAP.md]
    ROOT --> GITBOOK_GUIDE[GITBOOK_IMPORT_GUIDE.md]
    ROOT --> CHECKLIST[CHECKLIST_DEPLOY.md]

    ROOT --> TOOLS
    TOOLS --> UPDATE[Update-ZipHistory.ps1]
    TOOLS --> ADD[Add-ZipHistory.ps1]
    TOOLS --> START[START-DEMO.ps1]
    TOOLS --> INTEGRATE[INTEGRATE-RELEASE.ps1]
    TOOLS --> AUTOINBOX[AUTO-INBOX.ps1]

    ROOT --> ARCHIVE
    ARCHIVE --> CSV[ZIP_HISTORY.csv]
    ARCHIVE --> MD[ZIP_HISTORY.md]

    ROOT --> FOCUS
    FOCUS --> CHECK[TASK-CheckList.md]
    FOCUS --> FLOW[FLOW-README.md]
    FOCUS --> AUTOFLOW[AUTO-INBOX_Flow.md]

    classDef root fill:#f6f7fb,stroke:#8a8a8a,stroke-width:1px;
    classDef dir fill:#eef8ff,stroke:#4aa3ff,stroke-width:1px;
```

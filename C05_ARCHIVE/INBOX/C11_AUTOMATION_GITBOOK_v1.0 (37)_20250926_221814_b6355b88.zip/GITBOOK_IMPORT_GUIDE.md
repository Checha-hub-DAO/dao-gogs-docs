# GitBook Import Guide — C11_AUTOMATION

## 1. Підготовка
- Завантаж архів: `C11_AUTOMATION_GITBOOK_v1.0.zip`
- Переконайся, що він містить ключові файли:
  - `README_MAIN.md` (UA+EN титульний)
  - `README_C11_AUTOMATION.md` (UA)
  - `README_EN.md` (EN)
  - `SUMMARY.md` (UA зміст)
  - `SUMMARY_EN.md` (EN зміст)
  - `FLOW-README.md`, `AUTO-INBOX_Flow.md` (схеми)

---

## 2. Імпорт у GitBook
1. Увійди до свого робочого простору GitBook.  
2. Створи новий **Space** (наприклад: *C11_AUTOMATION*).  
3. У меню Space вибери: **Import → Upload a .zip file**.  
4. Завантаж архів `C11_AUTOMATION_GITBOOK_v1.0.zip`.  

---

## 3. Налаштування
- **Основна сторінка** → вистави `README_MAIN.md` як титульну.  
- **Зміст UA** → якщо працюєш українською, підключи `SUMMARY.md`.  
- **Зміст EN** → для англомовної версії можна дублювати Space і підключити `SUMMARY_EN.md`.  
- **Схеми** → `FLOW-README.md` і `AUTO-INBOX_Flow.md` автоматично рендеряться через Mermaid.  

---

## 4. Подальші кроки
- Після імпорту перевір відображення діаграм (Mermaid).  
- Додай цей Space у головну навігацію GitBook DAO-GOGS.  
- За потреби активуй **multi-language spaces** (UA/EN) через GitBook settings.  

---

📌 Це базовий імпорт-гайд. Далі можна налаштувати стиль, іконки та інтеграцію з іншими модулями DAO-GOGS.

---

🏷️ #UserGuide

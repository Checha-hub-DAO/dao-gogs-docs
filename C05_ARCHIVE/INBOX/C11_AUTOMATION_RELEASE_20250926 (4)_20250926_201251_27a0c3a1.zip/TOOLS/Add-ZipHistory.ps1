param(
    [Alias("n")][Parameter(Mandatory=$true)][string]$Name,
    [Alias("s")][Parameter(Mandatory=$true)][ValidateSet("Інтегровано","Чернетка","Тестування","Відхилено","Архівовано")] [string]$Status,
    [Alias("m")][Parameter(Mandatory=$true)][ValidateSet("Draft","Beta","Release")] [string]$Maturity,
    [Alias("p")][string]$Path = "D:\CHECHA_CORE\C11_AUTOMATION\",
    [Alias("hash")][switch]$ComputeHash,
    [Alias("zf")][string]$ZipFullPath,
    [Alias("csv")][string]$Csv = "D:\CHECHA_CORE\C05_ARCHIVE\ZIP_HISTORY.csv",
    [Alias("md")][string]$Md  = "D:\CHECHA_CORE\C05_ARCHIVE\ZIP_HISTORY.md",
    [Alias("preset")][ValidateSet("C11","WORKSHOP-DRAFT","WORKSHOP-TEST")] [string]$Preset
)

# Пресети шляхів
switch ($Preset) {
    "C11"            { $Path = "D:\CHECHA_CORE\C11_AUTOMATION\" }
    "WORKSHOP-DRAFT" { $Path = "D:\CHECHA_CORE\WORKSHOP\drafts\" }
    "WORKSHOP-TEST"  { $Path = "D:\CHECHA_CORE\WORKSHOP\testing\" }
}

$tool = "D:\CHECHA_CORE\TOOLS\Update-ZipHistory.ps1"
if (-not (Test-Path $tool)) {
    Write-Error "Не знайдено $tool. Скопіюй Update-ZipHistory.ps1 у D:\CHECHA_CORE\TOOLS\ і повтори."
    exit 1
}

# Проксі-виклик з передачою параметрів
$common = @{
    ZipName    = $Name
    Status     = $Status
    Maturity   = $Maturity
    PathValue  = $Path
    CsvPath    = $Csv
    MdPath     = $Md
}

if ($ComputeHash) { $common["ComputeHash"] = $true }
if ($ZipFullPath) { $common["ZipFullPath"]  = $ZipFullPath }

& $tool @common

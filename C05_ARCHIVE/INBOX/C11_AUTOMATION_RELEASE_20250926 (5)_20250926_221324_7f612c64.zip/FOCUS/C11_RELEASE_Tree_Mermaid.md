# C11_AUTOMATION_RELEASE_20250926 — Tree (Mermaid)

```mermaid
flowchart TD
    ROOT[C11_AUTOMATION_RELEASE_20250926.zip]

    ROOT --> TOOLS[TOOLS/]
    ROOT --> ARCHIVE[ARCHIVE/]
    ROOT --> FOCUS[FOCUS/]
    ROOT --> README[README.md]
    ROOT --> INSTALL[INSTALL.md]
    ROOT --> README_REL[README_RELEASE.md]

    TOOLS --> UZ[Update-ZipHistory.ps1]
    TOOLS --> AZ[Add-ZipHistory.ps1]
    TOOLS --> SD[START-DEMO.ps1]
    TOOLS --> IR[INTEGRATE-RELEASE.ps1]
    TOOLS --> AI[AUTO-INBOX.ps1]

    ARCHIVE --> ZC[ZIP_HISTORY.csv]
    ARCHIVE --> ZM[ZIP_HISTORY.md]

    FOCUS --> TCL[TASK-CheckList.md]
    FOCUS --> ZIF[ZIP_Integration_Flow.md]
    FOCUS --> FR[FLOW-README.md]
    FOCUS --> AIF[AUTO-INBOX_Flow.md]
```

*Порада:* у GitBook просто встав цей файл як Markdown — діаграма відрендериться автоматично.

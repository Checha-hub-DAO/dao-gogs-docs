# C11_AUTOMATION_ZIPTOOLS_v1.0

📦 Набір інструментів для роботи з ZIP-пакетами у блоці **C11_AUTOMATION**.

---

## Вміст

- **ZIP_HISTORY_template.csv** — шаблон історії ZIP-пакетів (CSV)
- **ZIP_HISTORY.md** — Markdown-версія історії для GitBook
- **Update-ZipHistory.ps1** — основний PowerShell-скрипт для оновлення історії ZIP
- **Add-ZipHistory.ps1** — обгортка для швидкого виклику з короткими ключами та пресетами
- **TASK-CheckList.md** — щоденний чекліст інтеграції ZIP
- **ZIP_Integration_Flow.md** — Mermaid-схема процесу інтеграції

---

## Використання

1. Розмістіть файли у директорії:
   ```
   D:\CHECHA_CORE\TOOLS\
   ```
   (крім CSV/MD, вони зберігатимуться у `C05_ARCHIVE`)

2. Використовуйте скрипти:
   - `Update-ZipHistory.ps1` — детальний контроль інтеграції.
   - `Add-ZipHistory.ps1` — скорочений виклик із пресетами.

3. Ведіть історію:
   - CSV (`ZIP_HISTORY.csv`) — для автоматизації та логів.
   - MD (`ZIP_HISTORY.md`) — для GitBook-публікацій.

4. Щодня проходьте чекліст (`TASK-CheckList.md`).  
5. Для візуалізації використовуйте Mermaid-схему (`ZIP_Integration_Flow.md`).

---

✍ Автор: С.Ч.  
Версія пакета: **v1.0**  

# Verify-Workshops.ps1 — Інструкція

**Призначення:** перевірка каталогу майстерень на основі CSV-індексу (`WORKSHOPS_INDEX_v0.2.csv`).  
Скрипт перевіряє наявність папок і вихідних артефактів, валідує статус-коди (S0–S3) і формує звіти у `logs`.

## Вимоги
- Windows PowerShell 5.1 або PowerShell 7+
- CSV із колонками: `ID, Назва, Статус, Шлях, Вихідні`

## Швидкий старт
```powershell
# Запуск у стандартному режимі
pwsh -NoProfile -ExecutionPolicy Bypass -File .\Verify-Workshops.ps1 `
  -IndexCsv "D:\CHECHA_CORE\WORKSHOP\WORKSHOPS_INDEX_v0.2.csv"

# Строгий режим (ненульовий ExitCode при помилках)
pwsh -NoProfile -ExecutionPolicy Bypass -File .\Verify-Workshops.ps1 `
  -IndexCsv "D:\CHECHA_CORE\WORKSHOP\WORKSHOPS_INDEX_v0.2.csv" -Strict
```

## Вихідні артефакти
- `logs\workshops_report_YYYYMMDD_HHMMSS.csv`
- `logs\workshops_report_YYYYMMDD_HHMMSS.json`
- `logs\workshops_report_YYYYMMDD_HHMMSS.log.txt`

## Поради
- Для шаблонів типу `MAPS_*.pdf/png` скрипт намагається знайти збіги за маскою. Якщо потрібно точніше — розпишіть окремими позиціями (`MAPS_*.pdf; MAPS_*.png`).
- Для `S0` (ідея) пропуски артефактів не вважаються критичною помилкою.

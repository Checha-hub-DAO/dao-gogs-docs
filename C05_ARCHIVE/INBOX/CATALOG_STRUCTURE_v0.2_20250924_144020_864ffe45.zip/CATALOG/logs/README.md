# logs
Тут зберігатимуться звіти перевірки (CSV/JSON/LOG), що генеруються Verify-Workshops.ps1.
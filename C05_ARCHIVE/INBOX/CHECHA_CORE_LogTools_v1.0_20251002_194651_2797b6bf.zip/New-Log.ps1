param(
    [Parameter(Mandatory=$true)]
    [string]$Project,
    [string]$Dir = "D:\CHECHA_CORE\C06_FOCUS",
    [string]$TemplatePath = "$PSScriptRoot\TEMPLATE_LOG.md"
)

# Ensure target directory exists
if (-not (Test-Path -Path $Dir)) {
    New-Item -ItemType Directory -Path $Dir -Force | Out-Null
}

# If template not found next to the script, try current directory
if (-not (Test-Path -Path $TemplatePath)) {
    $TemplatePath = Join-Path -Path (Get-Location) -ChildPath "TEMPLATE_LOG.md"
}

if (-not (Test-Path -Path $TemplatePath)) {
    Write-Error "Template file not found: $TemplatePath"
    exit 1
}

# Compose file name: YYYY-MM-DD_HH-mm_[Project]_LOG.md
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm"
# Sanitize project name for filename
$cleanProject = ($Project -replace '[^\w\s-]', '').Trim() -replace '\s+', '_'
$filename = "{0}_{1}_LOG.md" -f $timestamp, $cleanProject
$targetPath = Join-Path -Path $Dir -ChildPath $filename

# Read template and replace placeholders
$template = Get-Content -Path $TemplatePath -Raw -Encoding UTF8

# Prepare values
$displayDate = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

$body = $template -replace '\[YYYY-MM-DD HH:MM:SS\]', [Regex]::Escape($displayDate)
$body = $body -replace '\[Назва проєкту / теми\]', [Regex]::Escape($Project)

# Write file in UTF-8 (no BOM)
[System.IO.File]::WriteAllText($targetPath, $body, New-Object System.Text.UTF8Encoding($false))

Write-Host "Created log:"
Write-Host $targetPath

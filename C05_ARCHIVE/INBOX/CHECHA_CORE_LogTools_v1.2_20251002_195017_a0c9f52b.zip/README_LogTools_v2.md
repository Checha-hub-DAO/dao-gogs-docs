# 📘 CHECHA_CORE Log Tools v1.2

Набір інструментів для швидкого створення логів у системі **CHECHA_CORE (C06_FOCUS)**.

## 📂 Вміст пакету
- **TEMPLATE_LOG.md** — шаблон логу у форматі GitBook-ready.
- **New-Log.ps1** — PowerShell-скрипт для генерації нового логу (ручний режим).
- **New-Log.bat** — BAT-обгортка для ручного введення назви проєкту.
- **New-Log-Daily.bat** — BAT-версія з фіксованою назвою *Daily Session*.
- **README_LogTools_v2.md** — інструкція.

## ⚙️ Використання

### 🔹 Варіант 1: PowerShell (ручний)
```powershell
D:\CHECHA_CORE\C06_FOCUS\New-Log.ps1 -Project "My Ukrainian Book v1.2"
```
✅ Результат: створюється файл у форматі:
```
2025-10-02_20-10_My_Ukrainian_Book_v1.2_LOG.md
```

### 🔹 Варіант 2: BAT (ручний)
1. Двічі клацни `New-Log.bat`.
2. Введи назву проєкту (наприклад: *Ukrainian as Bridge Language*).
3. Файл буде створений у потрібному форматі.

### 🔹 Варіант 3: BAT (автоматичний)
1. Двічі клацни `New-Log-Daily.bat`.
2. Файл одразу створюється з назвою *Daily Session*.

---
С.Ч.

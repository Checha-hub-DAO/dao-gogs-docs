# 📘 CHECHA_CORE Log Tools v1.3

Набір інструментів для швидкого створення логів у системі **CHECHA_CORE (C06_FOCUS)**.

## 📂 Вміст пакету
- **TEMPLATE_LOG.md** — шаблон логу у форматі GitBook-ready.
- **New-Log.ps1** — PowerShell-скрипт (ручний режим).
- **New-Log.bat** — BAT-обгортка для ручного введення назви.
- **New-Log-Daily.bat** — автоматичний режим (*Daily Session*).
- **New-Log-Weekly.bat** — автоматичний режим (*Weekly Review*).
- **README_LogTools_v3.md** — інструкція.

## ⚙️ Використання

### 🔹 Ручний режим (PowerShell або BAT)
```powershell
D:\CHECHA_CORE\C06_FOCUS\New-Log.ps1 -Project "My Ukrainian Book v1.2"
```
Або подвійний клік по `New-Log.bat` і введи назву проєкту.

### 🔹 Автоматичний режим
- `New-Log-Daily.bat` → створює лог із назвою **Daily Session**.
- `New-Log-Weekly.bat` → створює лог із назвою **Weekly Review**.

## 📌 Розміщення файлів
Поклади всі файли в `D:\CHECHA_CORE\C06_FOCUS\`.  
За потреби створи ярлики на робочому столі на відповідні BAT-файли.

---
С.Ч.

param(
    [Parameter(Mandatory = $false)]
    [ValidateSet('Daily','Weekly','Custom')]
    [string]$Mode = 'Custom',

    [Parameter(Mandatory = $true)]
    [string]$Project,

    [string]$Dir = "D:\CHECHA_CORE\C06_FOCUS",

    # Основні робочі папки, в яких шукати недавні зміни (додай свої)
    [string[]]$ScanPaths = @("D:\CHECHA_CORE", "D:\Projects"),

    # Горизонт вибірки (за замовч): 24h для Daily, 7d для Weekly, інакше 24h
    [TimeSpan]$Since = [TimeSpan]::Zero,

    # Git: шлях до exe (якщо в PATH, можна лишити 'git')
    [string]$GitExe = "git",

    # Скільки комітів показувати
    [int]$GitMax = 10,

    # Шлях до шаблону
    [string]$TemplatePath = "D:\CHECHA_CORE\C06_FOCUS\TEMPLATE_LOG_v2.md"
)

function Resolve-Since {
    param([string]$Mode, [TimeSpan]$Since)
    if ($Since -ne [TimeSpan]::Zero) { return $Since }
    switch ($Mode) {
        'Daily'  { return [TimeSpan]::FromHours(24) }
        'Weekly' { return [TimeSpan]::FromDays(7) }
        default  { return [TimeSpan]::FromHours(24) }
    }
}

function Get-RecentFiles {
    param([string[]]$Roots, [DateTime]$After)
    $list = @()
    foreach ($r in $Roots) {
        if (Test-Path $r) {
            Get-ChildItem -Path $r -Recurse -File -ErrorAction SilentlyContinue |
                Where-Object { $_.LastWriteTime -ge $After } |
                Sort-Object LastWriteTime -Descending |
                Select-Object -First 50 |
                ForEach-Object {
                    "{0:yyyy-MM-dd HH:mm} — {1}" -f $_.LastWriteTime, $_.FullName
                } | ForEach-Object { $list += $_ }
        }
    }
    if ($list.Count -eq 0) { return "—" }
    return ($list -join "`r`n")
}

function Get-GitCommits {
    param([string]$GitExe, [int]$Max, [DateTime]$After, [string[]]$Roots)
    # Знайдемо перший каталог, що містить .git
    $repo = $null
    foreach ($r in $Roots) {
        if (Test-Path (Join-Path $r ".git")) { $repo = $r; break }
    }
    if (-not $repo) { return "—" }

    $sinceIso = $After.ToString("yyyy-MM-dd")
    try {
        $out = & $GitExe -C $repo log --since="$sinceIso" --max-count=$Max --pretty=format:"%h | %ad | %an | %s" --date=format:"%Y-%m-%d %H:%M"
        if ([string]::IsNullOrWhiteSpace($out)) { return "—" }
        $lines = $out -split "`r?`n" | Select-Object -First $Max
        return ($lines -join "`r`n")
    } catch {
        return "—"
    }
}

# === Підготовка ===
if (-not (Test-Path -Path $Dir)) {
    New-Item -ItemType Directory -Path $Dir -Force | Out-Null
}
if (-not (Test-Path -Path $TemplatePath)) {
    Write-Error "Template file not found: $TemplatePath"
    exit 1
}

$Since = Resolve-Since -Mode $Mode -Since $Since
$after = (Get-Date).Add(-$Since)

# Файл-ціль
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm"
$cleanProject = ($Project -replace '[^\w\s-]', '').Trim() -replace '\s+', '_'
$filename = "{0}_{1}_LOG.md" -f $timestamp, $cleanProject
$targetPath = Join-Path -Path $Dir -ChildPath $filename

# Читання шаблону
$template = Get-Content -Path $TemplatePath -Raw -Encoding UTF8

# Системний блок
$displayDate = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$sys = @()
$sys += ("User: {0}" -f $env:USERNAME)
$sys += ("Machine: {0}" -f $env:COMPUTERNAME)
$sys += ("Mode: {0}" -f $Mode)
$sys += ("Since: last {0}d {1}h" -f [int]$Since.TotalDays, [int]$Since.TotalHours)
$systemBlock = ($sys -join "`r`n")

# Автозбір
$filesBlock = Get-RecentFiles -Roots $ScanPaths -After $after
$gitBlock   = Get-GitCommits -GitExe $GitExe -Max $GitMax -After $after -Roots $ScanPaths

# Підстановки
$body = $template
$body = $body -replace '\[YYYY-MM-DD HH:MM:SS\]', [Regex]::Escape($displayDate)
$body = $body -replace '\[Назва проєкту / теми\]', [Regex]::Escape($Project)
$body = $body -replace '\[AUTOFILL:FILES\]',   [System.Text.RegularExpressions.Regex]::Escape($filesBlock)
$body = $body -replace '\[AUTOFILL:GIT\]',     [System.Text.RegularExpressions.Regex]::Escape($gitBlock)
$body = $body -replace '\[AUTOFILL:SYSTEM\]',  [System.Text.RegularExpressions.Regex]::Escape($systemBlock)

# Запис у файл у UTF-8 без BOM
$utf8NoBomEncoding = New-Object System.Text.UTF8Encoding $false
[System.IO.File]::WriteAllText($targetPath, $body, $utf8NoBomEncoding)

Write-Host "✅ Created log:"
Write-Host $targetPath

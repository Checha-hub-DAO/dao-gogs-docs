# 📘 CHECHA_CORE Log Tools v2.0 (з автозаповненням)

Ця версія додає **автоматичний збір контенту** у лог:
- недавні змінені файли у ваших робочих папках;
- останні git-коміти (якщо знайдено репозиторій);
- системна інформація (користувач, машина, режим, горизонт Since).

## 🧩 Шаблон
Використовується **TEMPLATE_LOG_v2.md** із токенами:
- `[AUTOFILL:FILES]`
- `[AUTOFILL:GIT]`
- `[AUTOFILL:SYSTEM]`

## ▶️ Запуск
### PowerShell (рекомендується)
```powershell
D:\CHECHA_CORE\C06_FOCUS\New-Log.ps1 -Mode Daily -Project "Daily Session"
D:\CHECHA_CORE\C06_FOCUS\New-Log.ps1 -Mode Weekly -Project "Weekly Review"
D:\CHECHA_CORE\C06_FOCUS\New-Log.ps1 -Mode Custom -Project "My Ukrainian Book v2.0" -Since (New-TimeSpan -Hours 48) -ScanPaths "D:\CHECHA_CORE","D:\Docs"
```

### BAT (для подвійного кліку)
- `New-Log.bat` → ручний ввід назви, режим **Custom**  
- `New-Log-Daily.bat` → режим **Daily**  
- `New-Log-Weekly.bat` → режим **Weekly**

## ⚙️ Налаштування
В `New-Log.ps1` можна змінити:
- `ScanPaths` — де шукати нещодавні файли;
- `GitExe` — шлях до `git` (за умовчанням у PATH);
- `GitMax` — скільки комітів показувати;
- `TemplatePath` — шлях до шаблону.

---
С.Ч.

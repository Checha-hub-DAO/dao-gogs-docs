# 🔄 ARTIFACTS_FLOW — Життєвий цикл артефакту

Цей документ описує повний шлях артефакту в системі **CREATOR_SUITE**: від створення у Майстерні до архівації після релізу.

---

## 1. Етапи життєвого циклу
1. **Idea (Draft)**  
   - Створюється у WORKSHOP.  
   - Мінімальний маніфест: ID, Title, Owner, Type.  

2. **Development (InProgress)**  
   - Робота над артефактом (додаються файли, візуали, документація).  
   - SHA-256 для кожного файлу перевіряється `Fix-Manifests.ps1`.  

3. **Review (Cabinet)**  
   - Артефакт надсилається у CABINET для обговорення.  
   - Використовуються: `ROOMS.md`, `ROLES.md`, `PROTOCOLS.md`.  
   - Стан: `Review`.  

4. **Decision (Council)**  
   - Рада приймає рішення (Approved / Rejected).  
   - Якщо `Approved` → артефакт повертається у WORKSHOP.  
   - Якщо `Rejected` → архівується.  

5. **Release Preparation (ReadyForRelease)**  
   - Артефакт позначається як готовий до релізу.  
   - Додається тег `ReleaseTag`.  

6. **Release (Released)**  
   - Артефакт публікується (може бути GitBook, сайт, соціальні мережі).  
   - Вноситься у Registry з датою та тегом.  

7. **Archive**  
   - Завершений артефакт зберігається у архіві.  
   - Всі файли + маніфест пакуються у ZIP.  

---

## 2. Правила переходів
- `Draft → InProgress` — коли з’явився перший файл/візуал.  
- `InProgress → Review` — після готовності чернетки (через Sync у CABINET).  
- `Review → ReadyForRelease` — після CouncilDecision = Approved.  
- `Review → Archive` — якщо CouncilDecision = Rejected.  
- `ReadyForRelease → Released` — після маркування релізу.  
- `Released → Archive` — за політикою архівації (наприклад, після певного часу).  

---

## 3. Автоматизація
- **Fix-Manifests.ps1** — перевіряє/дописує SHA-256 у маніфестах.  
- **Sync-WorkshopCabinet.ps1** — синхронізує артефакти між WORKSHOP і CABINET та оновлює Registry.  
- **pipeline.ps1** — інтегрований запуск Fix + Sync, звіти у CSV.  

---

## 4. Візуалізація
```mermaid
flowchart TD
    A[Idea / Draft] --> B[Development / InProgress]
    B --> C[Review / Cabinet]
    C -->|Approved| D[ReadyForRelease]
    C -->|Rejected| G[Archive]
    D --> E[Release / Published]
    E --> G[Archive]
```

---

© Життєвий цикл артефакту | v1.0 | С.Ч.

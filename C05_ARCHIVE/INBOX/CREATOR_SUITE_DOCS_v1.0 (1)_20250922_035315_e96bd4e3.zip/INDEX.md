# 📚 CREATOR_SUITE Documentation Index

Цей пакет містить базові документи для системи **CREATOR_SUITE v1.0**.

---

## 🔑 Документи

1. **[WORKSHOP_PARAMETERS.md](WORKSHOP_PARAMETERS.md)**  
   Параметри Майстерні Творця. Шляхи, протоколи, автоматизація, YAML-приклад.

2. **[CABINET_PARAMETERS.md](CABINET_PARAMETERS.md)**  
   Параметри Кабінету Творця. Ролі, протоколи, рада, YAML-приклад.

3. **[MASTER_PARAMETERS.md](MASTER_PARAMETERS.md)**  
   Інтегрований файл: об’єднані параметри Майстерні та Кабінету.

4. **[ARTIFACTS_FLOW.md](ARTIFACTS_FLOW.md)**  
   Життєвий цикл артефакту. Етапи, правила переходів, блок-схема.

---

## 🚀 Використання
- Почни з **MASTER_PARAMETERS.md** для розуміння всієї системи.  
- Для деталі по окремому модулю дивись **WORKSHOP_PARAMETERS.md** або **CABINET_PARAMETERS.md**.  
- Для управління життєвим циклом артефактів — **ARTIFACTS_FLOW.md**.  

---

© CREATOR_SUITE v1.0 | С.Ч.

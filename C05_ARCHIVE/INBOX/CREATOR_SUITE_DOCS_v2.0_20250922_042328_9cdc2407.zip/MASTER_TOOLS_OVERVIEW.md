# 🌌 MASTER_TOOLS_OVERVIEW — Об’єднаний огляд інструментів Майстерні та Кабінету Творця

Цей документ інтегрує всі основні інструменти з **WORKSHOP_CREATOR** та **CABINET_CREATOR**.

---

## 🛠️ Майстерня (WORKSHOP_CREATOR)

### Категорії інструментів
| Категорія | Інструмент | Призначення |
|-----------|------------|-------------|
| ✏️ Творчість | `IDEA_CAPTURE.ps1` | Створення нової ідеї |
| ✏️ Творчість | `Generate-Readme.ps1` | Шаблон README |
| 📄 Документація | `WORKSHOP_PARAMETERS.md` | Параметри середовища |
| 🧩 Артефакти | `Build-Package.ps1` | Формування ZIP |
| 🧩 Артефакти | `Fix-Manifests.ps1` | SHA-256 перевірка |
| 🔄 Синхронізація | `Sync-WorkshopCabinet.ps1` | Синхронізація з Кабінетом |
| 🔄 Синхронізація | `ArtifactsRegistry.csv` | Реєстр артефактів |
| 🧪 Перевірка | `Validate-Workshop.ps1` | Перевірка валідності |
| 📊 Аналітика | `Workshop-Report.ps1` | Звіт по Майстерні |

---

## 🏛️ Кабінет (CABINET_CREATOR)

### Категорії інструментів
| Категорія | Інструмент | Призначення |
|-----------|------------|-------------|
| 👥 Організація | `ROOMS.md` | Кімнати для обговорень |
| 👥 Організація | `ROLES.md` | Ролі учасників |
| 👥 Організація | `PROTOCOLS.md` | Регламенти |
| 🧾 Рішення | `COUNCIL_DECISIONS.md` | Рішення Ради |
| 🧾 Рішення | `Council-Report.ps1` | Автоматичний звіт |
| 🔄 Синхронізація | `Sync-WorkshopCabinet.ps1` | Отримання артефактів |
| 🔄 Синхронізація | `ArtifactsRegistry.csv` | Реєстр артефактів |
| 🧪 Перевірка | `Validate-Cabinet.ps1` | Перевірка валідності |
| 📊 Аналітика | `Cabinet-Report.ps1` | Звіт по Кабінету |

---

## 🔗 Єдиний потік роботи

```mermaid
flowchart LR
    subgraph WORKSHOP [Майстерня]
        A[IDEA_CAPTURE.ps1] --> B[Generate-Readme.ps1]
        B --> C[Fix-Manifests.ps1]
        C --> D[Build-Package.ps1]
        D --> E[Sync-WorkshopCabinet.ps1]
    end

    subgraph CABINET [Кабінет]
        E --> F[ROOMS.md]
        F --> G[ROLES.md]
        G --> H[PROTOCOLS.md]
        H --> I[COUNCIL_DECISIONS.md]
        I --> J[Council-Report.ps1]
        J --> K[Archive]
    end
```

---

📌 **Призначення:** цей об’єднаний огляд допомагає побачити повну екосистему інструментів, зрозуміти взаємозв’язки між Майстернею і Кабінетом та швидко орієнтуватись у роботі з артефактами.

© CREATOR_SUITE v1.0 | С.Ч.

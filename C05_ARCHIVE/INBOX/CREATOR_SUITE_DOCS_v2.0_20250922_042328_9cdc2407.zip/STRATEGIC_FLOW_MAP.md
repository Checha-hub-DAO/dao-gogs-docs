# 🧭 STRATEGIC_FLOW_MAP — Стратегічна мапа потоку артефактів
*Оновлено: 2025-09-22 01:21*

Ця мапа показує **циклічний стратегічний потік** між Майстернею (WORKSHOP), Кабінетом (CABINET), релізом (RELEASE) і архівом (ARCHIVE), а також ключові точки контролю.

---

## 1) Головний цикл
```mermaid
flowchart LR
    subgraph WORKSHOP[WORKSHOP — Майстерня]
      A1[Ідея / Draft] --> A2[Розробка / InProgress]
      A2 -->|Готово до огляду| A3[Пакування / Build]
    end

    subgraph CABINET[CABINET — Кабінет]
      B1[Огляд / Review] --> B2[Обговорення / Rooms+Roles]
      B2 --> B3[Рішення Ради / Council]
      B3 -->|Approved| C1[ReadyForRelease]
      B3 -->|Rejected| D1[Archive]
    end

    A3 --> B1
    C1 --> C2[Release / Publish]
    C2 --> D1[Archive]
    D1 -->|Переосмислення| A1
```

---

## 2) Контрольні точки та автоматизація
```mermaid
flowchart TB
    X1[Fix-Manifests.ps1<br/>SHA-256 & LastUpdated] --> X2[Sync-WorkshopCabinet.ps1<br/>Validation + Registry.csv]
    X2 -->|Strict OK| X3[pipeline.ps1<br/>Fix + Sync + Reports]
    X2 -->|Issues| X4[Validation Report CSV]
    X3 --> X5[Dashboard.html<br/>KPI + Filters + Export]
```

**Примітки:**  
- `Fix-Manifests.ps1` — усуває відсутні/невірні SHA-256.  
- `Sync-WorkshopCabinet.ps1 -Strict` — не пропускає маніфести з помилками до реєстру.  
- `pipeline.ps1` — інтегрований запуск, готує звіти.  
- `dashboard.html` — візуальний контроль та експорт зрізів.

---

## 3) KPI для керування потоком
- **Lead Time**: час від `Draft` до `Released`.  
- **Throughput/Тиждень**: кількість артефактів, що перейшли `Review → Approved` і `ReadyForRelease → Released`.  
- **WIP (Work in Progress)**: скільки в `InProgress` і `Review`.  
- **Quality Gate**: відсоток відхилених (`Rejected`) до надісланих у `Review`.  

---

## 4) Операційні ритуали (рекомендація)
- **Щодня**: короткий огляд `Dashboard.html` + виправлення помилок у `validation.csv`.  
- **Щотижня**: запуск `pipeline.ps1` у CRON/Task Scheduler, автоекспорт PDF-дайджесту.  
- **Щомісяця**: ревізія архівів, переосмислення відкладених артефактів → повернення в `Draft` (якщо актуально).

---

© CREATOR_SUITE | Стратегічна мапа циклу артефактів

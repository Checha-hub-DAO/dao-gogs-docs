<#
.SYNOPSIS
  Build-AgentKPI.ps1 — формує KPI Master-Agent з master-agent.log (+memory.json) у CSV/JSON/HTML.

.USAGE
  pwsh -NoProfile -ExecutionPolicy Bypass -File ".\Build-AgentKPI.ps1" `
    -LogPath ".\master-agent.log" `
    -MemoryPath ".\memory.json" `
    -OutCsv ".\agent_kpi.csv" `
    -OutJson ".\agent_kpi.json" `
    -OutHtml ".\agent_kpi.html"

.NOTES
  Очікуваний формат логів:
    [yyyy-MM-dd HH:mm:ss] RUN intentName
    [yyyy-MM-dd HH:mm:ss] OK  intentName
    [yyyy-MM-dd HH:mm:ss] ERR intentName -> message
    (додатково: в memory.json можуть бути записи про "cancel")
#>

param(
  [string]$LogPath   = ".\master-agent.log",
  [string]$MemoryPath= ".\memory.json",
  [string]$OutCsv    = ".\agent_kpi.csv",
  [string]$OutJson   = ".\agent_kpi.json",
  [string]$OutHtml   = ".\agent_kpi.html"
)

$ErrorActionPreference = "Stop"

function Parse-LogLine {
  param([string]$line)
  # [2025-09-22 11:22:33] RUN fix_manifests
  if ($line -match '^\[(?<ts>[\d\-:\s]+)\]\s+(?<type>RUN|OK|ERR)\s+(?<rest>.*)$') {
    $ts   = $Matches['ts']
    $type = $Matches['type']
    $rest = $Matches['rest']

    if ($type -eq 'RUN' -or $type -eq 'OK') {
      $intent = $rest.Trim()
      return [pscustomobject]@{ Timestamp=$ts; Type=$type; Intent=$intent; Message='' }
    } elseif ($type -eq 'ERR') {
      if ($rest -match '^(?<intent>[^ ]+)\s*->\s*(?<msg>.*)$') {
        return [pscustomobject]@{ Timestamp=$ts; Type=$type; Intent=$Matches['intent']; Message=$Matches['msg'] }
      } else {
        return [pscustomobject]@{ Timestamp=$ts; Type=$type; Intent=$rest; Message='' }
      }
    }
  }
  return $null
}

# 1) Зчитуємо лог
$events = @()
if (Test-Path -LiteralPath $LogPath) {
  Get-Content -LiteralPath $LogPath -Encoding UTF8 | ForEach-Object {
    $ev = Parse-LogLine -line $_
    if ($ev) { $events += $ev }
  }
}

# 2) Мапимо RUN→(OK|ERR), рахуємо тривалість
# Ключ — Intent, але подій може бути кілька; ідентифікуємо послідовно.
$rows = @()
$runStack = @{} # intent -> last RUN index/time
for ($i=0; $i -lt $events.Count; $i++) {
  $ev = $events[$i]
  $t  = [datetime]::ParseExact($ev.Timestamp, "yyyy-MM-dd HH:mm:ss", $null)
  if ($ev.Type -eq 'RUN') {
    if (-not $runStack.ContainsKey($ev.Intent)) { $runStack[$ev.Intent] = @() }
    $runStack[$ev.Intent] += ,@($i, $t)
  } elseif ($ev.Type -eq 'OK' -or $ev.Type -eq 'ERR') {
    if ($runStack.ContainsKey($ev.Intent) -and $runStack[$ev.Intent].Count -gt 0) {
      $pair = $runStack[$ev.Intent][0]
      # знімаємо найстаріший RUN
      $runStack[$ev.Intent] = $runStack[$ev.Intent][1..($runStack[$ev.Intent].Count-1)] 2>$null
      $runIdx, $runTime = $pair[0], $pair[1]
      $durSec = [int]([timespan]($t - $runTime)).TotalSeconds
      $status = ($ev.Type -eq 'OK') ? 'OK' : 'ERR'
      $rows += [pscustomobject]@{
        Date    = $runTime.ToString("yyyy-MM-dd")
        Start   = $runTime.ToString("HH:mm:ss")
        End     = $t.ToString("HH:mm:ss")
        Intent  = $ev.Intent
        Status  = $status
        Message = $ev.Message
        DurationSec = $durSec
      }
    } else {
      # Подія OK/ERR без RUN — запишемо без тривалості
      $rows += [pscustomobject]@{
        Date    = $t.ToString("yyyy-MM-dd")
        Start   = ''
        End     = $t.ToString("HH:mm:ss")
        Intent  = $ev.Intent
        Status  = ($ev.Type -eq 'OK') ? 'OK' : 'ERR'
        Message = $ev.Message
        DurationSec = ''
      }
    }
  }
}

# 3) Врахуємо "cancel" з memory.json (зафіксовані скасування)
if (Test-Path -LiteralPath $MemoryPath) {
  try {
    $mem = Get-Content -LiteralPath $MemoryPath -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($n in ($mem.notes | Where-Object { $_.tags -contains 'cancel' })) {
      $tt = [datetime]::Parse($n.timestamp)
      $rows += [pscustomobject]@{
        Date    = $tt.ToString("yyyy-MM-dd")
        Start   = ''
        End     = $tt.ToString("HH:mm:ss")
        Intent  = 'unknown/cancel'
        Status  = 'CANCEL'
        Message = $n.text
        DurationSec = ''
      }
    }
  } catch {
    Write-Warning "Не вдалося обробити memory.json: $($_.Exception.Message)"
  }
}

# 4) Зберігаємо CSV
$rows | Sort-Object Date, Start | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath $OutCsv

# 5) Агрегуємо KPI
$ok = ($rows | Where-Object { $_.Status -eq 'OK' }).Count
$err = ($rows | Where-Object { $_.Status -eq 'ERR' }).Count
$cancel = ($rows | Where-Object { $_.Status -eq 'CANCEL' }).Count
$total = ($rows).Count
$avgDur = 0
$durRows = $rows | Where-Object { $_.DurationSec -match '^\d+$' }
if ($durRows.Count -gt 0) { $avgDur = [math]::Round(($durRows | Measure-Object -Property DurationSec -Average).Average, 2) }

$byIntent = @()
$rows | Group-Object Intent | ForEach-Object {
  $name = $_.Name
  $g = $_.Group
  $byIntent += [pscustomobject]@{
    Intent = $name
    Count  = $g.Count
    OK     = ($g | Where-Object { $_.Status -eq 'OK' }).Count
    ERR    = ($g | Where-Object { $_.Status -eq 'ERR' }).Count
    CANCEL = ($g | Where-Object { $_.Status -eq 'CANCEL' }).Count
    AvgDur = if (($g | Where-Object { $_.DurationSec -match '^\d+$' }).Count -gt 0) {
      [math]::Round((($g | Where-Object { $_.DurationSec -match '^\d+$' }) | Measure-Object -Property DurationSec -Average).Average, 2)
    } else { 0 }
  }
}

$kpi = [pscustomobject]@{
  Total   = $total
  OK      = $ok
  ERR     = $err
  CANCEL  = $cancel
  SuccessRate = if ($total -gt 0) { [math]::Round(100.0 * $ok / $total, 2) } else { 0 }
  AvgDurationSec = $avgDur
  ByIntent = $byIntent
}

$kpi | ConvertTo-Json -Depth 10 | Out-File -LiteralPath $OutJson -Encoding UTF8

# 6) Генеруємо простий HTML-дашборд (без зовнішніх залежностей)
$html = @"
<!DOCTYPE html>
<html lang="uk">
<head>
  <meta charset="utf-8" />
  <title>Master-Agent KPI</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial; margin: 24px; color: #eaf2ff; background: #0b0f14; }
    .card { background:#121821; border:1px solid #223041; border-radius:16px; padding:16px; margin-bottom:16px; }
    h1 { margin: 0 0 12px; }
    .kpi { display:grid; grid-template-columns: repeat(5,1fr); gap: 12px; }
    .kpi .item { background:#0e1520; border:1px solid #223041; border-radius:14px; padding:12px; }
    .item h3 { margin:0 0 6px; font-size:12px; color:#c7d1e0; font-weight:500; }
    .item .val { font-size:18px; font-weight:700; }
    table { width:100%; border-collapse: collapse; }
    thead th { text-align:left; font-size:12px; color:#c7d1e0; border-bottom:1px solid #223041; padding:8px; position:sticky; top:0; background:#101722; }
    tbody td { border-bottom:1px solid #1a2636; padding:8px; font-size:13px; }
    .muted { color:#c7d1e0; }
  </style>
</head>
<body>
  <h1>Master-Agent KPI</h1>
  <div class="card">
    <div class="kpi">
      <div class="item"><h3>Подій всього</h3><div id="k_total" class="val">—</div></div>
      <div class="item"><h3>Успішно (OK)</h3><div id="k_ok" class="val">—</div></div>
      <div class="item"><h3>Помилки (ERR)</h3><div id="k_err" class="val">—</div></div>
      <div class="item"><h3>Скасовано</h3><div id="k_cancel" class="val">—</div></div>
      <div class="item"><h3>Сер. тривалість, с</h3><div id="k_avg" class="val">—</div></div>
    </div>
  </div>

  <div class="card">
    <h3 class="muted">Розподіл по інтентах</h3>
    <table id="tbl">
      <thead><tr><th>Intent</th><th>Count</th><th>OK</th><th>ERR</th><th>CANCEL</th><th>AvgDur(s)</th></tr></thead>
      <tbody></tbody>
    </table>
  </div>

  <div class="card">
    <h3 class="muted">Як оновити</h3>
    <p>Перегенеруйте файли, виконавши скрипт:<br><code>pwsh -NoProfile -File .\Build-AgentKPI.ps1</code></p>
  </div>

<script>
fetch('agent_kpi.json')
  .then(r => r.json())
  .then(k => {
    document.getElementById('k_total').textContent = k.Total;
    document.getElementById('k_ok').textContent = k.OK;
    document.getElementById('k_err').textContent = k.ERR;
    document.getElementById('k_cancel').textContent = k.CANCEL;
    document.getElementById('k_avg').textContent = k.AvgDurationSec;

    const tb = document.querySelector('#tbl tbody');
    k.ByIntent.forEach(row => {
      const tr = document.createElement('tr');
      ['Intent','Count','OK','ERR','CANCEL','AvgDur'].forEach(key => {
        const td = document.createElement('td');
        td.textContent = row[key];
        tr.appendChild(td);
      });
      tb.appendChild(tr);
    });
  })
  .catch(err => {
    const tb = document.querySelector('#tbl tbody');
    const tr = document.createElement('tr');
    const td = document.createElement('td');
    td.colSpan = 6;
    td.textContent = 'Не вдалося завантажити agent_kpi.json: ' + err;
    tr.appendChild(td);
    tb.appendChild(tr);
  });
</script>
</body>
</html>
"@

$html | Out-File -LiteralPath $OutHtml -Encoding UTF8

Write-Host "✅ KPI зібрано:"
Write-Host " - CSV : $OutCsv"
Write-Host " - JSON: $OutJson"
Write-Host " - HTML: $OutHtml"

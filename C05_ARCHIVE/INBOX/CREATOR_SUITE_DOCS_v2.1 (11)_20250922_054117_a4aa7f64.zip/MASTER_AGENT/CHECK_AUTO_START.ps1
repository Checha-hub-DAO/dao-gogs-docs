# CHECK_AUTO_START.ps1 — перевірка автозапуску Master-Agent у Windows

$Startup = [Environment]::GetFolderPath("Startup")
$Shortcut = Join-Path $Startup "Master-Agent.lnk"

if (Test-Path $Shortcut) {
    Write-Host "✅ Master-Agent є в автозапуску: $Shortcut"
} else {
    Write-Host "❌ Master-Agent не доданий у автозапуск."
}

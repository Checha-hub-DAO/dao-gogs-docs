# QUICKSTART.ps1 — запуск Master-Agent з меню

param(
    [string]$ExecutionPolicy = "Bypass"
)

$agentPath = "D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\MASTER_AGENT\master-agent.ps1"

if (-not (Test-Path $agentPath)) {
    Write-Error "❌ Не знайдено Master-Agent за шляхом: $agentPath"
    exit 1
}

Write-Host "🚀 Запуск Master-Agent..."
pwsh -NoProfile -ExecutionPolicy $ExecutionPolicy -File $agentPath

# AUTO_START.ps1 — додати Master-Agent у автозапуск Windows

$WshShell = New-Object -ComObject WScript.Shell

$Startup = [Environment]::GetFolderPath("Startup")
$Shortcut = $WshShell.CreateShortcut("$Startup\Master-Agent.lnk")

$Shortcut.TargetPath = "pwsh.exe"
$Shortcut.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\MASTER_AGENT\master-agent.ps1"'
$Shortcut.WorkingDirectory = "D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\MASTER_AGENT"
$Shortcut.WindowStyle = 1
$Shortcut.IconLocation = "pwsh.exe,0"
$Shortcut.Description = "Автозапуск Master-Agent (CREATOR_SUITE)"

$Shortcut.Save()

Write-Host "✅ Master-Agent додано в автозапуск Windows."

# 🚀 README — Master-Agent

Master-Agent — це консольний асистент у **CREATOR_SUITE**, який допомагає керувати процесами Майстерні.

---

## 📂 Запуск

Перейдіть у директорію агента:
```powershell
cd D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\MASTER_AGENT
```

Запустіть меню:
```powershell
pwsh -NoProfile -ExecutionPolicy Bypass -File ".\master-agent.ps1"
```

---

## 🧩 Інтенти

| Інтент                 | Призначення |
|-------------------------|-------------|
| `capture_idea`          | Створити новий артефакт (ID, маніфест, README) |
| `fix_manifests`         | Оновити SHA256 у маніфестах |
| `fix_manifests_dryrun`  | Перевірка SHA256 без змін |
| `sync_registry`         | Синхронізація WORKSHOP↔CABINET |
| `sync_registry_dryrun`  | Сухий запуск синхронізації |
| `run_pipeline`          | Запуск повного конвеєра |
| `run_pipeline_dryrun`   | Pipeline у DryRun-режимі |
| `report_kpi`            | Порахувати KPI (описово) |
| `report_kpi_table`      | Таблиця KPI в консолі |
| `report_kpi_csv`        | Звіт KPI у kpi_summary.csv |
| `guide_docs`            | Підсвітити ключові документи |
| `plan_next`             | Запропонувати наступні кроки |
| `weekly_digest`         | Згенерувати тижневий дайджест |

---

## 📊 Звіти KPI

- Таблиця KPI:  
  ```powershell
  pwsh -NoProfile -ExecutionPolicy Bypass -File ".\master-agent.ps1" -Intent report_kpi_table
  ```

- CSV-звіт KPI:  
  ```powershell
  pwsh -NoProfile -ExecutionPolicy Bypass -File ".\master-agent.ps1" -Intent report_kpi_csv
  ```

---

## 🌱 Рівні компетенцій
Мапа розвитку агента описана у [AGENT_COMPETENCE_MAP.md](MASTER_AGENT/AGENT_COMPETENCE_MAP.md).

---

✍️ Автор: С.Ч.

# ⚙️ AUTO_START_MANAGER — Керування автозапуском Master-Agent

Цей набір скриптів дозволяє додавати, прибирати та перевіряти статус **Master-Agent** у автозапуску Windows.

---

## 🚀 Додати в автозапуск
```powershell
cd D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\MASTER_AGENT
.\AUTO_START.ps1
```
✅ Створюється ярлик **Master-Agent.lnk** у папці автозапуску Windows.

---

## 🗑️ Прибрати з автозапуску
```powershell
cd D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\MASTER_AGENT
.\REMOVE_AUTO_START.ps1
```
🗑️ Ярлик буде видалено з автозапуску.

---

## 🔍 Перевірити статус
```powershell
cd D:\CHECHA_CORE\CREATOR_SUITE\INTEGRATION\MASTER_AGENT
.\CHECK_AUTO_START.ps1
```
- Якщо Master-Agent є в автозапуску → ✅ з повним шляхом.  
- Якщо відсутній → ❌ повідомлення про відсутність.

---

## 📂 Файли у наборі
- `AUTO_START.ps1` — додати у автозапуск  
- `REMOVE_AUTO_START.ps1` — прибрати з автозапуску  
- `CHECK_AUTO_START.ps1` — перевірити статус автозапуску  

---

✍️ Автор: С.Ч.

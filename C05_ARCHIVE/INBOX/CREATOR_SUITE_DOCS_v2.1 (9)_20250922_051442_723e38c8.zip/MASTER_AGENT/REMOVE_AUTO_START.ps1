# REMOVE_AUTO_START.ps1 — прибрати Master-Agent з автозапуску Windows

$Startup = [Environment]::GetFolderPath("Startup")
$Shortcut = Join-Path $Startup "Master-Agent.lnk"

if (Test-Path $Shortcut) {
    Remove-Item $Shortcut -Force
    Write-Host "🗑️ Master-Agent видалено з автозапуску."
} else {
    Write-Host "ℹ️ Ярлик Master-Agent не знайдено в автозапуску."
}

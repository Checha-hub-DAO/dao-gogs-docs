
[CmdletBinding()]
param(
  [string]$Root = "D:\CHECHA_CORE",
  [switch]$OpenMap,
  [switch]$OpenCouncil,
  [switch]$Quiet
)
$ErrorActionPreference = "Stop"
function Info { param([string]$m,[string]$c="") if (-not $Quiet) { if ($c){ Microsoft.PowerShell.Utility\Write-Host $m -ForegroundColor $c } else { Microsoft.PowerShell.Utility\Write-Host $m } } }
$cab = Join-Path $Root "CABINET_CREATOR"
if (-not (Test-Path $cab)) { Write-Error "Не знайдено CABINET_CREATOR у $Root"; exit 1 }
$md = Join-Path $cab "CABINET.md"
if (Test-Path $md) { Start-Process -FilePath $md | Out-Null; Info "Відкрито Кабінет: $md" "DarkYellow" }
if ($OpenMap) { $map = Join-Path $cab "VISUALS\Cabinet_Map.png"; if (Test-Path $map) { Start-Process -FilePath $map | Out-Null; Info "Мапа відкрито" "Gray" } }
if ($OpenCouncil) { $council = Join-Path $cab "COUNCIL.md"; if (Test-Path $council) { Start-Process -FilePath $council | Out-Null; Info "COUNCIL відкрито" "Gray" } }
Info "Готово." "Green"

README — Майстерня Творця
=================================

Цей пакет містить стартову структуру "Майстерні Творця".

Файли:
- WORKSHOP.md         — головна сторінка майстерні (маніфест + посилання)
- TECHNICAL.md        — технічна кузня (інструменти, скрипти, процеси)
- CREATIVE.md         — творча лабораторія (карти, герої, символи)
- RHYTHM.md           — життєвий ритм (календар, рефлексії)
- PHILOSOPHY.md       — філософське полотно (слова сили, принципи)
- VISUALS/Workshop_Map.png — візуальна схема майстерні
- Open-Workshop.ps1   — PowerShell-скрипт для запуску майстерні
- Open-Workshop.cmd   — ярлик для швидкого запуску (двоклік)

=================================
Як користуватися:
1. Розпакуйте папку WORKSHOP_CREATOR у D:\CHECHA_CORE\
2. Для запуску:
   - Двоклік по Open-Workshop.cmd
   - або у PowerShell:
     .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -OpenAll -OpenVisual -UseVSCode
3. Параметри:
   -OpenAll    — відкриє всі розділи (TECHNICAL/CREATIVE/RHYTHM/PHILOSOPHY)
   -OpenVisual — відкриє схему Workshop_Map.png
   -UseVSCode  — використати VS Code для відкриття файлів

=================================
ASCII-міні-мапа Майстерні
(вигляд зверху, символічно)

         [ Технічна Кузня ]
                |
[ Життєвий Ритм ] — (Серце Майстерні) — [ Філософське Полотно ]
                |
         [ Творча Лабораторія ]

=================================
Підпис: С.Ч.

---------------------------------
РЕЖИМИ ЗАПУСКУ (параметри)

-OpenAll       — відкриє TECHNICAL/CREATIVE/RHYTHM/PHILOSOPHY
-OpenVisual    — відкриє схему Workshop_Map.png
-UseVSCode     — використовувати VS Code для відкриття файлів
-ShowSlideshow — одразу запускати VISUALS\slideshow.html
-DailyRitual   — відкрити RHYTHM.md (фокус: 'День') + картку-вітання

---------------------------------
ДОДАТКОВІ ПАРАМЕТРИ

-Focus <section> — швидко відкрити один із блоків:
  technical | creative | rhythm | philosophy | all

-AutoRevizor   — спробувати автоматично запустити перевірки й архівацію:
  - C11\tools\Revizor-C12.ps1  (створює звіт C12\REPORTS\c12_revizor_report.csv)
  - C11\tools\Archive-Core.ps1 (архівація CHECHA_CORE)

Приклади:
  .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -Focus creative
  .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -AutoRevizor -DailyRitual

---------------------------------
НОВІ ПАРАМЕТРИ v2.2

-GitBookPush <path> — завантажити вказаний Markdown-файл у GitBook
  * Використовує Push-GitBook.ps1 з DAO-GOGS-MAIN\C11\tools
  * Потребує заданих env-змінних: GITBOOK_TOKEN, GITBOOK_SPACE_ID

-SessionLog — записати подію входу у файл C03_LOG\WORKSHOP_LOG.md
  (корисно для хронології відвідувань і відстеження параметрів запуску)

Приклади:
  .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -GitBookPush D:\CHECHA_CORE\WORKSHOP_CREATOR\WORKSHOP.md -SessionLog
  .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -DailyRitual -SessionLog

---------------------------------
GITBOOK PUSH та СЕСІЙНИЙ ЛОГ

-GitBookPush "<path>" — швидко імпортувати сторінку до GitBook
  Вимоги: 
    - DAO-GOGS-MAIN\C11\tools\Push-GitBook.ps1
    - env: GITBOOK_TOKEN, GITBOOK_SPACE_ID
  Приклад:
    .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -GitBookPush "D:\CHECHA_CORE\DAO-GOGS-MAIN\G-CATALOG\G\G46...\readme.md"

-SessionLog — додати запис у C03_LOG\WORKSHOP_LOG.md (час, Root, параметри)
  Приклад:
    .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -DailyRitual -SessionLog

---------------------------------
ПРОФІЛІ ЗАПУСКУ

-Profile <ім'я> — завантажує набір параметрів з Profiles.json

Файл: WORKSHOP_CREATOR\Profiles.json
Приклади:
{
  "DailyStart": ["-DailyRitual", "-SessionLog", "-ShowSlideshow"],
  "CreativeFocus": ["-Focus creative", "-OpenVisual", "-SessionLog"],
  "TechReview": ["-Focus technical", "-AutoRevizor", "-SessionLog"],
  "FullMode": ["-OpenAll", "-OpenVisual", "-UseVSCode", "-ShowSlideshow", "-DailyRitual", "-SessionLog", "-AutoRevizor"]
}

Приклад використання:
  .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -Profile DailyStart

---------------------------------
ПРОФІЛІ ЗАПУСКУ

Profiles.json — набір готових конфігурацій (приклади: DailyStart, CreativeFocus, TechOps).
Використання:
  .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -Profile DailyStart

Редагуйте WORKSHOP_CREATOR\Profiles.json під свої ритми.

---------------------------------
ПОРЯД З МАЙСТЕРНЕЮ — КАБІНЕТ

-EnterCabinet — під час входу одразу відкриє CABINET_CREATOR\CABINET.md (якщо існує).
Приклад:
  .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -EnterCabinet

---------------------------------
DASHBOARD & WEEKLY SUMMARY

-OpenDashboard — відкрити панель керування (dashboard.html)
-WeeklySummary — огляд тижня: відкриває RHYTHM.md + COUNCIL.md

Профіль: CommandCenter — тихий старт у панель + Кабінет, щотижневий огляд.
Приклад:
  .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -Profile CommandCenter

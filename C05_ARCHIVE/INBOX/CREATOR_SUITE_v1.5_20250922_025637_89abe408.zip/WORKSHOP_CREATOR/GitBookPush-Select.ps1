
[CmdletBinding()]
param([string]$Root = "D:\CHECHA_CORE")
Add-Type -AssemblyName System.Windows.Forms
$ofd = New-Object System.Windows.Forms.OpenFileDialog
$ofd.Filter = "Markdown (*.md;*.mdx;*.markdown)|*.md;*.mdx;*.markdown|All files (*.*)|*.*"
$ofd.Title = "Обери Markdown-файл для GitBook Push"
if ($ofd.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { Write-Host "Відмінено."; exit 0 }
$file = $ofd.FileName
$tools = Join-Path $Root "DAO-GOGS-MAIN\C11\tools"
$pushScript = Join-Path $tools "Push-GitBook.ps1"
if (-not (Test-Path $file)) { Write-Warning "Файл не знайдено: $file"; exit 1 }
if (-not (Test-Path $pushScript)) { Write-Warning "Не знайдено Push-GitBook.ps1: $pushScript"; exit 1 }
$token = $env:GITBOOK_TOKEN; $space = $env:GITBOOK_SPACE_ID
if (-not $token -or -not $space) { Write-Warning "Не задані змінні середовища GITBOOK_TOKEN / GITBOOK_SPACE_ID"; exit 1 }
Write-Host "GitBookPush → $file" -ForegroundColor Cyan
pwsh -NoProfile -ExecutionPolicy Bypass -File $pushScript -Mode PageImport -File $file -Token $token -SpaceId $space


[CmdletBinding()]
param(
  [string]$Root = "D:\CHECHA_CORE",
  [string]$Id,
  [Parameter(Mandatory=$true)][string]$Title,
  [string]$Type = "visual",
  [string]$Status = "draft",
  [string]$Tags = "",
  [string]$Note = "",
  [string]$Visual = ""
)

$ErrorActionPreference = "Stop"
$ws = Join-Path $Root "WORKSHOP_CREATOR"
$reg = Join-Path $ws "ARTIFACTS.md"
$folderRoot = Join-Path $ws "ARTIFACTS"

if (-not (Test-Path $folderRoot)) { New-Item -ItemType Directory -Path $folderRoot | Out-Null }
if (-not (Test-Path $reg)) {
  Write-Host "Реєстр не знайдено, створюю початковий ARTIFACTS.md..." -ForegroundColor Yellow
  Set-Content -Path $reg -Value "# ARTIFACTS (auto-created)`n" -Encoding UTF8
}

function Next-Id {
  param([int]$Year)
  $content = Get-Content -Path $reg -Encoding UTF8
  $nums = @()
  foreach ($line in $content) {
    if ($line -match "ART-$Year-(\d{3})") { $nums += [int]$matches[1] }
  }
  if ($nums.Count -eq 0) { return ("ART-{0}-001" -f $Year) }
  $next = ([int]([int]($nums | Measure-Object -Maximum).Maximum) + 1)
  return ("ART-{0}-{1}" -f $Year, $next.ToString("000"))
}

$year = (Get-Date).Year
if (-not $Id -or $Id -eq "") { $Id = Next-Id -Year $year }

$dir = Join-Path $folderRoot $Id
if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }

$today = Get-Date -Format "yyyy-MM-dd"
$owner = "С.Ч."
$loc = "WORKSHOP_CREATOR/ARTIFACTS/$Id"
if (-not $Visual) { $Visual = "VISUALS/Workshop_Greeting.png" }

# Append row to table (insert after header separator)
$content = Get-Content -Path $reg -Encoding UTF8
$sepIdx = ($content | Select-String -Pattern "^\|---").LineNumber[0] - 1
$insertLine = "| {0} | {1} | {2} | {3} | {4} | {5} | {6} | {7} | {8} | {9} |" -f $Id,$Title,$Type,$Status,$loc,$Visual,$owner,$today,$Tags,$Note
# Reconstruct file with inserted line after header (index+1)
$new = @()
$inserted = $false
for ($i=0; $i -lt $content.Length; $i++) {
  $new += $content[$i]
  if (-not $inserted -and $i -eq $sepIdx) {
    $new += $insertLine
    $inserted = $true
  }
}
Set-Content -Path $reg -Value $new -Encoding UTF8

# Create README for the artifact from template if present

$tpl = Join-Path $ws "TEMPLATES\ARTIFACT_README_TEMPLATE.md"
if (Test-Path $tpl) {
  $raw = Get-Content -Path $tpl -Raw -Encoding UTF8
  $map = @{
    "{{ID}}"    = $Id
    "{{TITLE}}" = $Title
    "{{TYPE}}"  = $Type
    "{{STATUS}}"= $Status
    "{{DATE}}"  = $today
    "{{TAGS}}"  = $Tags
    "{{VISUAL}}"= $Visual
    "{{NOTE}}"  = $Note
  }
  foreach ($k in $map.Keys) { $raw = $raw -replace [regex]::Escape($k), [string]$map[$k] }
  Set-Content -Path (Join-Path $dir "README.md") -Value $raw -Encoding UTF8
} else {
  $ard = @()
  $ard += "# $Id — $Title"
  $ard += ""
  $ard += "- **Тип:** $Type"
  $ard += "- **Статус:** $Status"
  $ard += "- **Дата:** $today"
  $ard += "- **Теги:** $Tags"
  $ard += "- **Візуал:** $Visual"
  $ard += ""
  $ard += "## Нотатки"
  $ard += $Note
  $ard += ""
  $ard += "## Матеріали"
  $ard += "- "
  Set-Content -Path (Join-Path $dir "README.md") -Value $ard -Encoding UTF8
}


Write-Host "Створено артефакт $Id у $dir та додано до ARTIFACTS.md" -ForegroundColor Green

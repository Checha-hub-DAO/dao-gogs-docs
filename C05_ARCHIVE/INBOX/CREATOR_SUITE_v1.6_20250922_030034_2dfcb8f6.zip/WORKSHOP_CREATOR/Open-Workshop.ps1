
<#
.SYNOPSIS
  Відкриває "Майстерню Творця" одним кліком.

.DESCRIPTION
  Скрипт відкриває WORKSHOP.md у стандартному редакторі (або VS Code, якщо є),
  може додатково відкрити інші ключові файли, візуальну схему, слайдшоу.
#>

[CmdletBinding()]
param(
  [string]$Root = "D:\CHECHA_CORE",
  [switch]$OpenAll,          # також відкрити TECHNICAL.md / CREATIVE.md / RHYTHM.md / PHILOSOPHY.md
  [switch]$OpenVisual,       # відкрити схему VISUALS\Workshop_Map.png
  [switch]$UseVSCode,        # намагатися відкривати у VS Code
  [switch]$ShowSlideshow,
  [switch]$DailyRitual,
  [switch]$AutoRevizor,
  [ValidateSet('technical','creative','rhythm','philosophy','all')][string]$Focus,
  [string]$GitBookPush,
  [switch]$SessionLog     # відкрити VISUALS\slideshow.html у браузері
)

$ErrorActionPreference = "Stop"

# Partial quiet mode: helper for new messages (legacy outputs may appear)
function Info {
  param([string]$Message, [string]$Color = "")
  if (-not $Quiet) {
    if ($Color) { Microsoft.PowerShell.Utility\Write-Host $Message -ForegroundColor $Color }
    else { Microsoft.PowerShell.Utility\Write-Host $Message }
  }
}

# EXEC_SUMMARY_INIT
$summary = [ordered]@{
  Workshop     = "no"
  Cabinet      = "no"
  Visual       = "no"
  Slideshow    = "no"
  Dashboard    = "no"
  WeeklySum    = "no"
  DailyRitual  = "no"
  Revizor      = "skip"
  Archive      = "skip"
  GitBookPush  = "skip"
  SessionLog   = "no"
}


function Resolve-WorkshopPath {
  param([string]$root)
  $ws = Join-Path $root "WORKSHOP_CREATOR"
  if (-not (Test-Path $ws)) {
    throw "Не знайдено WORKSHOP_CREATOR у `$root: $ws"
  }
  return $ws
}

function Open-File {
  param([string]$Path)
  if (-not (Test-Path $Path)) {
    Write-Warning "Файл не знайдено: $Path"
    return
  }
  if ($UseVSCode -and (Get-Command code -ErrorAction SilentlyContinue)) {
    Start-Process -FilePath "code" -ArgumentList @("--reuse-window", "--goto", $Path) | Out-Null
  } else {
    Start-Process -FilePath $Path | Out-Null
  }
}

try {
  $ws = Resolve-WorkshopPath -root $Root
  $workshop = Join-Path $ws "WORKSHOP.md"
  $tech     = Join-Path $ws "TECHNICAL.md"
  $creative = Join-Path $ws "CREATIVE.md"
  $rhythm   = Join-Path $ws "RHYTHM.md"
  $philo    = Join-Path $ws "PHILOSOPHY.md"
  $visual   = Join-Path $ws "VISUALS\Workshop_Map.png"
  $slideshow= Join-Path $ws "VISUALS\slideshow.html"

  Info "🔥 Відкриття Майстерні Творця..." "Yellow"
  Open-File -Path $workshop; $summary.Workshop = "yes"  # SUMMARY_WORKSHOP_OPEN
  # Open Dashboard (optional)
  if ($OpenDashboard) {
    $dash = Join-Path $ws "dashboard.html"
    if (Test-Path $dash) { Start-Process -FilePath $dash | Out-Null; $summary.Dashboard = "yes"; Info "Відкрито Панель Творця: $dash" "DarkCyan" }
    else { Write-Warning "dashboard.html не знайдено у $ws" }
  }

  # Enter Cabinet (optional)
  if ($EnterCabinet) {
    $cabinet = Join-Path $Root "CABINET_CREATOR\CABINET.md"
    if (Test-Path $cabinet) {
      Open-File -Path $cabinet
      Info "Відкрито Кабінет Творця: $cabinet" "DarkYellow"; $summary.Cabinet = "yes"
    } else {
      Write-Warning "Кабінет не знайдено: $cabinet"
    }
  }


  if ($OpenAll) {
    Open-File -Path $tech
    Open-File -Path $creative
    Open-File -Path $rhythm
    Open-File -Path $philo
  }

  if ($OpenVisual) { $summary.Visual = "yes"  # SUMMARY_VISUAL_OPEN
    Open-File -Path $visual
  }

  if ($ShowSlideshow -and (Test-Path $slideshow)) {
    Start-Process -FilePath $slideshow | Out-Null; $summary.Slideshow = "yes"  # SUMMARY_SLIDESHOW_OPEN
  }

  # Відкрити теку майстерні у Провіднику
  
  # FOCUS_LOGIC_ANCHOR
  if ($Focus) {
    switch ($Focus.ToLower()) {
      'technical'  { Open-File -Path $tech }
      'creative'   { Open-File -Path $creative }
      'rhythm'     { Open-File -Path $rhythm }
      'philosophy' { Open-File -Path $philo }
      'all'        { Open-File -Path $tech; Open-File -Path $creative; Open-File -Path $rhythm; Open-File -Path $philo }
    }
    Write-Host ("Фокус відкрито: {0}" -f $Focus) -ForegroundColor Magenta
  }

  # Weekly Summary (open Rhythm + Council)
  if ($WeeklySummary) {
    if (Test-Path $rhythm) { Open-File -Path $rhythm }
    $council = Join-Path $ws "..\CABINET_CREATOR\COUNCIL.md"
    if (Test-Path $council) { Open-File -Path $council }
    Info "Щотижневий огляд: відкрито RHYTHM.md і COUNCIL.md." "Yellow"; $summary.WeeklySum = "yes"
  }

  # Weekly Review Export (markdown to C03_LOG\WEEKLY)
  if ($WeeklyReviewExport) {
    try {
      $today     = Get-Date
      $dow       = [int]$today.DayOfWeek  # Sunday=0, Monday=1, ...
      $delta     = ($dow - 1); if ($delta -lt 0) { $delta = 6 }  # days since Monday
      $weekStart = $today.Date.AddDays(-$delta).AddDays(7 * $WeekOffset)  # weekOffsetApplied
      $weekEnd   = $weekStart.AddDays(6).Date.AddHours(23).AddMinutes(59).AddSeconds(59)

      $logRoot = Join-Path $Root "C03_LOG\WEEKLY"
      if (-not (Test-Path $logRoot)) { New-Item -ItemType Directory -Path $logRoot | Out-Null }
      $outFile = Join-Path $logRoot ("weekly_{0}_to_{1}{2}.md" -f $weekStart.ToString("yyyy-MM-dd"), $weekEnd.ToString("yyyy-MM-dd"), ($WeekOffset -ne 0 ? ("_offset" + $WeekOffset) : ""))  # weekly_offset

      $council = Join-Path $Root "CABINET_CREATOR\COUNCIL.md"
      $decRows = @()
      if (Test-Path $council) {
        $lines = Get-Content -Path $council -Encoding UTF8
        foreach ($line in $lines) {
          if ($line -match "^\s*-\s*`?(\d{4}-\d{2}-\d{2})\s*\|\s*(.*?)\|\s*(.*?)\|\s*(.*?)\|\s*(.*?)`?") {
            $d = [datetime]::ParseExact($matches[1], "yyyy-MM-dd", $null)
            if ($d -ge $weekStart -and $d -le $weekEnd) {
              $decRows += ("- {0} | {1} | {2} | {3} | {4}" -f $matches[1], $matches[2].Trim(), $matches[3].Trim(), $matches[4].Trim(), $matches[5].Trim())
            }
          }
        }
      }

      $sessionLog = Join-Path $Root "C03_LOG\WORKSHOP_LOG.md"
      $sessionRows = @()
      if (Test-Path $sessionLog) {
        $lines = Get-Content -Path $sessionLog -Encoding UTF8
        foreach ($line in $lines) {
          if ($line -match "^\*\s+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+\|\s+Root=(.*?)\s+\|\s+Params:\s*(.*)$") {
            $t = [datetime]::ParseExact($matches[1], "yyyy-MM-dd HH:mm:ss", $null)
            if ($t -ge $weekStart -and $t -le $weekEnd) { $sessionRows += $line }
          }
        }
      }

      $md = @()
      $md += "# Щотижневий огляд (Світ Ч)"
      $md += ""
      $md += ("**Період:** {0} — {1}" -f $weekStart.ToString("yyyy-MM-dd"), $weekEnd.ToString("yyyy-MM-dd"))
      $md += ""
      $md += "## Рішення Ради (за період)"
      if ($decRows.Count -gt 0) { $md += $decRows } else { $md += "_нема записів_" }
      $md += ""
      $md += "## Сесії Майстерні (за період)"
      if ($sessionRows.Count -gt 0) { $md += $sessionRows } else { $md += "_нема записів_" }
      $md += ""
      $md += "## Посилання"
      $md += "- [RHYTHM.md](../../WORKSHOP_CREATOR/RHYTHM.md)"
      $md += "- [COUNCIL.md](../../CABINET_CREATOR/COUNCIL.md)"
      $md += ""
      $md += "_Згенеровано Open-Workshop.ps1_"

      Set-Content -Path $outFile -Value $md -Encoding UTF8
      Info ("WeeklyReviewExport: створено " + $outFile) "Green"
      $summary.WeeklyExport = "yes"
    } catch {
      Write-Warning ("WeeklyReviewExport: помилка — " + $_.Exception.Message)
      $summary.WeeklyExport = "warn"
    }
  }


  # PUBLISH_ARTIFACT_BLOCK
  if ($PublishArtifact) {
    try {
      $pub = Join-Path $ws "Publish-Artifact.ps1"
      if (Test-Path $pub) {
        $json = pwsh -NoProfile -ExecutionPolicy Bypass -File $pub -Root $Root -Id $PublishArtifact -PublishToGitBook:$PublishToGitBook.IsPresent -UpdateStatus
        $obj = $null
        try { $obj = $json | ConvertFrom-Json } catch {}
        if ($obj) {
          $summary.PublishArt = if ($obj.Publish) { $obj.Publish } else { "ok" }
          Info ("Артефакт запаковано: " + $obj.Zip) "Green"
        } else {
          $summary.PublishArt = "ok"
          Info "Артефакт опрацьовано." "Green"
        }
      } else {
        Write-Warning "Не знайдено Publish-Artifact.ps1"
        $summary.PublishArt = "warn"
      }
    } catch {
      Write-Warning ("PublishArtifact: помилка — " + $_.Exception.Message)
      $summary.PublishArt = "warn"
    }
  }

if (-not $NoExplorer) { Start-Process -FilePath "explorer.exe" -ArgumentList $ws | Out-Null }  # NOEXPLORER_GUARD

  # AUTOREVIZOR_LOGIC_ANCHOR
  # GITBOOK_PUSH_LOGIC_ANCHOR
  if ($GitBookPush) {
    try {
      $tools = Join-Path $Root "DAO-GOGS-MAIN\C11\tools"
      $pushScript = Join-Path $tools "Push-GitBook.ps1"
      if (-not (Test-Path $GitBookPush)) {
        $summary.GitBookPush = "warn"; Write-Warning "GitBookPush: не знайдено файл для імпорту: $GitBookPush"
      } elseif (-not (Test-Path $pushScript)) {
        $summary.GitBookPush = "skip"; Write-Warning "GitBookPush: не знайдено Push-GitBook.ps1 ($pushScript)"
      } else {
        $token = $env:GITBOOK_TOKEN
        $space = $env:GITBOOK_SPACE_ID
        if (-not $token -or -not $space) {
          Write-Warning "GitBookPush: не задані змінні середовища GITBOOK_TOKEN або GITBOOK_SPACE_ID"
        } else {
          $summary.GitBookPush = "ok"; Info "GitBookPush: імпорт сторінки → $GitBookPush" "Cyan"
          pwsh -NoProfile -ExecutionPolicy Bypass -File $pushScript `
            -Mode PageImport `
            -File $GitBookPush `
            -Token $token `
            -SpaceId $space
        }
      }
    } catch {
      $summary.GitBookPush = "warn"; Write-Warning "GitBookPush: помилка — $($_.Exception.Message)"
    }
  }

  # GITBOOKPUSH_LOGIC_ANCHOR
  if ($GitBookPush) {
    Write-Host "GitBookPush: намагаюсь відправити сторінку $GitBookPush" -ForegroundColor Yellow
    try {
      if (-not $env:GITBOOK_TOKEN -or -not $env:GITBOOK_SPACE_ID) {
        Write-Warning "Не задані змінні оточення GITBOOK_TOKEN або GITBOOK_SPACE_ID"
      } else {
        $filePath = Resolve-Path $GitBookPush
        $pushScript = Join-Path $Root "DAO-GOGS-MAIN\C11\tools\Push-GitBook.ps1"
        if (Test-Path $pushScript) {
          pwsh -NoProfile -ExecutionPolicy Bypass -File $pushScript -Mode PageImport -File $filePath `
            -Token $env:GITBOOK_TOKEN -SpaceId $env:GITBOOK_SPACE_ID | Out-Null
          Write-Host "GitBookPush: завантажено $filePath" -ForegroundColor Green
        } else {
          Write-Warning "Не знайдено Push-GitBook.ps1 ($pushScript)"
        }
      }
    } catch {
      Write-Warning "GitBookPush завершився з помилкою: $($_.Exception.Message)"
    }
  }

  if ($AutoRevizor) {
    Write-Host "AutoRevizor: запуск перевірок..." -ForegroundColor Yellow
    $tools = Join-Path $Root "C11\tools"
    $revizor = Join-Path $tools "Revizor-C12.ps1"
    $archive = Join-Path $tools "Archive-Core.ps1"

    if (Test-Path $revizor) {
      try {
        $c12 = Join-Path $Root "C12"
        $reportDir = Join-Path $c12 "REPORTS"
        if (-not (Test-Path $reportDir)) { New-Item -ItemType Directory -Path $reportDir | Out-Null }
        $report = Join-Path $reportDir "c12_revizor_report.csv"
        pwsh -NoProfile -ExecutionPolicy Bypass -File $revizor -C12Root $c12 -ReportCsv $report | Out-Null
        $summary.Revizor = "ok"; Info "Revizor-C12: завершено. Звіт: $report" "Green"
      } catch {
        $summary.Revizor = "warn"; Write-Warning "Revizor-C12 завершився з помилкою: $($_.Exception.Message)"
      }
    } else {
      $summary.Revizor = "skip"; Write-Warning "Не знайдено Revizor-C12.ps1 ($revizor)"
    }

    if (Test-Path $archive) {
      try {
        pwsh -NoProfile -ExecutionPolicy Bypass -File $archive -Root $Root | Out-Null
        $summary.Archive = "ok"; Info "Archive-Core: завершено." "Green"
      } catch {
        $summary.Archive = "warn"; Write-Warning "Archive-Core завершився з помилкою: $($_.Exception.Message)"
      }
    } else {
      $summary.Archive = "skip"; Write-Warning "Не знайдено Archive-Core.ps1 ($archive)"
    }
  }


  # Малий ритуал входу: повідомлення у консолі
  
  # Денний ритуал
  if ($DailyRitual) {
    $rhythm = Join-Path $ws "RHYTHM.md"
    $greeting = Join-Path $ws "VISUALS\Workshop_Greeting.png"

    if (Test-Path $rhythm) {
      Open-File -Path $rhythm
    }
    if (Test-Path $greeting) {
      Start-Process -FilePath $greeting | Out-Null
    }
    Write-Host "🌞 Сьогодні твій ритм, твій день. Зроби його осмисленим." -ForegroundColor Yellow
  }

  
  # SESSIONLOG_LOGIC_ANCHOR
  
  # PROFILE_LOGIC_ANCHOR
  if ($Profile) {
    try {
      $profileFile = Join-Path $ws "Profiles.json"
      if (-not (Test-Path $profileFile)) {
        Write-Warning "Profiles.json не знайдено у $ws"
      } else {
        $profiles = Get-Content $profileFile | ConvertFrom-Json
        if ($profiles.$Profile) {
          Write-Host "Профіль '$Profile' знайдено. Використовую параметри: $($profiles.$Profile -join ' ')" -ForegroundColor Cyan
          # Рекурсивно викликаємо цей же скрипт з параметрами профілю
          $cmd = @($MyInvocation.MyCommand.Path, "-Root", $Root) + $profiles.$Profile
          pwsh -NoProfile -ExecutionPolicy Bypass -File $cmd
          exit
        } else {
          Write-Warning "Профіль '$Profile' не визначений у Profiles.json"
        }
      }
    } catch {
      Write-Warning "Profile: помилка — $($_.Exception.Message)"
    }
  }

if ($SessionLog) {
    try {
      $logDir = Join-Path $Root "C03_LOG"
      if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }
      $logFile = Join-Path $logDir "WORKSHOP_LOG.md"
      $stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
      $entry = "`n- Вхід у Майстерню: $stamp (Params: Focus=$Focus, DailyRitual=$DailyRitual, AutoRevizor=$AutoRevizor, ShowSlideshow=$ShowSlideshow, GitBookPush=$GitBookPush)`n"
      Add-Content -Path $logFile -Value $entry -Encoding UTF8
      Write-Host "SessionLog: записано у $logFile" -ForegroundColor DarkGray
    } catch {
      Write-Warning "SessionLog помилка: $($_.Exception.Message)"
    }
  }

  Write-Host "—" * 60
  Info "Тут я творю. Тут я об’єдную ритми. Тут народжується нове." "Cyan"
  Write-Host "WORKSHOP: $workshop" -ForegroundColor DarkGray
  Info "Готово." "Green"

# EXECUTION_SUMMARY_PRINT
$summaryText = @()
$summaryText += "Workshop:      " + $summary.Workshop
$summaryText += "Cabinet:       " + $summary.Cabinet
$summaryText += "Visual:        " + $summary.Visual
$summaryText += "Slideshow:     " + $summary.Slideshow
$summaryText += "Dashboard:     " + $summary.Dashboard
$summaryText += "WeeklySummary: " + $summary.WeeklySum
$summaryText += "DailyRitual:   " + $summary.DailyRitual
$summaryText += "Revizor:       " + $summary.Revizor
$summaryText += "Archive:       " + $summary.Archive
$summaryText += "GitBookPush:   " + $summary.GitBookPush
$summaryText += "SessionLog:    " + $summary.SessionLog
$summaryText += "WeeklyExport:  " + $summary.WeeklyExport

if (-not $Quiet) {
  Microsoft.PowerShell.Utility\Write-Host ("`n=== Execution Summary ===") -ForegroundColor DarkCyan
  $summaryText | ForEach-Object { Microsoft.PowerShell.Utility\Write-Host $_ -ForegroundColor Gray }
}

}
catch {
  Write-Error $_.Exception.Message
  exit 1
}

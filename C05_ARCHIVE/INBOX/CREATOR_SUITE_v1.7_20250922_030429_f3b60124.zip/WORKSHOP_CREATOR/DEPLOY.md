
# DEPLOY — Майстерня Творця

Короткий чек-лист розгортання пакета у `D:\CHECHA_CORE\`.

---

## 1) Розпакування
- Розпакуйте архів у: `D:\CHECHA_CORE\`
- У результаті має бути: `D:\CHECHA_CORE\WORKSHOP_CREATOR\`

## 2) Швидкий запуск
```powershell
# Мінімальний вхід
D:\CHECHA_CORE\WORKSHOP_CREATOR\Open-Workshop.cmd

# Розширений (PowerShell)
pwsh -NoProfile -ExecutionPolicy Bypass -File D:\CHECHA_CORE\WORKSHOP_CREATOR\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -OpenAll -OpenVisual
```

## 3) Змінні середовища (для GitBook Push)
Налаштуйте (User або System):
- `GITBOOK_TOKEN` — токен доступу
- `GITBOOK_SPACE_ID` — ID простору

Перевірка в PowerShell:
```powershell
Write-Host $env:GITBOOK_TOKEN
Write-Host $env:GITBOOK_SPACE_ID
```

## 4) Рекомендована структура інструментів
```
D:\CHECHA_CORE ├─ WORKSHOP_CREATOR │   ├─ WORKSHOP.md
 │   ├─ TECHNICAL.md
 │   ├─ CREATIVE.md
 │   ├─ RHYTHM.md
 │   ├─ PHILOSOPHY.md
 │   ├─ VISUALS\ (схеми, картки, slideshow.html)
 │   ├─ Open-Workshop.ps1 / .cmd
 │   └─ Show-WorkshopSlideshow.ps1
 ├─ C03_LOG\        (лог-сесії WORKSHOP_LOG.md)
 ├─ C11	ools\      (Revizor-C12.ps1, Archive-Core.ps1, Push-GitBook.ps1)
 ├─ C12\            (Vault/REPORTS/ ...)
 └─ DAO-GOGS-MAIN\  (структура GitBook)
```

## 5) Корисні приклади команд
```powershell
# Денний ритуал + лог
.\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -DailyRitual -SessionLog

# Слайдшоу
.\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -ShowSlideshow

# Автоматичні перевірки + архіватор
.\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -AutoRevizor

# GitBook Push сторінки
.\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -GitBookPush "D:\CHECHA_CORE\DAO-GOGS-MAIN\G-CATALOG\G\G46...eadme.md"

# Фокус на певному блоці
.\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -Focus creative
```

## 6) Нотатки безпеки
- Зберігайте архіви з підписом і контрольними сумами в `C05\ARCHIVE\` (за вашою політикою).
- Не зберігайте секрети в явному вигляді у файлах—лише через env.
- Регулярно запускайте `-SessionLog` для історії входів.

---

**Підпис:** С.Ч.

## 7) Профілі запуску
- Файл `WORKSHOP_CREATOR\Profiles.json` містить приклади: `DailyStart`, `CreativeFocus`, `TechOps`.
- Запуск за профілем:
```powershell
.\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -Profile DailyStart
```
Редагуйте значення прапорців і полів (`Focus`, `GitBookPush`) під себе.

---------------------------------
ПОРЯД З МАЙСТЕРНЕЮ — КАБІНЕТ

-EnterCabinet — під час входу одразу відкриє CABINET_CREATOR\CABINET.md (якщо існує).
Приклад:
  .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -EnterCabinet

---------------------------------
DASHBOARD & WEEKLY SUMMARY

-OpenDashboard — відкрити панель керування (dashboard.html)
-WeeklySummary — огляд тижня: відкриває RHYTHM.md + COUNCIL.md

Профіль: CommandCenter — тихий старт у панель + Кабінет, щотижневий огляд.
Приклад:
  .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -Profile CommandCenter

- Нове: -WeeklyReviewExport (експорт підсумку тижня) та GitBookPush-Select.ps1/.cmd (вибір файлу через GUI)

---------------------------------
ПУЛЬС ДНЯ (авто)
- При запуску з `-DailyRitual` система перевіряє RHYTHM.md.
- Якщо для сьогоднішньої дати немає секції, вгорі файлу додається блок:
  ## YYYY-MM-DD — Пульс дня
  - [ ] Фокус 1
  - [ ] Фокус 2
  - [ ] Фокус 3
  ---

---------------------------------
WEEK OFFSET (для WeeklyReviewExport)
-WeekOffset <N> — зсунути тиждень відносно поточного (понеділка):
   0 — цей тиждень (за замовч.)
  -1 — попередній тиждень
   1 — наступний тиждень
Приклад:
  .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -WeeklyReviewExport -WeekOffset -1


---------------------------------
ПУБЛІКАЦІЯ АРТЕФАКТУ
-PublishArtifact "<ART-YYYY-NNN>" — створити zip у C03_LOG\ARTIFACT_PACKS та (якщо є токени) опублікувати README.md у GitBook.
Додатково: -PublishToGitBook — явно вмикає спробу пушу в GitBook.
Приклади:
  .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -PublishArtifact "ART-2025-001"
  .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -PublishArtifact "ART-2025-001" -PublishToGitBook
  .\WORKSHOP_CREATOR\Publish-Artifact.ps1 -Root "D:\CHECHA_CORE" -Id "ART-2025-001" -PublishToGitBook -UpdateStatus


---------------------------------
ШАБЛОН README ДЛЯ АРТЕФАКТІВ
- TEMPLATES\ARTIFACT_README_TEMPLATE.md — використовується New-Artifact.ps1 для генерації README.md з полями:
  {{ID}}, {{TITLE}}, {{TYPE}}, {{STATUS}}, {{DATE}}, {{TAGS}}, {{VISUAL}}, {{NOTE}}

ПУБЛІКАЦІЯ — ВИБІР ІЗ СПИСКУ
- Publish-Artifact-Select.ps1/.cmd — GUI-вибір артефакту (зі списку тек ART-YYYY-NNN), опціональний пуш у GitBook і оновлення статусу.


---------------------------------
ПАКУВАННЯ ВСІХ АРТЕФАКТІВ (за місяць)
Artifacts-PackAll.ps1/.cmd
  -Month YYYY-MM   — який місяць пакувати (за замовч. — поточний)
  -StatusFilter    — список статусів, комою (напр. "artifact,published")

СИНХРОНІЗАЦІЯ РЕЄСТРУ З GITBOOK
Sync-ArtifactsRegistry.ps1/.cmd — імпорт ARTIFACTS.md у простір GitBook (потрібні GITBOOK_TOKEN і GITBOOK_SPACE_ID)
Лаунчер параметри:
  -PackAllArtifacts [-PackMonth YYYY-MM]
  -SyncArtifactsRegistry

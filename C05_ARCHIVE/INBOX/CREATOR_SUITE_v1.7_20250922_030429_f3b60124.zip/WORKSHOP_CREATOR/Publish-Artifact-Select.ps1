
[CmdletBinding()]
param(
  [string]$Root = "D:\CHECHA_CORE"
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ws = Join-Path $Root "WORKSHOP_CREATOR"
$arts = Join-Path $ws "ARTIFACTS"
if (-not (Test-Path $arts)) { [System.Windows.Forms.MessageBox]::Show("Не знайдено теку ARTIFACTS у " + $ws); exit 1 }

# Collect artifact IDs
$dirs = Get-ChildItem -Path $arts -Directory | Where-Object { $_.Name -match "^ART-\d{4}-\d{3}$" } | Sort-Object Name

$form = New-Object System.Windows.Forms.Form
$form.Text = "Publish Artifact — Світ Ч"
$form.Size = New-Object System.Drawing.Size(560, 420)
$form.StartPosition = "CenterScreen"

$lbl = New-Object System.Windows.Forms.Label
$lbl.Text = "Оберіть артефакт для публікації:"
$lbl.AutoSize = $true
$lbl.Location = New-Object System.Drawing.Point(12, 12)
$form.Controls.Add($lbl)

$list = New-Object System.Windows.Forms.ListBox
$list.Location = New-Object System.Drawing.Point(12, 36)
$list.Size = New-Object System.Drawing.Size(520, 250)
$list.SelectionMode = "One"

foreach ($d in $dirs) {
  # try read first heading from README.md
  $title = $d.Name
  $readme = Join-Path $d.FullName "README.md"
  if (Test-Path $readme) {
    try {
      $line = (Get-Content -Path $readme -Encoding UTF8 -TotalCount 1)
      if ($line -match "^#\s*(.+)$") { $title = $line.Trim('# ').Trim() }
    } catch {}
  }
  $list.Items.Add(("{0} — {1}" -f $d.Name, $title))
}
$form.Controls.Add($list)

$chkPush = New-Object System.Windows.Forms.CheckBox
$chkPush.Text = "Publish to GitBook"
$chkPush.Checked = $false
$chkPush.Location = New-Object System.Drawing.Point(12, 300)
$form.Controls.Add($chkPush)

$chkUpdate = New-Object System.Windows.Forms.CheckBox
$chkUpdate.Text = "Update status in registry"
$chkUpdate.Checked = $true
$chkUpdate.Location = New-Object System.Drawing.Point(180, 300)
$form.Controls.Add($chkUpdate)

$btn = New-Object System.Windows.Forms.Button
$btn.Text = "Publish"
$btn.Location = New-Object System.Drawing.Point(12, 330)
$btn.Width = 100
$form.Controls.Add($btn)

$out = New-Object System.Windows.Forms.TextBox
$out.Location = New-Object System.Drawing.Point(120, 330)
$out.Size = New-Object System.Drawing.Size(412, 24)
$out.ReadOnly = $true
$form.Controls.Add($out)

$btn.Add_Click({
  if ($list.SelectedIndex -lt 0) { [System.Windows.Forms.MessageBox]::Show("Оберіть артефакт зі списку."); return }
  $sel = $list.SelectedItem.ToString()
  if ($sel -match "^(ART-\d{4}-\d{3})") { $id = $matches[1] } else { [System.Windows.Forms.MessageBox]::Show("Не вдалося розпізнати ID."); return }
  $pub = Join-Path $ws "Publish-Artifact.ps1"
  if (-not (Test-Path $pub)) { [System.Windows.Forms.MessageBox]::Show("Не знайдено Publish-Artifact.ps1"); return }
  try {
    $args = @("-File", $pub, "-Root", $Root, "-Id", $id)
    if ($chkPush.Checked) { $args += "-PublishToGitBook" }
    if ($chkUpdate.Checked) { $args += "-UpdateStatus" }
    $json = pwsh -NoProfile -ExecutionPolicy Bypass @args | Out-String
    $out.Text = "OK: " + $id
  } catch {
    $out.Text = "ERROR: " + $_.Exception.Message
  }
})

$form.Topmost = $true
[void]$form.ShowDialog()

# DAO-EDU MEDIA PACKAGE

У цей блок входять:  
- PNG-картки (DAO-EDU, My English Book, зв’язок).  
- Горизонтальний банер.  
- PDF-буклет.  

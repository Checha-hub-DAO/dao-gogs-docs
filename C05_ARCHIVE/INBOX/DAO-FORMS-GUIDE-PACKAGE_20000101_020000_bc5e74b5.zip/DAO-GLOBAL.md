# DAO-GLOBAL.md
... (додано посилання на DAO-FORMS-GUIDE.md у розділ “Інструменти взаємодії”)

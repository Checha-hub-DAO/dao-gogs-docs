📦 Інструкція щодо інтеграції пакетного оновлення GitBook DAO-GOGS

1. Зайдіть у відповідний розділ у GitBook.
2. Для кожного .md файлу:
   - DAO-FORMS-CENTER.md → вставити в /dao-forms-center
   - DAO-FORMS-GUIDE.md → вставити в /dao-forms-center/dao-forms-guide
   - DAO-GLOBAL.md → оновити блок "Інструменти взаємодії"
   - DAO-JOURNAL.md → додати посилання у секцію "Реєстраційні дії"
3. Опублікувати зміни.

Підготовлено: С.Ч. + AI-помічник
Дата: 2025-06-14

# DAO-Forms Center v1.0

Єдина актуальна сторінка для GitBook та дубль у Vault (C12 → Forms_Index.md).

## Містить
- `DAO-Forms-Center.md` — готовий контент сторінки.
- `RELEASE_NOTES.md` — короткі нотатки релізу.
- `CHECKSUMS.txt` — контрольна сума ZIP-пакета.

## Версія
v1.0 — 2025-09-02 04:53:37 UTC

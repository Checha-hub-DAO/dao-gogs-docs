# DAO-G01_ARCHIVE.md

Технічна документація для DAO-G01.
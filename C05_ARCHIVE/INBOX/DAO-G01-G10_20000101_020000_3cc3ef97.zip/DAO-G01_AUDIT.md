# DAO-G01_AUDIT.md

Технічна документація для DAO-G01.
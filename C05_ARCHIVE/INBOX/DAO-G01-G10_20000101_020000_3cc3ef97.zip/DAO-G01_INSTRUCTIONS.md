# DAO-G01_INSTRUCTIONS.md

Технічна документація для DAO-G01.
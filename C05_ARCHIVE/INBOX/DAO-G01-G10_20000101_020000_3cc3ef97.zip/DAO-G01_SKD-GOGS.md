# DAO-G01_SKD-GOGS.md

Технічна документація для DAO-G01.
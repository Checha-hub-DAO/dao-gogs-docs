# DAO-G02_GUIDE.md

Технічна документація для DAO-G02.
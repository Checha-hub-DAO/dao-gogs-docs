# DAO-G02_SKD-GOGS.md

Технічна документація для DAO-G02.
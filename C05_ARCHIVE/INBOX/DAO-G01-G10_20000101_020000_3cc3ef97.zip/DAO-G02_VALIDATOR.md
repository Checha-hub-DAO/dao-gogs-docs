# DAO-G02_VALIDATOR.md

Технічна документація для DAO-G02.
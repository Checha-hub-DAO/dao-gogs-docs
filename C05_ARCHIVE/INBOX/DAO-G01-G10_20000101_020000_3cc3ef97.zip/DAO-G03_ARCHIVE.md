# DAO-G03_ARCHIVE.md

Технічна документація для DAO-G03.
# DAO-G03_README.md

Технічна документація для DAO-G03.
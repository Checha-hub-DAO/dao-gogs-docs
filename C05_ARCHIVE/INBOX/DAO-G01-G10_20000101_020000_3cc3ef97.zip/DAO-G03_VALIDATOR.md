# DAO-G03_VALIDATOR.md

Технічна документація для DAO-G03.
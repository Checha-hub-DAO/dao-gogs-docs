# DAO-G04_ARCHIVE.md

Технічна документація для DAO-G04.
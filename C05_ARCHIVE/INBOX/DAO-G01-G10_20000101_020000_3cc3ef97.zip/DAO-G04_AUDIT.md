# DAO-G04_AUDIT.md

Технічна документація для DAO-G04.
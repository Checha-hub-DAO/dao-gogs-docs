# DAO-G04_INSTRUCTIONS.md

Технічна документація для DAO-G04.
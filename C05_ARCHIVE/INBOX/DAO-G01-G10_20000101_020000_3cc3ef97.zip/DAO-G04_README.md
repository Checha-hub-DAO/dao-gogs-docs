# DAO-G04_README.md

Технічна документація для DAO-G04.
# DAO-G04_SKD-GOGS.md

Технічна документація для DAO-G04.
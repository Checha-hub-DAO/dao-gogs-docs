# DAO-G04_VALIDATOR.md

Технічна документація для DAO-G04.
# DAO-G05_INSTRUCTIONS.md

Технічна документація для DAO-G05.
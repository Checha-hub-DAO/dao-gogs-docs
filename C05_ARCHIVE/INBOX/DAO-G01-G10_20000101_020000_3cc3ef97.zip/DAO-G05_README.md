# DAO-G05_README.md

Технічна документація для DAO-G05.
# DAO-G05_VALIDATOR.md

Технічна документація для DAO-G05.
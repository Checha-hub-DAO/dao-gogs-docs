# DAO-G06_AUDIT.md

Технічна документація для DAO-G06.
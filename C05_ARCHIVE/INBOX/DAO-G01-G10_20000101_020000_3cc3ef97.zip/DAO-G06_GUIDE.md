# DAO-G06_GUIDE.md

Технічна документація для DAO-G06.
# DAO-G06_INSTRUCTIONS.md

Технічна документація для DAO-G06.
# DAO-G06_SKD-GOGS.md

Технічна документація для DAO-G06.
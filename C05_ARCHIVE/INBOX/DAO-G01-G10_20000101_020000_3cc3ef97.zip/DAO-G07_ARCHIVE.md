# DAO-G07_ARCHIVE.md

Технічна документація для DAO-G07.
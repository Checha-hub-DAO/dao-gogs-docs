# DAO-G07_README.md

Технічна документація для DAO-G07.
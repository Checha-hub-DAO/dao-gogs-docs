# DAO-G07_VALIDATOR.md

Технічна документація для DAO-G07.
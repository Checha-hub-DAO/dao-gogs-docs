# DAO-G08_INSTRUCTIONS.md

Технічна документація для DAO-G08.
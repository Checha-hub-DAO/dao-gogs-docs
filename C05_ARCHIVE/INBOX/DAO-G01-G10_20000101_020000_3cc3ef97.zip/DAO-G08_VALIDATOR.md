# DAO-G08_VALIDATOR.md

Технічна документація для DAO-G08.
# DAO-G09_GUIDE.md

Технічна документація для DAO-G09.
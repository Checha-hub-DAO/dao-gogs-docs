# DAO-G09_SKD-GOGS.md

Технічна документація для DAO-G09.
# DAO-G10_INSTRUCTIONS.md

Технічна документація для DAO-G10.
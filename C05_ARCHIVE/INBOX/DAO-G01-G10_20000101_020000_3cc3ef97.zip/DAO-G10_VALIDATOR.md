# DAO-G10_VALIDATOR.md

Технічна документація для DAO-G10.
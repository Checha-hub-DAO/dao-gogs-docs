{
  "module_id": "DAO-G04",
  "title": "DAO-Мережа",
  "status": "active",
  "version": "v1.0",
  "category": "core",
  "created": "2025-06-04",
  "updated": "2025-06-04",
  "author": "С.Ч.",
  "maintainer": "DAO-GOGS",
  "tags": ["мережа", "зв'язки", "інтеграція"],
  "linked_modules": ["DAO-G03", "DAO-G05", "DAO-G07"],
  "documentation_links": [
    "README.md",
    "SKD-GOGS.md",
    "INSTRUCTIONS.md"
  ]
}

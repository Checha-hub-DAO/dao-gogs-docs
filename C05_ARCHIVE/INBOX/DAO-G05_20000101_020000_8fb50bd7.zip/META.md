# 🧩 META.md — Мета-дані

```json
{
  "module_id": "DAO-G05",
  "title": "DAO-Команда",
  "status": "active",
  "version": "v1.0",
  "category": "core",
  "created": "2025-06-04",
  "updated": "2025-06-04",
  "author": "С.Ч.",
  "maintainer": "DAO-GOGS",
  "tags": ["команда", "структура", "ролі"],
  "linked_modules": ["DAO-G01", "DAO-G04"],
  "documentation_links": [
    "README.md",
    "SKD-GOGS.md",
    "INSTRUCTIONS.md"
  ]
}
```
# G13 — DAO-Бот

**Код модуля:** DAO-G13  
**Назва:** Бот Свідомих  
**Платформа:** Telegram  
**Стан:** 🔄 Активна розробка  
**Офіційний бот:** [@dao_g13_bot](https://t.me/dao_g13_bot)  
**Куратор модуля:** DAO-Tech Core

## 🔹 Опис
DAO-Бот — офіційний Telegram-бот DAO-GOGS. Його роль — взаємодія між учасниками, модулями, формами й рішеннями.

## 🧭 Основні можливості
- 🔐 Реєстрація
- 🧠 GPT-Асистент
- 🗂️ Навігація GitBook
- 📝 Подача ідей
- 🗳️ Голосування
- 🔔 Сповіщення

## ⚙️ Технології
- Python (aiogram)
- PostgreSQL / Redis (опц.)
- GitBook / OpenAI / Google API

## 📂 Команди
/start, /register, /ask_gpt, /navigate, /vote, /help

## 📎 Додатково
- docker-compose.yml
- Dockerfile
- .env.example

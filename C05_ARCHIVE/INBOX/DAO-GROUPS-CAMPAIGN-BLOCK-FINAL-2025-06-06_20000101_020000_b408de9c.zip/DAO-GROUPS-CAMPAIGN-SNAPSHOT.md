
# DAO-GROUPS-CAMPAIGN-SNAPSHOT.md
📌 DAO-GROUPS-CAMPAIGN → SNAPSHOT → Публічний/Службовий Знімок Кампанії
Дата формування: YYYY-MM-DD
Оператор: С.Ч.
...(повний текст як у Snapshot.md)...

# Changelog DAO-Gallery

### 2025-09-02
- Створено каркас DAO-Gallery.

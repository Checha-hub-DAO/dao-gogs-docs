# ETHNO — Етнокод Нації

ETHNO — культурно-духовне ядро DAO-GOGS.

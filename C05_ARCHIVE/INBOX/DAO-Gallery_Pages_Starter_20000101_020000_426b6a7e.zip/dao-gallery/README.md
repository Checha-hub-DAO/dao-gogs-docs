# DAO-Gallery

Офіційний візуальний центр **DAO-GOGS**: символи, анімації, бренд-набір і релізні пакети (ZIP+MP4).

## Навіщо
- Єдине місце для візуальної інфраструктури
- Контроль версій та цілісності (SHA-256)
- Мости між **GitHub Releases ↔ GitBook ↔ CORE (C05_ARCHIVE/GALLERY)**

## Структура
- **[Символи](symbols/README.md)** — C01–C08 та розширення, ETHNO
- **[Анімації](animations/README.md)** — MP4-прев’ю (radial, wave, vibe, ETHNO)
- **[Пакети](packs/README.md)** — ZIP + CHECKSUMS із GitHub Releases
- **[Бренд-набір](brand/README.md)** — логотипи, палітра, шрифти, правила

## Швидкий старт
1. Поклади готові ассети у `gallery/<TOPIC>/dist`
2. Запусти workflow **gallery-publish.yml**
3. Перевір реліз через **gallery-verify.yml** та локально `Verify-GalleryArchive.ps1`
4. Додай посилання та прев’ю в розділи нижче

_Оновлено: 2025-09-02_

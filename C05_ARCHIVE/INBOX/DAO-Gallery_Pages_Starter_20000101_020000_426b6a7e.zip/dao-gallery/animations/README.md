# Анімації DAO-GOGS

Офіційні MP4-анімації (radial, wave, vibe, ETHNO).

## Релізи (приклади)
| Тег | Файли | Опис | Завантажити |
|---|---|---|---|
| `ethno-v1.2` | `C02_radial_anim_light.mp4`, `C02_radial_anim_dark.mp4` | ETHNO radial | _(посилання на GitHub Release)_ |

## Прев’ю
> Встав PNG-кадри: `static/gallery/previews/<tag>_*.png`

# DAO-Brand Pack

Офіційні логотипи, палітра, типографіка та правила використання.

## Вміст (приклади)
- `dao_logo.svg`, `dao_logo.png`
- `palette.json` / `palette.png`
- Шрифти: `.ttf`, `.otf`
- `brand-guidelines.pdf`

## Релізи (приклади)
| Тег | Файли | Завантажити |
|---|---|---|
| `brand-v1.0` | `GALLERY_BRAND_v1.0_YYYYMMDD_HHMMSS.zip` | _(посилання)_ |

# Changelog DAO-Gallery

### 2025-09-02
- Додано мінімальні заготовки сторінок: README (root), Symbols, Animations, Packs, Brand, Changelog.
- Синхронізовано структуру з релізним циклом (publish + verify).

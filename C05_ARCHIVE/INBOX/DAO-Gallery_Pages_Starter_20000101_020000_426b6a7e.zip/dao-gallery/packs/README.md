# Релізні пакети (ZIP + CHECKSUMS)

Усі релізи публікуються через **GitHub Releases**. Іменування ZIP:
```
GALLERY_<TOPIC>_vX.Y_YYYYMMDD_HHMMSS.zip
```
де `<TOPIC>`: ETHNO / SYMBOLS / ANIM / BRAND.

## Останні (приклади)
- **ETHNO v1.2** — тег `ethno-v1.2` — ZIP + MP4 + CHECKSUMS — _(посилання)_
- **Symbols 2025-08-31** — тег `symbols-2025-08-31_1200` — ZIP + CHECKSUMS — _(посилання)_

## Як перевірити
```powershell
Get-FileHash -Algorithm SHA256 <file.zip>
```

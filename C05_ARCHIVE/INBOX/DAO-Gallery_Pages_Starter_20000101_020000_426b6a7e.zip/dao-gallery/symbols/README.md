# Символи DAO-GOGS

Офіційна символіка: C01–C08 (сакральні) та розширення, включно з ETHNO.

## Релізи (приклади)
| Тег | Пакет | Опис | Завантажити |
|---|---|---|---|
| `ethno-v1.2` | `GALLERY_ETHNO_v1.2_YYYYMMDD_HHMMSS.zip` | ETHNO Block v1.2 | _(посилання на GitHub Release)_ |
| `symbols-2025-08-31_1200` | `GALLERY_SYMBOLS_v1.0_YYYYMMDD_HHMMSS.zip` | Symbols Pack | _(посилання на GitHub Release)_ |

## Прев’ю
> Додай 1–2 PNG кадри ключових візуалів (статичні прев’ю).

## Перевірка цілісності
```powershell
Get-FileHash -Algorithm SHA256 <file.zip>
```

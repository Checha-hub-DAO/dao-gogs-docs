# Adaptive Presentation — Mermaid Diagram

```mermaid
flowchart TB
  Style[StyleGuide v1.0]
  Media[DAO-MEDIA Root]
  SKD[СКД-GOGS<br/>контроль документів]
  Matrix[Matrix Systems<br/>Restore • Acceleration]
  Data[(KPI/CSV • GitBook • Dashboards)]

  subgraph AP[Adaptive Presentation]
    Core[Core<br/>README • PARAMETERS]
    Audience[AUDIENCE KITS<br/>Внутрішня • Медіа • Партнери • Стейкхолдери]
    Blocks[CONTENT BLOCKS<br/>Intro • Data • Narrative • CTA]
    Engine[ADAPTIVE ENGINE<br/>режими • UA/EN]
    Releases[RELEASE FORMS<br/>Internal • Public]
  end

  Core --> Audience
  Core --> Blocks
  Core --> Engine
  Engine --> Audience
  Engine --> Blocks
  Audience --> Releases
  Blocks --> Releases

  Style --> AP
  AP --> Media
  AP --> SKD
  Matrix --> Engine
  Data --> Blocks
```
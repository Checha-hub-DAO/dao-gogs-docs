# ROOT MAP — DAO-MEDIA Visual System v1.0

Орієнтир по документам у корені головної структури релізу.

## 🗂 Структура (tree)
```
/
├─ OFFICIAL_RELEASE_NOTE.pdf         # Титульний реліз-нот (1 сторінка)
├─ INDEX.md                          # Головна сторінка пакета
├─ README.md                         # Опис, як користуватись
├─ SUMMARY.md                        # Навігація GitBook
├─ GITBOOK_STRUCTURE.md              # Mermaid-схема навігації
│
├─ DAO-MEDIA_VisualSystem_v1.0_REPORT.md
├─ DAO-MEDIA_VisualSystem_v1.0_HASHES.txt
├─ DCE-20250925-DAO-MEDIA-STYLEGUIDE-v1.0.md
│
├─ CONTROL_FLOW.md
├─ DAO-MEDIA_VisualSystem_v1.0_CONTROL_FLOW.pdf
│
├─ DAO-MEDIA_VisualSystem_v1.0_RELEASE_NOTE.md
├─ DAO-MEDIA_VisualSystem_v1.0_RELEASE_NOTE.pdf
├─ DAO-MEDIA_VisualSystem_v1.0_RELEASE_PACKAGE.pdf
│
├─ ROADMAP_v1.1.md
├─ ROADMAP_v2.0.md
│
├─ TIMELINE.md
├─ DAO-MEDIA_VisualSystem_v1.0_TIMELINE.pdf
│
├─ DAO-MEDIA_VisualSystem_v1.0_INDEX_PDF.pdf
│
├─ DAO-MEDIA_VisualSystem_v1.0_MASTER.pdf
├─ DAO-MEDIA_VisualSystem_v1.0_MASTER_COVER.pdf
├─ DAO-MEDIA_VisualSystem_v1.0_MASTER.pptx
├─ DAO-MEDIA_VisualSystem_v1.0_MASTER_PRESENTATION.pdf
├─ DAO-MEDIA_VisualSystem_v1.0_MASTER_RENDERED.pdf
│
├─ DAO-MEDIA_VisualSystem_v1.0_CONTROL_REPORT.md
├─ DAO-MEDIA_VisualSystem_v1.0_CONTROL_REPORT.pdf
│
├─ DCE-20250925-DAO-MEDIA-CONTROLREPORT.md
├─ DCE-20250925-DAO-MEDIA-CONTROLREPORT.pdf
│
└─ DAO-MEDIA_VisualSystem_v1.0_CONTROL_SUMMARY.pdf   # Заключний підсумковий документ
```

## 🔗 Ключові посилання
- **OFFICIAL_RELEASE_NOTE.pdf** — стартовий документ
- **INDEX.md** — головна точка входу
- **SUMMARY.md** — структура GitBook
- **REPORT.md** — детальний опис релізу
- **HASHES.txt** — контрольні SHA-256
- **DCE-STYLEGUIDE.md** — офіційний запис для StyleGuide v1.0
- **CONTROL_FLOW.md / .pdf** — процес СКД
- **RELEASE_NOTE.md / .pdf** — короткий довідник
- **RELEASE_PACKAGE.pdf** — Note + Flow в одному файлі
- **ROADMAP_v1.1.md / v2.0.md** — плани
- **TIMELINE.md / .pdf** — розвиток
- **INDEX_PDF.pdf** — титульний огляд
- **MASTER.pdf / MASTER_COVER.pdf** — буклет
- **MASTER.pptx / PRESENTATION.pdf / RENDERED.pdf** — презентації
- **CONTROL_REPORT.md / .pdf** — контрольний аналіз
- **DCE-CONTROLREPORT.md / .pdf** — запис із SHA256
- **CONTROL_SUMMARY.pdf** — заключний підсумок

## 🧭 Mermaid · карта (огляд)
```mermaid
flowchart TB
  A[OFFICIAL_RELEASE_NOTE.pdf] --> B[INDEX.md]
  B --> C[SUMMARY.md]
  C --> R1[REPORT.md]
  C --> H1[HASHES.txt]
  C --> D1[DCE-STYLEGUIDE.md]
  C --> CF[CONTROL_FLOW.md / .pdf]
  C --> RN[RELEASE_NOTE.md / .pdf]
  C --> RP[RELEASE_PACKAGE.pdf]
  C --> RM1[ROADMAP v1.1]
  C --> RM2[ROADMAP v2.0]
  C --> TL[TIMELINE.md / .pdf]
  C --> IP[INDEX_PDF.pdf]
  C --> MS[MASTER.pdf / COVER]
  C --> PP[MASTER.pptx / PRESENTATION / RENDERED]
  C --> CR[CONTROL_REPORT.md / .pdf]
  C --> DC[DCE-CONTROLREPORT.md / .pdf]
  C --> CS[CONTROL_SUMMARY.pdf]
```

# DAO-MEDIA Root

* [Adaptive Presentation](adaptive_presentation/README.md)
  * [Diagram](adaptive_presentation/diagram.md)

---

📌 Цей архів є уніфікованою структурою DAO-MEDIA Root. 
Можна доповнювати іншими модулями (media pages, kits, reports).

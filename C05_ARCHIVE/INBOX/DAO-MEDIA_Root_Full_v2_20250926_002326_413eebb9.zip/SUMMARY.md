# DAO-MEDIA Root

* [Adaptive Presentation](adaptive_presentation/README.md)
  * [Diagram](adaptive_presentation/diagram.md)
* [StyleGuide](styleguide/README.md)

---

📌 Цей архів є уніфікованою структурою DAO-MEDIA Root з кількома модулями.

# 🗺️ Timeline — DAO-MEDIA Report

> Weekly report template: [WEEKLY_REPORT_TEMPLATE_EN.md](templates/WEEKLY_REPORT_TEMPLATE_EN.md)

```mermaid
timeline
  title DAO-MEDIA Report Timeline (EN)
  2025-09-26 : Report 2025-09-26 (launch)
  2025-10-03 : Weekly Report (planned) — see template
  2025-10-10 : Weekly Report (planned) — see template
  2025-10-31 : Monthly Report (October 2025, planned)
```

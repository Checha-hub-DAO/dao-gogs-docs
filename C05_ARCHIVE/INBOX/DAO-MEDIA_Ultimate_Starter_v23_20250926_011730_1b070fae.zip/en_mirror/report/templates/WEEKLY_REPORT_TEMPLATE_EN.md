# 📊 DAO-MEDIA Weekly Report (EN)

Date: YYYY-MM-DD  
Status: [Draft / Published]

## 1) Weekly Events
- 

## 2) Metrics
- Publications: 
- Reach: 
- Engagement: 

## 3) Decisions / Initiatives
- 

## 4) Next Steps
- 

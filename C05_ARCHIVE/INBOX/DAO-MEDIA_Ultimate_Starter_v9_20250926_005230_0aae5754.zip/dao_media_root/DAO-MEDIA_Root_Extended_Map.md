# DAO-MEDIA Root — Extended Map (Mermaid)

```mermaid
flowchart TB
  %% Top-level
  Root([DAO-MEDIA Root])
  GB[GitBook]
  Showcase[[DAO-MEDIA Showcase]]

  %% Modules
  AP[Adaptive Presentation]
  SG[StyleGuide]
  RP[Report]

  %% AP children
  AP_README[[README]]
  AP_PDF[[PDF]]
  AP_COVER[[Cover]]
  AP_DIAGRAM[[Diagram]]

  %% Edges
  Root --> AP
  Root --> SG
  Root --> RP

  AP --> AP_README
  AP --> AP_PDF
  AP --> AP_COVER
  AP --> AP_DIAGRAM

  Root --> GB
  GB --> Showcase
```

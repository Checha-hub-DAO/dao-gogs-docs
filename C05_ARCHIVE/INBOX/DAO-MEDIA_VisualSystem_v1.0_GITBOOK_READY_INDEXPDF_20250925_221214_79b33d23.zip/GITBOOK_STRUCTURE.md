# GitBook Structure · DAO-MEDIA Visual System v1.0

```mermaid
graph TD
  A[DAO-MEDIA Visual System v1.0<br/>INDEX.md] --> B[Release Note<br/>RELEASE_NOTE.md]
  A --> C[Report<br/>REPORT.md]
  A --> D[Hashes<br/>HASHES.txt]
  A --> E[Document Control Entry<br/>DCE.md]
  A --> F[Control Flow<br/>CONTROL_FLOW.md]
  F --> F1[Control Flow PDF<br/>CONTROL_FLOW.pdf]
  B --> B1[Release Note PDF<br/>RELEASE_NOTE.pdf]
  A --> G[Release Package PDF<br/>RELEASE_PACKAGE.pdf]
```

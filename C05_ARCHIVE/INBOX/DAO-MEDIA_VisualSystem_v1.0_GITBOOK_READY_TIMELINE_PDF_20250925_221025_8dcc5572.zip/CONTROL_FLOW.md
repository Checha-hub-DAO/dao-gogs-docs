# DAO-MEDIA Visual System · Control Flow (СКД-GOGS)

```mermaid
flowchart TD
  %% Вхідні артефакти релізу
  A[Release Artifacts<br/>PNG · PDF · ZIP] --> R[REPORT.md<br/>Звіт про реліз]
  A --> H[HASHES.txt<br/>SHA-256 контроль]
  A --> D[DCE.md<br/>Document Control Entry]

  %% Перевірка та валідація
  R --> V1[Review<br/>Контент/обсяг/статус]
  H --> V2[Verify Hashes<br/>Перевірка цілісності]
  D --> V3[Doc Control Check<br/>ID · дата · статус]

  %% СКД сховище
  V1 --> S[C05_ARCHIVE<br/>Архів релізів]
  V2 --> S
  V3 --> S

  %% Прив'язки і використання
  S --> L[C06_FOCUS / LOG<br/>Запис про реліз]
  S --> GB[GitBook / DAO-MEDIA<br/>Вітрина релізу]
  S --> AUDIT[Audit Trail<br/>Контрольні події]

  %% Контур оновлень
  GB --> FEEDBACK[Зворотний зв'язок/KPI]
  FEEDBACK --> NEXT[Next Version Prep<br/>(v1.1, v2.0)]
  NEXT -->|оновлені артефакти| A
```

# 📦 DAO-GOGS Onboarding MediaPack

Цей медіа-комплект містить усі матеріали для швидкого і повного онбордингу учасників DAO-GOGS.

---

## 📘 Основні матеріали
- **DAO-OnboardingGuide.pdf** — повний текстовий гід для нових учасників.
- **DAO-OnboardingGuide_Poster.pdf / .png** — постер у форматі A4 та PNG.
- **DAO-OnboardingGuide_Poster_Mobile.png** — мобільна вертикальна версія (1080x1920).

---

## 📱 Картки
- **DAO-Onboarding_Card_1.png … DAO-Onboarding_Card_5.png** — мобільні картки для кожного кроку.
- **DAO-OnboardingCards.pdf** — зібрані всі картки у PDF.
- **DAO-OnboardingCards_Pack.zip** — архів із PNG + PDF.

---

## 🎬 Відео-матеріали
- **DAO-GOGS_Onboarding_Storyboard.pdf** — сценарій для створення відео-сторіс (6 кадрів).
- **DAO-GOGS_Onboarding_Storyline.svg / .png** — візуальна схема (flow) послідовності кадрів.

---

## 🗂 Використання
1. **Для швидкого входу** — мобільні картки або постер.  
2. **Для детального розуміння** — гід (PDF).  
3. **Для промо і соцмереж** — мобільний постер, картки, storyline.  
4. **Для відеопрезентацій** — storyboard + storyline.  

---

📌 Цей пакет забезпечує різні рівні онбордингу: від швидкого знайомства до повного занурення у DAO-GOGS.

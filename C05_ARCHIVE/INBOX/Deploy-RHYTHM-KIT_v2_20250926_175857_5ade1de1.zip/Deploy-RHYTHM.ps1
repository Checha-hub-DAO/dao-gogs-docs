
<#
.SYNOPSIS
  Deploy-RHYTHM.ps1 (v2) — розгортання RHYTHM_FULL_PACK_* у C06_FOCUS з SHA256, бекапами і логами

.DESCRIPTION
  - Валідує ZIP (і .sha256, якщо задано)
  - Створює резерв поточного C06_FOCUS\RHYTHM → ARCHIVE\DEPLOY_BACKUPS\YYYYMMDD_HHMMSS
  - Очищає ціль і розпаковує ZIP
  - Копіює .sha256 у C07_ANALYTICS\HASHES і дописує CHECKSUM_LOG.md
  - Пише детальний лог у _INBOX\RHYTHM_DEPLOY_LOG.md
  - Підтримує -VerifyOnly та -WhatIf

.PARAMETER ZipPath
  Шлях до RHYTHM_FULL_PACK_*.zip (обов'язковий).

.PARAMETER Sha256Path
  Необов'язковий шлях до відповідного .sha256 (якщо не задано — шукає поряд із ZIP).

.PARAMETER CoreRoot
  Корінь CHECHA_CORE. Типово: D:\CHECHA_CORE

.PARAMETER FocusSubdir
  Куди розпаковувати. Типово: C06_FOCUS\RHYTHM

.PARAMETER HashesSubdir
  Куди складати .sha256 і журнал. Типово: C07_ANALYTICS\HASHES

.PARAMETER VerifyOnly
  Лише перевірка (SHA256 і звіт), без змін у файловій системі.

.PARAMETER WhatIf
  Сухий прогін — показує, що зробив би.

.EXAMPLE
  pwsh -NoProfile -ExecutionPolicy Bypass -File .\Deploy-RHYTHM.ps1 -ZipPath "RHYTHM_FULL_PACK_v1.2.zip"

.EXAMPLE
  pwsh -File .\Deploy-RHYTHM.ps1 -ZipPath ".\RHYTHM_FULL_PACK_v1.2.zip" -VerifyOnly
#>

[CmdletBinding(SupportsShouldProcess=$true)]
param(
  [Parameter(Mandatory=$true)][string]$ZipPath,
  [string]$Sha256Path,
  [string]$CoreRoot = "D:\CHECHA_CORE",
  [string]$FocusSubdir = "C06_FOCUS\RHYTHM",
  [string]$HashesSubdir = "C07_ANALYTICS\HASHES",
  [switch]$VerifyOnly,
  [switch]$WhatIf
)

function Info([string]$m){ Write-Host "[INFO] $m" -ForegroundColor Cyan }
function Ok([string]$m){ Write-Host "[ OK ] $m" -ForegroundColor Green }
function Err([string]$m){ Write-Host "[ERR ] $m" -ForegroundColor Red }
function Warn([string]$m){ Write-Warning $m }

$ErrorActionPreference = "Stop"

# --- Validate inputs ---
if (-not (Test-Path -LiteralPath $ZipPath)) { throw "ZipPath не існує: $ZipPath" }
if (-not $Sha256Path) {
  $candidate = "$ZipPath.sha256"
  if (Test-Path -LiteralPath $candidate) { $Sha256Path = $candidate }
}

if ($Sha256Path -and -not (Test-Path -LiteralPath $Sha256Path)) {
  Warn "Вказаний Sha256Path не знайдено: $Sha256Path"
  $Sha256Path = $null
}

# --- Resolve paths ---
$focusDir  = Join-Path $CoreRoot $FocusSubdir
$hashesDir = Join-Path $CoreRoot $HashesSubdir
$archiveBackups = Join-Path $CoreRoot "ARCHIVE\DEPLOY_BACKUPS"
$logDir = Join-Path $CoreRoot "_INBOX"

$ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$tsId = Get-Date -Format "yyyyMMdd_HHmmss"

foreach ($d in @($focusDir, $hashesDir, $archiveBackups, $logDir)) {
  if (-not (Test-Path -LiteralPath $d)) {
    if ($WhatIf) { Info "WhatIf: створив би $d" }
    else { New-Item -ItemType Directory -Path $d -Force | Out-Null }
  }
}

$deployLog = Join-Path $logDir "RHYTHM_DEPLOY_LOG.md"
Add-Content -LiteralPath $deployLog -Value "`n## $ts — Deploy-RHYTHM v2"

# --- SHA256 of ZIP & optional compare with .sha256 ---
$zipHash = $null
try {
  $zipHash = (Get-FileHash -Path $ZipPath -Algorithm SHA256).Hash
  Info "SHA256(ZIP) = $zipHash"
  Add-Content -LiteralPath $deployLog -Value "- ZIP: $ZipPath"
  Add-Content -LiteralPath $deployLog -Value "- SHA256(ZIP): $zipHash"
} catch {
  Err "Не вдалося порахувати SHA256: $($_.Exception.Message)"
  Add-Content -LiteralPath $deployLog -Value "- ERR sha256 calc: $($_.Exception.Message)"
  if ($VerifyOnly) { exit 3 }
}

if ($Sha256Path) {
  try {
    $expected = ((Get-Content -LiteralPath $Sha256Path -TotalCount 1) -split '\s+')[0].ToLower()
    if ($expected -ne $zipHash.ToLower()) {
      Err "SHA256 НЕ збігається з файлом .sha256"
      Add-Content -LiteralPath $deployLog -Value "- FAIL sha256 mismatch vs $(Split-Path $Sha256Path -Leaf)"
      if ($VerifyOnly) { exit 2 }
    } else {
      Ok "SHA256 збіг"
      Add-Content -LiteralPath $deployLog -Value "- OK sha256 match"
    }
  } catch {
    Warn "Не вдалося прочитати .sha256: $($_.Exception.Message)"
    Add-Content -LiteralPath $deployLog -Value "- WARN .sha256 read failed"
  }
} else {
  Warn "Файл .sha256 не вказано. Продовжую без порівняння."
  Add-Content -LiteralPath $deployLog -Value "- WARN: no .sha256 provided"
}

if ($VerifyOnly) {
  Ok "Режим перевірки завершено."
  exit 0
}

# --- Backup existing RHYTHM dir (if has content) ---
$needBackup = Test-Path -LiteralPath $focusDir -and (Get-ChildItem -LiteralPath $focusDir -Force -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1)
if ($needBackup) {
  $backupDir = Join-Path $archiveBackups ("RHYTHM_" + $tsId)
  if ($WhatIf) {
    Info "WhatIf: створив би бекап → $backupDir"
  } else {
    Info "Резервую поточний вміст → $backupDir"
    New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
    Copy-Item -LiteralPath ($focusDir + "\*") -Destination $backupDir -Recurse -Force
    Add-Content -LiteralPath $deployLog -Value "- Backup: $backupDir"
  }
}

# --- Clean target ---
if ($WhatIf) {
  Info "WhatIf: очистив би $focusDir"
} else {
  if (-not (Test-Path -LiteralPath $focusDir)) { New-Item -ItemType Directory -Path $focusDir -Force | Out-Null }
  Get-ChildItem -LiteralPath $focusDir -Force | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}

# --- Extract ZIP ---
if ($WhatIf) {
  Info "WhatIf: розпакував би $ZipPath → $focusDir"
  Add-Content -LiteralPath $deployLog -Value "- EXTRACT(whatif): $ZipPath → $focusDir"
} else {
  try {
    Expand-Archive -LiteralPath $ZipPath -DestinationPath $focusDir -Force
    Ok "Розпаковано: $focusDir"
    Add-Content -LiteralPath $deployLog -Value "- EXTRACT: $ZipPath → $focusDir"
  } catch {
    Err "Помилка розпаковки: $($_.Exception.Message)"
    Add-Content -LiteralPath $deployLog -Value "- ERR extract: $($_.Exception.Message)"
    exit 4
  }
}

# --- Copy .sha256 and update CHECKSUM_LOG ---
$checksumLog = Join-Path $hashesDir "CHECKSUM_LOG.md"
if ($Sha256Path) {
  $dstSha = Join-Path $hashesDir (Split-Path $Sha256Path -Leaf)
  if ($WhatIf) {
    Info "WhatIf: скопіював би .sha256 → $dstSha"
  } else {
    Copy-Item -LiteralPath $Sha256Path -Destination $dstSha -Force
    Ok "Збережено .sha256: $dstSha"
  }
}

if (-not (Test-Path -LiteralPath $checksumLog)) {
@"
# CHECKSUM_LOG — RHYTHM
| Timestamp | File | SHA256 |
|---|---|---|
"@ | Out-File -LiteralPath $checksumLog -Encoding UTF8 -Force
}

$zipLeaf = Split-Path $ZipPath -Leaf
$line = "| $ts | $zipLeaf | $zipHash |"

if ($WhatIf) {
  Info "WhatIf: додав би рядок у CHECKSUM_LOG.md"
} else {
  Add-Content -LiteralPath $checksumLog -Value $line
  Ok "Оновлено CHECKSUM_LOG.md"
}

Ok "Deploy-RHYTHM v2 завершено успішно."
Info "Лог: $deployLog"
exit 0


# Deploy-RHYTHM (v2) — інструкція

## Запуск (приклад)
```powershell
pwsh -NoProfile -ExecutionPolicy Bypass -File .\Deploy-RHYTHM.ps1 `
  -ZipPath "C:\Users\me\Downloads\RHYTHM_FULL_PACK_v1.2.zip" `
  -Sha256Path "C:\Users\me\Downloads\RHYTHM_FULL_PACK_v1.2.sha256"
```

### Параметри
- `-CoreRoot D:\CHECHA_CORE` — корінь системи (типово).
- `-FocusSubdir "C06_FOCUS\RHYTHM"` — ціль розпаковки.
- `-HashesSubdir "C07_ANALYTICS\HASHES"` — директорія контрольних сум/журналу.
- `-VerifyOnly` — лише перевірка (SHA256 + звіт) без змін.
- `-WhatIf` — сухий прогін.

### Що робить
1) Перевірка ZIP + (опціонально) звірка з `.sha256`.  
2) Резервна копія поточного вмісту `C06_FOCUS\RHYTHM` → `ARCHIVE\DEPLOY_BACKUPS\YYYYMMDD_HHMMSS`.  
3) Очищення цілі та розпакування ZIP.  
4) Копія `.sha256` → `C07_ANALYTICS\HASHES` + запис у `CHECKSUM_LOG.md`.  
5) Журнал розгортання → `_INBOX\RHYTHM_DEPLOY_LOG.md`.

# DIALOGS — GPT-Світлячок

**Family**
- Guide: Hello, Mark! This is my mom. Who is this?
- Mark: This is my dad.

**Colors**
- Guide: What color is the sky?
- Mark: It is blue.
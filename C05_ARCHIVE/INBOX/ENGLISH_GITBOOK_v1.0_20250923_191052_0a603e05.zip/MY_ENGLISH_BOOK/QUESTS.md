# QUESTS — Learning by Doing

## Outdoors
- Color Hunt — знайди предмети різних кольорів.  
- Animal Watch — назви 5 тварин.

## City
- Mini-Shop — *I would like…*  
- Ask & Find — *Where is…?*

## Home
- Label It — door, table, window…  
- My Day — 5–7 речень.
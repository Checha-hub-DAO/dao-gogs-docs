# G05 — DAO-Цінності.txt

#draft #to-integrate

Чернетка для інтеграції у модуль.

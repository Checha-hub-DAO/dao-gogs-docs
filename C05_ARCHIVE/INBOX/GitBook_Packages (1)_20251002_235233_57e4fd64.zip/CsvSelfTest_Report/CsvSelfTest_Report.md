# CsvSelfTest Report Example

Це приклад згенерованого звіту для тестування CSV.

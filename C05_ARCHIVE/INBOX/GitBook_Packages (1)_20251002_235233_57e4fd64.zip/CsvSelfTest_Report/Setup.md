# Setup — CsvSelfTest_Report

Цей документ описує, як запустити скрипт CsvSelfTest_Report.ps1 для генерації звітів.

## ⚙️ Вимоги
- Windows 10/11 або Linux з PowerShell 7+.
- Доступ до каталогу `C06_FOCUS` у CHECHA_CORE.

## 🚀 Запуск
```powershell
# Запуск скрипта у PowerShell
& 'D:\CHECHA_CORE\TOOLS\CsvSelfTest_Report.ps1'
```

## 📑 Результат
- Звіт збережеться у `D:\CHECHA_CORE\C06_FOCUS\CsvSelfTest_Report_YYYYMMDD.md`.
- Журнал виконання оновиться у `CSV_LOG.md`.

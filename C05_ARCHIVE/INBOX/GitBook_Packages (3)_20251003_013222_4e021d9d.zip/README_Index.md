# 📖 README_Index

Цей документ є інтеграційним індексом для структури GitBook і CHECHA_CORE.  
Він допомагає швидко зорієнтуватися у модулях, освітніх блоках та інструментах.

---

## 🏛 CORE (CHECHA_CORE — локальна база)

- **C06_FOCUS** — контрольні файли та щоденна робота  
  - `MAT_RESTORE.md`, `CHECKLIST`

- **C07_ANALYTICS** — аналітика та KPI  
  - `CsvSelfTest_Report.md` — інструмент перевірки CSV, KPI-контроль

- **C08_EDU** — освітні пакети  
  - `dao-edu-explained.md` — базове пояснення DAO  
  - `faq.md` — відповіді на часті запитання  
  - **my-english-book/** (DAO-EDU-LANG)  
    - `q1-basics.md` — основи  
    - `q2-practice.md` — практика  
    - `q3-dialogs.md` — діалоги  
    - `q4-advanced.md` — поглиблення  

- **C09_PROJECTS** — регіональні проекти  
  - **G46-InfoShield/** — Щит Поділля  
    - `README.md` — загальний опис  
    - `service-pack.md` — OPSEC, KPI, Legal, Style  
    - `g46.1-podilsk-infohub.md`  
    - `g46.2-mohyliv-infohub.md`  
    - `g46.3-haisyn-infohub.md`  
    - `g46.4-vinnytsia-infohub.md`  
    - `g46.5-odesa-infohub.md`

---

## 🌐 GitBook (онлайн-бібліотека)

- **dao-g/** — DAO-модулі  
  - `g23-youth/` — молодіжна активація  
  - `g35-media/` — DAO-Медіа-контур  
  - `g45-shield/` — національний щит  
  - `g46-info-shield/` — Щит Поділля (з InfoHub-ами і Service Pack)

- **dao-edu/** — освітній контур  
  - `dao-edu-explained.md` — ядро DAO-EDU  
  - `faq.md` — FAQ  
  - **my-english-book/** — воркбук англійської мови (Q1–Q4)

- **dao-tools/** — технічні інструменти  
  - `csvselftest-report.md` — KPI та контрольні звіти

- **Глобальні файли**  
  - `SUMMARY.md` — структура навігації  
  - `README_Master.md` — стратегічний індекс  
  - `cover.md` — титул  

---

## 📌 Використання
1. **CHECHA_CORE** — головне сховище та робоче середовище.  
2. **GitBook** — онлайн-версія для публікації та роботи спільноти.  
3. **Ключова логіка:**  
   - **DAO-EDU Explained** → ядро пояснень.  
   - **My English Book** → окремий освітній модуль.  
   - **CsvSelfTest_Report** → технічний інструмент.  
   - **G46 InfoShield** → регіональний модуль (Поділля).  

---

👤 Автор: Сергій Чеча (С.Ч.)  
📅 Дата: Жовтень 2025

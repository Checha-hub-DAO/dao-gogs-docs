# 🤖 INBOX — Автоматизація (v1.5)

## Що входить
- **Run-InboxDaily.ps1** — майстер-пайплайн: Verify → Dispatch → Check → Archive → Log
- **Verify-INBOX.ps1** — індексація хешів (SHA-256), пошук дублікатів, звіти
- **Dispatch-INBOX.ps1** — розподіл файлів по C-блоках за правилами `INBOX.config.json`
- **Check-INBOX.ps1** — формує GitBook-звіт `INBOX_REPORT.md`
- **Archive-INBOX.ps1** — добовий архів `SESSIONS\INBOX_SESSION_YYYYMMDD.zip` + SHA256SUMS
- **Register-InboxScheduledTask.ps1** — планувальник задач (щодня о 23:59)
- **Unregister-InboxScheduledTask.ps1** — видалення задачі
- **INBOX.config.json** — конфіг (шляхи, правила Dispatch, час запуску)

## Швидкий старт
```powershell
Set-ExecutionPolicy Bypass -Scope Process -Force
cd D:\CHECHA_CORE\INBOX\SCRIPTS

# 1) Перевірка (індекс хешів + дублікати)
.\Verify-INBOX.ps1

# 2) Розподіл по блоках згідно правил
.\Dispatch-INBOX.ps1 -Config "D:\CHECHA_CORE\INBOX\INBOX.config.json" -WhatIf  # зняти -WhatIf для дії

# 3) Звіт INBOX
.\Check-INBOX.ps1

# 4) Архів доби
.\Archive-INBOX.ps1

# Майстер-пайплайн
.\Run-InboxDaily.ps1 -Verbose
```

## Планувальник
```powershell
.\Register-InboxScheduledTask.ps1 -DailyTime "23:59"
# Для повного пайплайна додати:
.\Set-Task-To-RunPipeline.ps1
```

## Логи і звіти
- `C03_LOG\INBOX\INBOX_HASHES.csv` — індекс файлів та SHA-256
- `C03_LOG\INBOX\INBOX_DUPLICATES.csv` — можливі дублікати (за хешем)
- `C03_LOG\INBOX\INBOX_TASK_LOG.csv` — виконання задач
- `C07_ANALYTICS\INBOX_REPORT.md` — поточний стан INBOX
- `SESSIONS\INBOX_SESSION_YYYYMMDD.zip` + `SHA256SUMS.txt` — архів сесії

✍ Автор: С.Ч.

param([switch]$DryRun)

Add-Type -AssemblyName System.IO.Compression.FileSystem
function New-ZipFile($zipPath, $sourceDir) {
  if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
  [System.IO.Compression.ZipFile]::CreateFromDirectory($sourceDir, $zipPath)
}

$inbox = "D:\CHECHA_CORE\INBOX"
$sessions = "D:\CHECHA_CORE\INBOX\SESSIONS"
if (-not (Test-Path $sessions)) { New-Item -ItemType Directory -Force -Path $sessions | Out-Null }

$stamp = (Get-Date).ToString("yyyyMMdd")
$tempDir = Join-Path $inbox ("SESSION_" + $stamp)
New-Item -ItemType Directory -Force -Path $tempDir | Out-Null

# Copy current files into tempDir (to avoid archiving the SESSIONS folder itself)
Get-ChildItem $inbox -File | Copy-Item -Destination $tempDir -Force

$zipPath = Join-Path $sessions ("INBOX_SESSION_" + $stamp + ".zip")
if ($DryRun) {
  Write-Host "DryRun: would create archive $zipPath"
} else {
  New-ZipFile -zipPath $zipPath -sourceDir $tempDir
  # Create SHA256SUMS
  $sha = Join-Path $sessions ("INBOX_SESSION_" + $stamp + "_SHA256SUMS.txt")
  Get-ChildItem $tempDir -File -Recurse | ForEach-Object {
    $h = Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName
    ('{0}  {1}' -f $h.Hash, $_.Name) | Add-Content -Path $sha -Encoding UTF8
  }
  Remove-Item $tempDir -Recurse -Force
  Write-Host "✅ Archive created: $zipPath"
  Write-Host "✅ Checksums: $sha"
}

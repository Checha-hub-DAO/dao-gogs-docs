param(
  [string]$Config = "D:\CHECHA_CORE\INBOX\INBOX.config.json",
  [switch]$WhatIf
)
$ErrorActionPreference = "Stop"
if (-not (Test-Path $Config)) { throw "Config not found: $Config" }
$c = Get-Content $Config | ConvertFrom-Json

$inbox = $c.InboxPath
$rules = $c.DispatchRules

if (-not (Test-Path $inbox)) { throw "Inbox not found: $inbox" }

$files = Get-ChildItem $inbox -File -ErrorAction SilentlyContinue
foreach ($f in $files) {
  $dest = $null
  foreach ($r in $rules) {
    if ($f.Name -like $r.pattern) { $dest = $r.dest; break }
  }
  if (-not $dest) { $dest = "D:\CHECHA_CORE\C05_ARCHIVE" }
  if (-not (Test-Path $dest)) { New-Item -ItemType Directory -Force -Path $dest | Out-Null }
  if ($WhatIf) {
    Write-Host "Would move '$($f.Name)' -> '$dest'"
  } else {
    Move-Item -LiteralPath $f.FullName -Destination $dest -Force
    Write-Host "Moved '$($f.Name)' -> '$dest'"
  }
}

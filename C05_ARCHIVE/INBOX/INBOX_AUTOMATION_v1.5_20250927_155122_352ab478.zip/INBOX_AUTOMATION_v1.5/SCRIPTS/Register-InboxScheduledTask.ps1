param(
  [string]$TaskName = "CHECHA_CORE-INBOX-Daily",
  [string]$DailyTime = "23:59"
)
$ErrorActionPreference = "Stop"

$pipeline = "D:\CHECHA_CORE\INBOX\SCRIPTS\Run-InboxDaily.ps1"
if (-not (Test-Path $pipeline)) { throw "Pipeline not found: $pipeline" }

$parts = $DailyTime.Split(":")
$h = [int]$parts[0]; $m = [int]$parts[1]

$pwsh = (Get-Command pwsh -ErrorAction SilentlyContinue)?.Source
if (-not $pwsh) { $pwsh = (Get-Command powershell -ErrorAction SilentlyContinue).Source }

$action  = New-ScheduledTaskAction -Execute $pwsh -Argument ('-NoProfile -File "' + $pipeline + '"')
$trigger = New-ScheduledTaskTrigger -Daily -At ([datetime]::Today.AddHours($h).AddMinutes($m))
$principal = New-ScheduledTaskPrincipal -UserId "$env:UserName" -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable

if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
  Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false | Out-Null
}
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings | Out-Null
Write-Host "✅ Task '$TaskName' registered at $DailyTime to run pipeline."

param(
  [switch]$DryRun
)
$ErrorActionPreference = "Stop"

$configPath = "D:\CHECHA_CORE\INBOX\INBOX.config.json"
if (-not (Test-Path $configPath)) { throw "Config not found: $configPath" }
$config = Get-Content $configPath | ConvertFrom-Json

$logDir = $config.LogDir
$logCsv = Join-Path $logDir "INBOX_TASK_LOG.csv"
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Force -Path $logDir | Out-Null }
if (-not (Test-Path $logCsv)) {
  "DateTimeUTC,LocalTime,Step,Status,DurationSec,Message" | Out-File -FilePath $logCsv -Encoding UTF8
}

function Log-Step($step,$status,$start,$msg="") {
  $end = Get-Date
  $dur = [int]($end - $start).TotalSeconds
  $row = ($((Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss")) + "," +
          $((Get-Date).ToString("yyyy-MM-dd HH:mm:ss")) + "," +
          $step + "," + $status + "," + $dur + "," + ('"'+$msg.Replace('"','""')+'"'))
  Add-Content -Path $logCsv -Value $row -Encoding UTF8
}

# Steps
$steps = @(
  @{Name="Verify";  Cmd={ & "$PSScriptRoot\Verify-INBOX.ps1" }},
  @{Name="Dispatch";Cmd={ & "$PSScriptRoot\Dispatch-INBOX.ps1" -Config $configPath -WhatIf:$DryRun.IsPresent }},
  @{Name="Check";   Cmd={ & "$PSScriptRoot\Check-INBOX.ps1" }},
  @{Name="Archive"; Cmd={ & "$PSScriptRoot\Archive-INBOX.ps1" -DryRun:$DryRun.IsPresent }}
)

foreach ($s in $steps) {
  $start = Get-Date
  try {
    & $s.Cmd
    Log-Step $s.Name "OK" $start
  } catch {
    Log-Step $s.Name "ERROR" $start $_.Exception.Message
  }
}

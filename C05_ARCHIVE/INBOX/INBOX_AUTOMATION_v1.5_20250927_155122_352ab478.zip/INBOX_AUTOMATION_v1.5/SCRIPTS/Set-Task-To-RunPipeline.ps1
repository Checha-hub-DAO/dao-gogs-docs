param([string]$TaskName = "CHECHA_CORE-INBOX-Daily")
$pipeline = "D:\CHECHA_CORE\INBOX\SCRIPTS\Run-InboxDaily.ps1"
$pwsh = (Get-Command pwsh -ErrorAction SilentlyContinue)?.Source
if (-not $pwsh) { $pwsh = (Get-Command powershell -ErrorAction SilentlyContinue).Source }
$action  = New-ScheduledTaskAction -Execute $pwsh -Argument ('-NoProfile -File "' + $pipeline + '"')
Set-ScheduledTask -TaskName $TaskName -Action $action
Write-Host "🔧 Task '$TaskName' now runs the full pipeline."

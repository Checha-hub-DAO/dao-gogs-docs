param([string]$TaskName = "CHECHA_CORE-INBOX-Daily")
if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
  Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
  Write-Host "🗑️  Task removed: $TaskName"
} else {
  Write-Host "No task: $TaskName"
}

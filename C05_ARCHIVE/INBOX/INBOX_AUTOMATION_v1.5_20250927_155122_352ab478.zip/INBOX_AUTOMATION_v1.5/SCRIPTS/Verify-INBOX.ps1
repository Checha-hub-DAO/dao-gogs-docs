param(
  [string[]]$SearchRoots = @("D:\CHECHA_CORE"),
  [string]$OutDir = "D:\CHECHA_CORE\C03_LOG\INBOX"
)
$ErrorActionPreference = "Stop"
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Force -Path $OutDir | Out-Null }

$csv = Join-Path $OutDir "INBOX_HASHES.csv"
$dup = Join-Path $OutDir "INBOX_DUPLICATES.csv"

"FullName,Length,LastWriteTime,SHA256" | Out-File -FilePath $csv -Encoding UTF8

$all = @()
foreach ($root in $SearchRoots) {
  if (-not (Test-Path $root)) { continue }
  Get-ChildItem $root -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
    try {
      $h = Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName
      $line = ('"'+$_.FullName.Replace('"','""')+'",' + $_.Length + "," + $_.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss") + "," + $h.Hash)
      Add-Content -Path $csv -Value $line -Encoding UTF8
      $all += [pscustomobject]@{Path=$_.FullName; Hash=$h.Hash}
    } catch {}
  }
}

# duplicates by hash
$groups = $all | Group-Object Hash | Where-Object { $_.Count -gt 1 }
"SHA256,Count,Paths" | Out-File -FilePath $dup -Encoding UTF8
foreach ($g in $groups) {
  $paths = ($g.Group | ForEach-Object { $_.Path }) -join " | "
  Add-Content -Path $dup -Value ($g.Name + "," + $g.Count + ',"' + $paths.Replace('"','""') + '"') -Encoding UTF8
}
Write-Host "✅ Verify complete. CSV: $csv; Duplicates: $dup"

# Check-INBOX.ps1
$InboxPath = "D:\CHECHA_CORE\INBOX"
$OutReport = "D:\CHECHA_CORE\C07_ANALYTICS\INBOX_REPORT.md"
$Files = Get-ChildItem $InboxPath -File

$md = @()
$md += "# 📥 INBOX REPORT"
$md += "Дата: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
$md += ""
foreach ($f in $Files) {
    $md += "- $($f.Name) | $([math]::Round($f.Length/1KB,2)) KB | $($f.LastWriteTime)"
}
$md -join "`n" | Set-Content -Path $OutReport -Encoding UTF8
Invoke-Item $OutReport

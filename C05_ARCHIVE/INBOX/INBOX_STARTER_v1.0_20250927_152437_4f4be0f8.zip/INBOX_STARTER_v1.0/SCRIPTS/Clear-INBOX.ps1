# Clear-INBOX.ps1
# Переміщення оброблених файлів із INBOX у відповідні блоки або видалення

$InboxPath = "D:\CHECHA_CORE\INBOX"
$ArchivePath = "D:\CHECHA_CORE\C05_ARCHIVE\INBOX_CLEARED_$(Get-Date -Format yyyyMMdd)"
New-Item -ItemType Directory -Force -Path $ArchivePath

Get-ChildItem $InboxPath -File | ForEach-Object {
    Move-Item $_.FullName -Destination $ArchivePath
}

Write-Output "INBOX очищено та збережено у $ArchivePath"

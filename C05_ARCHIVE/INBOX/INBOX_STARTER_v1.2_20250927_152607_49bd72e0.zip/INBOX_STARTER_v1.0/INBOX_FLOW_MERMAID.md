# 📥 INBOX FLOW — Mermaid (GitBook-ready)

> Встав у GitBook як є. Блок нижче автоматично рендериться.

```mermaid
flowchart TD
    CHAOS[ПОТОК ХАОСУ] --> INBOX[📥 INBOX]
    INBOX --> C01[C01 — PARAMETERS]
    INBOX --> C06[C06 — FOCUS]
    INBOX --> C07[C07 — ANALYTICS]
    C01 --> WORKSHOP[WORKSHOP — Чернетки/Концепти]
    C06 --> ARCHIVE[C05 — ARCHIVE]
    C07 --> DELETE[DELETE — Непотрібне]
    WORKSHOP --> ZERO[ZERO INBOX]
    ARCHIVE --> ZERO
    DELETE --> ZERO
    INBOX -. щоденний розбір .-> ZERO
```

# Dispatch-INBOX.ps1
# Розподіл файлів з INBOX по C-блоках залежно від розширення чи тегів

$InboxPath = "D:\CHECHA_CORE\INBOX"

Get-ChildItem $InboxPath -File | ForEach-Object {
    switch ($_.Extension) {
        ".ps1" { Move-Item $_.FullName "D:\CHECHA_CORE\C11_AUTOMATION\" }
        ".md"  { Move-Item $_.FullName "D:\CHECHA_CORE\WORKSHOP\" }
        ".csv" { Move-Item $_.FullName "D:\CHECHA_CORE\C07_ANALYTICS\" }
        ".zip" { Move-Item $_.FullName "D:\CHECHA_CORE\C05_ARCHIVE\" }
        default { Move-Item $_.FullName "D:\CHECHA_CORE\C05_ARCHIVE\" }
    }
}

# C03_LOG — INBOX Task Log

Формат основного логу — `INBOX_TASK_LOG.csv`

**Колонки:**
- `DateTimeUTC` — час виконання (UTC)
- `LocalTime` — локальний час
- `Script` — назва виконаного сценарію
- `Status` — OK / ERROR
- `DurationSec` — тривалість, сек
- `Message` — коротке повідомлення про помилку/статус

Для швидкого перегляду CSV у Markdown можна вставляти останні 10 рядків вручну.

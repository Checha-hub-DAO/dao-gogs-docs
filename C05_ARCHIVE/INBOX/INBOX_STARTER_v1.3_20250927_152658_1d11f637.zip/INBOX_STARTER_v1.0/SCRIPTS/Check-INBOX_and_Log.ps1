<#
  Wrapper: runs Check-INBOX.ps1 and appends a line into C03_LOG\INBOX\INBOX_TASK_LOG.csv
#>
$ErrorActionPreference = "Stop"

$CheckScript = "D:\CHECHA_CORE\INBOX\SCRIPTS\Check-INBOX.ps1"
$LogDir      = "D:\CHECHA_CORE\C03_LOG\INBOX"
$LogCsv      = Join-Path $LogDir "INBOX_TASK_LOG.csv"

if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Force -Path $LogDir | Out-Null }

$start = Get-Date
$status = "OK"
$msg = ""

try {
  & $CheckScript
} catch {
  $status = "ERROR"
  $msg = $_.Exception.Message.Replace("`n"," ").Replace("`r"," ")
}

$end = Get-Date
$durationSec = [int]($end - $start).TotalSeconds

$row = [pscustomobject]@{
  DateTimeUTC = (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss")
  LocalTime   = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
  Script      = "Check-INBOX.ps1"
  Status      = $status
  DurationSec = $durationSec
  Message     = $msg
}

if (-not (Test-Path $LogCsv)) {
  "DateTimeUTC,LocalTime,Script,Status,DurationSec,Message" | Out-File -FilePath $LogCsv -Encoding UTF8
}
($row.DateTimeUTC + "," + $row.LocalTime + "," + $row.Script + "," + $row.Status + "," + $row.DurationSec + "," + ('"'+$row.Message.Replace('"','""')+'"')) | Add-Content -Path $LogCsv -Encoding UTF8

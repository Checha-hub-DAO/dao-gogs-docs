<#
  Registers a Windows Task Scheduler job to run Check-INBOX.ps1 daily at 23:59.
  Requires: Windows PowerShell 5+ or PowerShell 7+ with admin privileges.
#>

param(
  [string]$InboxScriptPath = "D:\CHECHA_CORE\INBOX\SCRIPTS\Check-INBOX.ps1",
  [string]$TaskName = "CHECHA_CORE-INBOX-Report",
  [string]$DailyTime = "23:59"
)

# Ensure path exists
if (-not (Test-Path $InboxScriptPath)) {
  Write-Error "Script not found: $InboxScriptPath"
  exit 1
}

$timeParts = $DailyTime.Split(":")
if ($timeParts.Count -ne 2) { Write-Error "DailyTime must be HH:MM"; exit 1 }

$hour = [int]$timeParts[0]
$minute = [int]$timeParts[1]

# Define action (PowerShell 7 if available, fallback to Windows PowerShell)
$pwsh = (Get-Command pwsh -ErrorAction SilentlyContinue)?.Source
if (-not $pwsh) { $pwsh = (Get-Command powershell -ErrorAction SilentlyContinue).Source }

$action  = New-ScheduledTaskAction -Execute $pwsh -Argument "-NoProfile -File `"$InboxScriptPath`""
$trigger = New-ScheduledTaskTrigger -Daily -At ([datetime]::Today.AddHours($hour).AddMinutes($minute))

# Run with highest privileges
$principal = New-ScheduledTaskPrincipal -UserId "$env:UserName" -RunLevel Highest

$task = New-ScheduledTask -Action $action -Trigger $trigger -Principal $principal -Settings (New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable)

try {
  # Remove existing task if exists
  if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false | Out-Null
  }
  Register-ScheduledTask -TaskName $TaskName -InputObject $task | Out-Null
  Write-Host "✅ Scheduled task '$TaskName' registered to run daily at $DailyTime."
} catch {
  Write-Error $_
  exit 1
}

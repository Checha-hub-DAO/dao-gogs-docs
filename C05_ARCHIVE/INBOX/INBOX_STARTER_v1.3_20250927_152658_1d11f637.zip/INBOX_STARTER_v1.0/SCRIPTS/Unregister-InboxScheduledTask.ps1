param([string]$TaskName = "CHECHA_CORE-INBOX-Report")
if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
  Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
  Write-Host "🗑️  Scheduled task '$TaskName' removed."
} else {
  Write-Host "No task named '$TaskName' found."
}

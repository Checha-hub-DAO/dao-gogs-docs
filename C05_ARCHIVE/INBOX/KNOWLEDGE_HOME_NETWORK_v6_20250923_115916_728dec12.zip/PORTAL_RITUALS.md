# PORTAL_RITUALS.md
*Ритуали і практики «Дому Знань»*
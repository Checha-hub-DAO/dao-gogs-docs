# SYMBOLS_VISUALS.md
*Візуальна мова мережі «Дім Знань»*

# MONTHLY_AUDIT.md — Щомісячний аудит системи CHECHA_CORE

Періодичність: **останній день місяця** або **перша субота нового місяця**.

## 1) Інвентаризація каталогів
- [ ] Переглянути структуру `D:\CHECHA_CORE\` та підтвердити наявність ключових блоків:
  - `C01_PARAMETERS`, `C06_FOCUS`, `C07_ANALYTICS`, `C11_AUTOMATION`
  - `TOOLS`, `WORKSHOP`, `ARCHIVE`, `_INBOX`
- [ ] Запустити скрипт:  
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\TOOLS\Generate-IndexRunTimeline_v1.1.ps1" `
  -LogsDir "D:\CHECHA_CORE\logs" -OutPath "D:\CHECHA_CORE\TIMELINE_ARTIFACTS_INDEX.md" -Mode timeline
```
- [ ] Переконатися, що всі основні журнали та README актуальні.

## 2) Об’єми та ріст
- [ ] Перевірити розмір `D:\CHECHA_CORE\ARCHIVE\` і `D:\CHECHA_BACKUP\`.
- [ ] Зафіксувати обсяг у `C07_ANALYTICS\STATS_SIZE.csv` (дата, обсяг у GB).
- [ ] Якщо приріст >20% за місяць → спланувати оптимізацію.

## 3) Контроль логів
- [ ] Переглянути `_INBOX\UPDATES_LOG.md` — чи є старі WARN/ERR, які не закриті.
- [ ] Вибірково перевірити 2–3 SHA256 з архіву (за різні тижні).
- [ ] У `SOD_LOG.md` має бути щоденний запис (мінімум 26–28 за місяць).

## 4) Перевірка автоматизації
- [ ] Переконатися, що всі `.ps1` у `TOOLS` мають актуальні версії та README.
- [ ] Запустити сухий прогін `Apply-Update.ps1 -WhatIf` для перевірки логіки.
- [ ] Перевірити останні зміни у `TOOLS_CHANGELOG.md`.

## 5) План оптимізації
- [ ] Визначити пакети, які можна перевести з DRAFT → STABLE.
- [ ] Очистити `WORKSHOP\INBOX_EXTRACTS\` від тимчасових файлів.
- [ ] Спланувати оновлення MASTER-набору (`MASTER_UPDATE_APPLY_vX`).

## 6) Резервна копія (повна)
- [ ] Створити повний `TECH_TOOLS_PACK_<YYYYMM>.zip` (без HOT).
- [ ] Перевірити SHA256, додати у `ARCHIVE\UPDATES\YYYYMMDD`.
- [ ] Скопіювати на зовнішній носій або у хмарне сховище.

---
**С.Ч. — стандарт щомісячного аудиту**

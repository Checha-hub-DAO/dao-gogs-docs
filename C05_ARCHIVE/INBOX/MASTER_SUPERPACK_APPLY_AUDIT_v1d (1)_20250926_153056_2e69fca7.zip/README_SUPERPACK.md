
# README_SUPERPACK.md — MASTER_SUPERPACK_APPLY_AUDIT_v1d

Єдиний пакет для повного циклу роботи з системою **CHECHA_CORE**:
- **APPLY** — застосування оновлень та робочих пакетів.
- **AUDIT** — контроль, перевірка, аудит на всіх рівнях.

---

## 1. APPLY (MASTER_UPDATE_APPLY_v3-stable.zip)
Містить:
- `Apply-Update.ps1` — застосування пакету в системі.
- `MASTER_UPDATE_APPLY_v3.md` — опис логіки.
- Стабільні інструменти (`TOOLS\`, `WORKSHOP\`).
- README + CHANGELOG.

📌 Використання:
```powershell
pwsh -NoProfile -ExecutionPolicy Bypass -File Apply-Update.ps1 -Path .\PACKAGE.zip
```

---

## 2. AUDIT (MASTER_AUDIT_FULL_v3.zip)
Містить:
- `DAILY_CHECKLIST.md` — щоденний контроль.
- `WEEKLY_CHECKLIST.md` — щотижнева перевірка.
- `MONTHLY_AUDIT.md` — щомісячний аудит.
- `README_AUDIT_FLOW.md` — інтегрована карта.
- `AUDIT_FLOW_GUIDE_v2.pdf` — PDF з текстом і діаграмою.
- `AUDIT_FLOW_STICKER.png / BW.png` — шпаргалки.
- `AUDIT_FLOW_DIAGRAM.png` — схема рівнів.
- `AUDIT_FLOW.md` — GitBook-версія.

---

## 3. Використання разом
1. Спочатку застосувати оновлення з **APPLY**.
2. Потім виконувати контроль за допомогою чеклістів з **AUDIT**.
3. Раз на місяць — повний аудит + створення резерву `TECH_TOOLS_PACK`.
4. Для GitBook — імпортувати `AUDIT_FLOW.md` та зображення.

---

## 📊 Схема APPLY ↔ AUDIT (Mermaid)

```mermaid
flowchart LR
    A[APPLY — Оновлення] --> B[DAILY — Щоденний контроль]
    B --> C[WEEKLY — Щотижневий аудит]
    C --> D[MONTHLY — Повний аудит]
    D --> A

    subgraph APPLY
      A1[Apply-Update.ps1]
      A2[MASTER_UPDATE_APPLY]
      A --> A1 --> A2
    end

    subgraph AUDIT
      B1[DAILY_CHECKLIST]
      C1[WEEKLY_CHECKLIST]
      D1[MONTHLY_AUDIT]
      B --> B1
      C --> C1
      D --> D1
    end
```

---

## 📟 ASCII-версія схеми

```
   ┌───────────────┐
   │   APPLY       │
   │ (Оновлення)   │
   └───────┬───────┘
           │
           ▼
   ┌───────────────┐
   │   DAILY       │
   │ (Щоденний     │
   │  контроль)    │
   └───────┬───────┘
           │
           ▼
   ┌───────────────┐
   │   WEEKLY      │
   │ (Щотижневий   │
   │   аудит)      │
   └───────┬───────┘
           │
           ▼
   ┌───────────────┐
   │   MONTHLY     │
   │ (Повний       │
   │   аудит)      │
   └───────┬───────┘
           │
           ▼
   ┌───────────────┐
   │   APPLY       │
   │  (новий цикл) │
   └───────────────┘
```

---

## 4. SHA256 перевірка
Кожен архів має `.sha256` файл для валідації:
```powershell
Get-FileHash MASTER_SUPERPACK_APPLY_AUDIT_v1d.zip -Algorithm SHA256
```

---
**С.Ч. — інтегрований цикл APPLY + AUDIT**

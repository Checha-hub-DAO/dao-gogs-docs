# NARRATIVE — Наративний контент
Маніфести, сценарії, історії, меседжі для кампаній.

## Стартові файли
- `manifest-template.md`
- `story-template.md`
- `message-pack.md`

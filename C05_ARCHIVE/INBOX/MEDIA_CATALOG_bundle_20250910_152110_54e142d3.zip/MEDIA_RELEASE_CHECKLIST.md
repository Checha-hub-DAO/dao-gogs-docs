# MEDIA RELEASE CHECKLIST — DAO-GOGS
**Дата:** 2025-09-10

## 1) Календар та контент
- [ ] `PUBLISHING/content_calendar.csv` заповнений (Date, Channel, Title, Body, Tags, Cover, Type)
- [ ] Типи класифіковані (`PUBLISHING/type_rules.yml`), немає `post` там, де потрібна спеціалізація
- [ ] `PUBLISHING/out/` — згенеровані Markdown-пости (фронтматер + cover)

## 2) Візуали
- [ ] SYMBOLIC v1.1 — SVG/PNG присутні (`S01..S08`)
- [ ] Галерея `SYMBOLIC/GALLERY_2x4_2048.png` оновлена
- [ ] Соцкарусель `SOCIAL_CAROUSEL` зібрана (PNG + ZIP)

## 3) Наратив
- [ ] NARRATIVE — 7 сюжетів (draft v0.1) заповнені
- [ ] Карта `NARRATIVE_SYMBOLIC_MAP.md` оновлена та відповідає візуалам

## 4) Автогенерація постів
- [ ] `tools/generate_social_posts.py` (TXT) пройшов успішно → `PUBLISHING/social_posts/`
- [ ] `tools/generate_social_posts_md.py` (MD) пройшов успішно → `PUBLISHING/social_posts_md/`
- [ ] `SOCIAL_CAPTIONS.md` — актуальні стилі та хештеги

## 5) Аналітика та пороги
- [ ] Heatmap `analytics/heatmap_channel_type.png` оновлено
- [ ] Daily load `analytics/daily_load_per_channel.png` оновлено
- [ ] Перевищень добового порогу (≤2/день/канал) — **нема** (`analytics/threshold_violations.csv` порожній)
- [ ] Тижневий бюджет (≤6/канал/тиждень) — **ок** (`analytics/weekly_budget_report.csv` без violation)

## 6) CI/CD
- [ ] Бейдж у `README.md` налаштований (`<org>/<repo>` замінено)
- [ ] Workflow `sync-publishing.yml` пройшов зелено
- [ ] Артефакти (графіки/звіти) додаються у коміт/реліз

## 7) Реліз
- [ ] Зібрано `MEDIA_CATALOG_v1.0.zip`
- [ ] Опис релізу: цілі, головні зміни, інструкції
- [ ] Поширення: Telegram/FB/GitBook пост + карусель

© DAO-GOGS • С.Ч.

# MEDIA RELEASE SOP — “Медіахвиля за 15 хвилин”
**Дата оновлення:** 2025-09-10

## 0) Підготовка
- Відкрий `MEDIA_RELEASE_CHECKLIST.md` і пройдися по пунктах.
- Переконайся, що CI зелений (бейдж у `README.md`).

## 1) Контент (5 хв)
- [ ] Відкрити `PUBLISHING/content_calendar.csv` → перевірити `Date, Channel, Title, Body, Tags, Cover`.
- [ ] Оновити типи за правилами `PUBLISHING/type_rules.yml` (авто у CI).
- [ ] Згенерувати пости (локально або почекати CI):
  - `python tools/generate_social_posts_md.py --root . --style auto`
  - `python tools/generate_social_posts.py --root . --style auto`
- [ ] Переконатися, що Type ≠ `post` у всіх релевантних записах.

## 2) Візуали (3 хв)
- [ ] SYMBOLIC: `S01..S08` SVG/PNG + `GALLERY_2x4_2048.png`.
- [ ] NARRATIVE: карта `NARRATIVE_SYMBOLIC_MAP.md` актуальна.
- [ ] Соцкарусель: `SOCIAL_CAROUSEL/` + `SOCIAL_CAROUSEL_v1.0.zip`.

## 3) Аналітика (3 хв)
- [ ] Відкрити `PUBLISHING/ANALYTICS.md`.
- [ ] Графіки: `analytics/heatmap_channel_type.png`, `analytics/daily_load_per_channel.png`.
- [ ] Пороги: `analytics/threshold_violations.csv` (порожній), `analytics/weekly_budget_report.csv` без порушень.

## 4) Реліз (4 хв)
- [ ] Зібрати `MEDIA_CATALOG_v1.0.zip` (або використати готовий).
- [ ] Створити GitHub Release або оновити Draft (див. Release Drafter).
- [ ] Додати артефакти: ZIP, ключові графіки, соцкарусель.
- [ ] Опублікувати в Telegram / Facebook / GitBook тексти з `social_posts_md/`.

## 5) Після релізу
- [ ] Пройти ретроспективу: що покращити в правилах типізації та бюджетах.
- [ ] Оновити `SOCIAL_CAPTIONS.md` при потребі.

---

### Корисні шляхи
- `PUBLISHING/content_calendar.csv`
- `PUBLISHING/ANALYTICS.md`
- `PUBLISHING/analytics/*.png, *.csv`
- `PUBLISHING/social_posts_md/`
- `SOCIAL_CAROUSEL/`
- `.github/workflows/sync-publishing.yml`

© DAO-GOGS • С.Ч.

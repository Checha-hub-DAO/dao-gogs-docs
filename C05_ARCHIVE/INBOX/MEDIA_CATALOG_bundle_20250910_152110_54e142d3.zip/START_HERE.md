# START HERE — MEDIA_CATALOG v1.0
**Зібрано:** 2025-09-10 15:21 (Europe/Kyiv)

## Що всередині
- **Core (lightweight)** — ядро `SYMBOLIC + NARRATIVE + PUBLISHING` (швидкий старт).
- **Full** — повний знімок репозиторію (для бекапу/аудиту).
- **Соцкарусель** — готовий ZIP із PNG-слайдами.
- **Презентація** — Canva-стильний PPTX.
- **Аналітика** — графіки та звіти.
- **SOP + Чеклист** — операційні кроки для релізу.

## Як користуватись (15 хв)
1) Відкрий `MEDIA_RELEASE_CHECKLIST.md` і `MEDIA_RELEASE_SOP.md`.
2) Переглянь `PUBLISHING/ANALYTICS.md` та графіки.
3) Якщо треба — згенеруй пости (`tools/generate_social_posts*.py`).
4) Використай **Core** для передачі партнерам / **Full** для архіву.
5) Соцкарусель — одразу у публікацію.

## Ключові файли
- Core ZIP, Full ZIP, Manifest → `dist/`
- Соцкарусель: `SOCIAL_CAROUSEL_v1.0.zip`
- Презентація: `MEDIA_CATALOG_PRESENTATION_CANVA.pptx`
- Аналітика: `PUBLISHING/ANALYTICS.md` + `PUBLISHING/analytics/`
- Контент: `PUBLISHING/content_calendar.csv`, `SOCIAL_CAPTIONS.md`

© DAO-GOGS • С.Ч.

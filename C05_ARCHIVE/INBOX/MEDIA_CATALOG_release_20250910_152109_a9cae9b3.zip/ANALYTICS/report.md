# DAO Media Report (шаблон)
- Період: YYYY-MM
- Підсумок: …
- KPI: Reach / Engagement / Conversion / Retention
- Висновки й наступні кроки

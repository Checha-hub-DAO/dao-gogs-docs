# 📚 MEDIA_CATALOG — Дашборд
**Версія:** v1.0 • **Оновлено:** 2025-09-10 13:03

## 🔗 Навігація по блоках
- [SYMBOLIC/](SYMBOLIC/) — символи, ритуали, візуали
- [NARRATIVE/](NARRATIVE/) — історії, маніфести, меседжі
- [AUDIO_VIDEO/](AUDIO_VIDEO/) — аудіо/відео, сценарії
- [INTERACTIVE/](INTERACTIVE/) — боти, форми, інтерактив
- [ANALYTICS/](ANALYTICS/) — метрики, звіти, схеми
- [INTAKE/](INTAKE/) — вхідні матеріали, сирці
- [PUBLISHING/](PUBLISHING/) — календар публікацій і план

## 🗂️ Стан робіт
- План завдань: [TODO_MEDIA_CATALOG.md](../TODO_MEDIA_CATALOG.md)
- Таблиця завдань: [TODO_MEDIA_CATALOG.csv](../TODO_MEDIA_CATALOG.csv) / [Excel](../TODO_MEDIA_CATALOG.xlsx)

## 🧭 Режим запуску (мінімальний контур)
1) SYMBOLIC + NARRATIVE + PUBLISHING → стартова публікація
2) AUDIO_VIDEO + INTERACTIVE → підсилення
3) ANALYTICS → цикл оптимізації

## ⚙️ Синхронізація публікацій
- Скрипт: **Sync-Publishing.ps1** (див. нижче у розділі Автоматизація)
- Вхід: `PUBLISHING/content_calendar.csv`
- Вихід: `PUBLISHING/out/` (згенеровані .md-пости)

---

# 📦 Вміст каталогів (огляд)

## SYMBOLIC
- README.md
- kits
- ritual-template.md
- rituals
- sample.md
- symbols

## NARRATIVE
- README.md
- manifest-template.md
- message-pack.md
- sample.md
- story-template.md

## AUDIO_VIDEO
- README.md
- avatar_script.txt
- sample.md
- signal_audio.wav
- teaser.mp4

## INTERACTIVE
- README.md
- dao_bot_spec.md
- response_form.md
- sample.md

## ANALYTICS
- README.md
- content_metadata.schema.json
- report.md
- sample.md

## INTAKE
- README.md

## PUBLISHING
- PUBLISHING_PLAN.md
- content_calendar.csv

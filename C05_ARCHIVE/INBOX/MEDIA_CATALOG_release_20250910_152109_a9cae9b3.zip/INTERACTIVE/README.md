# INTERACTIVE — Інтерактиви
Боти, фільтри, форми.

## Приклади
- `dao_bot_spec.md` — специфікація Telegram-бота (G13)
- `ig_filter_idea.md` — ідея AR-фільтру «Прийняв Сигнал»
- `response_form.md` — форма «Твоя відповідь Сигналу»

# PUBLISHING — Аналітика

**Оновлено:** 2025-09-10 14:28:43

## Підсумок
- Всього постів у календарі: **20**
- Канали: Facebook, GitBook, Instagram, Telegram
- Типи: message, narrative, post, symbolic, teaser
- Поріг навантаження: **≤ 2 постів/день/канал**

## Візуалізації
- Heatmap Канал × Тип: `assets/analytics/heatmap_channel_type.png`
- Щоденне навантаження за каналами: `assets/analytics/daily_load_per_channel.png`

## Порушення порогу
Збережено у CSV: `analytics/threshold_violations.csv`

Попередній перегляд (перші 20 рядків):

```
day,Channel,count

```

## Нотатки
- Правила класифікації редагуються у `PUBLISHING/type_rules.yml` (порядок важливий).
- Рекомендація: уникати більше ніж 2 постів на день у тому самому каналі.

© DAO-GOGS • С.Ч.


## Тижневий бюджет
- Ліміт: **≤ 6 постів/канал/тиждень**
- Автоматична перевірка у CI: `tools/check_publication_budget.py --budget 6 --fail-on-violation`
- Звіт: `analytics/weekly_budget_report.csv`


## Перевищення тижневого бюджету
Поріг: **≤ 6 постів/канал/тиждень**

CSV: `analytics/weekly_budget_violations.csv`

Попередній перегляд (перші 20 рядків):

```
week,Channel,count

```

## Контроль ваги релізу (CI)

- Перевірка виконується у workflow `.github/workflows/publish-release-assets.yml` **перед** завантаженням артефактів до релізу.
- Скрипт: `tools/check_release_sizes.py`
- Джерело даних: `dist/release_manifest.json` (поле `files[].size_mb`).

**Пороги:**
- Full ≤ 25 MB
- Core ≤ 10 MB

**Локальний запуск:**
```bash
python tools/package_release_assets.py
python tools/check_release_sizes.py --root . --full-max 25 --core-max 10
```
У CI використовується прапорець `--fail-on-violation`, тому при перевищенні порогів крок **падає** і реліз не публікується.

# MEDIA_CATALOG v1.0 — Структура

![Структура](assets/MEDIA_CATALOG_STRUCTURE.png)

---

## 📂 Головні блоки

### SYMBOLIC
- Символи **S01..S08** (SVG/PNG, кольорові й моно).  
- `manifest.json` — опис пакета.  
- `README.md` — огляд символічної системи.  
- `GALLERY` — сітка з усіма символами.  

**Призначення:** візуальна мова DAO-GOGS, обкладинки, обряди.

---

### NARRATIVE
- `lines/` — 7 сюжетних ліній (N01..N07, draft v0.1).  
- `PACK_v1.1.md` — огляд усіх історій.  
- `manifest.json` — метадані.  
- `MAP` — карта зв’язків SYMBOLIC ↔ NARRATIVE.  

**Призначення:** нова українська міфологія, тексти для публікацій, освітні матеріали.

---

### PUBLISHING
- `content_calendar.csv` — календар публікацій.  
- `out/` — згенеровані Markdown-пости.  
- `README.md` — SOP + інструкції.  

**Призначення:** щоденна/тижнева комунікація, CI/CD, публікації в Telegram, Facebook, GitBook.

---

### tools
- `Sync-Publishing.ps1` — скрипт генерації постів із календаря.  
- `README.md` — опис інструментів.  

**Призначення:** автоматизація, інтеграція з GitHub Actions.

---

© DAO-GOGS • С.Ч. • v1.0

import os
# -*- coding: utf-8 -*-
import pandas as pd

REQUIRED = {"Date", "Channel", "Title", "Body", "Type"}

def test_calendar_schema():
    df = pd.read_csv(os.path.join(os.path.dirname(__file__), "..", "PUBLISHING", "content_calendar.csv"))
    assert REQUIRED.issubset(df.columns), f"CSV must contain columns: {REQUIRED}"
    assert len(df) > 0

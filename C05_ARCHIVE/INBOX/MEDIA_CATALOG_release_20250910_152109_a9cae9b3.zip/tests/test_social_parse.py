import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
# -*- coding: utf-8 -*-
from tools.lib_social import parse_captions, make_slug, frontmatter

def test_parse_captions():
    with open(os.path.join(os.path.dirname(__file__), "..", "SOCIAL_CAPTIONS.md"), "r", encoding="utf-8") as f:
        md = f.read()
    styles, hashtags = parse_captions(md)
    assert set(styles.keys()) == {"official", "emotional", "short"}
    assert hashtags.startswith("#DAO_GOGS")

def test_frontmatter_and_slug():
    fm = frontmatter({"title": "Тест", "date": "2025-09-10", "channel": "GitBook"})
    assert fm.strip().startswith("---") and "title: \"Тест\"" in fm
    assert make_slug("Hello World!") == "hello-world"

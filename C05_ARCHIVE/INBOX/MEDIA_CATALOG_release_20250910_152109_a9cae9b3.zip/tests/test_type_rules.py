import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
# -*- coding: utf-8 -*-
from tools.lib_types import load_rules, classify_row

def test_message_rule_priority():
    rules = load_rules(os.path.join(os.path.dirname(__file__), "..", "PUBLISHING", "type_rules.yml"))
    t = "Меседж сьогодні: творці, не споживачі"
    s = "message-today-creators-not-consumers"
    assert classify_row(t, s, rules) == "message"

def test_symbolic_detection():
    rules = load_rules(os.path.join(os.path.dirname(__file__), "..", "PUBLISHING", "type_rules.yml"))
    t = "Символ дня: Коло"
    s = "sym-02-circle-power"
    assert classify_row(t, s, rules) == "symbolic"

# tools/ — CI/CD та автоматизація публікацій

## Sync-Publishing.ps1
Експортує пости з `PUBLISHING/content_calendar.csv` у Markdown (`PUBLISHING/out/*.md`).

### Запуск локально
```powershell
pwsh -NoProfile -File ".\tools\Sync-Publishing.ps1" -Root "$PWD" -DryRun   # перевірка без запису
pwsh -NoProfile -File ".\tools\Sync-Publishing.ps1" -Root "$PWD"          # генерація .md
pwsh -NoProfile -File ".\tools\Sync-Publishing.ps1" -Root "$PWD" -GitCommit -GitMessage "chore: export posts"
```

### Очікувані колонки CSV
`Date, Channel, Title, Slug, Body, Tags`
*(Slug можна не задавати — згенерується з Title.)*

### Логи
Записуються у `C03\LOG\publishing_sync.log` (якщо шлях існує).

## GitHub Actions
Workflow: `.github/workflows/sync-publishing.yml`
- Працює щодня о 06:00 UTC (≈09:00 Київ).
- Тригериться при змінах у `PUBLISHING/content_calendar.csv` або у самому скрипті.

## Рекомендований цикл
1. Оновити `PUBLISHING/content_calendar.csv` на 1–3 тижні вперед.
2. Прогнати `-DryRun`, перевірити попередній вигляд.
3. Згенерувати `.md` пости.
4. Зробити `git add/commit/push` → CI виконає свій ран.
5. Після публікації — зібрати аналітику (ANALYTICS) і оновити план.

Param(
  [Parameter(Mandatory=$false)][string]$Root = "C:\CHECHA_CORE\MEDIA_CATALOG",
  [Parameter(Mandatory=$false)][string]$CalendarCsv = "PUBLISHING\content_calendar.csv",
  [Parameter(Mandatory=$false)][string]$OutDir = "PUBLISHING\out",
  [switch]$DryRun,
  [switch]$GitCommit,
  [string]$GitMessage = "chore: auto-export posts from content_calendar.csv",
  [string]$LogFile = "C03\LOG\publishing_sync.log"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Log([string]$msg) {
  $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
  $line = "$ts [INFO ] $msg"
  Write-Host $line
  try {
    $logPath = Join-Path $Root $LogFile
    New-Item -ItemType Directory -Force -Path (Split-Path $logPath) | Out-Null
    Add-Content -Path $logPath -Value $line
  } catch {}
}

# Resolve paths
$root = Convert-Path $Root
$csvPath = Join-Path $root $CalendarCsv
$outPath = Join-Path $root $OutDir

Write-Log "Root: $root"
Write-Log "CSV : $csvPath"
Write-Log "Out : $outPath"

if (-not (Test-Path $csvPath)) {
  throw "Не знайдено календар: $csvPath"
}

# Ensure out dir exists
New-Item -ItemType Directory -Force -Path $outPath | Out-Null

# Expected CSV columns (приклад): Date, Channel, Title, Slug, Body, Tags
$items = Import-Csv -Path $csvPath

foreach ($row in $items) {
  $date   = $row.Date
  $chan   = $row.Channel
  $title  = $row.Title
  $slug   = $row.Slug
  $body   = $row.Body
  $tags   = $row.Tags
  $cover  = $row.Cover


  if (-not $slug) {
    # генеруємо простий slug з Title
    $slug = ($title -replace "[^a-zA-Z0-9\- ]","").ToLower().Trim() -replace " +","-"
  }

  $fileName = "{0}_{1}.md" -f $date, $slug
  $postPath = Join-Path $outPath $fileName

  $md = @"
---
title: "$title"
date: "$date"
channel: "$chan"
tags: "$tags"
---
@if ($cover) { "cover: `$cover`" }
---

$body

"@

  if ($DryRun) {
    Write-Log "DRYRUN would write: $postPath"
  } else {
    Set-Content -Path $postPath -Value $md -Encoding UTF8
    Write-Log "Wrote: $postPath"
  }
}

if ($GitCommit) {
  try {
    Push-Location $root
    git add .
    git commit -m "$GitMessage"
    git push
    Pop-Location
    Write-Log "Git committed & pushed."
  } catch {
    Write-Log "Git step failed: $($_.Exception.Message)"
  }
}

Write-Log "Sync complete."

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Перевірка тижневого бюджету постів за каналами.
Групує календар по тижнях (ISO week) і каналах, порівнює з бюджетом.
Генерує CSV-звіт і (опційно) падає з exit 1, якщо є порушення.

Приклад:
  python tools/check_publication_budget.py --root . --budget 6 --fail-on-violation
"""
import os, sys, argparse
import pandas as pd

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--budget", type=int, default=6, help="макс. постів/канал/тиждень")
    ap.add_argument("--fail-on-violation", action="store_true")
    args = ap.parse_args()

    root = os.path.abspath(args.root)
    csv_path = os.path.join(root, "PUBLISHING", "content_calendar.csv")
    out_dir = os.path.join(root, "PUBLISHING", "analytics")
    os.makedirs(out_dir, exist_ok=True)

    df = pd.read_csv(csv_path)
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df["ISO_Year"] = df["Date"].dt.isocalendar().year
    df["ISO_Week"] = df["Date"].dt.isocalendar().week

    weekly = (df.groupby(["ISO_Year","ISO_Week","Channel"])
                .size().reset_index(name="posts"))
    weekly["budget"] = args.budget
    weekly["over"] = weekly["posts"] - weekly["budget"]
    weekly["violation"] = weekly["over"] > 0

    # Звіт
    out_csv = os.path.join(out_dir, "weekly_budget_report.csv")
    weekly.sort_values(["ISO_Year","ISO_Week","Channel"]).to_csv(out_csv, index=False, encoding="utf-8-sig")

    # Короткий підсумок
    violations = weekly[weekly["violation"]]
    print(f"Weekly budget = {args.budget} posts/channel/week")
    print(f"Total rows: {len(weekly)}, violations: {len(violations)}")
    if len(violations):
        print("Examples of violations (up to 10 rows):")
        print(violations.head(10).to_string(index=False))

    if args.fail_on_violation and len(violations):
        sys.exit(1)

if __name__ == "__main__":
    main()

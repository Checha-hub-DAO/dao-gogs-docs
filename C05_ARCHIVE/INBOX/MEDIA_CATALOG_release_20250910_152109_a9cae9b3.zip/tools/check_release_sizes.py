#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Перевірка порогів ваги релізу на основі dist/release_manifest.json

Використання:
  python tools/check_release_sizes.py --root . --full-max 25 --core-max 10 --fail-on-violation
"""
import os, json, argparse, sys

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--manifest", default="dist/release_manifest.json")
    ap.add_argument("--full-max", type=float, default=25.0, help="MB: поріг для Full архіву")
    ap.add_argument("--core-max", type=float, default=10.0, help="MB: поріг для Core архіву")
    ap.add_argument("--fail-on-violation", action="store_true")
    args = ap.parse_args()

    root = os.path.abspath(args.root)
    mf_path = os.path.join(root, args.manifest)

    if not os.path.exists(mf_path):
        print(f"[ERROR] Не знайдено manifest: {mf_path}")
        sys.exit(1)

    with open(mf_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    full_name = os.path.basename(data.get("archive",""))
    core_name = os.path.basename(data.get("core_archive",""))
    files = { item["name"]: float(item.get("size_mb", 0)) for item in data.get("files", []) }

    full_size = files.get(full_name, None)
    core_size = files.get(core_name, None)

    print(f"Full archive: {full_name} — {full_size} MB (max {args.full_max} MB)")
    print(f"Core archive: {core_name} — {core_size} MB (max {args.core_max} MB)")

    violations = []
    if full_size is None or core_size is None:
        print("[WARN] Не вдалося знайти розміри у маніфесті. Переконайтесь, що пакувальник згенерував поле files[].")
    if full_size is not None and full_size > args.full_max:
        violations.append(f"FULL>{args.full_max}MB ({full_size}MB)")
    if core_size is not None and core_size > args.core_max:
        violations.append(f"CORE>{args.core_max}MB ({core_size}MB)")

    if violations:
        print("[VIOLATION] Перевищено поріг ваги: " + ", ".join(violations))
        if args.fail_on_violation:
            sys.exit(1)
    else:
        print("[OK] Вага релізу в межах порогів.")

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Генератор соцпостів з календаря + шаблонів підписів.

Використання:
  python tools/generate_social_posts.py --root . [--style auto|official|emotional|short]

Вихід:
  PUBLISHING/social_posts/YYYY-MM-DD_slug_CHANNEL.txt
"""

import os
import re
import argparse
from tools.lib_social import parse_captions, make_slug
import pandas as pd
from datetime import datetime

STYLE_KEYS = {
    "official": "1. 🏛 Офіційний стиль",
    "emotional": "2. 💙💛 Емоційний стиль",
    "short": "3. ⚡ Короткий стиль",
}

CHANNEL_STYLE_AUTO = {
    "Facebook": "official",
    "GitBook": "official",
    "Instagram": "emotional",
    "Telegram": "short",
    "Twitter": "short",
    "YouTube": "official",
}

def parse_captions(md_text: str):
    """Парсить SOCIAL_CAPTIONS.md у словник стилів + хештеги."""
    styles = {}
    hashtags = ""
    # Витяг блоків стилів
    for key, header in STYLE_KEYS.items():
        pattern = rf"##\s*{re.escape(header)}.*?\n(.*?)(?=\n---|\Z)"
        m = re.search(pattern, md_text, flags=re.DOTALL)
        if m:
            styles[key] = m.group(1).strip()
    # Хештеги
    m = re.search(r"##\s*🔖\s*Хештеги.*?\n`([^`]+)`", md_text, flags=re.DOTALL)
    if m:
        hashtags = m.group(1).strip()
    return styles, hashtags

def make_slug(text: str):
    base = re.sub(r"[^a-zA-Z0-9\- ]", "", text).strip().lower()
    return re.sub(r"\s+", "-", base) or "post"

def build_post(title, body, cover, style_text, hashtags, ptype):
    lines = []
    if title:
        lines.append(f"{title} [Type: {ptype}]\n")
    if body:
        lines.append(body.strip())
    if cover:
        lines.append(f"\n[cover] {cover}")
    if hashtags:
        lines.append(f"\n{hashtags}")
    return "\n".join(lines).strip() + "\n"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--style", default="auto", choices=["auto", "official", "emotional", "short"])
    args = ap.parse_args()

    root = os.path.abspath(args.root)
    publ_dir = os.path.join(root, "PUBLISHING")
    out_dir = os.path.join(publ_dir, "social_posts")
    os.makedirs(out_dir, exist_ok=True)

    captions_path = os.path.join(root, "SOCIAL_CAPTIONS.md")
    if not os.path.exists(captions_path):
        raise FileNotFoundError(f"Не знайдено SOCIAL_CAPTIONS.md у {root}")
    with open(captions_path, "r", encoding="utf-8") as f:
        captions_md = f.read()
    styles, hashtags = parse_captions(captions_md)
    if not styles:
        raise RuntimeError("Не вдалося розпізнати стилі у SOCIAL_CAPTIONS.md")

    csv_path = os.path.join(publ_dir, "content_calendar.csv")
    df = pd.read_csv(csv_path)

    generated = []
    for _, row in df.iterrows():
        date = str(row.get("Date","")).strip()
        channel = str(row.get("Channel","")).strip()
        title = str(row.get("Title","")).strip()
        slug = str(row.get("Slug","")).strip() or make_slug(title)
        body = str(row.get("Body","")).strip()
        cover = str(row.get("Cover","")).strip() if "Cover" in row else ""

        # Обираємо стиль
        if args.style == "auto":
            style_key = CHANNEL_STYLE_AUTO.get(channel, "official")
        else:
            style_key = args.style

        style_text = styles.get(style_key, "")
        # Формуємо фінальний текст: короткий опис із календаря + стильний підпис/CTA
        post_text = build_post(title, body + "\n\n" + style_text, cover, style_text, hashtags, str(row.get("Type","")))

        # Ім'я файлу
        safe_channel = re.sub(r"[^A-Za-z0-9]+", "_", channel).strip("_")
        fname = f"{date}_{slug}_{safe_channel}.txt"
        fpath = os.path.join(out_dir, fname)
        with open(fpath, "w", encoding="utf-8") as f:
            f.write(post_text)
        generated.append(fpath)

    print(f"Generated {len(generated)} files in {out_dir}")
    for p in generated[:10]:
        print(os.path.basename(p))
    if len(generated) > 10:
        print("...")

if __name__ == "__main__":
    main()

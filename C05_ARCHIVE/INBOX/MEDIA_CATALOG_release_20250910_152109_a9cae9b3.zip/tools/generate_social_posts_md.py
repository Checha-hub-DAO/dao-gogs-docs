#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Генератор соцпостів у форматі Markdown із frontmatter.
Вхід: SOCIAL_CAPTIONS.md + PUBLISHING/content_calendar.csv
Вихід: PUBLISHING/social_posts_md/YYYY-MM-DD_slug_CHANNEL.md
"""

import os, re, argparse, pandas as pd
from datetime import datetime

STYLE_KEYS = {
    "official": "1. 🏛 Офіційний стиль",
    "emotional": "2. 💙💛 Емоційний стиль",
    "short": "3. ⚡ Короткий стиль",
}

CHANNEL_STYLE_AUTO = {
    "Facebook": "official",
    "GitBook": "official",
    "Instagram": "emotional",
    "Telegram": "short",
    "Twitter": "short",
    "YouTube": "official",
}

def parse_captions(md_text: str):
    styles = {}
    hashtags = ""
    for key, header in STYLE_KEYS.items():
        pattern = rf"##\s*{re.escape(header)}.*?\n(.*?)(?=\n---|\Z)"
        m = re.search(pattern, md_text, flags=re.DOTALL)
        if m:
            styles[key] = m.group(1).strip()
    m = re.search(r"##\s*🔖\s*Хештеги.*?\n`([^`]+)`", md_text, flags=re.DOTALL)
    if m:
        hashtags = m.group(1).strip()
    return styles, hashtags

def make_slug(text: str):
    base = re.sub(r"[^a-zA-Z0-9\- ]", "", text).strip().lower()
    return re.sub(r"\s+", "-", base) or "post"

def frontmatter(data: dict) -> str:
    lines = ["---"]
    for k, v in data.items():
        v = str(v).replace('"','\\"')
        lines.append(f'{k}: "{v}"')
    lines.append("---\n")
    return "\n".join(lines)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--style", default="auto", choices=["auto", "official", "emotional", "short"])
    args = ap.parse_args()

    root = os.path.abspath(args.root)
    publ_dir = os.path.join(root, "PUBLISHING")
    out_dir = os.path.join(publ_dir, "social_posts_md")
    os.makedirs(out_dir, exist_ok=True)

    captions_path = os.path.join(root, "SOCIAL_CAPTIONS.md")
    if not os.path.exists(captions_path):
        raise FileNotFoundError(f"Не знайдено SOCIAL_CAPTIONS.md у {root}")
    with open(captions_path, "r", encoding="utf-8") as f:
        captions_md = f.read()
    styles, hashtags = parse_captions(captions_md)

    csv_path = os.path.join(publ_dir, "content_calendar.csv")
    import pandas as pd
    df = pd.read_csv(csv_path)

    generated = []
    for _, row in df.iterrows():
        date = str(row.get("Date","")).strip()
        channel = str(row.get("Channel","")).strip()
        title = str(row.get("Title","")).strip()
        slug = str(row.get("Slug","")).strip() or make_slug(title)
        body = str(row.get("Body","")).strip()
        cover = str(row.get("Cover","")).strip() if "Cover" in row else ""

        if args.style == "auto":
            style_key = CHANNEL_STYLE_AUTO.get(channel, "official")
        else:
            style_key = args.style
        style_text = styles.get(style_key, "")

        meta = { "type": (row.get("Type") if "Type" in row else ""),
            "title": title or slug,
            "date": date,
            "channel": channel,
            "hashtags": hashtags,
        }
        if cover:
            meta["cover"] = cover

        content = f"{body}\n\n{style_text}\n\n{hashtags}\n"
        fm = frontmatter(meta)
        md = fm + "# " + (title or slug) + "\n\n" + content

        safe_channel = re.sub(r"[^A-Za-z0-9]+", "_", channel).strip("_")
        fname = f"{date}_{slug}_{safe_channel}.md"
        fpath = os.path.join(out_dir, fname)
        with open(fpath, "w", encoding="utf-8") as f:
            f.write(md)
        generated.append(fpath)

    print(f"Generated {len(generated)} markdown posts at {out_dir}")

if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
import re
from typing import Dict, Tuple

STYLE_KEYS = {
    "official": "1. 🏛 Офіційний стиль",
    "emotional": "2. 💙💛 Емоційний стиль",
    "short": "3. ⚡ Короткий стиль",
}

def parse_captions(md_text: str) -> Tuple[Dict[str,str], str]:
    """Повертає (styles_dict, hashtags) із SOCIAL_CAPTIONS.md"""
    styles = {}
    hashtags = ""
    for key, header in STYLE_KEYS.items():
        pattern = rf"##\s*{re.escape(header)}.*?\n(.*?)(?=\n---|\Z)"
        m = re.search(pattern, md_text, flags=re.DOTALL)
        if m:
            styles[key] = m.group(1).strip()
    m = re.search(r"##\s*🔖\s*Хештеги.*?\n`([^`]+)`", md_text, flags=re.DOTALL)
    if m:
        hashtags = m.group(1).strip()
    return styles, hashtags

def make_slug(text: str) -> str:
    base = re.sub(r"[^a-zA-Z0-9\- ]", "", text).strip().lower()
    return re.sub(r"\s+", "-", base) or "post"

def frontmatter(data: dict) -> str:
    lines = ["---"]
    for k, v in data.items():
        v = str(v).replace('"', '\\"')
        lines.append(f'{k}: "{v}"')
    lines.append("---\n")
    return "\n".join(lines)

# -*- coding: utf-8 -*-
import re, yaml
from typing import Dict, Any

def load_rules(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def classify_row(title: str, slug: str, rules: Dict[str, Any]) -> str:
    t = (title or "").lower()
    s = (slug or "").lower()
    for rule in rules["order"]:
        for pat in rule["patterns"]:
            if re.search(pat, t) or re.search(pat, s):
                return rule["type"]
    return rules.get("fallback", "post")

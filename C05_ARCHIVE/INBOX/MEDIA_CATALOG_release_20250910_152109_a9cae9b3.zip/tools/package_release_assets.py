#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Пакує релізні артефакти у dist/:
- Full ZIP (з виключеннями)
- Core ZIP (SYMBOLIC, NARRATIVE, PUBLISHING)
- Копії аналітики та соцкаруселі (як окремі файли)
- release_manifest.json з розмірами файлів (MB)
"""
import os, zipfile, shutil, json
from datetime import datetime

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DIST = os.path.join(ROOT, "dist")
os.makedirs(DIST, exist_ok=True)

# Налаштування виключень та включень
EXCLUDE_DIRS = {".git", "dist", "__pycache__"}
EXCLUDE_SUFFIX = {".pyc"}
EXCLUDE_ZIP = True
ZIP_ALLOWLIST_PREFIXES = ["SOCIAL_CAROUSEL_v"]

LIGHTWEIGHT_DIRS = ["SYMBOLIC", "NARRATIVE", "PUBLISHING"]  # core assets only

def zipdir(path, ziph, base, exclude_dirs=None, exclude_suffix=None, exclude_zip=False, zip_allow=None):
    for base_dir, dirnames, files in os.walk(path):
        # Вирізаємо виключені каталоги
        if exclude_dirs:
            dirnames[:] = [d for d in dirnames if d not in exclude_dirs]
        for file in files:
            fpath = os.path.join(base_dir, file)
            # Фільтр за суфіксами
            if exclude_suffix and any(fpath.endswith(suf) for suf in exclude_suffix):
                continue
            # Фільтр ZIP-ів
            if exclude_zip and fpath.lower().endswith(".zip"):
                bn = os.path.basename(fpath)
                if not any(bn.startswith(p) for p in (zip_allow or [])):
                    continue
            arc = os.path.relpath(fpath, base)
            ziph.write(fpath, arc)

def size_mb(path):
    try:
        return round(os.path.getsize(path) / 1024 / 1024, 2)
    except OSError:
        return None

def main():
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")

    # 1) Full ZIP
    full_zip = os.path.join(DIST, f"MEDIA_CATALOG_release_{ts}.zip")
    with zipfile.ZipFile(full_zip, 'w', zipfile.ZIP_DEFLATED) as z:
        zipdir(ROOT, z, ROOT, EXCLUDE_DIRS, EXCLUDE_SUFFIX, EXCLUDE_ZIP, ZIP_ALLOWLIST_PREFIXES)

    # 2) Core ZIP
    core_zip = os.path.join(DIST, f"MEDIA_CATALOG_core_{ts}.zip")
    with zipfile.ZipFile(core_zip, 'w', zipfile.ZIP_DEFLATED) as zc:
        for d in LIGHTWEIGHT_DIRS:
            p = os.path.join(ROOT, d)
            if os.path.isdir(p):
                zipdir(p, zc, ROOT, EXCLUDE_DIRS, EXCLUDE_SUFFIX, EXCLUDE_ZIP, ZIP_ALLOWLIST_PREFIXES)

    # 3) Додаткові активи (аналітика + соцкарусель)
    assets = []
    analytics_dir = os.path.join(ROOT, "PUBLISHING", "analytics")
    if os.path.isdir(analytics_dir):
        for f in os.listdir(analytics_dir):
            src = os.path.join(analytics_dir, f)
            if os.path.isfile(src):
                dst = os.path.join(DIST, f"analytics_{f}")
                shutil.copy2(src, dst)
                assets.append(dst)
    carousel_zip = os.path.join(ROOT, "SOCIAL_CAROUSEL_v1.0.zip")
    if os.path.isfile(carousel_zip):
        dst = os.path.join(DIST, os.path.basename(carousel_zip))
        shutil.copy2(carousel_zip, dst)
        assets.append(dst)

    # 4) Маніфест з розмірами
    files = [full_zip, core_zip] + assets
    manifest = {
        "archive": full_zip,
        "core_archive": core_zip,
        "assets": [os.path.basename(a) for a in [full_zip] + assets],
        "files": [{"name": os.path.basename(p), "size_mb": size_mb(p)} for p in files],
    }
    mf_path = os.path.join(DIST, "release_manifest.json")
    with open(mf_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()

# AUDIO_VIDEO — Аудіо/Відео
Зберігання бренд-тонів, звернень, тизерів.

## Файли
- `avatar_script.txt` — скрипт звернення (G35)
- `signal_audio.wav` — бренд-тон 7s
- `teaser.mp4` — тизер

# INTake — Прийом контенту

1) Додай файл у відповідну папку та заповни метадані (див. schema).
2) Признач статус: draft/ready/scheduled/published.
3) Додай у `PUBLISHING/content_calendar.csv` рядок із датою й каналом.
4) Після публікації — перенеси в архів і додай KPI у `ANALYTICS/report.md`.

# DAO Bot Spec (G13)
- Команди: /signal, /ritual, /join
- Логи: архів сигналів
- Інтеграції: Looker Studio, GitBook

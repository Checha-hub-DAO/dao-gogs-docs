# 🗂️ MEGA_INDEX — 2024–2025 (W/M/Q/Y)

```mermaid
flowchart TB
  subgraph Y2024[2024]
    direction TB
    subgraph Q24[Квартали 2024]
      Q24_1[QUARTER_SUMMARY_2024-Q1.md]
      Q24_2[QUARTER_SUMMARY_2024-Q2.md]
      Q24_3[QUARTER_SUMMARY_2024-Q3.md]
      Q24_4[QUARTER_SUMMARY_2024-Q4.md]
    end
    subgraph M24[Місяці 2024]
      M24_01[MONTH_SUMMARY_2024-M01.md]; ...; M24_12[MONTH_SUMMARY_2024-M12.md]
    end
  end

  subgraph Y2025[2025]
    direction TB
    subgraph Q25[Квартали 2025]
      Q25_1[QUARTER_SUMMARY_2025-Q1.md]
      Q25_2[QUARTER_SUMMARY_2025-Q2.md]
      Q25_3[QUARTER_SUMMARY_2025-Q3.md]
      Q25_4[QUARTER_SUMMARY_2025-Q4.md]
    end
    subgraph M25[Місяці 2025]
      M25_01[MONTH_SUMMARY_2025-M01.md]; ...; M25_12[MONTH_SUMMARY_2025-M12.md]
    end
  end

  Y2024 --> Y2025
```

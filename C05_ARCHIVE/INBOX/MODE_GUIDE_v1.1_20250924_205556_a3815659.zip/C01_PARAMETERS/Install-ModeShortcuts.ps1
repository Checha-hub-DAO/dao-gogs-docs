# === Install-ModeShortcuts.ps1 ===
$Root      = "D:\CHECHA_CORE\C01_PARAMETERS"
$Switch    = Join-Path $Root "Switch-Mode.ps1"
$ShortDir  = Join-Path $Root "shortcuts"
$Desktop   = [Environment]::GetFolderPath('Desktop')

if (-not (Test-Path $ShortDir)) { New-Item -ItemType Directory -Path $ShortDir | Out-Null }

$cmds = @(
  @{Name="smartphone.cmd"; Mode="смартфон"},
  @{Name="tablet.cmd"    ; Mode="планшет"},
  @{Name="laptop.cmd"    ; Mode="ноутбук"}
)
foreach ($c in $cmds) {
  $path = Join-Path $ShortDir $c.Name
  @"
@echo off
pwsh -NoProfile -ExecutionPolicy Bypass -File "$Switch" $($c.Mode)
"@ | Set-Content -LiteralPath $path -Encoding utf8
  Write-Host "✓ Створено $path"
}

$Wsh = New-Object -ComObject WScript.Shell
$map = @{
  "Switch to Smartphone.lnk" = Join-Path $ShortDir "smartphone.cmd"
  "Switch to Tablet.lnk"     = Join-Path $ShortDir "tablet.cmd"
  "Switch to Laptop.lnk"     = Join-Path $ShortDir "laptop.cmd"
}
foreach ($k in $map.Keys) {
  $lnkPath = Join-Path $Desktop $k
  $sc      = $Wsh.CreateShortcut($lnkPath)
  $sc.TargetPath = $map[$k]
  $sc.WorkingDirectory = $ShortDir
  $sc.IconLocation = "$env:SystemRoot\System32\shell32.dll,201"
  $sc.Save()
  Write-Host "✓ Ярлик на Desktop: $lnkPath"
}

Write-Host "=== Готово. Натисни ярлик на Desktop, щоб перемкнути режим. ===" -ForegroundColor Green

param(
    [Parameter(Mandatory=$true, Position=0)]
    [string]$Mode
)
# --- CONFIG ---
$Root      = "D:\CHECHA_CORE\C01_PARAMETERS"
$ActiveTxt = Join-Path $Root "ACTIVE_MODE.txt"
$ActiveJson= Join-Path $Root "ACTIVE_MODE.json"
$LogsDir   = Join-Path $Root "logs"
$LogCsv    = Join-Path $LogsDir "mode_history.csv"

function Normalize-Mode($m) {
    $map = @{
        "смартфон"="смартфон"; "smartphone"="смартфон"; "phone"="смартфон"; "1"="смартфон";
        "планшет" ="планшет";  "tablet"     ="планшет";  "pad"  ="планшет";  "2"="планшет";
        "ноутбук" ="ноутбук";  "laptop"     ="ноутбук";  "pc"   ="ноутбук";  "3"="ноутбук"
    }
    $key = ($m -replace '\s+','').ToLowerInvariant()
    if ($map.ContainsKey($key)) { return $map[$key] }
    throw "Невідомий режим: '$m'. Доступні: смартфон | планшет | ноутбук (або 1|2|3)."
}
function Ensure-Dir($p) { if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p | Out-Null } }

try { $ModeNorm = Normalize-Mode $Mode } catch { Write-Error $_.Exception.Message; exit 1 }

Ensure-Dir $Root; Ensure-Dir $LogsDir

$now   = Get-Date
$stamp = $now.ToString("yyyy-MM-dd HH:mm:ss")
$hostn = $env:COMPUTERNAME
$usern = "$($env:USERDOMAIN)\$($env:USERNAME)"

$txt = @"
$ModeNorm
# device-mode for CheCha System
# updated: $stamp
# user: $usern
# host: $hostn
"@

$state = [ordered]@{
    mode      = $ModeNorm
    updated   = $now.ToString("o")
    user      = $usern
    host      = $hostn
    pid       = $PID
}
$null = $txt | Set-Content -LiteralPath $ActiveTxt -Encoding utf8
$null = ($state | ConvertTo-Json -Depth 5) | Set-Content -LiteralPath $ActiveJson -Encoding utf8

if (-not (Test-Path $LogCsv)) { "timestamp,mode,user,host" | Set-Content -LiteralPath $LogCsv -Encoding utf8 }
"$stamp,$ModeNorm,$usern,$hostn" | Add-Content -LiteralPath $LogCsv -Encoding utf8

[Environment]::SetEnvironmentVariable('CHECHA_ACTIVE_MODE', $ModeNorm, 'User')

$icon = switch ($ModeNorm) { "смартфон" {"📱"} "планшет" {"📖"} "ноутбук" {"💻"} }
$Host.UI.RawUI.WindowTitle = "$icon CheCha Mode: $ModeNorm — $stamp"
Write-Host ("="*60)
Write-Host (" ✅ Режим активовано: {0} {1}" -f $icon, $ModeNorm) -ForegroundColor Green
Write-Host (" 📝 Запис: {0}" -f $ActiveTxt)
Write-Host (" 🧭 Історія: {0}" -f $LogCsv)
Write-Host (" 🌿 Env: CHECHA_ACTIVE_MODE={0} (User)" -f $ModeNorm)
Write-Host ("="*60)

switch ($ModeNorm) {
    "смартфон" { Write-Host "Рекомендації: короткі відповіді, фіксація ідей/фото/голосу, швидкі задачі." -ForegroundColor Yellow }
    "планшет"  { Write-Host "Рекомендації: читання/огляд, правки у GitBook, візуали/схеми." -ForegroundColor Yellow }
    "ноутбук"  { Write-Host "Рекомендації: скрипти/збірки/архіви, важкі задачі, повні інструкції." -ForegroundColor Yellow }
}

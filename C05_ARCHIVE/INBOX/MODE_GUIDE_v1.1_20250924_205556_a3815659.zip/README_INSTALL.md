# 🧩 MODE_GUIDE_v1.1 — Інструкція встановлення

**Склад пакету:**
- `DOCS/SMARTPHONE_MODE.md`, `DOCS/TABLET_MODE.md`, `DOCS/LAPTOP_MODE.md`, `DOCS/README_MODE_INDEX.md`
- `C01_PARAMETERS/Switch-Mode.ps1`
- `C01_PARAMETERS/Install-ModeShortcuts.ps1`
- `C01_PARAMETERS/shortcuts/smartphone.cmd`, `tablet.cmd`, `laptop.cmd`

## Встановлення (на ноутбуці, Windows + PowerShell 7)
1) Розпакуй архів і скопіюй папку **C01_PARAMETERS** у `D:\CHECHA_CORE\` (створи, якщо нема).
2) Запусти:
```powershell
pwsh -NoProfile -ExecutionPolicy Bypass -File "D:\CHECHA_CORE\C01_PARAMETERS\Install-ModeShortcuts.ps1"
```
3) На Desktop з’являться ярлики **Switch to Smartphone / Tablet / Laptop**.

## Використання
- Перемикай режим одним кліком або вручну:
```powershell
pwsh -NoProfile -File "D:\CHECHA_CORE\C01_PARAMETERS\Switch-Mode.ps1" смартфон
```
- Поточний стан: `D:\CHECHA_CORE\C01_PARAMETERS\ACTIVE_MODE.txt`

## Примітки
- На смартфоні/планшеті фізично `.cmd` не запускаються — там використовуй короткі команди в чаті: `смартфон`, `планшет`, `ноутбук`.

# README — Run_Shield4_Release.ps1

Цей допоміжний скрипт створений для швидкого запуску релізів SHIELD4.

## 🔧 Як працює
- Ти редагуєш лише верхній блок змінних:
  - `$Version` — номер версії релізу (наприклад `v2.6`).
  - `$NewReleasePath` — шлях до головного ZIP-пакета.
  - `$mods` — список додаткових модулів (ZIP/PDF/MD…).

- Решта параметрів (`-AutoPickPrintBook`, `-SkipMissing`, `-ExtractZip`) залишаються за замовчуванням.

## ▶️ Запуск

### 1. Симуляція (нічого не копіює, тільки показує дії)
```powershell
& "D:\CHECHA_CORE\C11\tools\Run_Shield4_Release.ps1"
```

### 2. Бойовий запуск
Відкрий файл `Run_Shield4_Release.ps1` і зніми коментар з блоку:

```powershell
# --- Бойовий запуск ---
# & "$BaseDir\..\tools\Manage_Shield4_Release.ps1" `
#   -BaseDir $BaseDir `
#   -NewReleasePath $NewReleasePath `
#   -Version $Version `
#   -ModulesToAdd $mods `
#   -AutoPickPrintBook `
#   -SkipMissing `
#   -ExtractZip `
#   -Verbose
```

→ Просто прибери `#` з початку рядків.

## 📂 Де дивитися результат
- Реліз: `<BaseDir>\RELEASES\<Version>\`
- Лог: `<BaseDir>\C03\LOG\shield4_release.log`
- Індекс: `<BaseDir>\RELEASES\INDEX.md`

## ℹ️ Поради
- Завжди спочатку запускай у режимі **симуляції** (`-WhatIf` вже вшитий).  
- Міняй `$mods` як масив для зручності.  
- Якщо PDF PrintBook відсутній, але потрібен, використовуй прапор `-AutoPickPrintBook`.  

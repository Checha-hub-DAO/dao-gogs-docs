<#
.SYNOPSIS
  Готовий запуск релізу SHIELD4 v2.7 (підставлені файли з Downloads).
.NOTES
  Зараз у Downloads є лише UltimatePack v2.6. Ми ставимо версію релізу v2.7,
  але головний пакет вказує на v2.6 ZIP (це дозволено, але краще замінити на v2.7,
  щойно зʼявиться файл).
#>

$BaseDir        = 'D:\CHECHA_CORE\C11\SHIELD4_ODESA'
$Version        = 'v2.7'
$NewReleasePath = 'C:\Users\serge\Downloads\SHIELD4_ODESA_UltimatePack_v2.6.zip'

$mods = @(
  'C:\Users\serge\Downloads\SHIELD4_ODESA_MegaPack_v1.0.zip',
  'C:\Users\serge\Downloads\SHIELD4_ODESA_MegaVisualPack_v1.0.zip'
)

# Опційно: нотатки до релізу (якщо є)
# $ReleaseNotes = 'C:\Users\serge\Docs\SHIELD4_ODESA_ReleaseNotes_v2.7.md'

# --- Симуляція ---
& "$BaseDir\..\tools\Manage_Shield4_Release.ps1" `
  -BaseDir $BaseDir `
  -NewReleasePath $NewReleasePath `
  -Version $Version `
  -ModulesToAdd $mods `
  -AutoPickPrintBook `
  -SkipMissing `
  -ExtractZip `
  -Verbose -WhatIf

# --- Бойовий запуск (зніми коментар, коли перевірив) ---
# & "$BaseDir\..\tools\Manage_Shield4_Release.ps1" `
#   -BaseDir $BaseDir `
#   -NewReleasePath $NewReleasePath `
#   -Version $Version `
#   -ModulesToAdd $mods `
#   -AutoPickPrintBook `
#   -SkipMissing `
#   -ExtractZip `
#   -Verbose

# ARCHITECTURE.md  
**Проєкт:** My English Book — English for Marko  
**Автор:** Сергій Чеча (С.Ч.)  
**Версія:** v1.0  

---

## 🎯 Мета
Створити річну програму вивчення англійської мови для дітей (6–10 років) у форматі карток, ігор і ритуалів.  
Курс базується на щотижневих темах, картках-тренажерах, архівуванні та сімейному включенні.  

---

## 📂 Структура документів

### 1. Root
```
/English_Course/
│── ARCHITECTURE.md        # опис архітектури
│── README.md              # головне пояснення курсу
│── Year_Plan.md           # календар 12 місяців / 48 тижнів
│
│── Month_Books/           # зібрані книги по місяцях
│── All_Cards/             # база всіх карток (CSV/JSON)
│── Templates/             # шаблони README, карток
│── Covers/                # PNG обкладинки
│── Symbols/               # іконки, тотеми
│── Archive/               # старі версії (v1.0, v1.1…)
```

### 2. Місячні блоки
```
/English_Course/Month_XX/
│── README.md              # опис місяця
│── Week_01/ … Week_04/    # тижні
│   │── README.md
│   │── Cards_Full.pdf
│   │── Cards_Compact.pdf
│   │── ZIP_Pack.zip
│
│── MonthX_Book.pdf
│── MonthX_Book_with_Cover.pdf
│── MonthX_Pack_FULL.zip
```

---

## 📆 Річний план (12 місяців)

### Month 1  
- Week 1 — Family & School (Mom, Dad, Brother…)  
- Week 2 — Toys & Animals (Ball, Car, Dog…)  
- Week 3 — Colors & Nature (Red, Blue, Tree…)  
- Week 4 — Home & Daily Life (House, Bed, Window…)  

### Month 2  
- Week 5 — Food & Drinks (Apple, Bread, Water…)  
- Week 6 — Body & Clothes (Head, Shoes, Hat…)  
- Week 7 — Actions & Play (Run, Draw, Smile…)  
- Week 8 — Seasons & Weather (Winter, Summer, Rain…)  

### Month 3  
- Week 9 — Numbers & Counting (One–Seven)  
- Week 10 — Animals 2 (Horse, Cow, Sheep…)  
- Week 11 — Feelings (Happy, Sad, Angry…)  
- Week 12 — Opposites (Big/Small, Hot/Cold…)  

### Month 4  
- Week 13 — Food 2 (Vegetables)  
- Week 14 — Clothes 2 (Dress, Jacket, Boots…)  
- Week 15 — Actions 2 (Eat, Sleep, Read…)  
- Week 16 — Weather 2 (Storm, Cloud, Sky…)  

### Month 5  
- Week 17 — Transport (Bus, Train, Bike…)  
- Week 18 — Nature 2 (River, Mountain, Forest…)  
- Week 19 — Daily Routine (Wake up, Brush teeth…)  
- Week 20 — Family 2 (Grandma, Grandpa, Baby…)  

### Month 6  
- Week 21 — Food 3 (Meat, Rice, Soup…)  
- Week 22 — Animals 3 (Elephant, Lion, Monkey…)  
- Week 23 — Feelings 2 (Excited, Tired, Calm…)  
- Week 24 — Colors 2 (Pink, Brown, Purple…)  

### Month 7  
- Week 25 — House 2 (Kitchen, Bathroom, Garden…)  
- Week 26 — Numbers 2 (Eight–Fifteen)  
- Week 27 — Body 2 (Eyes, Nose, Mouth…)  
- Week 28 — Clothes 3 (Gloves, Scarf, Socks…)  

### Month 8  
- Week 29 — School 2 (Pen, Paper, Desk…)  
- Week 30 — Actions 3 (Write, Listen, Speak…)  
- Week 31 — Animals 4 (Duck, Frog, Butterfly…)  
- Week 32 — Nature 3 (Sea, Beach, Island…)  

### Month 9  
- Week 33 — Food 4 (Pizza, Pasta, Cheese…)  
- Week 34 — Feelings 3 (Proud, Shy, Brave…)  
- Week 35 — Opposites 2 (Fast/Slow, Old/Young…)  
- Week 36 — Transport 2 (Plane, Ship, Subway…)  

### Month 10  
- Week 37 — Body 3 (Legs, Arms, Heart…)  
- Week 38 — Clothes 4 (Coat, Belt, Tie…)  
- Week 39 — Actions 4 (Cook, Build, Swim…)  
- Week 40 — Seasons 2 (Spring rain, Summer sun…)  

### Month 11  
- Week 41 — School 3 (Book, Board, Teacher…)  
- Week 42 — Home 3 (Roof, Floor, Doorbell…)  
- Week 43 — Numbers 3 (Sixteen–Twenty)  
- Week 44 — Nature 4 (Star, Moon, Sky…)  

### Month 12  
- Week 45 — Review 1 (повторення тем)  
- Week 46 — Review 2 (ігри з картками)  
- Week 47 — Storytelling 1 (створення казок з картками)  
- Week 48 — Celebration & Archive (підсумки, ритуали)  

---

## 🧭 Принципи
- Кожен тиждень = **7 карток** (1 день — 1 слово/образ).  
- Кожен місяць = **28 карток + книга**.  
- Весь рік = **336 карток + 12 книг + 1 річний архів**.  
- Інтеграція міфології (Світляк, Тотеми, Архів).  
- Гнучкість: Full A4 для творчості, Compact для ігор, Книга для збору.  

---

## 📌 Версійність
- v1.0 — перша публічна структура.  
- v2.0 — після тестування з учнями/сім’ями.  
- v3.0 — після інтеграції в освітні спільноти.  

---

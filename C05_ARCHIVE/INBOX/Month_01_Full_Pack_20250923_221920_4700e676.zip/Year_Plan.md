# Year_Plan.md
**Проєкт:** My English Book — English for Marko  
**Автор:** Сергій Чеча (С.Ч.)  
**Версія:** v1.0  

---

## 📆 Річний план (48 тижнів)

| Місяць | Тиждень | Тема                | Слова (7 карток) |
|--------|---------|---------------------|------------------|
| Month 1 | Week 1 | Family & School     | Mom, Dad, Brother, Sister, Teacher, School, Book |
|         | Week 2 | Toys & Animals      | Ball, Car, Teddy, Dog, Cat, Bird, Fish |
|         | Week 3 | Colors & Nature     | Red, Blue, Green, Yellow, Sun, Tree, Flower |
|         | Week 4 | Home & Daily Life   | House, Room, Table, Chair, Bed, Door, Window |
| Month 2 | Week 5 | Food & Drinks       | Apple, Banana, Bread, Milk, Water, Juice, Cake |
|         | Week 6 | Body & Clothes      | Head, Hand, Foot, Shirt, Pants, Shoes, Hat |
|         | Week 7 | Actions & Play      | Run, Jump, Dance, Sing, Draw, Play, Smile |
|         | Week 8 | Seasons & Weather   | Winter, Spring, Summer, Autumn, Rain, Snow, Wind |
| Month 3 | Week 9 | Numbers & Counting  | One, Two, Three, Four, Five, Six, Seven |
|         | Week 10| Animals 2           | Horse, Cow, Sheep, Pig, Goat, Duck, Hen |
|         | Week 11| Feelings            | Happy, Sad, Angry, Scared, Tired, Excited, Calm |
|         | Week 12| Opposites           | Big/Small, Hot/Cold, Fast/Slow, Old/Young, In/Out, Up/Down, Day/Night |
| Month 4 | Week 13| Food 2 (Vegetables) | Carrot, Potato, Tomato, Onion, Cucumber, Pea, Corn |
|         | Week 14| Clothes 2           | Dress, Jacket, Boots, Skirt, Sweater, Coat, Gloves |
|         | Week 15| Actions 2           | Eat, Sleep, Read, Write, Listen, Speak, Watch |
|         | Week 16| Weather 2           | Storm, Cloud, Sky, Rainbow, Lightning, Fog, Snowflake |
| Month 5 | Week 17| Transport           | Bus, Train, Bike, Car, Plane, Ship, Subway |
|         | Week 18| Nature 2            | River, Mountain, Forest, Lake, Valley, Hill, Desert |
|         | Week 19| Daily Routine       | Wake up, Brush, Wash, Dress, Eat, Go, Sleep |
|         | Week 20| Family 2            | Grandma, Grandpa, Uncle, Aunt, Cousin, Baby, Friend |
| Month 6 | Week 21| Food 3              | Meat, Rice, Soup, Egg, Cheese, Butter, Honey |
|         | Week 22| Animals 3           | Elephant, Lion, Monkey, Tiger, Bear, Giraffe, Zebra |
|         | Week 23| Feelings 2          | Proud, Shy, Brave, Curious, Bored, Silly, Kind |
|         | Week 24| Colors 2            | Pink, Brown, Purple, White, Black, Grey, Gold |
| Month 7 | Week 25| House 2             | Kitchen, Bathroom, Garden, Garage, Roof, Floor, Wall |
|         | Week 26| Numbers 2           | Eight, Nine, Ten, Eleven, Twelve, Thirteen, Fourteen |
|         | Week 27| Body 2              | Eyes, Nose, Mouth, Ear, Hair, Teeth, Back |
|         | Week 28| Clothes 3           | Scarf, Socks, Belt, Tie, Cap, Jacket, Mittens |
| Month 8 | Week 29| School 2            | Pen, Paper, Desk, Chair, Board, Bag, Computer |
|         | Week 30| Actions 3           | Run fast, Jump high, Sit, Stand, Open, Close, Carry |
|         | Week 31| Animals 4           | Duck, Frog, Butterfly, Ant, Bee, Bird, Fish |
|         | Week 32| Nature 3            | Sea, Beach, Island, Ocean, Rock, Cliff, Cave |
| Month 9 | Week 33| Food 4              | Pizza, Pasta, Cheese, Soup, Salad, Ice cream, Sandwich |
|         | Week 34| Feelings 3          | Worried, Relaxed, Confident, Lonely, Friendly, Polite, Grateful |
|         | Week 35| Opposites 2         | Near/Far, Light/Heavy, Clean/Dirty, Full/Empty, Loud/Quiet, Tall/Short, Thick/Thin |
|         | Week 36| Transport 2         | Tram, Helicopter, Rocket, Taxi, Motorcycle, Boat, Subway |
| Month 10| Week 37| Body 3              | Legs, Arms, Fingers, Stomach, Heart, Brain, Skin |
|         | Week 38| Clothes 4           | Coat, Suit, Shoes, Sandals, Pajamas, Swimsuit, Raincoat |
|         | Week 39| Actions 4           | Cook, Build, Swim, Drive, Fly, Catch, Throw |
|         | Week 40| Seasons 2           | Spring rain, Summer sun, Autumn leaves, Winter snow, Warm/Cold, Day/Night, Morning/Evening |
| Month 11| Week 41| School 3            | Book, Notebook, Ruler, Eraser, Teacher, Lesson, Class |
|         | Week 42| Home 3              | Window, Door, Bell, Lamp, Sofa, Picture, Clock |
|         | Week 43| Numbers 3           | Fifteen, Sixteen, Seventeen, Eighteen, Nineteen, Twenty, Zero |
|         | Week 44| Nature 4            | Star, Moon, Sky, Cloud, Planet, Galaxy, Universe |
| Month 12| Week 45| Review 1            | Повторення тем (Family, Toys, Colors…) |
|         | Week 46| Review 2            | Ігри з картками, загадки |
|         | Week 47| Storytelling 1      | Казки з картками, рольові ігри |
|         | Week 48| Celebration & Archive| Підсумки року, ритуали, архівування |

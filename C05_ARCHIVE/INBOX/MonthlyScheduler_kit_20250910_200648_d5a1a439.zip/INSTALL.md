# MonthlyScheduler Kit — Інструкція встановлення

## 📦 Склад пакета
- `Register-DAO-GOGS_MAP-Monthly.ps1` — реєстрація щомісячної задачі у Планувальнику Windows.
- `Unregister-DAO-GOGS_MAP-Monthly.ps1` — видалення щомісячної задачі.
- (*використовує*) `Run-DAO-GOGS_MAP-Validation.ps1` — існуючий скрипт запуску перевірки (той самий, що у Weekly kit).

## ⚙️ Встановлення

1. Переконайтесь, що файл запуску існує:
   - `C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Run-DAO-GOGS_MAP-Validation.ps1`

2. Зареєструйте задачу (за замовчуванням — **1-го числа о 09:00**):
```powershell
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Register-DAO-GOGS_MAP-Monthly.ps1"
```

3. Налаштуйте свій день/час (рекомендовано 1–28 число):
```powershell
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Register-DAO-GOGS_MAP-Monthly.ps1" `
  -Day 1 -Hour 9 -Minute 0
```

## 🗑 Видалення задачі
```powershell
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Unregister-DAO-GOGS_MAP-Monthly.ps1"
```

## 📂 Логування
Результати валідації — в `C:\CHECHA_CORE\C03\LOG\releases_validate.log`.

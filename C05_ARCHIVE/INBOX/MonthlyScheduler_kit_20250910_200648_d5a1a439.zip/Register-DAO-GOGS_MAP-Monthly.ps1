<#
.SYNOPSIS
  Реєстрація щомісячної перевірки архівів DAO-GOGS_MAP.
.DESCRIPTION
  Створює Scheduled Task "\Checha\DAO-GOGS-MAP-Monthly", яка щомісяця у вказаний день
  о заданому часі запускає Run-DAO-GOGS_MAP-Validation.ps1.
.PARAMETER Root
  Корінь CHECHA_CORE. За замовчуванням: C:\CHECHA_CORE
.PARAMETER Day
  День місяця (1..28 рекомендується). За замовчуванням: 1
.PARAMETER Hour
  Година (0..23). За замовчуванням: 9
.PARAMETER Minute
  Хвилина (0..59). За замовчуванням: 0
#>
[CmdletBinding()]
Param(
  [string]$Root = "C:\CHECHA_CORE",
  [int]$Day = 1,
  [int]$Hour = 9,
  [int]$Minute = 0
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$taskFolder = "\Checha"
$taskName   = "DAO-GOGS-MAP-Monthly"
$fullName   = "$taskFolder\$taskName"

$runner = Join-Path $Root "C11\C11_AUTOMATION\tools\Run-DAO-GOGS_MAP-Validation.ps1"
if (-not (Test-Path $runner)) {
  throw "Не знайдено $runner. Спершу розмістіть Run-DAO-GOGS_MAP-Validation.ps1 у C11\C11_AUTOMATION\tools"
}

$pwsh = "C:\Program Files\PowerShell\7\pwsh.exe"
$arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$runner`""
$action = New-ScheduledTaskAction -Execute $pwsh -Argument $arguments

# Тригер: щомісячний у вказаний день
$time = New-Object DateTime ([DateTime]::Today.Year, [DateTime]::Today.Month, [Math]::Min([Math]::Max($Day,1),28), $Hour, $Minute, 0)
$trigger = New-ScheduledTaskTrigger -Monthly -DaysOfMonth $Day -At $time.TimeOfDay

$principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -RunLevel Highest
$settings  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable

try {
  $service = New-Object -ComObject "Schedule.Service"
  $service.Connect()
  $rootFolder = $service.GetFolder("\")
  try { $null = $service.GetFolder($taskFolder) } catch { $rootFolder.CreateFolder("Checha") | Out-Null }

  Register-ScheduledTask -TaskName $taskName -TaskPath $taskFolder -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
  Write-Host "✅ Зареєстровано задачу: $fullName (щомісяця, день $Day о $Hour:$('{0:D2}' -f $Minute))"
} catch {
  Write-Error "Помилка реєстрації задачі $fullName: $($_.Exception.Message)"
  exit 1
}

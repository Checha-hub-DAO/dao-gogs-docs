<#
.SYNOPSIS
  Видалення щомісячної задачі DAO-GOGS-MAP-Monthly.
#>
[CmdletBinding()]
Param()

$taskFolder = "\Checha"
$taskName   = "DAO-GOGS-MAP-Monthly"
$fullName   = "$taskFolder\$taskName"

try {
  Unregister-ScheduledTask -TaskName $taskName -TaskPath $taskFolder -Confirm:$false -ErrorAction Stop
  Write-Host "🗑 Видалено задачу: $fullName"
} catch {
  Write-Error "Не вдалося видалити $fullName: $($_.Exception.Message)"
  exit 1
}

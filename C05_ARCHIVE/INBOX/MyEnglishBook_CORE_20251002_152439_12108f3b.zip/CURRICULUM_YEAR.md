# CURRICULUM_YEAR — My English Book

### Q1 — Alphabet + Words
Topics: Family, Colors, Animals, Objects

### Q2 — Simple Sentences
Patterns: I am…, This is…, I like…

### Q3 — Action Language
Patterns: I can…, Let’s…

### Q4 — Mini Stories
Tales, Dialogues, Dreams and Plans

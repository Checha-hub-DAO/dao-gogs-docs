Guide: What color is the sky?
Mark: It is blue.
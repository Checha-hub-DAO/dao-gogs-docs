# Q1 — Alphabet + Words
Topics: Family, Colors, Animals, Objects
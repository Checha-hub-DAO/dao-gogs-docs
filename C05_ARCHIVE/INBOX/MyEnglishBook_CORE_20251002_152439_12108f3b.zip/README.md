# 📘 My English Book

Офіційний освітній продукт DAO-GOGS.

## Структура
- Q1 — Alphabet + Words
- Q2 — Simple Sentences
- Q3 — Action Language
- Q4 — Mini Stories

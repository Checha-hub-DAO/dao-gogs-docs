# 👨‍👩‍👧 Parent’s Starter Kit — My English Book

## Вміст
- One-Pager (короткий опис для батьків)
- Launch Guide (PDF, щоб зрозуміти як працює програма)
- Presentation (слайди для знайомства з курсом)

Цей набір створено для батьків, щоб швидко зрозуміти зміст та переваги програми My English Book.

# 🌐 Podilsk.InfoHub Live — MediaKit v1.0
**Статус:** Active  
**Версія:** v1.0  
**Автор:** DAO-GOGS • С.Ч.  

---

## 📘 Що таке InfoHub Live?
Podilsk.InfoHub Live — це жива інформаційна платформа для громади.  
Мета — зробити життя міста прозорим, зручним і зрозумілим.  

---

## 📂 Склад MediaKit v1.0
- 📄 README_INFOHUB_LIVE.md  
- 🖼️ Podilsk_InfoHub_Live_Infographic.png  
- 📑 Podilsk_InfoHub_Live_Infographic.pdf  
- 🎞️ Podilsk_InfoHub_Live_Presentation.pdf  
- 🖼️ Слайди (PNG):  
  - Podilsk_InfoHub_Live_Slide_1.png  
  - Podilsk_InfoHub_Live_Slide_2.png  
  - Podilsk_InfoHub_Live_Slide_3.png  
  - Podilsk_InfoHub_Live_Slide_4.png  

---

## 🎯 Використання
- **Соцмережі (Telegram / Facebook):** PNG-слайди + інфографіка.  
- **Презентації:** PDF-презентація.  
- **GitBook:** README та інтегрований MediaKit.  

---

💙💛 Podilsk.InfoHub Live — твоя точка входу в життя міста.  

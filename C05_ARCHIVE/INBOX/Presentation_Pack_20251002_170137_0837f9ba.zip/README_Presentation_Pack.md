# 📊 Presentation Pack — My English Book

## Вміст
- Presentation (слайди PDF)
- One-Pager (стислий опис PDF)
- Cover (обкладинка PNG)

Цей пакет призначений для публічного представлення курсу My English Book.

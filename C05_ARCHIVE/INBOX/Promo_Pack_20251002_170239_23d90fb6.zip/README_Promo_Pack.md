# 📢 Promo Pack — My English Book

## Вміст
- Banners (PNG, square + stories)
- Posts (MD + DOCX)
- Promo One-Liner

Готовий пакет для соцмережевого запуску.

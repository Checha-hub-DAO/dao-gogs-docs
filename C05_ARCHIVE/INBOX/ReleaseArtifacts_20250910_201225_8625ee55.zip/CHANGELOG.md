# Changelog
Усі значні зміни цього проєкту документуються у цьому файлі.

Формат базується на [Keep a Changelog](https://keepachangelog.com/uk/1.0.0/),
і цей проєкт дотримується [Semantic Versioning](https://semver.org/).

## [Unreleased]
- Планується інтеграція з `Validate-Releases.ps1` як централізованим модулем.
- Можливе додавання email/Telegram-сповіщень про результати перевірки.

## [1.0.0] - 2025-09-10
### Додано
- **Scheduler Suite v1.0** — стартовий реліз.
- `WeeklyScheduler_kit.zip`:
  - `Register-DAO-GOGS_MAP-Weekly.ps1` — реєстрація задачі.
  - `Run-DAO-GOGS_MAP-Validation.ps1` — запуск перевірки.
  - `Unregister-DAO-GOGS_MAP-Weekly.ps1` — видалення задачі.
  - `INSTALL.md` — інструкція.
- `MonthlyScheduler_kit.zip`:
  - `Register-DAO-GOGS_MAP-Monthly.ps1` — реєстрація задачі.
  - `Unregister-DAO-GOGS_MAP-Monthly.ps1` — видалення задачі.
  - `INSTALL.md` — інструкція.
  - (*використовує спільний* `Run-DAO-GOGS_MAP-Validation.ps1`).
- `SchedulerSuite_v1.0.zip`:
  - `Scheduler_Suite.png` — схема у PNG.
  - `Scheduler_Suite.svg` — схема у SVG.
  - `Scheduler_Suite.md` — документація.

---
© DAO-GOGS | С.Ч.

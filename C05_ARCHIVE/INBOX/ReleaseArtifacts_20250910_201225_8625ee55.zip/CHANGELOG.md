# Changelog
Усі значні зміни цього проєкту документуються у цьому файлі.

Формат базується на [Keep a Changelog](https://keepachangelog.com/uk/1.0.0/),
і цей проєкт дотримується [Semantic Versioning](https://semver.org/).

## [Unreleased]
- Планується інтеграція з `Validate-Releases.ps1` як централізованим модулем.
- Можливе додавання email/Telegram-сповіщень про результати перевірки.

## [1.0.0] - 2025-09-10
### Додано
- **Scheduler Suite v1.0** — стартовий реліз.
- `WeeklyScheduler_kit.zip`:
  - `Register-DAO-GOGS_MAP-Weekly.ps1` — реєстрація задачі.
  - `Run-DAO-GOGS_MAP-Validation.ps1` — запуск перевірки.
  - `Unregister-DAO-GOGS_MAP-Weekly.ps1` — видалення задачі.
  - `INSTALL.md` — інструкція.
- `MonthlyScheduler_kit.zip`:
  - `Register-DAO-GOGS_MAP-Monthly.ps1` — реєстрація задачі.
  - `Unregister-DAO-GOGS_MAP-Monthly.ps1` — видалення задачі.
  - `INSTALL.md` — інструкція.
  - (*використовує спільний* `Run-DAO-GOGS_MAP-Validation.ps1`).
- `SchedulerSuite_v1.0.zip`:
  - `Scheduler_Suite.png` — схема у PNG.
  - `Scheduler_Suite.svg` — схема у SVG.
  - `Scheduler_Suite.md` — документація.


## 📊 Digest — v1.0
| 📄 Файл / Архів | 📝 Опис | ✅ Статус | ⚙️ Використання |
|-----------------|---------|-----------|-----------------|
| **DAO-GOGS_MAP_v1.0.zip** | Повний пакет карти DAO-GOGS (PNG, легенда, README, CHECKSUMS, GitBook версія, Scheduler Suite) | Готово v1.0 | Архів зберігається у `C12\Vault\ARCHIVE`, використовується як основний реліз карти |
| **SchedulerSuite_v1.0.zip** | Схеми (PNG + SVG) та документація (`Scheduler_Suite.md`) | Готово v1.0 | Візуалізація та документація для GitBook/презентацій |
| **WeeklyScheduler_kit.zip** | Скрипти: Register / Unregister / Run для щотижневої перевірки + INSTALL.md | Готово v1.0 | Розмістити у `C11\C11_AUTOMATION\tools`, запускається щонеділі о 09:00 |
| **MonthlyScheduler_kit.zip** | Скрипти: Register / Unregister для щомісячної перевірки + INSTALL.md | Готово v1.0 | Розмістити у `C11\C11_AUTOMATION\tools`, запускається 1-го числа о 09:00 |
| **ReleaseArtifacts.zip** | Повний набір для GitHub Release: SchedulerSuite, Weekly, Monthly, CHANGELOG, RELNOTES | Готово v1.0 | Завантажити у GitHub Release (Tag v1.0) |
| **CHANGELOG.md** | Історія змін у форматі *Keep a Changelog* | Готово v1.0 | Використовувати для відстеження версійності |
| **RELNOTES.md** | Повний опис релізу (GitHub Release body) | Готово v1.0 | Копіювати в тіло релізу на GitHub |
| **RELNOTES_SOCIAL.md** | Короткі нотатки для соцмереж/Telegram | Готово v1.0 | Використовувати для публічних анонсів |
| **Scheduler_Suite.md** | Зведена документація (опис Weekly + Monthly, логування, інсталяція) | Готово v1.0 | Включити у GitBook як технічну сторінку |
| **Scheduler_Suite.png** | Візуальна схема Suite (PNG) | Готово v1.0 | Для звітів і статичних публікацій |
| **Scheduler_Suite.svg** | Масштабована схема Suite (SVG) | Готово v1.0 | Для GitBook / інтерактивних публікацій |
| **Постер (PNG)** | Візуал для соцмереж: реліз Scheduler Suite v1.0 | Готово v1.0 | Для Telegram / Facebook / презентацій |

---
© DAO-GOGS | С.Ч.

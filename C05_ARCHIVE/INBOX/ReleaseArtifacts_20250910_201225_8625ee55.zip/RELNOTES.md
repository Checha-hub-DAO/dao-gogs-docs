# Release Notes — Scheduler Suite v1.0

**Дата релізу:** 2025-09-10  
**Автор:** С.Ч.  

---

## 🔎 Огляд
Scheduler Suite v1.0 — це перший стабільний реліз автоматизованої системи перевірки цілісності архівів **DAO-GOGS_MAP**.  
Він включає щотижневі та щомісячні перевірки, логування та готові інструкції для інтеграції у середовище `CHECHA_CORE`.

---

## 🚀 Основні можливості
- **Автоматичні перевірки архівів** `DAO-GOGS_MAP_v*.zip`:
  - WeeklyScheduler (неділя 09:00 за замовчуванням).
  - MonthlyScheduler (1-го числа 09:00).

- **Контроль цілісності через SHA256** (`CHECKSUMS.txt`).

- **Централізоване логування** у `C03\LOG\releases_validate.log`.

- **Візуальні схеми** (PNG + SVG) для GitBook / презентацій.

- **Документація у форматі Markdown**:
  - Scheduler_Suite.md (зведена).
  - INSTALL.md для кожного комплекту.

---

## 📦 Файли у релізі
- `SchedulerSuite_v1.0.zip` — документація + схеми (PNG, SVG, MD).  
- `WeeklyScheduler_kit.zip` — комплект для щотижневої перевірки.  
- `MonthlyScheduler_kit.zip` — комплект для щомісячної перевірки.  
- `CHANGELOG.md` — історія змін.

---

## ⚙️ Встановлення
1. Розпакувати потрібний пакет (`WeeklyScheduler_kit.zip` або `MonthlyScheduler_kit.zip`).  
2. Скопіювати скрипти у `C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\`.  
3. Виконати команду реєстрації задачі (weekly або monthly).  
4. Перевірити лог у: `C:\CHECHA_CORE\C03\LOG\releases_validate.log`.

---

## 🔑 Важливе
- Weekly та Monthly використовують один спільний валідатор: `Run-DAO-GOGS_MAP-Validation.ps1`.  
- Рекомендовано протестувати обидва режими після встановлення.  
- Наступна версія планує інтеграцію зі сповіщеннями (email/Telegram).  

---

© DAO-GOGS | С.Ч.

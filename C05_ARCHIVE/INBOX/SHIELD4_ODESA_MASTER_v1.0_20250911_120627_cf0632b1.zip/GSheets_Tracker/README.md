# GSheets Tracker — SHIELD-4 ODESA

Це Google Sheets-версія трекера прогресу.
Вміст:
- Checklist.csv
- Dashboard.csv
- AppsScript_Code.gs
- README.md (інструкції)

Як розгорнути: див. README.md або коротко — імпортуй CSV у новий Google Sheet, встав скрипт в Apps Script і виконай `setup()`.
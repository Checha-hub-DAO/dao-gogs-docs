```
SHIELD4_ODESA_MASTER_v1.0/
├── DAO-INIT-003_SHIELD4_ODESA_FULL_v1.0.zip
├── G23_Odesa
│   ├── DAO-G23-YouthActivation_SHIELD4_ODESA_v1.0.zip
│   ├── DATA
│   │   └── map_points.csv
│   ├── FORMS
│   │   ├── form_feedback_event.md
│   │   └── form_student_join.md
│   └── README.md
├── GSheets_Tracker
│   ├── AppsScript_Code.gs
│   ├── Checklist.csv
│   ├── Dashboard.csv
│   ├── README.md
│   └── SHIELD4_GSheets_Tracker_v1.0.zip
├── README.md
├── SHIELD4_GForm_and_Bot_Template_UA.txt
├── SHIELD4_Message_Templates_UA.txt
├── chat_scenarios.ods
├── intake.ods
├── md
│   ├── SHIELD4_Role_A_Scout_G43.md
│   ├── SHIELD4_Role_B_MiniAnalyst_G43.md
│   ├── SHIELD4_Role_C_MediaHelper_G09.md
│   ├── SHIELD4_Role_D_Host_G28.md
│   └── SHIELD4_Role_E_RouteCoordinator_G11.md
├── tools
│   ├── README_tools.md
│   ├── SHIELD4_Starter.bat
│   └── SHIELD4_Starter.ps1
├── активації студентів
│   ├── SHIELD4_Ambassador_Guide_UA.md
│   ├── SHIELD4_Code_of_Conduct_UA.md
│   ├── SHIELD4_OnePager_UA.md
│   ├── SHIELD4_Student_Activation_Odesa.xlsx
│   ├── SHIELD4_Student_Activation_Pack_UA.zip
│   ├── SHIELD4_Student_Messages_UA.txt
│   ├── SHIELD4_Student_Playbook_UA.md
│   └── SHIELD4_Students_GForm_template_UA.csv
└── зіпи
    ├── CHECHA_LOGICAL_2025-08-18.zip
    ├── G23_Brand_v1_1_SVGs.tar.gz
    ├── G23_Brand_v1_1_SVGs.zip
    ├── G23_DAO_Badges_Full.zip
    ├── G23_DAO_Stickers_WEBP.zip
    ├── G23_DAO_Visual_Identity_Extras.zip
    ├── G23_DAO_Visual_Identity_Pack.zip
    ├── G23_Odesa_Partnership_Kit.zip
    ├── G23_Social_Templates.zip
    ├── G23_ThreeStep_StarterPack.zip
    ├── G23_Youth_Activation_Integration_Pack_UA.zip
    ├── SHIELD4_Privoz_3km_Starter_kit.zip
    ├── SHIELD4_Privoz_3km_Starter_kit_v2.zip
    └── SHIELD4_Recruit_Onboarding_LogicalPack_UA.zip
```
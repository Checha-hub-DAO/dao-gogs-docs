# 🛡️ SHIELD-4 ODESA — Master Package

Цей архів містить повний набір матеріалів для запуску та розвитку ініціативи **«Щит-4 Одеса»**.

---

## 📑 Структура

### 1. Ядро
- `DAO-INIT-003_SHIELD4_ODESA_FULL_v1.0.zip` — головний стартовий пакет.

### 2. Студентські активації
- `активації студентів/SHIELD4_Ambassador_Guide_UA.md` — гід для амбасадора.
- `активації студентів/SHIELD4_Code_of_Conduct_UA.md` — кодекс поведінки.
- `активації студентів/SHIELD4_OnePager_UA.md` — стислий опис ініціативи.
- `активації студентів/SHIELD4_Student_Playbook_UA.md` — покроковий сценарій.
- `активації студентів/SHIELD4_Student_Activation_Odesa.xlsx` — таблиця організації.
- `активації студентів/SHIELD4_Students_GForm_template_UA.csv` — шаблон Google-форми.
- `активації студентів/SHIELD4_Student_Activation_Pack_UA.zip` — повний пакет для студентів.
- `активації студентів/SHIELD4_Student_Messages_UA.txt` — готові повідомлення.

### 3. Ролі учасників
- `md/SHIELD4_Role_A_Scout_G43.md`
- `md/SHIELD4_Role_B_MiniAnalyst_G43.md`
- `md/SHIELD4_Role_C_MediaHelper_G09.md`
- `md/SHIELD4_Role_D_Host_G28.md`
- `md/SHIELD4_Role_E_RouteCoordinator_G11.md`

### 4. Дані та сценарії
- `chat_scenarios.ods` — сценарії для чатів.
- `intake.ods` — база для збору учасників.
- `G23_Odesa/DATA/map_points.csv` — координати точок.

### 5. Візуали та бренд
- `зіпи/G23_Brand_v1_1_SVGs.zip`  
- `зіпи/G23_Brand_v1_1_SVGs.tar.gz`  

### 6. Технічні шаблони
- `SHIELD4_GForm_and_Bot_Template_UA.txt`
- `SHIELD4_Message_Templates_UA.txt`

---

## 🚀 Використання
1. Почати з **ядра (DAO-INIT пакет)**.  
2. Налаштувати **студентські активації** через готові файли та пакети.  
3. Призначити ролі учасникам за документами в папці `md`.  
4. Використати **дані (intake, map_points)** для організації роботи.  
5. Використати **бренд та візуали** для публічної комунікації.  
6. Інтегрувати форми та бота через `SHIELD4_GForm_and_Bot_Template_UA.txt`.  

---

✍️ Автор: Сергій Чеча (С.Ч.)  
Версія пакету: **v1.0**  

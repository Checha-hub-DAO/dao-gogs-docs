# 🛠️ SHIELD4 Tools — Інструкція

У цій папці зберігаються стартові скрипти для швидкого розгортання структури **SHIELD-4 ODESA** у локальному середовищі.

## 📜 Скрипти

### 1. SHIELD4_Starter.ps1 (PowerShell)
- Використання: Windows 10/11, PowerShell 7+
- Запуск: 
  1. Клацніть правою кнопкою на файлі → "Run with PowerShell", або
  2. Відкрийте PowerShell і виконайте:
     ```powershell
     ./SHIELD4_Starter.ps1 -TargetRoot "C:\CHECHA_CORE\C08_COORD\SHIELD4_ODESA"
     ```
- За замовчуванням створює папки у `C:\CHECHA_CORE\C08_COORD\SHIELD4_ODESA`.

### 2. SHIELD4_Starter.bat (Batch)
- Використання: Windows CMD
- Запуск: подвійний клік по файлу або:
  ```cmd
  SHIELD4_Starter.bat
  ```
- Створює аналогічну структуру у `C:\CHECHA_CORE\C08_COORD\SHIELD4_ODESA`.

## 📂 Структура, яку створюють скрипти
- CORE  
- ACTIVATION  
- ROLES  
- DATA  
- VISUALS  
- TEMPLATES  
- TRACKERS  

## ⚠️ Примітка
- Якщо розпакований MASTER-архів знаходиться поруч, скрипт також скопіює `README.md` та `SHIELD4_ODESA_STRUCTURE.md` у папку CORE.
- Переконайтесь, що маєте права доступу на створення папок у `C:\CHECHA_CORE`.

✍️ Автор: Сергій Чеча (С.Ч.)

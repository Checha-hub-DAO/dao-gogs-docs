# ==========================
# SHIELD-4 ODESA Starter Script
# Версія: v1.0
# ==========================

param(
    [string]$TargetRoot = "C:\CHECHA_CORE\C08_COORD\SHIELD4_ODESA"
)

Write-Host ">>> Створюю структуру папок у $TargetRoot..."

# Створюємо основні папки
$folders = @(
    "CORE",
    "ACTIVATION",
    "ROLES",
    "DATA",
    "VISUALS",
    "TEMPLATES",
    "TRACKERS"
)

foreach ($f in $folders) {
    $path = Join-Path $TargetRoot $f
    if (-not (Test-Path $path)) {
        New-Item -ItemType Directory -Path $path | Out-Null
        Write-Host " + Папка створена: $f"
    } else {
        Write-Host " - Папка існує: $f"
    }
}

# Копіюємо основні файли з MASTER архіву (якщо розпаковано поруч)
$source = Join-Path (Get-Location) "SHIELD4_ODESA_MASTER_v1.0"
if (Test-Path $source) {
    Write-Host ">>> Копіюю стартові файли..."
    Copy-Item -Path "$source\README.md" -Destination (Join-Path $TargetRoot "CORE\") -Force -ErrorAction SilentlyContinue
    Copy-Item -Path "$source\SHIELD4_ODESA_STRUCTURE.md" -Destination (Join-Path $TargetRoot "CORE\") -Force -ErrorAction SilentlyContinue
} else {
    Write-Host "⚠️ Папку MASTER не знайдено. Скопіюй архів сюди та розпакуй."
}

Write-Host ">>> Стартова структура SHIELD-4 готова."

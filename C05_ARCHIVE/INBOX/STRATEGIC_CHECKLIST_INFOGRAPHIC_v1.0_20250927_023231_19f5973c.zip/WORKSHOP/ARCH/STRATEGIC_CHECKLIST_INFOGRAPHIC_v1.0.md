# ✅ STRATEGIC_CHECKLIST_INFOGRAPHIC v1.0

*Mermaid-інфографіка-чекліст у вигляді «таблиці» для GitBook. Позначай виконання символами ☐/☑.*

---

## 📊 Mermaid (table-style)

```mermaid
flowchart LR
    %% Legend
    L[Legend:\n☐ = todo\n☑ = done]:::legend

    %% Column headers
    subgraph C0[Базові перевірки]
    A1[Стратегічний звіт (тиждень): ☐]:::cell
    A2[Оновлено C03_LOG: ☐]:::cell
    A3[ARTIFACT_ID синхронізовано: ☐]:::cell
    A4[STRATEGIC_OVERVIEW оновлено: ☐]:::cell
    A5[Ритми (доба→тиждень) витримано: ☐]:::cell
    end

    subgraph C1[G-01..G-04]
    B1[G-01 GUIDES_CORE: ☐]:::cell
    B2[G-02 MEDIA_PIPE: ☐]:::cell
    B3[G-03 KNOWLEDGE_HOUSE: ☐]:::cell
    B4[G-04 NATIONAL_LIBRARY: ☐]:::cell
    end

    subgraph C2[G-05..G-08]
    C1a[G-05 RESILIENCE_INSTITUTE: ☐]:::cell
    C2a[G-06 ODESSA_SHIELD: ☐]:::cell
    C3a[G-07 ANALYTICS_CORE: ☐]:::cell
    C4a[G-08 ARCHIVE_GATE: ☐]:::cell
    end

    %% Arrange rows visually using invisible connectors
    L --- A1 --- B1 --- C1a
    L --- A2 --- B2 --- C2a
    L --- A3 --- B3 --- C3a
    L --- A4 --- B4 --- C4a
    L --- A5

    classDef legend fill:#222,stroke:#999,color:#fff;
    classDef cell fill:#111,stroke:#0f0,color:#fff
```

---

## ✍️ Як користуватись
- Замінюй **☐** на **☑** у відповідних клітинках після виконання.
- За потреби додай KPI поруч: `G-02 MEDIA_PIPE: ☑ (постів=3, ER=6.2%)`.
- Для місячного циклу — дублюй блок схеми і позначай **(Month)** у заголовку.
```

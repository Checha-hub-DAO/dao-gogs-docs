# Strategic Report — Form → PDF (Apps Script)

## Що це
Скрипт Google Apps Script, який на подію "On form submit" бере останню відповідь з Google Sheet, заповнює Docs-шаблон плейсхолдерами та зберігає PDF у Drive (і опційно надсилає на e-mail).

## Кроки
1. Відкрий Google Sheet з відповідями → Extensions → Apps Script → встав `apps_script_form_to_pdf.gs`.
2. У CONFIG задай:
   - SHEET_NAME (назва аркуша з відповідями),
   - TEMPLATE_DOC_ID (ID Docs-шаблону),
   - OUTPUT_FOLDER_ID (ID папки для PDF),
   - EMAIL_TO (необов’язково).
3. У Docs-шаблоні розмісти плейсхолдери: `{{Дата звіту}}`, `{{Тип звіту}}`, `{{G-01 GUIDES_CORE}}`, ... (мають відповідати CONFIG.FIELD_MAP).
4. Додай тригер: Triggers → Add → run: `onFormSubmit` → From spreadsheet → On form submit.
5. Відправ тестову відповідь у Формі — PDF з’явиться у вказаній папці.

## Поради
- Якщо назва аркуша не англійська (наприклад, «Відповіді форми 1»), онови `SHEET_NAME`.
- Для пакової генерації по всіх рядках додай функцію, що ітерує `getLastRow()` і викликає `fillTemplate_`/`exportToPdf_` для кожного.

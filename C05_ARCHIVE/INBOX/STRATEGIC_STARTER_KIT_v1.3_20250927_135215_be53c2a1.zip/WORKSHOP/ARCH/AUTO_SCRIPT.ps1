<#
.SYNOPSIS
  AUTO_SCRIPT.ps1 — швидке створення щотижневих і щомісячних звітів з шаблонів.
.DESCRIPTION
  Скрипт генерує файли на основі:
    - WORKSHOP\ARCH\WEEK_REPORT_TEMPLATE.md
    - WORKSHOP\ARCH\MONTH_SUMMARY_TEMPLATE.md
  та автоматично підставляє період і службову шапку.

.PARAMETER Mode
  "Week" або "Month". Визначає тип звіту.
.PARAMETER Date
  Опорна дата (за замовчуванням: сьогодні). Для Week рахується ISO-тиждень, для Month — місяць/рік.
.PARAMETER OutRoot
  Каталог для збереження результатів (за замовчуванням: ..\REPORTS).
.EXAMPLE
  # Створити тижневий звіт за поточним тижнем
  .\AUTO_SCRIPT.ps1 -Mode Week
.EXAMPLE
  # Створити тижневий звіт за конкретну дату
  .\AUTO_SCRIPT.ps1 -Mode Week -Date "2025-09-27"
.EXAMPLE
  # Створити місячний звіт за серпень 2025
  .\AUTO_SCRIPT.ps1 -Mode Month -Date "2025-08-01"
#>

param(
  [Parameter(Mandatory=$true)]
  [ValidateSet("Week","Month")]
  [string]$Mode,

  [datetime]$Date = (Get-Date),

  [string]$OutRoot = (Join-Path (Split-Path -Parent $PSScriptRoot) "REPORTS")
)

function Get-IsoWeek {
  param([datetime]$d)
  $ci = [System.Globalization.CultureInfo]::InvariantCulture
  $cal = $ci.Calendar
  $rule = [System.Globalization.CalendarWeekRule]::FirstFourDayWeek
  $dow  = [System.DayOfWeek]::Monday
  return $cal.GetWeekOfYear($d, $rule, $dow)
}

# Визначаємо шляхи до шаблонів відносно скрипта
$root = Split-Path -Parent $PSScriptRoot
$arch = Join-Path $root "ARCH"
$tplWeek  = Join-Path $arch "WEEK_REPORT_TEMPLATE.md"
$tplMonth = Join-Path $arch "MONTH_SUMMARY_TEMPLATE.md"

if ($Mode -eq "Week") {
  $isoWeek = Get-IsoWeek -d $Date
  $year = $Date.Year
  $outDir = Join-Path $OutRoot (Join-Path $year ("W{0:d2}" -f $isoWeek))
  New-Item -ItemType Directory -Force -Path $outDir | Out-Null
  $fileName = "WEEK_REPORT_{0}-W{1:d2}.md" -f $year, $isoWeek
  $outPath = Join-Path $outDir $fileName

  if (!(Test-Path $tplWeek)) { throw "Template not found: $tplWeek" }
  $body = Get-Content -LiteralPath $tplWeek -Raw -Encoding UTF8

  $monday = (Get-Date $Date).Date
  while ($monday.DayOfWeek -ne 'Monday') { $monday = $monday.AddDays(-1) }
  $sunday = $monday.AddDays(6)

  $header = @"
# 📅 Щотижневий звіт — $($monday.ToString('yyyy-MM-dd')) → $($sunday.ToString('yyyy-MM-dd')) (W$("{0:d2}" -f $isoWeek), $year)

Автор: С.Ч.  
Згенеровано: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")  

---

"@

  ($header + $body) | Out-File -LiteralPath $outPath -Encoding UTF8 -Force
  Write-Host "Created: $outPath"
  exit 0
}

if ($Mode -eq "Month") {
  $y = $Date.Year
  $m = $Date.Month
  $outDir = Join-Path $OutRoot (Join-Path $y ("M{0:d2}" -f $m))
  New-Item -ItemType Directory -Force -Path $outDir | Out-Null
  $fileName = "MONTH_SUMMARY_{0}-M{1:d2}.md" -f $y, $m
  $outPath = Join-Path $outDir $fileName

  if (!(Test-Path $tplMonth)) { throw "Template not found: $tplMonth" }
  $body = Get-Content -LiteralPath $tplMonth -Raw -Encoding UTF8

  $first = Get-Date -Year $y -Month $m -Day 1
  $last  = $first.AddMonths(1).AddDays(-1)

  $header = @"
# 📆 Щомісячний підсумок — $($first.ToString('yyyy-MM'))  ($($first.ToString('yyyy-MM-dd')) → $($last.ToString('yyyy-MM-dd')))

Автор: С.Ч.  
Згенеровано: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")  

---

"@

  ($header + $body) | Out-File -LiteralPath $outPath -Encoding UTF8 -Force
  Write-Host "Created: $outPath"
  exit 0
}

# AUTO_SCRIPT.ps1 — генератор звітів

## Що робить
- Створює **щотижневий** (`Week`) або **щомісячний** (`Month`) звіт із шаблонів:
  - `WORKSHOP/ARCH/WEEK_REPORT_TEMPLATE.md`
  - `WORKSHOP/ARCH/MONTH_SUMMARY_TEMPLATE.md`

## Використання
```powershell
# Перейдіть у WORKSHOP\ARCH
cd WORKSHOP\ARCH

# Тижневий звіт (поточний тиждень)
.\AUTO_SCRIPT.ps1 -Mode Week

# Тижневий звіт за конкретну дату
.\AUTO_SCRIPT.ps1 -Mode Week -Date "2025-09-27"

# Місячний підсумок (поточний місяць)
.\AUTO_SCRIPT.ps1 -Mode Month

# Місячний підсумок за конкретний місяць
.\AUTO_SCRIPT.ps1 -Mode Month -Date "2025-08-01"
```

## Куди зберігає
- У каталог `REPORTS\<YYYY>\W<WW>` або `REPORTS\<YYYY>\M<MM>` поряд із `WORKSHOP`.

## Примітки
- Скрипт сам додасть службову шапку: період, автора, час генерації.
- Для ISO-тижня використовується правило **FirstFourDayWeek** і понеділок як перший день тижня.

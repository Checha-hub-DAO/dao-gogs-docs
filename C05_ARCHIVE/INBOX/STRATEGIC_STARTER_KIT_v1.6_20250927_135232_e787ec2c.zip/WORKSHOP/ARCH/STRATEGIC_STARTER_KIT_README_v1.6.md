# STRATEGIC_STARTER_KIT v1.6

Дата збирання: 2025-09-27 05:41:23

**Що нового у v1.6**
- Додано `YEAR_SUMMARY_TEMPLATE.md` — для річного стратегічного аналізу.

**Вміст (основне):**
- FRAME / RHYTHM / REPORT_TEMPLATE / OVERVIEW
- WEEK_REPORT_TEMPLATE (з KPI + вузлові)
- MONTH_SUMMARY_TEMPLATE (з KPI)
- QUARTER_SUMMARY_TEMPLATE
- YEAR_SUMMARY_TEMPLATE (новий)
- AUTO_SCRIPT.ps1 + README

**Порада:**
- Використовуй `YEAR_SUMMARY_TEMPLATE.md` для великої річної сесії.
- Порівнюй результати року з квартальними та місячними звітами.
- Визначай стратегічні напрями на наступний рік.

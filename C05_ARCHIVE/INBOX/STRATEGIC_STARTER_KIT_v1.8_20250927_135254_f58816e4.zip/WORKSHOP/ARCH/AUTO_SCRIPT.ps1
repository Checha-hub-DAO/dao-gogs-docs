<#
.SYNOPSIS
  AUTO_SCRIPT.ps1 — швидке створення звітів з шаблонів (Week/Month/Quarter/Year).
.DESCRIPTION
  Генерує файли на основі шаблонів у WORKSHOP\ARCH:
    - WEEK_REPORT_TEMPLATE.md
    - MONTH_SUMMARY_TEMPLATE.md
    - QUARTER_SUMMARY_TEMPLATE.md
    - YEAR_SUMMARY_TEMPLATE.md
  Автоматично підставляє період і службову шапку.

  *За замовчуванням параметр -Date = сьогодні.*
  Це означає:
    - Week: ISO-тиждень дати сьогодні.
    - Month: місяць дати сьогодні.
    - Quarter: квартал дати сьогодні.
    - Year: рік дати сьогодні.

.PARAMETER Mode
  "Week", "Month", "Quarter", або "Year".
.PARAMETER Date
  Опорна дата (за замовчуванням: сьогодні).
.PARAMETER OutRoot
  Каталог для збереження результатів (за замовчуванням: ..\REPORTS).
.EXAMPLE
  .\AUTO_SCRIPT.ps1 -Mode Week
.EXAMPLE
  .\AUTO_SCRIPT.ps1 -Mode Month
.EXAMPLE
  .\AUTO_SCRIPT.ps1 -Mode Quarter
.EXAMPLE
  .\AUTO_SCRIPT.ps1 -Mode Year
#>

param(
  [Parameter(Mandatory=$true)]
  [ValidateSet("Week","Month","Quarter","Year")]
  [string]$Mode,

  [datetime]$Date = (Get-Date),

  [string]$OutRoot = (Join-Path (Split-Path -Parent $PSScriptRoot) "REPORTS")
)

function Get-IsoWeek {
  param([datetime]$d)
  $ci = [System.Globalization.CultureInfo]::InvariantCulture
  $cal = $ci.Calendar
  $rule = [System.Globalization.CalendarWeekRule]::FirstFourDayWeek
  $dow  = [System.DayOfWeek]::Monday
  return $cal.GetWeekOfYear($d, $rule, $dow)
}

function Get-QuarterInfo {
  param([datetime]$d)
  $q = [math]::Ceiling($d.Month / 3.0)
  $qStartMonth = (3 * ($q - 1)) + 1
  $start = Get-Date -Year $d.Year -Month $qStartMonth -Day 1
  $end = $start.AddMonths(3).AddDays(-1)
  return @{ Q = $q; Start = $start; End = $end }
}

# Визначаємо шляхи до шаблонів
$root = Split-Path -Parent $PSScriptRoot
$arch = Join-Path $root "ARCH"
$tplWeek    = Join-Path $arch "WEEK_REPORT_TEMPLATE.md"
$tplMonth   = Join-Path $arch "MONTH_SUMMARY_TEMPLATE.md"
$tplQuarter = Join-Path $arch "QUARTER_SUMMARY_TEMPLATE.md"
$tplYear    = Join-Path $arch "YEAR_SUMMARY_TEMPLATE.md"

switch ($Mode) {
  "Week" {
    $isoWeek = Get-IsoWeek -d $Date
    $year = $Date.Year
    $outDir = Join-Path $OutRoot (Join-Path $year ("W{0:d2}" -f $isoWeek))
    New-Item -ItemType Directory -Force -Path $outDir | Out-Null
    $fileName = "WEEK_REPORT_{0}-W{1:d2}.md" -f $year, $isoWeek
    $outPath = Join-Path $outDir $fileName

    if (!(Test-Path $tplWeek)) { throw "Template not found: $tplWeek" }
    $body = Get-Content -LiteralPath $tplWeek -Raw -Encoding UTF8

    $monday = (Get-Date $Date).Date
    while ($monday.DayOfWeek -ne 'Monday') { $monday = $monday.AddDays(-1) }
    $sunday = $monday.AddDays(6)

    $header = @"
# 📅 Щотижневий звіт — $($monday.ToString('yyyy-MM-dd')) → $($sunday.ToString('yyyy-MM-dd')) (W$("{0:d2}" -f $isoWeek), $year)

Автор: С.Ч.  
Згенеровано: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")  

---

"@

    ($header + $body) | Out-File -LiteralPath $outPath -Encoding UTF8 -Force
    Write-Host "Created: $outPath"
    break
  }

  "Month" {
    $y = $Date.Year
    $m = $Date.Month
    $outDir = Join-Path $OutRoot (Join-Path $y ("M{0:d2}" -f $m))
    New-Item -ItemType Directory -Force -Path $outDir | Out-Null
    $fileName = "MONTH_SUMMARY_{0}-M{1:d2}.md" -f $y, $m
    $outPath = Join-Path $outDir $fileName

    if (!(Test-Path $tplMonth)) { throw "Template not found: $tplMonth" }
    $body = Get-Content -LiteralPath $tplMonth -Raw -Encoding UTF8

    $first = Get-Date -Year $y -Month $m -Day 1
    $last  = $first.AddMonths(1).AddDays(-1)

    $header = @"
# 📆 Щомісячний підсумок — $($first.ToString('yyyy-MM'))  ($($first.ToString('yyyy-MM-dd')) → $($last.ToString('yyyy-MM-dd')))

Автор: С.Ч.  
Згенеровано: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")  

---

"@

    ($header + $body) | Out-File -LiteralPath $outPath -Encoding UTF8 -Force
    Write-Host "Created: $outPath"
    break
  }

  "Quarter" {
    $qi = Get-QuarterInfo -d $Date
    $y = $Date.Year
    $q = $qi.Q
    $qs = $qi.Start
    $qe = $qi.End

    $outDir = Join-Path $OutRoot (Join-Path $y ("Q{0}" -f $q))
    New-Item -ItemType Directory -Force -Path $outDir | Out-Null
    $fileName = "QUARTER_SUMMARY_{0}-Q{1}.md" -f $y, $q
    $outPath = Join-Path $outDir $fileName

    if (!(Test-Path $tplQuarter)) { throw "Template not found: $tplQuarter" }
    $body = Get-Content -LiteralPath $tplQuarter -Raw -Encoding UTF8

    $header = @"
# 📊 Квартальний підсумок — $y-Q$q  ($($qs.ToString('yyyy-MM-dd')) → $($qe.ToString('yyyy-MM-dd')))

Автор: С.Ч.  
Згенеровано: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")  

---

"@

    ($header + $body) | Out-File -LiteralPath $outPath -Encoding UTF8 -Force
    Write-Host "Created: $outPath"
    break
  }

  "Year" {
    $y = $Date.Year
    $outDir = Join-Path $OutRoot (Join-Path $y "YEAR")
    New-Item -ItemType Directory -Force -Path $outDir | Out-Null
    $fileName = "YEAR_SUMMARY_{0}.md" -f $y
    $outPath = Join-Path $outDir $fileName

    if (!(Test-Path $tplYear)) { throw "Template not found: $tplYear" }
    $body = Get-Content -LiteralPath $tplYear -Raw -Encoding UTF8

    $first = Get-Date -Year $y -Month 1 -Day 1
    $last  = Get-Date -Year $y -Month 12 -Day 31

    $header = @"
# 🗓️ Річний підсумок — $y  ($($first.ToString('yyyy-MM-dd')) → $($last.ToString('yyyy-MM-dd')))

Автор: С.Ч.  
Згенеровано: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")  

---

"@

    ($header + $body) | Out-File -LiteralPath $outPath -Encoding UTF8 -Force
    Write-Host "Created: $outPath"
    break
  }
}

# AUTO_SCRIPT.ps1 — генератор звітів (Week / Month / Quarter / Year)

## Швидкий старт (без -Date — береться сьогодні)
```powershell
.\AUTO_SCRIPT.ps1 -Mode Week
.\AUTO_SCRIPT.ps1 -Mode Month
.\AUTO_SCRIPT.ps1 -Mode Quarter
.\AUTO_SCRIPT.ps1 -Mode Year
```

## Приклади з конкретною датою
```powershell
.\AUTO_SCRIPT.ps1 -Mode Week -Date "2025-09-27"
.\AUTO_SCRIPT.ps1 -Mode Month -Date "2025-09-01"
.\AUTO_SCRIPT.ps1 -Mode Quarter -Date "2025-10-10"
.\AUTO_SCRIPT.ps1 -Mode Year -Date "2025-01-01"
```

## Куди зберігає
- Week → `REPORTS\<YYYY>\W<WW>\WEEK_REPORT_YYYY-WWW.md`
- Month → `REPORTS\<YYYY>\M<MM>\MONTH_SUMMARY_YYYY-MM.md`
- Quarter → `REPORTS\<YYYY>\Q<Q>\QUARTER_SUMMARY_YYYY-Qq.md`
- Year → `REPORTS\<YYYY>\YEAR\YEAR_SUMMARY_YYYY.md`

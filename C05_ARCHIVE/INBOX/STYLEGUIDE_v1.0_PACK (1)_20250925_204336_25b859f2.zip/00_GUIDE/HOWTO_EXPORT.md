# HOWTO — Експорт банерів (StyleGuide v1.0)

1) Підготуй вихідні PNG (бажано 1920×1080) у папці, наприклад:
```
D:\CHECHA_CORE\MEDIA\STYLEGUIDE_v1\20_EXPORTS\PNG\SOURCE
```
2) Запусти PowerShell **x64**:
```
pwsh -NoProfile -ExecutionPolicy Bypass `
  -File "D:\CHECHA_CORE\MEDIA\STYLEGUIDE_v1\00_GUIDE\Export-StyleBanners.ps1" `
  -SourceDir "D:\CHECHA_CORE\MEDIA\STYLEGUIDE_v1\20_EXPORTS\PNG\SOURCE" `
  -OutDir    "D:\CHECHA_CORE\MEDIA\STYLEGUIDE_v1\20_EXPORTS\PNG" `
  -Sizes     "1920x1080","1600x900","1080x1080"
```
3) Якщо встановлено **ImageMagick**, скрипт автоматично створить **PDF** для кожного PNG.

4) Іменування файлів очікується як:
```
{
  BLOCK}__{VERSION}__{TAG}   // наприклад: AudienceKits__v1.6__Update
→ Скрипт додасть суфікс розміру: __1920x1080 / __1600x900 / __1080x1080
```
5) Після експорту — зібрати ZIP реліз:
```
D:\CHECHA_CORE\MEDIA\STYLEGUIDE_v1\99_RELEASES\STYLEGUIDE_v1.0_RELEASE_20250925.zip
```

> Примітка: для PDF без ImageMagick можна скористатися будь-яким зовнішнім конвертером (наприклад, у графічному редакторі), головне — вбудувати шрифти DejaVu Sans / Arial Unicode.

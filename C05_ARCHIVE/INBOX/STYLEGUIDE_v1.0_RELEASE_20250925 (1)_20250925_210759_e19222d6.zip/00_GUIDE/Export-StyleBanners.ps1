<#
.SYNOPSIS
  Експорт банерів StyleGuide: масове масштабування PNG у 3 розмірах (+опційне створення PDF через ImageMagick).
.DESCRIPTION
  Скрипт проходить усі PNG у SourceDir та формує копії у потрібних розмірах у OutDir.
  Якщо встановлено ImageMagick (`magick` у PATH) — додатково створює одно-сторінкові PDF.
.PARAMETER SourceDir
  Вхідна папка з вихідними PNG (бажано 1920x1080).
.PARAMETER OutDir
  Вихідна папка для експортів.
.PARAMETER Sizes
  Масив розмірів у форматі WIDTHxHEIGHT. За замовчуванням: 1920x1080,1600x900,1080x1080.
.PARAMETER Quality
  Якість PNG (0–100), за замовчуванням 95.
.EXAMPLE
  .\Export-StyleBanners.ps1 -SourceDir "D:\CHECHA_CORE\MEDIA\STYLEGUIDE_v1\20_EXPORTS\PNG" -OutDir "D:\CHECHA_CORE\MEDIA\STYLEGUIDE_v1\20_EXPORTS\PNG"
#>

[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$SourceDir,
  [Parameter(Mandatory=$true)][string]$OutDir,
  [string[]]$Sizes = @("1920x1080","1600x900","1080x1080"),
  [ValidateRange(0,100)][int]$Quality = 95
)

function Test-Magick {
  try {
    $p = Get-Command magick -ErrorAction Stop
    return $true
  } catch {
    return $false
  }
}

function Parse-Size([string]$s) {
  if ($s -notmatch "^\d+x\d+$") {
    throw "Неправильний формат розміру: $s (очікується WIDTHxHEIGHT)"
  }
  $parts = $s.Split("x")
  return @{ W = [int]$parts[0]; H = [int]$parts[1] }
}

function Ensure-Dir([string]$p) {
  if (-not (Test-Path $p)) { New-Item -ItemType Directory -Force -Path $p | Out-Null }
}

function Resize-PngNet([string]$src, [string]$dst, [int]$w, [int]$h, [int]$quality) {
  Add-Type -AssemblyName System.Drawing
  $bmp = New-Object System.Drawing.Bitmap $src
  try {
    $dest = New-Object System.Drawing.Bitmap $w, $h
    $g = [System.Drawing.Graphics]::FromImage($dest)
    try {
      $g.InterpolationMode  = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
      $g.SmoothingMode      = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
      $g.PixelOffsetMode    = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
      $g.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
      $g.DrawImage($bmp, 0, 0, $w, $h)

      $pngCodec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq "image/png" }
      $encParams = New-Object System.Drawing.Imaging.EncoderParameters(1)
      # У PNG параметр Quality не має значення, але залишимо для симетрії. 
      $encParams.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter([System.Drawing.Imaging.Encoder]::Quality, $quality)
      if ($pngCodec) {
        $dest.Save($dst, $pngCodec, $encParams)
      } else {
        $dest.Save($dst, [System.Drawing.Imaging.ImageFormat]::Png)
      }
    } finally {
      $g.Dispose()
      $dest.Dispose()
    }
  } finally {
    $bmp.Dispose()
  }
}

# === MAIN ===
if (-not (Test-Path $SourceDir)) { throw "SourceDir не існує: $SourceDir" }
Ensure-Dir $OutDir

$hasMagick = Test-Magick
Write-Host "ImageMagick доступний: $hasMagick"

$pngs = Get-ChildItem -Path $SourceDir -Filter *.png -File -Recurse
if (-not $pngs) {
  Write-Warning "PNG файлів не знайдено у $SourceDir"
  exit 0
}

foreach ($png in $pngs) {
  foreach ($s in $Sizes) {
    $sz = Parse-Size $s
    $name = [System.IO.Path]::GetFileNameWithoutExtension($png.Name)
    $dstName = "{0}__{1}.png" -f $name, $s
    $dst = Join-Path $OutDir $dstName
    Write-Host ">> Resize $($png.Name) → $dst ($($sz.W)x$($sz.H))"
    Resize-PngNet -src $png.FullName -dst $dst -w $sz.W -h $sz.H -quality $Quality

    if ($hasMagick) {
      $pdfDst = (Join-Path $OutDir ($name + "__" + $s + ".pdf"))
      $args = @($dst, "-density", "300", "-units", "PixelsPerInch", "-compress", "zip", $pdfDst)
      Write-Host "   PDF via magick: $pdfDst"
      & magick @args
      if ($LASTEXITCODE -ne 0) { Write-Warning "magick помилка для $pdfDst" }
    }
  }
}

Write-Host "✅ Готово. Експорти у: $OutDir"

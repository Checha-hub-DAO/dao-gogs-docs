# STYLEGUIDE_v1.0_PACK
Вміст: керівництво, шаблони, приклади, експортні профілі.
Інсталяція: розпакувати в D:\CHECHA_CORE\MEDIA\STYLEGUIDE_v1\
Шрифти: DejaVu Sans / Arial Unicode (вбудовано у PDF, локально для PNG).
Ліцензія/Кредити: © DAO‑GOGS | С.Ч.

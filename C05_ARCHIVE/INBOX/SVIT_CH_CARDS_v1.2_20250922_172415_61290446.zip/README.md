# 📚 Пакет карт «Світ Ч»

У цьому архіві зібрано три основні блоки:

## 1. MAP_FLOWS
- README.md — опис розділу потоків
- ARTIFACTS.md — артефакти потоків
- MAP_FLOWS_placeholder.png — візуал-заглушка

## 2. MAP_HEROES
- README.md — опис розділу героїв
- ARTIFACTS.md — артефакти героїв
- MAP_HEROES_placeholder.png — візуал-заглушка

## 3. MAP_SYMBOLS
- README.md — опис розділу символів
- ARTIFACTS.md — артефакти символів
- MAP_SYMBOLS_placeholder.png — візуал-заглушка

---

✍ Автор: **С.Ч.**

# 🗺 Карта сайту «Світ Ч»

## Основні розділи
1. Головна сторінка (README)
2. Картки (Flows, Heroes, Symbols)
3. Візуали (Matrix, Legend, Booklet)
4. Документація (Changelog, Deploy Plan)

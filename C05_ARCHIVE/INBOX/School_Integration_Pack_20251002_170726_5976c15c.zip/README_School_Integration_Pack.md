# 🏫 School Integration Pack — My English Book

## Вміст
- Presentation (слайди для адміністрації та вчителів)
- Launch Guide (PDF, покрокова інструкція для впровадження)
- Teacher’s Calendar (річний план для інтеграції)

Цей набір створено для директорів, завучів та адміністрацій шкіл для легкого впровадження програми My English Book.

# 🎒 Starter Kits Bundle — My English Book

## Вміст
- Teacher’s Starter Kit
- Student’s Starter Kit
- Parent’s Starter Kit

Цей пакет містить усі стартер-кити для різних учасників освітнього процесу.

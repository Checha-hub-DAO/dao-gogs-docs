# 🎒 Student’s Starter Kit — My English Book

## Вміст
- Workbook (повний Q1–Q4)
- One-Pager (короткий опис курсу)
- Cover (обкладинка для роздруку/зошита)

Цей набір створено для учнів як простий старт у програмі My English Book.


<#
.SYNOPSIS
  Збирає технічний ZIP-пакет інструментів (скрипти/конфіги) із CHECHA_CORE, рахує SHA256 і синхронізує в CHECHA_CORE_SYNC.

.DESCRIPTION
  - Включає лише дозволені розширення (.ps1, .psm1, .psd1, .bat, .cmd, .py, .json, .yaml, .yml, .ini, .md, .txt, .csv, .ps1xml)
  - Працює по вибраних підпапках (типово: TOOLS, CONFIG, C11_AUTOMATION, C06_FOCUS\TEMPLATES)
  - Створює архів у ARCHIVE з ім'ям TECH_TOOLS_PACK_yyyyMMdd_HHmmss.zip + .sha256
  - Опційно копіює в D:\CHECHA_CORE_SYNC\TOOLS (+датовану копію) і веде лог у TOOLS_LOG.md

.PARAMETER Root
  Корінь CHECHA_CORE (типово D:\CHECHA_CORE)

.PARAMETER IncludeSubfolders
  Перелік підпапок відносно Root, які слід включити в пакет.

.PARAMETER OutArchive
  Каталог для вихідних архівів (типово D:\CHECHA_CORE\ARCHIVE)

.PARAMETER SyncRoot
  Корінь синхронізації (типово D:\CHECHA_CORE_SYNC)

.PARAMETER SyncSubFolder
  Підпапка всередині SyncRoot для викладання пакета (типово TOOLS)

.PARAMETER PackPrefix
  Префікс імені пакета (типово TECH_TOOLS_PACK)

.PARAMETER IncludeExt
  Розширення файлів для включення (як масив). Якщо не задано — використовується набір за замовчуванням.

.PARAMETER ExcludeDirs
  Винятки каталогів (масив). Напр., .git, .venv, node_modules, __pycache__

.PARAMETER CreateDatedCopy
  Створити додаткову датовану копію в SyncRoot\SyncSubFolder\<yyyyMMdd_HHmmss>

.PARAMETER WhatIf
  Показує, що буде зроблено, без фактичних змін.

.PARAMETER OpenAfter
  Відкрити папку з архівом після завершення.
#>

[CmdletBinding(SupportsShouldProcess=$true)]
param(
  [string]$Root = "D:\CHECHA_CORE",
  [string[]]$IncludeSubfolders = @("TOOLS","CONFIG","C11_AUTOMATION","C06_FOCUS\TEMPLATES"),
  [string]$OutArchive = "D:\CHECHA_CORE\ARCHIVE",
  [string]$SyncRoot = "D:\CHECHA_CORE_SYNC",
  [string]$SyncSubFolder = "TOOLS",
  [string]$PackPrefix = "TECH_TOOLS_PACK",
  [string[]]$IncludeExt = @("*.ps1","*.psm1","*.psd1","*.bat","*.cmd","*.py","*.json","*.yaml","*.yml","*.ini","*.md","*.txt","*.csv","*.ps1xml"),
  [string[]]$ExcludeDirs = @(".git",".venv","node_modules","__pycache__",".pytest_cache",".mypy_cache",".vscode",".idea"),
  [switch]$CreateDatedCopy,
  [switch]$WhatIf,
  [switch]$OpenAfter
)

function New-TempDir {
  $p = Join-Path ([System.IO.Path]::GetTempPath()) ("TECHZIP_" + [System.Guid]::NewGuid().ToString("N"))
  New-Item -ItemType Directory -Path $p -Force | Out-Null
  return $p
}

function Write-Info($msg){ Write-Host "[INFO] $msg" -ForegroundColor Cyan }
function Write-Warn($msg){ Write-Warning $msg }
function Write-Err ($msg){ Write-Host "[ERR ] $msg" -ForegroundColor Red }

# 0) Перевіримо корені
if (-not (Test-Path -LiteralPath $Root)) { throw "Root не існує: $Root" }
if (-not (Test-Path -LiteralPath $OutArchive)) {
  if ($PSCmdlet.ShouldProcess($OutArchive, "Створити каталог")) {
    New-Item -ItemType Directory -Path $OutArchive -Force | Out-Null
  }
}
if (-not (Test-Path -LiteralPath $SyncRoot)) {
  if ($PSCmdlet.ShouldProcess($SyncRoot, "Створити каталог")) {
    New-Item -ItemType Directory -Path $SyncRoot -Force | Out-Null
  }
}

# 1) Збір списку файлів
$includePaths = @()
foreach ($sub in $IncludeSubfolders) {
  $p = Join-Path $Root $sub
  if (Test-Path -LiteralPath $p) {
    $includePaths += (Resolve-Path -LiteralPath $p).Path
  } else {
    Write-Warn "Пропущено (нема): $p"
  }
}

if ($includePaths.Count -eq 0) { throw "Немає жодного існуючого каталогу з IncludeSubfolders." }

$files = New-Object System.Collections.Generic.List[System.IO.FileInfo]

foreach ($base in $includePaths) {
  # Візьмемо всі дозволені розширення рекурсивно
  foreach ($ext in $IncludeExt) {
    Get-ChildItem -LiteralPath $base -Recurse -File -Filter $ext -ErrorAction SilentlyContinue | ForEach-Object {
      # Перевіримо виключення директорій по частковому входженню
      $skip = $false
      foreach ($ex in $ExcludeDirs) {
        if ($_.DirectoryName -like "*\$ex*" ) { $skip = $true; break }
      }
      if (-not $skip) { $files.Add($_) }
    }
  }
}

if ($files.Count -eq 0) { throw "Не знайдено файлів за заданими правилами включення/виключення." }

Write-Info ("Знайдено файлів: {0}" -f $files.Count)

# 2) Тимчасовий staging, збереження відносної структури
$stage = New-TempDir
Write-Info "Staging → $stage"

foreach ($f in $files) {
  # Відносний шлях від Root
  $rel = [System.IO.Path]::GetRelativePath($Root, $f.FullName)
  $dest = Join-Path $stage $rel
  $destDir = Split-Path -Path $dest -Parent
  if (-not (Test-Path -LiteralPath $destDir)) {
    if ($PSCmdlet.ShouldProcess($destDir, "Створити каталог у staging")) {
      New-Item -ItemType Directory -Path $destDir -Force | Out-Null
    }
  }
  if (-not $WhatIf) {
    Copy-Item -LiteralPath $f.FullName -Destination $dest -Force
  } else {
    Write-Host "WhatIf: копіював би $($f.FullName) → $dest"
  }
}

# 3) Формування імені архіву
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$zipName = "{0}_{1}.zip" -f $PackPrefix, $stamp
$zipPath = Join-Path $OutArchive $zipName
$shaPath = "$zipPath.sha256"

Write-Info "Архів → $zipPath"

# 4) Створення ZIP
if (-not $WhatIf) {
  if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }
  if (Get-Command Compress-Archive -ErrorAction SilentlyContinue) {
    Compress-Archive -LiteralPath (Get-ChildItem -LiteralPath $stage -Recurse | Select-Object -ExpandProperty FullName) -DestinationPath $zipPath -Force
  } else {
    # .NET fallback
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::CreateFromDirectory($stage, $zipPath)
  }
} else {
  Write-Host "WhatIf: створив би архів $zipPath"
}

# 5) SHA256
if (-not $WhatIf) {
  try {
    $hash = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash.ToLower()
    "$hash  $($zipName)" | Out-File -LiteralPath $shaPath -Encoding ascii -Force
    Write-Info "SHA256: $hash"
  } catch {
    Write-Err "Не вдалося порахувати SHA256: $($_.Exception.Message)"
  }
}

# 6) Синхронізація в SyncRoot\SyncSubFolder
$targetDir = Join-Path $SyncRoot $SyncSubFolder
if (-not (Test-Path -LiteralPath $targetDir)) {
  if ($PSCmdlet.ShouldProcess($targetDir, "Створити папку синхронізації")) {
    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
  }
}

if (-not $WhatIf) {
  Copy-Item -LiteralPath $zipPath -Destination (Join-Path $targetDir $zipName) -Force
  if (Test-Path -LiteralPath $shaPath) {
    Copy-Item -LiteralPath $shaPath -Destination (Join-Path $targetDir (Split-Path $shaPath -Leaf)) -Force
  }

  if ($CreateDatedCopy) {
    $datedDir = Join-Path $targetDir $stamp
    New-Item -ItemType Directory -Path $datedDir -Force | Out-Null
    Copy-Item -LiteralPath $zipPath -Destination (Join-Path $datedDir $zipName) -Force
    if (Test-Path -LiteralPath $shaPath) {
      Copy-Item -LiteralPath $shaPath -Destination (Join-Path $datedDir (Split-Path $shaPath -Leaf)) -Force
    }
    Write-Info "Датована копія: $datedDir"
  }
}

# 7) Лог
$logDir = $targetDir
$logFile = Join-Path $logDir "TOOLS_LOG.md"
$ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$log = @"
- $ts | Built: $zipName → ARCHIVE, synced → $($targetDir)
"@
if (-not $WhatIf) {
  Add-Content -LiteralPath $logFile -Value $log
}

# 8) Прибирання staging
if (-not $WhatIf) {
  try { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue } catch {}
}

Write-Host "✅ Готово. Пакет: $zipPath"
if ($OpenAfter) { Invoke-Item (Split-Path -Path $zipPath -Parent) }

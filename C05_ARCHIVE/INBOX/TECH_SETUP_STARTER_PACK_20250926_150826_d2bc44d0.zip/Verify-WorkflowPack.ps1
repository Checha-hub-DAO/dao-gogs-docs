
param (
    [string]$ZipPath = "SCRIPT_WORKFLOW_PACK.zip",
    [string]$ShaFile = "SCRIPT_WORKFLOW_PACK.sha256"
)

if (-Not (Test-Path $ZipPath)) {
    Write-Host "❌ Архів не знайдено: $ZipPath"
    exit 1
}
if (-Not (Test-Path $ShaFile)) {
    Write-Host "❌ Файл SHA256 не знайдено: $ShaFile"
    exit 1
}

# Обчислюємо SHA256 для архіву
$computedHash = (Get-FileHash -Path $ZipPath -Algorithm SHA256).Hash.ToLower()

# Читаємо еталонне значення
$expectedHash = (Get-Content $ShaFile).Split(" ")[0].ToLower()

if ($computedHash -eq $expectedHash) {
    Write-Host "✅ Хеш збігається. Файл цілісний."
    exit 0
} else {
    Write-Host "❌ Хеш НЕ збігається!"
    Write-Host "Очікувано: $expectedHash"
    Write-Host "Отримано : $computedHash"
    exit 2
}

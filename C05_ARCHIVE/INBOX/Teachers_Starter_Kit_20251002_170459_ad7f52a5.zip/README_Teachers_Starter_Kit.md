# 📘 Teacher’s Starter Kit — My English Book

## Вміст
- Workbook (повний Q1–Q4)
- Teacher’s Calendar (річний план)
- Launch Guide (PDF)
- One-Pager (короткий опис)

Цей набір створено для швидкого старту вчителя з програмою My English Book.

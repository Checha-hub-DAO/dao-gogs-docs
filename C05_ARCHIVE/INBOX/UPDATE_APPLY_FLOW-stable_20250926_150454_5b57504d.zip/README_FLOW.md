
# UPDATE_APPLY_FLOW — Стандарт потоку оновлень

## 1. Завантаження
- Усі згенеровані ZIP-и (STABLE або DRAFT) потрапляють у **Завантаження**.
- Ти вручну переносиш їх у:
  - `D:\CHECHA_CORE\_INBOX` → якщо **STABLE**
  - `D:\CHECHA_CORE\WORKSHOP\DRAFTS` → якщо **DRAFT**

## 2. Запуск централізатора
- Для STABLE-пакетів: `Apply-Update-STABLE.cmd`
- Для STABLE + DRAFT: `Apply-Update-DRAFT.cmd`
- Обидва запускають `Apply-Update.ps1` з відповідними параметрами.

## 3. Дії сценарію
- Перевіряє **SHA256** (якщо є).
- Розкладає файли у відповідні блоки:
  - `CHECHA_TOOLS_ONECLICK*` → `TOOLS\`
  - `AUTO-SCHEDULE*` → `TOOLS\ScheduleProfiles\` (+ README → `C01_PARAMETERS`)
  - `EVENING_BACKUP*` → `TOOLS\`
  - `PARAMETERS_UPDATE*` → `C01_PARAMETERS\`
  - інші → `WORKSHOP\INBOX_EXTRACTS\<ім’я>`
- Пакети переміщує у `ARCHIVE\UPDATES\YYYYMMDD\`.

## 4. Лог
- Всі дії фіксуються у `_INBOX\UPDATES_LOG.md`.
- Кожен прогін має власний timestamp.

## 5. Рівні зрілості
- `*-draft.zip` → чернетки (WORKSHOP/DRAFTS).
- `*-stable.zip` або без суфіксу → застосовуються.
- Можна застосувати draft-пакети вручну, якщо додати прапор `-ApplyDraft`.

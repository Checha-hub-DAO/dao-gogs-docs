
# WEEKLY_CHECKLIST.md — Щотижнева перевірка системи CHECHA_CORE

Періодичність: **щоп'ятниці** після завершення робіт або **щосуботи вранці**.

## 1) Архіви та бекапи
- [ ] Перевірити наявність архівів у `D:\CHECHA_CORE\ARCHIVE\` за тиждень.
- [ ] Відкрити `D:\CHECHA_BACKUP\DAILY\` і переконатися, що є каталоги за всі дні тижня.
- [ ] Вибірково звірити 1–2 дні: ZIP ↔ `.sha256` (команда нижче).

### Команда звірки SHA256 (приклад)
```powershell
Get-ChildItem "D:\CHECHA_BACKUP\DAILY\2025*" -Directory | Select-Object -First 1 | %{
  Get-ChildItem $_.FullName -Filter *.zip | Select-Object -First 1 | %{
    $sha = (Get-FileHash $_.FullName -Algorithm SHA256).Hash
    (Get-Content ($_.FullName + ".sha256") -ea SilentlyContinue)[0]
    "$($sha)  $($_.Name)"
  }
}
```

## 2) Логи та сигнали
- [ ] Переглянути `_INBOX\UPDATES_LOG.md` — чи немає FAIL / ERR / SHA mismatch.
- [ ] Перевірити `SYNC\DOCS\SOD_LOG.md` — чи був попереджений відсутній Evening Backup.
- [ ] Переглянути `D:\CHECHA_BACKUP\EVENING_LOG.md` — чи немає пропусків або помилок.

## 3) Пакети та версії
- [ ] В `SYNC\TOOLS\TOOLS_CHANGELOG.md` звірити, що версії збиралися послідовно.
- [ ] Вибірково розпакувати останній `TECH_TOOLS_PACK_*` і перевірити `VERSION.txt` (дата/час, host, user).
- [ ] Якщо використовувався HOT-режим — зібрати **повний** пакет (без `-Hot`) та зафіксувати у CHANGELOG.

## 4) Очищення та порядок
- [ ] Очистити `D:\CHECHA_CORE\WORKSHOP\INBOX_EXTRACTS\` від тимчасових копій.
- [ ] Звільнити місце у `D:\CHECHA_BACKUP\DAILY\`, якщо воно наближається до ліміту (налаштувати `RetainDays` за потреби).
- [ ] Переконатися, що в `_INBOX\` не залишилося старих ZIP-ів після застосування.

## 5) Планувальник
- [ ] Відкрити Task Scheduler та перевірити, що задачі активні:
  - `CHECHA_StartOfDay_v2` (HOT)
  - `CHECHA_StartOfDay_v2_FULL` (FULL)
  - `CHECHA_EveningBackup` (20:00)
- [ ] У логах `SOD_LOG.md` має бути щоденний запис; у разі відсутності — відновити задачу.

## 6) Контроль доступу та права
- [ ] Запустити `Create-CoreStructure.ps1 -VerifyWrite` (сухий прогін) для перевірки прав на ключових теках.
- [ ] Переконатися, що антивірус/SmartScreen не блокує `*.ps1` (винятки на `D:\CHECHA_CORE\TOOLS\`).

## 7) Зрілість пакетів
- [ ] Перевірити, чи всі пакети в `_INBOX\` мають суфікси **-stable** або **-draft**.
- [ ] DRAFT-и, що стали стабільними — перейменувати в **-stable**, оновити README та SHA256.

## 8) Резерв на зовнішній носій (раз на тиждень)
- [ ] Скопіювати `D:\CHECHA_CORE\ARCHIVE\TECH_TOOLS_PACK_*` (поточний тиждень) на флешку/зовнішній диск.
- [ ] Перевірити контрольну суму на носії (довільна вибірка).

---
**С.Ч. — стандарт щотижневої рутини**

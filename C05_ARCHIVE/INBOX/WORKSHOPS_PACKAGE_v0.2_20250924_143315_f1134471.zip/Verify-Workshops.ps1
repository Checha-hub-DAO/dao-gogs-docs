﻿# Requires -Version 5.1
<#
.SYNOPSIS
  Перевірка каталогу майстерень за індексом CSV (WORKSHOPS_INDEX.csv).

.DESCRIPTION
  Скрипт читає CSV (колонки: ID, Назва, Статус, Шлях, Вихідні),
  перевіряє наявність папок та вихідних артефактів (підтримує шаблони *.md, *.png тощо),
  валідує статус-коди (S0–S3) і формує звіт у CSV/JSON/TXT.

.PARAMETER IndexCsv
  Шлях до CSV-індексу (наприклад, D:\CHECHA_CORE\WORKSHOP\WORKSHOPS_INDEX_v0.2.csv).

.PARAMETER ReportDir
  Каталог для збереження звітів. Якщо не задано — поруч із IndexCsv у /logs.

.PARAMETER Strict
  Якщо увімкнено, відсутність будь-якого обов’язкового артефакту призведе до ненульового ExitCode.

.EXAMPLE
  .\Verify-Workshops.ps1 -IndexCsv "D:\CHECHA_CORE\WORKSHOP\WORKSHOPS_INDEX_v0.2.csv"

.EXAMPLE
  pwsh -NoProfile -ExecutionPolicy Bypass -File .\Verify-Workshops.ps1 `
    -IndexCsv "D:\CHECHA_CORE\WORKSHOP\WORKSHOPS_INDEX_v0.2.csv" -Strict

.OUTPUTS
  Створює у ReportDir файли:
   - workshops_report_<timestamp>.csv
   - workshops_report_<timestamp>.json
   - workshops_report_<timestamp>.log.txt
#>

[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)]
  [string]$IndexCsv,

  [string]$ReportDir,

  [switch]$Strict
)

function New-ReportPath {
  param([string]$BaseDir, [string]$Ext)
  $ts = Get-Date -Format "yyyyMMdd_HHmmss"
  $name = "workshops_report_{0}{1}" -f $ts, $Ext
  return (Join-Path $BaseDir $name)
}

# --- Перевірки вхідних параметрів ---
if (!(Test-Path -LiteralPath $IndexCsv)) {
  Write-Error "Не знайдено файл індексу: $IndexCsv"
  exit 2
}

# Якщо ReportDir не заданий — створюємо 'logs' поруч із CSV
if (-not $ReportDir -or $ReportDir.Trim() -eq "") {
  $csvDir = Split-Path -LiteralPath $IndexCsv -Parent
  $ReportDir = Join-Path $csvDir "logs"
}
if (!(Test-Path -LiteralPath $ReportDir)) {
  New-Item -Type Directory -Path $ReportDir | Out-Null
}

# --- Читання CSV ---
try {
  $items = Import-Csv -LiteralPath $IndexCsv
} catch {
  Write-Error "Не вдалося прочитати CSV: $($_.Exception.Message)"
  exit 3
}

# --- Підготовка звітів ---
$csvOut  = New-ReportPath -BaseDir $ReportDir -Ext ".csv"
$jsonOut = New-ReportPath -BaseDir $ReportDir -Ext ".json"
$logOut  = New-ReportPath -BaseDir $ReportDir -Ext ".log.txt"

"== Verify-Workshops Log ==" | Out-File -LiteralPath $logOut -Encoding utf8BOM
("CSV: {0}" -f $IndexCsv)   | Out-File -LiteralPath $logOut -Append -Encoding utf8BOM
("UTC: {0:u}" -f (Get-Date).ToUniversalTime()) | Out-File -LiteralPath $logOut -Append -Encoding utf8BOM
"--------------------------" | Out-File -LiteralPath $logOut -Append -Encoding utf8BOM

$validStatuses = @("S0","S1","S2","S3")
$summary = @()
$hasErrors = $false

foreach ($row in $items) {
  $id     = $row.ID
  $name   = $row.Назва
  $status = $row.Статус
  $root   = $row.Шлях
  $outs   = $row.Вихідні

  $dirExists = Test-Path -LiteralPath $root
  $statusOk  = $validStatuses -contains $status

  $missing = @()
  $present = @()

  if ($outs -and $outs.Trim() -ne "") {
    # Вихідні можуть бути розділені ; або ,
    $tokens = $outs -split '[;,]'
    foreach ($t in $tokens) {
      $pat = $t.Trim()
      if ([string]::IsNullOrWhiteSpace($pat)) { continue }
      # Дозволяємо шаблони (наприклад, MAPS_*.pdf/png). Розширимо '/*.png' випадки з альтернативами.
      $expanded = @()
      if ($pat -match "/") {
        # Підтримка скорочення типу "*.pdf/png"
        $parts = $pat -split "/"
        if ($parts.Count -eq 2 -and $parts[1].StartsWith(".")) {
          $expanded += (Join-Path $root ($parts[0]))
          $expanded += (Join-Path $root ($parts[0] -replace '\*', '*.')) # приблизна підтримка
        }
      } else {
        $expanded += (Join-Path $root $pat)
      }

      $found = $false
      foreach ($p in $expanded) {
        $dir  = Split-Path -Path $p -Parent
        $file = Split-Path -Path $p -Leaf
        if (-not (Test-Path -LiteralPath $dir)) { continue }
        $hits = Get-ChildItem -LiteralPath $dir -Filter $file -File -ErrorAction SilentlyContinue
        if ($hits -and $hits.Count -gt 0) {
          $found = $true
          break
        }
      }

      if ($found) { $present += $pat } else { $missing += $pat }
    }
  }

  $rowOk = $dirExists -and $statusOk -and ($missing.Count -eq 0 -or $status -eq "S0")
  if (-not $rowOk) { $hasErrors = $true }

  $summary += [pscustomobject]@{
    ID          = $id
    Назва       = $name
    Статус      = $status
    СтатусOK    = $statusOk
    Шлях        = $root
    ПапкаОк     = $dirExists
    Знайдено    = ($present -join "; ")
    Відсутнє    = ($missing -join "; ")
    AllOK       = $rowOk
  }

  ("[{0}] {1} :: Dir={2}, Status={3}, Missing={4}" -f $id, $name, $dirExists, $status, ($missing -join "|")) |
    Out-File -LiteralPath $logOut -Append -Encoding utf8BOM
}

# --- Запис звітів ---
$summary | Export-Csv -LiteralPath $csvOut -NoTypeInformation -Encoding UTF8
$summary | ConvertTo-Json -Depth 5 | Out-File -LiteralPath $jsonOut -Encoding utf8BOM

"--------------------------" | Out-File -LiteralPath $logOut -Append -Encoding utf8BOM
("Summary saved: {0}" -f $csvOut) | Out-File -LiteralPath $logOut -Append -Encoding utf8BOM
("Summary saved: {0}" -f $jsonOut) | Out-File -LiteralPath $logOut -Append -Encoding utf8BOM

if ($Strict -and $hasErrors) {
  Write-Error "Виявлено невідповідності. Дивись $csvOut та $logOut"
  exit 1
} else {
  Write-Host "Готово. Звіт: $csvOut"
}

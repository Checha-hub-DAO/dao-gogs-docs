# 📝 Список змін (Changelog)

## 🔹 Призначення
Цей файл документує всі зміни в майстернях CheCha Core від версії до версії.  
Він деталізує доповнення, виправлення та поліпшення.

---

## 📌 Версії

### v0.1 — Стартовий каркас (2025-09-23)
**Додано:**
- README.md у 14 майстернях.  
- TASKS.md для задач.  
- NOTES.md для нотаток.  
- JOURNAL.md для хроніки.  
- ARTIFACTS.md для артефактів.  

**Архів:** WORKSHOPS_README_PACK_v0.1.zip  

---

### v0.2 — Контроль і GitBook інтеграція (2025-09-24)
**Додано:**
- MASTER_CONTROL.md, MASTER_CHECKLIST.md, MASTER_SYNC.md.  
- Скрипти: MASTER_SCRIPT.ps1, MASTER_RELEASE.ps1, master_release.sh.  
- GitBook-сторінки: INDEX_PAGE.md, SUMMARY.md, OVERVIEW.md, FLOW.md, METRICS.md, ROADMAP.md, ARCHIVE.md, GUIDELINES.md, DASHBOARD.md, TIMELINE.md.  
- 14 GitBook-сторінок для майстерень.  

**Змінено:**
- README.md у майстернях синхронізовано зі стандартом GitBook.  

**Архів:** WORKSHOPS_README_PACK_v0.2.zip  

---

## 🔹 Наступні релізи
- v0.3 — заповнення JOURNAL.md і ARTIFACTS.md.  
- v0.5 — візуалізації й KPI.  
- v0.8 — автоматизація та інтеграція.  
- v1.0 — публічний реліз.  

---

✍ Автор: Сергій ЧеЧа (С.Ч.)  
Версія: v0.2  
Дата: 2025-09-24

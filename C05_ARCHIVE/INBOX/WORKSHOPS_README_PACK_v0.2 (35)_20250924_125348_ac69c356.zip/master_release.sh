#!/usr/bin/env bash
# master_release.sh — релізне збирання пакета майстерень (Linux/macOS)
# Використання: ./master_release.sh 0.3 release

set -euo pipefail

NEW_VERSION="${1:-}"
STAGE="${2:-release}"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -z "$NEW_VERSION" ]]; then
  echo "Usage: ./master_release.sh <new_version> [stage]" >&2
  exit 1
fi

DATE="$(date +%Y-%m-%d)"
ZIP_NAME="WORKSHOPS_README_PACK_v${NEW_VERSION}.zip"
ZIP_PATH="${ROOT_DIR}/${ZIP_NAME}"
HASH_PATH="${ROOT_DIR}/WORKSHOPS_README_PACK_v${NEW_VERSION}_SHA256.txt"

workshops=(CREATOR ARCHITECT SMITH ANALYST CHRONIST STRATEGIST PHILOSOPHER MEDIA TEACHER RITUAL ENGINEER RESEARCHER PSYCHOLOGIST COMMUNITY)
files=(README.md ARTIFACTS.md JOURNAL.md TASKS.md NOTES.md MASTER_DOC.md)

ensure_workshops() {
  for w in "${workshops[@]}"; do
    mkdir -p "${ROOT_DIR}/${w}"
    for f in "${files[@]}"; do
      fp="${ROOT_DIR}/${w}/${f}"
      [[ -f "$fp" ]] || echo "# Авто-створено 2025-09-24" > "$fp"
    done
  done
}

update_masterdocs() {
  for w in "${workshops[@]}"; do
    md="${ROOT_DIR}/${w}/MASTER_DOC.md"
    if [[ -f "$md" ]]; then
      sed -E -i.bak "s/Версія: v[0-9]+\.[0-9]+/Версія: v${NEW_VERSION}/g; s/Дата: [0-9]{4}-[0-9]{2}-[0-9]{2}/Дата: $DATE/g" "$md"
      rm -f "${md}.bak"
    fi
  done
}

update_rootdocs() {
  for rf in CONTROL_PANEL.md VERSION_LOG.md CHANGELOG.md MASTER_OVERVIEW.md DASHBOARD.md SUMMARY.md; do
    p="${ROOT_DIR}/${rf}"
    [[ -f "$p" ]] || continue
    case "$rf" in
      CONTROL_PANEL.md)
        sed -E -i.bak "s/Версія пакета: v[0-9\.]+( \([^)]+\))?/Версія пакета: v${NEW_VERSION} ($STAGE)/" "$p";;
      VERSION_LOG.md)
        printf "\n### v%s — %s\n- Релізне збирання пакета.\n- Статус: %s\n\n" "$NEW_VERSION" "$DATE" "$STAGE" >> "$p";;
      CHANGELOG.md)
        printf "\n## v%s (%s)\n- Реліз: оновлені документація та індекси.\n- Архів сформовано: %s\n- Статус: %s\n\n" "$NEW_VERSION" "$DATE" "$ZIP_NAME" "$STAGE" >> "$p";;
      *)
        sed -E -i.bak "s/Версія: v[0-9]+\.[0-9]+/Версія: v${NEW_VERSION}/g" "$p";;
    esac
    rm -f "${p}.bak"
  done
}

build_zip() {
  rm -f "$ZIP_PATH"
  (cd "$ROOT_DIR" && zip -qr "$ZIP_PATH" .)
}

write_hash() {
  sha256sum "$ZIP_PATH" > "$HASH_PATH" 2>/dev/null || shasum -a 256 "$ZIP_PATH" > "$HASH_PATH"
  cat "$HASH_PATH"
}

echo "=== master_release.sh ==="
ensure_workshops
update_masterdocs
update_rootdocs
build_zip
write_hash
echo "Готово ✅ Реліз v${NEW_VERSION}"

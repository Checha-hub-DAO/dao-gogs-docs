# 📖 Summary

* [Каталог майстерень](INDEX_PAGE.md)
* [Creator Майстерня](CREATOR_PAGE.md)
* [Architect Майстерня](ARCHITECT_PAGE.md)
* [Smith Майстерня](SMITH_PAGE.md)
* [Analyst Майстерня](ANALYST_PAGE.md)
* [Chronist Майстерня](CHRONIST_PAGE.md)
* [Strategist Майстерня](STRATEGIST_PAGE.md)
* [Philosopher Майстерня](PHILOSOPHER_PAGE.md)
* [Media Майстерня](MEDIA_PAGE.md)
* [Teacher Майстерня](TEACHER_PAGE.md)
* [Ritual Майстерня](RITUAL_PAGE.md)
* [Engineer Майстерня](ENGINEER_PAGE.md)
* [Researcher Майстерня](RESEARCHER_PAGE.md)
* [Psychologist Майстерня](PSYCHOLOGIST_PAGE.md)
* [Community Майстерня](COMMUNITY_PAGE.md)

---
✍ Автор: Сергій ЧеЧа (С.Ч.)  
Версія: v0.2  
Дата: 2025-09-24

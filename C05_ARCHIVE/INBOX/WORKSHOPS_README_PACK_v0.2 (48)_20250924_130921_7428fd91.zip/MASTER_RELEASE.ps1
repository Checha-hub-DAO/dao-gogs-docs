<#
.SYNOPSIS
  MASTER_RELEASE.ps1 — релізне збирання пакета майстерень CheCha Core.

.DESCRIPTION
  Скрипт виконує реліз: проставляє нову версію, оновлює контрольні файли,
  формує ZIP архів, рахує SHA-256, вносить записи у VERSION_LOG і CHANGELOG.

.PARAMETER NewVersion
  Нова версія у форматі X.Y (наприклад, 0.3 або 1.0).

.PARAMETER Stage
  Стадія релізу: release (за замовчуванням) або rc.

.EXAMPLE
  .\MASTER_RELEASE.ps1 -NewVersion 0.3 -Stage release
#>

param(
  [Parameter(Mandatory=$true)][string]$NewVersion,
  [string]$Stage = "release",
  [string]$Root = (Join-Path $PSScriptRoot ".")
)

$ErrorActionPreference = "Stop"

$Date = Get-Date -Format "yyyy-MM-dd"
$ZipName = "WORKSHOPS_README_PACK_v$NewVersion.zip"
$ZipPath = Join-Path $Root $ZipName
$HashPath = Join-Path $Root ("WORKSHOPS_README_PACK_v$NewVersion_SHA256.txt")

$Workshops = @(
  "CREATOR","ARCHITECT","SMITH","ANALYST","CHRONIST","STRATEGIST",
  "PHILOSOPHER","MEDIA","TEACHER","RITUAL","ENGINEER","RESEARCHER",
  "PSYCHOLOGIST","COMMUNITY"
)
$WorkshopFiles = @("README.md","ARTIFACTS.md","JOURNAL.md","TASKS.md","NOTES.md","MASTER_DOC.md")

function Update-MasterDocsDates {
  foreach ($w in $Workshops) {
    $md = Join-Path (Join-Path $Root $w) "MASTER_DOC.md"
    if (Test-Path $md) {
      (Get-Content $md -Raw) `
        -replace "Версія:\s*v\d+\.\d+","Версія: v$NewVersion" `
        -replace "Дата:\s*\d{4}-\d{2}-\d{2}","Дата: $Date" | `
        Set-Content -Encoding UTF8 $md
    }
  }
}

function Ensure-WorkshopFiles {
  foreach ($w in $Workshops) {
    $path = Join-Path $Root $w
    if (!(Test-Path $path)) { New-Item -Type Directory -Path $path | Out-Null }
    foreach ($f in $WorkshopFiles) {
      $fp = Join-Path $path $f
      if (!(Test-Path $fp)) { "# Авто-створено 2025-09-24" | Set-Content -Encoding UTF8 $fp }
    }
  }
}

function Update-RootDocs {

  $rootFiles = @(
    "CONTROL_PANEL.md","VERSION_LOG.md","CHANGELOG.md",
    "MASTER_OVERVIEW.md","DASHBOARD.md","SUMMARY.md"
  )

  foreach ($rf in $rootFiles) {
    $p = Join-Path $Root $rf
    if (!(Test-Path $p)) { continue }
    switch ($rf) {
      "CONTROL_PANEL.md" {
        (Get-Content $p -Raw) `
          -replace "Версія пакета: v[\d\.]+(?: \([^)]+\))?","Версія пакета: v$NewVersion ($Stage)" | `
          Set-Content -Encoding UTF8 $p
      }
      "VERSION_LOG.md" {
        $entry = @"
### v$NewVersion — $Date
- Релізне збирання пакета.
- Статус: $Stage

"@
        Add-Content -Encoding UTF8 $p $entry
      }
      "CHANGELOG.md" {
        $entry = @"
## v$NewVersion ($Date)
- Реліз: оновлені документація та індекси.
- Архів сформовано: $ZipName
- Статус: $Stage

"@
        Add-Content -Encoding UTF8 $p $entry
      }
      default {
        # Проставляємо версію в заголовках цих документів, якщо є
        (Get-Content $p -Raw) `
          -replace "Версія:\s*v\d+\.\d+","Версія: v$NewVersion" | `
          Set-Content -Encoding UTF8 $p
      }
    }
  }
}

function Build-Zip {
  if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }
  Add-Type -Assembly 'System.IO.Compression.FileSystem'
  [System.IO.Compression.ZipFile]::CreateFromDirectory($Root, $ZipPath)
}

function Write-Hash {
  $sha256 = [System.Security.Cryptography.SHA256]::Create()
  $fs = [System.IO.File]::OpenRead($ZipPath)
  try {
    $hash = ($sha256.ComputeHash($fs) | ForEach-Object { $_.ToString("x2") }) -join ""
  } finally {
    $fs.Dispose()
  }
  $line = "SHA256  $hash  $ZipName  ($Date)"
  Set-Content -Encoding UTF8 -Path $HashPath -Value $line
  Write-Host $line -ForegroundColor Yellow
}

Write-Host "=== MASTER_RELEASE.ps1 ===" -ForegroundColor Cyan
Ensure-WorkshopFiles
Update-MasterDocsDates
Update-RootDocs
Build-Zip
Write-Hash
Write-Host "Готово ✅ Реліз v$NewVersion" -ForegroundColor Green

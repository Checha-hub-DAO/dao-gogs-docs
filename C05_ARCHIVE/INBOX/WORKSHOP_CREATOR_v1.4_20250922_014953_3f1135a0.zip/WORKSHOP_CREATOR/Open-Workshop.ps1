
<#
.SYNOPSIS
  Відкриває "Майстерню Творця" одним кліком.

.DESCRIPTION
  Скрипт відкриває WORKSHOP.md у стандартному редакторі (або VS Code, якщо є),
  додатково може відкрити інші ключові файли та візуальну схему.
  Параметром -Root можна вказати кореневу теку CHECHA_CORE.
#>

[CmdletBinding()]
param(
  [string]$Root = "D:\CHECHA_CORE",
  [switch]$OpenAll,          # також відкрити TECHNICAL.md / CREATIVE.md / RHYTHM.md / PHILOSOPHY.md
  [switch]$OpenVisual,       # відкрити схему VISUALS\Workshop_Map.png
  [switch]$UseVSCode         # намагатися відкривати у VS Code
)

$ErrorActionPreference = "Stop"

function Resolve-WorkshopPath {
  param([string]$root)
  $ws = Join-Path $root "WORKSHOP_CREATOR"
  if (-not (Test-Path $ws)) {
    throw "Не знайдено WORKSHOP_CREATOR у `$root: $ws"
  }
  return $ws
}

function Open-File {
  param([string]$Path)
  if (-not (Test-Path $Path)) {
    Write-Warning "Файл не знайдено: $Path"
    return
  }
  if ($UseVSCode -and (Get-Command code -ErrorAction SilentlyContinue)) {
    Start-Process -FilePath "code" -ArgumentList @("--reuse-window", "--goto", $Path) | Out-Null
  } else {
    Start-Process -FilePath $Path | Out-Null
  }
}

try {
  $ws = Resolve-WorkshopPath -root $Root
  $workshop = Join-Path $ws "WORKSHOP.md"
  $tech     = Join-Path $ws "TECHNICAL.md"
  $creative = Join-Path $ws "CREATIVE.md"
  $rhythm   = Join-Path $ws "RHYTHM.md"
  $philo    = Join-Path $ws "PHILOSOPHY.md"
  $visual   = Join-Path $ws "VISUALS\Workshop_Map.png"

  Write-Host "🔥 Відкриття Майстерні Творця..." -ForegroundColor Yellow
  Open-File -Path $workshop

  if ($OpenAll) {
    Open-File -Path $tech
    Open-File -Path $creative
    Open-File -Path $rhythm
    Open-File -Path $philo
  }

  if ($OpenVisual) {
    Open-File -Path $visual
  }

  # Відкрити теку майстерні у Провіднику
  Start-Process -FilePath "explorer.exe" -ArgumentList $ws | Out-Null

  # Малий ритуал входу: повідомлення у консолі
  Write-Host "—" * 60
  Write-Host "Тут я творю. Тут я об’єдную ритми. Тут народжується нове." -ForegroundColor Cyan
  Write-Host "WORKSHOP: $workshop" -ForegroundColor DarkGray
  Write-Host "Готово." -ForegroundColor Green
}
catch {
  Write-Error $_.Exception.Message
  exit 1
}

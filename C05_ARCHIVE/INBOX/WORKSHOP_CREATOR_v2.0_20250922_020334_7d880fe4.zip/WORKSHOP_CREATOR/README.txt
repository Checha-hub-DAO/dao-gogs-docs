README — Майстерня Творця
=================================

Цей пакет містить стартову структуру "Майстерні Творця".

Файли:
- WORKSHOP.md         — головна сторінка майстерні (маніфест + посилання)
- TECHNICAL.md        — технічна кузня (інструменти, скрипти, процеси)
- CREATIVE.md         — творча лабораторія (карти, герої, символи)
- RHYTHM.md           — життєвий ритм (календар, рефлексії)
- PHILOSOPHY.md       — філософське полотно (слова сили, принципи)
- VISUALS/Workshop_Map.png — візуальна схема майстерні
- Open-Workshop.ps1   — PowerShell-скрипт для запуску майстерні
- Open-Workshop.cmd   — ярлик для швидкого запуску (двоклік)

=================================
Як користуватися:
1. Розпакуйте папку WORKSHOP_CREATOR у D:\CHECHA_CORE\
2. Для запуску:
   - Двоклік по Open-Workshop.cmd
   - або у PowerShell:
     .\Open-Workshop.ps1 -Root "D:\CHECHA_CORE" -OpenAll -OpenVisual -UseVSCode
3. Параметри:
   -OpenAll    — відкриє всі розділи (TECHNICAL/CREATIVE/RHYTHM/PHILOSOPHY)
   -OpenVisual — відкриє схему Workshop_Map.png
   -UseVSCode  — використати VS Code для відкриття файлів

=================================
ASCII-міні-мапа Майстерні
(вигляд зверху, символічно)

         [ Технічна Кузня ]
                |
[ Життєвий Ритм ] — (Серце Майстерні) — [ Філософське Полотно ]
                |
         [ Творча Лабораторія ]

=================================
Підпис: С.Ч.

---------------------------------
РЕЖИМИ ЗАПУСКУ (параметри)

-OpenAll       — відкриє TECHNICAL/CREATIVE/RHYTHM/PHILOSOPHY
-OpenVisual    — відкриє схему Workshop_Map.png
-UseVSCode     — використовувати VS Code для відкриття файлів
-ShowSlideshow — одразу запускати VISUALS\slideshow.html
-DailyRitual   — відкрити RHYTHM.md (фокус: 'День') + картку-вітання


[CmdletBinding()]
param(
  [string]$Root = "D:\CHECHA_CORE",
  [string]$Month = "",          # формат YYYY-MM; якщо порожнє — поточний місяць
  [string]$StatusFilter = "artifact,published"
)

$ErrorActionPreference = "Stop"
function Info { param([string]$m,[string]$c="") if ($c){ Microsoft.PowerShell.Utility\Write-Host $m -ForegroundColor $c } else { Microsoft.PowerShell.Utility\Write-Host $m } }

$ws = Join-Path $Root "WORKSHOP_CREATOR"
$reg = Join-Path $ws "ARTIFACTS.md"
$artsRoot = Join-Path $ws "ARTIFACTS"
if (-not (Test-Path $reg)) { throw "Не знайдено реєстр: $reg" }
if (-not (Test-Path $artsRoot)) { throw "Не знайдено теку артефактів: $artsRoot" }

# Обчислити місяць
if (-not $Month -or $Month.Trim() -eq "") {
  $Month = (Get-Date -Format "yyyy-MM")
}
$monthStart = [datetime]::ParseExact($Month + "-01", "yyyy-MM-dd", $null)
$monthEnd   = $monthStart.AddMonths(1).AddSeconds(-1)

$allowed = $StatusFilter.Split(",") | ForEach-Object { $_.Trim().ToLower() }

# Розпарсити таблицю реєстру
$lines = Get-Content -Path $reg -Encoding UTF8
$ids = @()
foreach ($ln in $lines) {
  if ($ln -match "^\s*\|\s*ART-\d{4}-\d{3}\s*\|") {
    $parts = $ln.Trim("|").Split("|").ForEach{ $_.Trim() }
    if ($parts.Count -ge 8) {
      $id = $parts[0]
      $status = $parts[3].ToLower()
      $dateStr = $parts[7]
      try { $d = [datetime]::ParseExact($dateStr, "yyyy-MM-dd", $null) } catch { continue }
      if ($allowed -contains $status -and $d -ge $monthStart -and $d -le $monthEnd) {
        $ids += $id
      }
    }
  }
}

if ($ids.Count -eq 0) { Write-Warning "Немає артефактів за $Month із статусом $StatusFilter"; return }

# Підготовка тимчасової теки та зип-архіву
$packsRoot = Join-Path $Root "C03_LOG\ARTIFACT_PACKS"
$tmpRoot   = Join-Path $Root "C03_LOG\TMP_PACK"
if (-not (Test-Path $packsRoot)) { New-Item -ItemType Directory -Path $packsRoot | Out-Null }
if (-not (Test-Path $tmpRoot)) { New-Item -ItemType Directory -Path $tmpRoot | Out-Null }

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$stage = Join-Path $tmpRoot ("pack_" + $Month + "_" + $ts)
New-Item -ItemType Directory -Path $stage | Out-Null

# Скопіювати вибрані артефакти
foreach ($id in $ids) {
  $src = Join-Path $artsRoot $id
  if (Test-Path $src) {
    $dst = Join-Path $stage $id
    Copy-Item -Path $src -Destination $dst -Recurse -Force
    # Згенерувати локальні CHECKSUMS для копії
    $files = Get-ChildItem -Path $dst -File -Recurse
    $lines = foreach ($f in $files) {
      $h = Get-FileHash -Path $f.FullName -Algorithm SHA256
      "{0}  {1}" -f $h.Hash, ($f.FullName.Substring($dst.Length+1))
    }
    Set-Content -Path (Join-Path $dst "CHECKSUMS.txt") -Value $lines -Encoding UTF8
  } else {
    Write-Warning "Пропуск — не знайдено теку артефакту: $src"
  }
}

# Створити архів
$zip = Join-Path $packsRoot ("pack_" + $Month + "_" + $ts + ".zip")
Add-Type -AssemblyName System.IO.Compression.FileSystem
if (Test-Path $zip) { Remove-Item $zip -Force }
[System.IO.Compression.ZipFile]::CreateFromDirectory($stage, $zip)

Info ("Створено пакунок артефактів: " + $zip) "Green"
$zip | Write-Output

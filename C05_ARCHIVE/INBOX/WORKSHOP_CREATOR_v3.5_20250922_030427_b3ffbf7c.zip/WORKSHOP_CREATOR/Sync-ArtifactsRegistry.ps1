
[CmdletBinding()]
param(
  [string]$Root = "D:\CHECHA_CORE"
)
$ErrorActionPreference = "Stop"
function Info { param([string]$m,[string]$c="") if ($c){ Microsoft.PowerShell.Utility\Write-Host $m -ForegroundColor $c } else { Microsoft.PowerShell.Utility\Write-Host $m } }

$ws = Join-Path $Root "WORKSHOP_CREATOR"
$reg = Join-Path $ws "ARTIFACTS.md"
$tools = Join-Path $Root "DAO-GOGS-MAIN\C11\tools"
$push  = Join-Path $tools "Push-GitBook.ps1"

if (-not (Test-Path $reg)) { throw "Не знайдено ARTIFACTS.md: $reg" }
if (-not (Test-Path $push)) { throw "Не знайдено Push-GitBook.ps1: $push" }
if (-not $env:GITBOOK_TOKEN -or -not $env:GITBOOK_SPACE_ID) { throw "Не задані GITBOOK_TOKEN / GITBOOK_SPACE_ID" }

Info ("GitBookPush: " + $reg) "Cyan"
pwsh -NoProfile -ExecutionPolicy Bypass -File $push `
  -Mode PageImport `
  -File $reg `
  -Token $env:GITBOOK_TOKEN `
  -SpaceId $env:GITBOOK_SPACE_ID
Info "Реєстр артефактів синхронізовано з GitBook." "Green"

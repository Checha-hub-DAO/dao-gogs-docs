# WeeklyScheduler Kit — Інструкція встановлення

## 📦 Склад пакета
- `Register-DAO-GOGS_MAP-Weekly.ps1` — реєстрація щотижневої задачі у Планувальнику Windows.
- `Run-DAO-GOGS_MAP-Validation.ps1` — запуск перевірки архівів DAO-GOGS_MAP з логуванням.
- `Unregister-DAO-GOGS_MAP-Weekly.ps1` — видалення задачі з Планувальника.

## ⚙️ Встановлення

1. Скопіюйте файли до вашої системи:
   - `Validate-DAO-GOGS_MAP.ps1` → `C:\CHECHA_CORE\C12\Vault\ARCHIVE\`
   - `Run-DAO-GOGS_MAP-Validation.ps1` → `C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\`
   - `Register-DAO-GOGS_MAP-Weekly.ps1` → `C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\`
   - `Unregister-DAO-GOGS_MAP-Weekly.ps1` → `C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\`

2. Зареєструйте задачу (за замовчуванням — неділя 09:00):
```powershell
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Register-DAO-GOGS_MAP-Weekly.ps1"
```

3. (Необов’язково) Вкажіть власні дні й час:
```powershell
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Register-DAO-GOGS_MAP-Weekly.ps1" `
  -DaysOfWeek Monday,Thursday -Hour 10 -Minute 30
```

## 🧪 Запуск вручну
Можна перевірити архіви без Планувальника:
```powershell
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Run-DAO-GOGS_MAP-Validation.ps1"
```

## 🗑 Видалення задачі
```powershell
pwsh -NoProfile -File "C:\CHECHA_CORE\C11\C11_AUTOMATION\tools\Unregister-DAO-GOGS_MAP-Weekly.ps1"
```

## 📂 Логування
Усі результати зберігаються у файлі:
```
C:\CHECHA_CORE\C03\LOG\releases_validate.log
```

---
© DAO-GOGS | С.Ч.

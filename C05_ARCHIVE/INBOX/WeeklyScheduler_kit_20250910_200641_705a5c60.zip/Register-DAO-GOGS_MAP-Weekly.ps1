<#
.SYNOPSIS
  Реєстрація щотижневої перевірки архівів DAO-GOGS_MAP.
.DESCRIPTION
  Створює Scheduled Task "\Checha\DAO-GOGS-MAP-Weekly", яка щотижня запускає
  Run-DAO-GOGS_MAP-Validation.ps1 (перевірка усіх DAO-GOGS_MAP_v*.zip у C12\Vault\ARCHIVE).
.PARAMETER Root
  Корінь CHECHA_CORE. За замовчуванням: C:\CHECHA_CORE
.PARAMETER DaysOfWeek
  Дні тижня (масив): Monday,Tuesday,...  За замовчуванням: Sunday
.PARAMETER Hour
  Година запуску (0-23). За замовчуванням: 9
.PARAMETER Minute
  Хвилина запуску (0-59). За замовчуванням: 0
#>
[CmdletBinding()]
Param(
  [string]$Root = "C:\CHECHA_CORE",
  [string[]]$DaysOfWeek = @("Sunday"),
  [int]$Hour = 9,
  [int]$Minute = 0
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$taskFolder = "\Checha"
$taskName   = "DAO-GOGS-MAP-Weekly"
$fullName   = "$taskFolder\$taskName"

# Переконаймося, що скрипт запуску існує
$runner = Join-Path $Root "C11\C11_AUTOMATION\tools\Run-DAO-GOGS_MAP-Validation.ps1"
if (-not (Test-Path $runner)) {
  throw "Не знайдено $runner. Спершу скопіюйте туди Run-DAO-GOGS_MAP-Validation.ps1"
}

# Побудова дії
$pwsh = "C:\Program Files\PowerShell\7\pwsh.exe"
$arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$runner`""
$action = New-ScheduledTaskAction -Execute $pwsh -Argument $arguments

# Тригер: щотижневий
$trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $DaysOfWeek -At ([datetime]::Today.Date.AddHours($Hour).AddMinutes($Minute).TimeOfDay)

# Налаштування: запуск з найвищими правами, збереження при пропуску
$principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -RunLevel Highest
$settings  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable

# Реєстрація
try {
  # Створимо теку \Checha якщо її немає
  $service = New-Object -ComObject "Schedule.Service"
  $service.Connect()
  $rootFolder = $service.GetFolder("\")
  try {
    $null = $service.GetFolder($taskFolder)
  } catch {
    $rootFolder.CreateFolder("Checha") | Out-Null
  }

  Register-ScheduledTask -TaskName $taskName -TaskPath $taskFolder -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
  Write-Host "✅ Зареєстровано задачу: $fullName (щотижня о $Hour:$('{0:D2}' -f $Minute), дні: $($DaysOfWeek -join ', '))"
} catch {
  Write-Error "Помилка реєстрації задачі $fullName: $($_.Exception.Message)"
  exit 1
}

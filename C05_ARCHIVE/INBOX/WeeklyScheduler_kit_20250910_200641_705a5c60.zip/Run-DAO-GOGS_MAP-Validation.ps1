<#
.SYNOPSIS
  Запуск валідації всіх архівів DAO-GOGS_MAP у C12\Vault\ARCHIVE з логуванням.
#>
[CmdletBinding()]
Param(
  [string]$Root = "C:\CHECHA_CORE"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$archiveDir = Join-Path $Root "C12\Vault\ARCHIVE"
$logPath    = Join-Path $Root "C03\LOG\releases_validate.log"
$validator  = Join-Path $archiveDir "Validate-DAO-GOGS_MAP.ps1"

function Write-RelLog {
  param([string]$Message,[string]$Level="INFO")
  $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
  $line = "$ts [$Level] $Message"
  $dir = Split-Path -Parent $logPath
  if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
  Add-Content -Path $logPath -Value $line
  if ($Level -eq "ERROR") {
      Write-Host $line -ForegroundColor Red
  } elseif ($Level -eq "WARN") {
      Write-Host $line -ForegroundColor Yellow
  } else {
      Write-Host $line -ForegroundColor Cyan
  }
}

Write-RelLog "=== DAO-GOGS_MAP Weekly Validation START ==="

if (-not (Test-Path $archiveDir)) {
  Write-RelLog "Немає каталогу архівів: $archiveDir" "ERROR"
  exit 1
}
if (-not (Test-Path $validator)) {
  Write-RelLog "Не знайдено скрипт валідатора: $validator" "ERROR"
  exit 1
}

$archives = Get-ChildItem -Path $archiveDir -Filter "DAO-GOGS_MAP_v*.zip" -File -ErrorAction SilentlyContinue
if (-not $archives) {
  Write-RelLog "Архівів не знайдено: DAO-GOGS_MAP_v*.zip" "WARN"
  exit 0
}

foreach ($zip in $archives) {
  Write-RelLog "Перевірка архіву: $($zip.FullName)"
  try {
    & pwsh -NoProfile -File $validator -ZipPath $zip.FullName
    if ($LASTEXITCODE -eq 0) {
      Write-RelLog "✅ OK: $($zip.Name)"
    } else {
      Write-RelLog "❌ FAIL ($LASTEXITCODE): $($zip.Name)" "ERROR"
    }
  } catch {
    Write-RelLog "❌ Виняток: $($zip.Name) — $($_.Exception.Message)" "ERROR"
  }
}

Write-RelLog "=== DAO-GOGS_MAP Weekly Validation END ==="

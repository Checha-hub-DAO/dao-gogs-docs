<#
.SYNOPSIS
  Видалення щотижневої задачі DAO-GOGS-MAP-Weekly.
#>
[CmdletBinding()]
Param()

$taskFolder = "\Checha"
$taskName   = "DAO-GOGS-MAP-Weekly"
$fullName   = "$taskFolder\$taskName"

try {
  Unregister-ScheduledTask -TaskName $taskName -TaskPath $taskFolder -Confirm:$false -ErrorAction Stop
  Write-Host "🗑 Видалено задачу: $fullName"
} catch {
  Write-Error "Не вдалося видалити $fullName: $($_.Exception.Message)"
  exit 1
}

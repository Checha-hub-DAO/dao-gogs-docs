# ARCHIVE_MAP.md (Template)
_Last generated: 2025-09-21 20:34:55Z UTC_

```mermaid
flowchart TD
    ROOT[C05/ARCHIVE]
    ROOT --> W[workflows_*]
    ROOT --> R[releases_*]
    ROOT --> D[datasets_*]
    ROOT --> M[media_*]
    ROOT --> S[scripts_cleanup_*]
    classDef pkg fill:#fef6e4,stroke:#333,stroke-width:1px
    W --> P1[package_workflows_YYYYMMDD_HHMMSS]:::pkg
    R --> P2[package_releases_YYYYMMDD_HHMMSS]:::pkg
    D --> P3[package_datasets_YYYYMMDD_HHMMSS]:::pkg
    M --> P4[package_media_YYYYMMDD_HHMMSS]:::pkg
    S --> P5[package_scripts_cleanup_YYYYMMDD_HHMMSS]:::pkg
    P1 --> L1[ARCHIVE_LOG.md]
    P1 --> C1[CHECKSUMS.txt]
    P1 --> J1[MANIFEST.json]
    P1 --> R1[DOCS/README.md]
    P1 --> T1[CONTENT/…]
    P1 --> E1[META/…]
    ROOT --> GLOG[ARCHIVE_LOG.md (global)]
    ROOT --> GIDX[ARCHIVE_INDEX.csv]
    ROOT --> GMAP[ARCHIVE_MAP.md]
    ROOT --> GSC[ARCHIVE_SCHEMA.yaml]
```

param(
    [string]$Root = "D:\CHECHA_CORE\C05\ARCHIVE",
    [string]$OutCsv = "ARCHIVE_INDEX.csv"
)
$items = @()
$dirs = Get-ChildItem $Root -Directory | Sort-Object LastWriteTime
foreach ($d in $dirs) {
    $checks = Test-Path (Join-Path $d.FullName "CHECKSUMS.txt")
    $manifest = Test-Path (Join-Path $d.FullName "MANIFEST.json")
    $log = Test-Path (Join-Path $d.FullName "ARCHIVE_LOG.md")
    $files = (Get-ChildItem $d.FullName -Recurse -File -ErrorAction SilentlyContinue)
    $bytes = ($files | Measure-Object Length -Sum).Sum
    $items += [pscustomobject]@{
        folder       = $d.Name
        category     = ($d.Name -split "_")[0]
        created_at   = ($d.Name -replace '.*_(\d{8}_\d{6}).*','$1')
        has_checks   = [bool]$checks
        has_manifest = [bool]$manifest
        has_log      = [bool]$log
        file_count   = ($files | Measure-Object).Count
        total_bytes  = [int64]$bytes
        path         = $d.FullName
        last_write   = $d.LastWriteTime
    }
}
$items | Export-Csv (Join-Path $Root $OutCsv) -NoTypeInformation -Encoding UTF8
Write-Host "✅ Index written: $(Join-Path $Root $OutCsv)"

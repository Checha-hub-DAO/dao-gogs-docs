param(
    [string]$Root = "D:\CHECHA_CORE\C05\ARCHIVE",
    [string]$OutMd = "ARCHIVE_MAP.md"
)
$csv = Join-Path $Root "ARCHIVE_INDEX.csv"
if (-not (Test-Path $csv)) {
    Write-Error "ARCHIVE_INDEX.csv not found. Run Build-ArchiveIndex.ps1 first."
    exit 1
}
$data = Import-Csv $csv
$now = Get-Date -Format "yyyy-MM-dd HH:mm:ss K"

$catGroups = $data | Group-Object category
$lines = @()
$lines += "# ARCHIVE_MAP.md"
$lines += "_Generated: $now_"
$lines += ""
$lines += "## Summary"
$lines += "- Total packages: {0}" -f ($data.Count)
foreach ($g in $catGroups) { $lines += "- {0}: {1}" -f ($g.Name, $g.Count) }
$lines += ""
$lines += "## By Category"
foreach ($g in $catGroups) {
    $lines += "### {0}" -f $g.Name
    $lines += ""
    $g.Group | Sort-Object last_write -Descending | ForEach-Object {
        $lines += "- **$($_.folder)** — files: $($_.file_count), size: $([math]::Round($_.total_bytes/1MB,2)) MB, checksums: $($_.has_checks), manifest: $($_.has_manifest)"
        $lines += "  - path: `$($_.path)`"
    }
    $lines += ""
}
$lines -join "`r`n" | Out-File (Join-Path $Root $OutMd) -Encoding UTF8
Write-Host "✅ Map written: $(Join-Path $Root $OutMd)"

# DAO-G13 Telegram Bot
Бот для зв’язку DAO-модулів.
# Головний файл бота

from handlers import start

if __name__ == '__main__':
    print('Запуск DAO-G13 бота...')
# Обробник стартової команди

def handle_start():
    return 'Вітаємо у DAO-G13!'
# DAO-MEDIA (публічна сторінка)

DAO-MEDIA — публічний медіа-контур DAO-GOGS: кампанії, дайджести, зворотний зв’язок, плейбуки.

## Швидка навігація
- **Огляд модуля** → [G35 — DAO-MEDIA](../dao-g/dao-g-mods/g35-dao-media/docs/_index.md)
- **Кампанії** → [Список і правила](../dao-g/dao-g-mods/g35-dao-media/docs/campaigns/_index.md)
- **Дайджести** → [Структура і випуски](../dao-g/dao-g-mods/g35-dao-media/docs/digest/_index.md)
- **Медіа-фідбек** → [Форми та аналітика](../dao-g/dao-g-mods/g35-dao-media/docs/feedback/_index.md)
- **Playbooks** → [Шаблони і ролі](../dao-g/dao-g-mods/g35-dao-media/docs/playbooks/_index.md)
- **Технічний контур** → [Пайплайни, CI/CD](../dao-g/dao-g-mods/g35-dao-media/docs/tech/_index.md)

> **Єдине джерело:** увесь зміст підтримується в модулі **G35**; ця сторінка — лише точка входу без копіювання матеріалів.

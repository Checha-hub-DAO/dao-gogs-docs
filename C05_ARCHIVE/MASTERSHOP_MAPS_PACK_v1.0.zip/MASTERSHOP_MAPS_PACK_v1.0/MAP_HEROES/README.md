# MAP_HEROES
Опис карти.

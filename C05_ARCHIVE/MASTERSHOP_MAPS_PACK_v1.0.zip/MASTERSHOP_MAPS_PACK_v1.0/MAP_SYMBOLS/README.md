# MAP_SYMBOLS
Опис карти.

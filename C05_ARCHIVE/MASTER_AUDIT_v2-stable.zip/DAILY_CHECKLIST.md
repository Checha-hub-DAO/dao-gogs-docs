
# DAILY_CHECKLIST.md — Щоденний цикл роботи з оновленнями

## 1. Завантаження
- Перевірити нові ZIP-и у **Завантаженнях**
- Розкласти:
  - `*-stable.zip` → `D:\CHECHA_CORE\_INBOX\`
  - `*-draft.zip` → `D:\CHECHA_CORE\WORKSHOP\DRAFTS\`

## 2. Запуск
- Подвійний клік:
  - `Apply-Update-STABLE.cmd` → тільки stable
  - `Apply-Update-DRAFT.cmd` → stable + draft

## 3. Контроль
- Переглянути лог: `_INBOX\UPDATES_LOG.md`
- Переконатися, що не було **SHA256 mismatch**

## 4. Архівація
- Використані пакети вже автоматично перенесені у `ARCHIVE\UPDATES\YYYYMMDD\`
- Раз на тиждень перевірити архів: за потреби зробити додатковий SHA256-зріз

## 5. Що пам’ятати
- Draft → лише для тестів, не змішувати з продуктивними блоками
- Stable → основний шлях інтеграції
- Якщо є сумніви у версії — запускати з `-WhatIf` у PowerShell

---
**С.Ч. — стандарт щоденної рутини Apply-Update**

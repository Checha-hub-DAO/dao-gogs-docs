
# README_AUDIT_FLOW.md — Єдина карта контролю (Day → Week → Month)

Цей документ об’єднує три рівні контролю системи **CHECHA_CORE**.

---

## 1. Щоденний (DAILY)
- Завантаження ZIP → `_INBOX` або `WORKSHOP\DRAFTS`
- Запуск `Apply-Update-STABLE.cmd` / `...-DRAFT.cmd`
- Перевірка логів `_INBOX\UPDATES_LOG.md`
- Автоматична архівація у `ARCHIVE\UPDATES\YYYYMMDD\`
- Контроль SHA256

📄 Детально: `DAILY_CHECKLIST.md`

---

## 2. Щотижневий (WEEKLY)
- Перевірка архівів та бекапів (SHA256 вибірково)
- Аналіз `_INBOX\UPDATES_LOG.md` і `EVENING_LOG.md`
- Перевірка пакетів та CHANGELOG
- Очищення `WORKSHOP\INBOX_EXTRACTS\`
- Контроль Task Scheduler (SOD / EveningBackup)

📄 Детально: `WEEKLY_CHECKLIST.md`

---

## 3. Щомісячний (MONTHLY)
- Інвентаризація ключових блоків (`C01_PARAMETERS`, `C06_FOCUS`, …)
- Оцінка росту архівів і статистики (`C07_ANALYTICS`)
- Повна перевірка логів та SHA256 за вибіркою
- Тест `Apply-Update.ps1 -WhatIf`
- План оптимізації: DRAFT → STABLE, оновлення MASTER-наборів
- Повний TECH_TOOLS_PACK + зовнішній резерв

📄 Детально: `MONTHLY_AUDIT.md`

---

## 📊 Узагальнена схема
```mermaid
flowchart TD
    A[Щоденний контроль] --> B[Щотижневий контроль] --> C[Щомісячний аудит]

    subgraph Daily
      A1[Завантаження ZIP] --> A2[Запуск Apply-Update]
      A2 --> A3[Лог + SHA256]
      A3 --> A4[Архівування]
    end

    subgraph Weekly
      B1[Перевірка архівів/бекапів]
      B2[Контроль логів]
      B3[Перевірка CHANGELOG]
      B4[Task Scheduler]
      B1 --> B2 --> B3 --> B4
    end

    subgraph Monthly
      C1[Інвентаризація блоків]
      C2[Аналіз об’ємів]
      C3[Перевірка автоматизації]
      C4[План оптимізації]
      C5[Повний TECH_TOOLS_PACK]
      C1 --> C2 --> C3 --> C4 --> C5
    end

    A --> B --> C
```
---

**С.Ч. — інтегрований стандарт контролю**

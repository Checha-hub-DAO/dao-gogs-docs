
<#
.SYNOPSIS
  Apply-Update.ps1 — централізоване застосування оновлень з _INBOX (С.Ч.)

.DESCRIPTION
  - Підбирає ZIP-пакети з D:\CHECHA_CORE\_INBOX
  - Розрізняє рівень зрілості за суфіксами в назві: "-stable.zip" / "-draft.zip"
  - (За замовчуванням) застосовує лише STABLE; DRAFT → переносить у WORKSHOP\DRAFTS
  - Вміє перевіряти SHA256, якщо поруч лежить .sha256
  - Розкладає файли по цільових блоках залежно від типу пакета:
      * CHECHA_TOOLS_ONECLICK*     → TOOLS
      * CHECHA_TOOLS_ONECLICK_v2*  → TOOLS
      * CHECHA_TOOLS_ONECLICK_v2_1 → TOOLS
      * AUTO-SCHEDULE*             → TOOLS\ScheduleProfiles
      * EVENING_BACKUP*            → TOOLS (xml теж у TOOLS)
      * PARAMETERS_UPDATE*         → C01_PARAMETERS
      * Інакше                     → WORKSHOP\INBOX_EXTRACTS\<ім'я пакета>
  - Після успіху переміщує ZIP (+ .sha256) у ARCHIVE\UPDATES\YYYYMMDD
  - Веде лог: _INBOX\UPDATES_LOG.md

.PARAMETER CoreRoot
  Корінь CHECHA_CORE. Типово: D:\CHECHA_CORE

.PARAMETER Inbox
  Каталог вхідних пакетів. Типово: D:\CHECHA_CORE\_INBOX

.PARAMETER ArchiveUpdates
  Куди складати використані архіви. Типово: D:\CHECHA_CORE\ARCHIVE\UPDATES

.PARAMETER DraftsDir
  Куди перекладати DRAFT-пакети. Типово: D:\CHECHA_CORE\WORKSHOP\DRAFTS

.PARAMETER ApplyDraft
  Дозволити застосування -draft.zip (інакше — тільки -stable.zip).

.PARAMETER WhatIf
  Сухий прогін (лише логіка, без змін).

.EXAMPLE
  pwsh -NoProfile -ExecutionPolicy Bypass -File D:\CHECHA_CORE\TOOLS\Apply-Update.ps1
#>

[CmdletBinding(SupportsShouldProcess=$true)]
param(
  [string]$CoreRoot       = "D:\CHECHA_CORE",
  [string]$Inbox          = "D:\CHECHA_CORE\_INBOX",
  [string]$ArchiveUpdates = "D:\CHECHA_CORE\ARCHIVE\UPDATES",
  [string]$DraftsDir      = "D:\CHECHA_CORE\WORKSHOP\DRAFTS",
  [switch]$ApplyDraft,
  [switch]$WhatIf
)

function Write-Info($m){ Write-Host "[INFO] $m" -ForegroundColor Cyan }
function Write-Ok($m){ Write-Host "[ OK ] $m" -ForegroundColor Green }
function Write-Warn($m){ Write-Warning $m }
function Write-Err($m){ Write-Host "[ERR ] $m" -ForegroundColor Red }

$ErrorActionPreference = "Stop"

# Ensure dirs
foreach ($d in @($Inbox, $ArchiveUpdates, $DraftsDir)) {
  if (-not (Test-Path -LiteralPath $d)) {
    if ($WhatIf) { Write-Info "WhatIf: створив би $d" }
    else { New-Item -ItemType Directory -Path $d -Force | Out-Null }
  }
}

# Log file
$log = Join-Path $Inbox "UPDATES_LOG.md"
$ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
Add-Content -LiteralPath $log -Value "`n## $ts — Apply-Update run"

# Collect zips
$zips = Get-ChildItem -LiteralPath $Inbox -Filter *.zip -File | Sort-Object Name
if (-not $zips) {
  Write-Info "Немає ZIP у _INBOX"
  Add-Content -LiteralPath $log -Value "- No ZIPs found"
  exit 0
}

# Helper: verify SHA256 if .sha256 exists
function Test-Sha256Match($zipPath) {
  $shaFile = "$zipPath.sha256"
  if (-not (Test-Path -LiteralPath $shaFile)) { return $true } # nothing to verify
  try {
    $expected = ((Get-Content -LiteralPath $shaFile -TotalCount 1) -split '\s+')[0].ToLower()
    $actual = (Get-FileHash -Algorithm SHA256 -Path $zipPath).Hash.ToLower()
    return ($expected -eq $actual)
  } catch {
    Write-Warn "Не вдалося перевірити SHA256: $($_.Exception.Message)"
    return $false
  }
}

# Decide target folder by filename
function Get-TargetPath($name) {
  if ($name -match '^CHECHA_TOOLS_ONECLICK') { return (Join-Path $CoreRoot 'TOOLS') }
  if ($name -match '^AUTO-SCHEDULE')        { return (Join-Path $CoreRoot 'TOOLS\ScheduleProfiles') }
  if ($name -match '^EVENING_BACKUP')       { return (Join-Path $CoreRoot 'TOOLS') }
  if ($name -match '^PARAMETERS_UPDATE')    { return (Join-Path $CoreRoot 'C01_PARAMETERS') }
  # default
  return (Join-Path $CoreRoot ("WORKSHOP\INBOX_EXTRACTS\" + [IO.Path]::GetFileNameWithoutExtension($name)))
}

# Processing loop
foreach ($zip in $zips) {
  $name = $zip.Name
  $full = $zip.FullName
  $isDraft  = ($name -like '*-draft.zip')
  $isStable = ($name -like '*-stable.zip') -or -not ($isDraft)  # якщо без суфіксу — вважаємо stable

  if ($isDraft -and -not $ApplyDraft) {
    Write-Info "$name позначено як DRAFT → переношу в $DraftsDir"
    Add-Content -LiteralPath $log -Value "- DRAFT moved → $name"
    if (-not $WhatIf) {
      Move-Item -LiteralPath $full -Destination (Join-Path $DraftsDir $name) -Force
      if (Test-Path "$full.sha256") {
        Move-Item -LiteralPath "$full.sha256" -Destination (Join-Path $DraftsDir ("{0}.sha256" -f $name)) -Force
      }
    }
    continue
  }

  # Verify SHA if present
  if (-not (Test-Sha256Match -zipPath $full)) {
    Write-Err "$name: SHA256 mismatch → пропуск"
    Add-Content -LiteralPath $log -Value "- FAIL sha256: $name"
    continue
  }

  # Ensure target dir
  $target = Get-TargetPath -name $name
  if (-not (Test-Path -LiteralPath $target)) {
    if ($WhatIf) { Write-Info "WhatIf: створив би $target" }
    else { New-Item -ItemType Directory -Path $target -Force | Out-Null }
  }

  # Expand-Archive
  Write-Info ("Застосовую → {0} → {1}" -f $name, $target)
  if ($WhatIf) {
    Add-Content -LiteralPath $log -Value "- APPLY (whatif): $name → $target"
  } else {
    try {
      # очистка тимчасової папки
      $tmp = Join-Path $env:TEMP ("APPLY_" + [guid]::NewGuid().ToString("N"))
      New-Item -ItemType Directory -Path $tmp -Force | Out-Null
      Expand-Archive -LiteralPath $full -DestinationPath $tmp -Force

      # Спеціальні правила розкладки для відомих пакетів
      if ($name -match '^AUTO-SCHEDULE') {
        # .xml -> TOOLS\ScheduleProfiles
        $schedDir = Join-Path $CoreRoot 'TOOLS\ScheduleProfiles'
        if (-not (Test-Path $schedDir)) { New-Item -ItemType Directory -Path $schedDir -Force | Out-Null }
        Get-ChildItem -LiteralPath $tmp -Filter *.xml -File -Recurse | ForEach-Object {
          Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $schedDir $_.Name) -Force
        }
        # інше → PARAMETERS (README)
        $paramsDir = Join-Path $CoreRoot 'C01_PARAMETERS'
        if (-not (Test-Path $paramsDir)) { New-Item -ItemType Directory -Path $paramsDir -Force | Out-Null }
        Get-ChildItem -LiteralPath $tmp -Exclude *.xml -File -Recurse | ForEach-Object {
          Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $paramsDir $_.Name) -Force
        }
      } elseif ($name -match '^EVENING_BACKUP') {
        # .ps1 + .xml → TOOLS
        Get-ChildItem -LiteralPath $tmp -File -Recurse | ForEach-Object {
          Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $target $_.Name) -Force
        }
      } else {
        # За замовчуванням — просто розпаковуємо контент у target (плоско)
        Get-ChildItem -LiteralPath $tmp -File -Recurse | ForEach-Object {
          Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $target $_.Name) -Force
        }
      }

      # Архівуємо використані пакети
      $dayDir = Join-Path $ArchiveUpdates (Get-Date -Format "yyyyMMdd")
      if (-not (Test-Path -LiteralPath $dayDir)) { New-Item -ItemType Directory -Path $dayDir -Force | Out-Null }
      Move-Item -LiteralPath $full -Destination (Join-Path $dayDir $name) -Force
      if (Test-Path "$full.sha256") {
        Move-Item -LiteralPath "$full.sha256" -Destination (Join-Path $dayDir ("{0}.sha256" -f $name)) -Force
      }

      Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue

      Write-Ok "OK: $name застосовано"
      Add-Content -LiteralPath $log -Value "- OK: $name → $target"
    } catch {
      Write-Err "ERR applying $name: $($_.Exception.Message)"
      Add-Content -LiteralPath $log -Value "- ERR: $name — $($_.Exception.Message)"
    }
  }
}

Write-Ok "Готово. Лог: $log"
exit 0


# UPDATE_APPLY_FLOW — Стандарт потоку оновлень

## 1. Завантаження
- Усі згенеровані ZIP-и (STABLE або DRAFT) потрапляють у **Завантаження**.
- Ти вручну переносиш їх у:
  - `D:\CHECHA_CORE\_INBOX` → якщо **STABLE**
  - `D:\CHECHA_CORE\WORKSHOP\DRAFTS` → якщо **DRAFT**

## 2. Запуск централізатора
- Для STABLE-пакетів: `Apply-Update-STABLE.cmd`
- Для STABLE + DRAFT: `Apply-Update-DRAFT.cmd`
- Обидва запускають `Apply-Update.ps1` з відповідними параметрами.

## 3. Дії сценарію
- Перевіряє **SHA256** (якщо є).
- Розкладає файли у відповідні блоки:
  - `CHECHA_TOOLS_ONECLICK*` → `TOOLS\`
  - `AUTO-SCHEDULE*` → `TOOLS\ScheduleProfiles\` (+ README → `C01_PARAMETERS`)
  - `EVENING_BACKUP*` → `TOOLS\`
  - `PARAMETERS_UPDATE*` → `C01_PARAMETERS\`
  - інші → `WORKSHOP\INBOX_EXTRACTS\<ім’я>`
- Пакети переміщує у `ARCHIVE\UPDATES\YYYYMMDD\`.

## 4. Лог
- Всі дії фіксуються у `_INBOX\UPDATES_LOG.md`.
- Кожен прогін має власний timestamp.

## 5. Рівні зрілості
- `*-draft.zip` → чернетки (WORKSHOP/DRAFTS).
- `*-stable.zip` або без суфіксу → застосовуються.
- Можна застосувати draft-пакети вручну, якщо додати прапор `-ApplyDraft`.

---

## 📊 Схема (Mermaid)
```mermaid
flowchart LR
    subgraph User["Завантаження користувачем"]
      DRAFT[ZIP -draft]:::draft
      STABLE[ZIP -stable]:::stable
    end

    INBOX[_INBOX]:::core
    DRAFTS[WORKSHOP/DRAFTS]:::work
    APPLY[Apply-Update.ps1]:::tool
    SCHED[ScheduleProfiles]:::tool
    TOOLS[TOOLS]:::core
    PARAMS[C01_PARAMETERS]:::core
    EXTRACTS[WORKSHOP/INBOX_EXTRACTS/*]:::work
    ARCHUPD[ARCHIVE/UPDATES/YYMMDD]:::archive
    LOG[_INBOX/UPDATES_LOG.md]:::log

    DRAFT -->|ручне переміщення| DRAFTS
    STABLE -->|ручне переміщення| INBOX

    INBOX -->|ярлик .cmd| APPLY
    APPLY -->|перевірка SHA256| LOG
    APPLY -->|AUTO-SCHEDULE*.xml| SCHED
    APPLY -->|CHECHA_TOOLS_ONECLICK*| TOOLS
    APPLY -->|EVENING_BACKUP*| TOOLS
    APPLY -->|PARAMETERS_UPDATE*| PARAMS
    APPLY -->|інші| EXTRACTS
    APPLY -->|перемістити ZIP(.sha256)| ARCHUPD

    classDef core fill:#e8f4ff,stroke:#2b6cb0,color:#1a365d;
    classDef work fill:#fffbea,stroke:#b7791f,color:#7b341e;
    classDef tool fill:#e6fffa,stroke:#2c7a7b,color:#234e52;
    classDef archive fill:#f3e8ff,stroke:#6b46c1,color:#44337a;
    classDef log fill:#edf2f7,stroke:#4a5568,color:#2d3748;
    classDef draft fill:#ffe4e6,stroke:#e11d48,color:#9f1239;
    classDef stable fill:#dcfce7,stroke:#16a34a,color:#166534;
```

## 📊 ASCII-схема (резерв)
```
[ZIP -draft]        [ZIP -stable]
     |                   |
     v                   v
WORKSHOP\DRAFTS      _INBOX
                          |
                      (Apply-Update.ps1)
                          |
               +----------+-----------+-------------------+-------------+
               |          |           |                   |             |
           TOOLS    TOOLS\Schedule  C01_PARAMETERS   WORKSHOP\      _INBOX\
     (ONECLICK*,         Profiles   (PARAMETERS_     INBOX_EXTRACTS  UPDATES_LOG.md
      EVENING_*)      (AUTO-SCHED*)  UPDATE*)        (інші)
               \__________________________/ 
                         |
             ARCHIVE\UPDATES\YYYYMMDD  (переміщення застосованих ZIP + .sha256)
```

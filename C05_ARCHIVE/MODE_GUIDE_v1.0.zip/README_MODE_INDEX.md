# 📑 README_MODE_INDEX.md
*CheCha System — навігація по режимах*
**Автор:** С.Ч.
**Дата:** 24.09.2025

## 🎯 Призначення
Цей документ — **швидкий навігатор по режимах використання пристроїв**.

---

## 📱 Смартфон — «Вхідні двері»
📂 [SMARTPHONE_MODE.md](SMARTPHONE_MODE.md)

## 📖 Планшет — «Огляд і візуалізація»
📂 [TABLET_MODE.md](TABLET_MODE.md)

## 💻 Ноутбук — «Майстерня та архів»
📂 [LAPTOP_MODE.md](LAPTOP_MODE.md)

---

## 🔗 Схема режимів (Mermaid)
```mermaid
flowchart LR
    A[📱 Смартфон<br/>Вхідні двері] 
    B[📖 Планшет<br/>Огляд і візуалізація]
    C[💻 Ноутбук<br/>Майстерня та архів]

    A --> B --> C
    C --> A
    C --> B

    classDef mode fill:#f5f5f5,stroke:#999,stroke-width:1px,color:#111;
    class A,B,C mode;
```

---

## 🔗 ASCII-схема режимів
```
   [📱 Смартфон]
          |
          v
   [📖 Планшет]
          |
          v
   [💻 Ноутбук]
          ^
         / \
        /   v
   [📱]   [📖]
```

# QUESTS — Learning by Doing

## Outdoors
1) **Color Hunt** — знайди 5 предметів і назви їхній колір англійською.
2) **Animal Watch** — назви 5 тварин, утвори речення *I see a …*.

## City
1) **Mini‑Shop** — купи воду/хліб, скажи *I would like …* (рольова гра).
2) **Ask & Find** — запитай дорогу: *Where is…?* (безпеки дотримуватися!).

## Home
1) **Label It** — наліпки на предмети: *door, table, window…*
2) **My Day** — опиши день у 5–7 реченнях: *I wake up…*

# EVENING_BACKUP — вечірній резерв (20:00)

## Логіка (без захаращення)
- Бере **лише останні 2** архіви з:
  - `D:\CHECHA_CORE\ARCHIVE\`
  - `D:\CHECHA_CORE_SYNC\TOOLS\`
- Копіює їх (разом із `.sha256`) у `D:\CHECHA_BACKUP\DAILY\YYYYMMDD\`.
- Підтримує **Retention**: за замовчуванням зберігає **14 днів** щоденних бекапів.
- Пише лог у `D:\CHECHA_BACKUP\EVENING_LOG.md`.

## Ручний запуск
```powershell
pwsh -NoProfile -ExecutionPolicy Bypass `
  -File "D:\CHECHA_CORE\TOOLS\Evening-Backup.ps1" `
  -KeepLatest 2 -RetainDays 14
```

## Імпорт задачі в Планувальник (20:00 щодня)
1. Відкрий **Task Scheduler** → **Action → Import Task…**  
2. Обери `CHECHA_EveningBackup.xml`  
3. Перевір шлях до `pwsh.exe` та збережи

## Налаштування
- Змінити кількість архівів: `-KeepLatest 3` (тощо)
- Змінити період збереження: `-RetainDays 7` або `0` (не чистити)

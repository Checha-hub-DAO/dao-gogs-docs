
# TECH_SETUP_STARTER_PACK — Інсталяційний пакет (С.Ч.)

Цей пакет містить скрипти та пам’ятки для технічного циклу «Смартфон → Ноутбук → Планшет»,
а також збірку і перевірку тех-архівів з інструментами.

## Склад пакета
- `Build-TechZip.ps1` — збірка технічного ZIP-пакета з CHECHA_CORE (фільтр за розширеннями, SHA256, синхронізація у SYNC\TOOLS).
- `Verify-WorkflowPack.ps1` — перевірка SHA256 для `SCRIPT_WORKFLOW_PACK.zip`.
- `Verify-AndSync-WorkflowPack.ps1` — перевірка SHA256 + авто-копіювання в `CHECHA_CORE_SYNC\DOCS` (з датованою копією).
- `SCRIPT_WORKFLOW.pdf` / `SCRIPT_WORKFLOW.png` — повна пам’ятка (PDF/PNG).
- `SCRIPT_WORKFLOW_MINI.png` / `SCRIPT_WORKFLOW_MINI_DARK.png` — міні-стікери (світлий/темний).
- `SCRIPT_WORKFLOW_PACK.zip` + `SCRIPT_WORKFLOW_PACK.sha256` — зібраний архів із усіма видами пам’ятки.

## Рекомендоване розміщення на ноуті
```
D:\CHECHA_CORE\TOOLS\Build-TechZip.ps1
D:\CHECHA_CORE\TOOLS\Verify-WorkflowPack.ps1
D:\CHECHA_CORE\TOOLS\Verify-AndSync-WorkflowPack.ps1
D:\CHECHA_CORE_SYNC\DOCS\SCRIPT_WORKFLOW_* (png/pdf/zip/sha256)
```
> За потреби створіть папки `D:\CHECHA_CORE\ARCHIVE` та `D:\CHECHA_CORE_SYNC\{DOCS,TOOLS}`.

## Швидкий старт

1) **Розмістити скрипти**
Скопіюйте три `.ps1` у `D:\CHECHA_CORE\TOOLS`.

2) **Оновити пам’ятки**
Скопіюйте файли `SCRIPT_WORKFLOW_*` у `D:\CHECHA_CORE_SYNC\DOCS`.

3) **Перевірити пам’ятковий ZIP**
```powershell
cd D:\CHECHA_CORE_SYNC\DOCS
.\Verify-WorkflowPack.ps1 -ZipPath .\SCRIPT_WORKFLOW_PACK.zip -ShaFile .\SCRIPT_WORKFLOW_PACK.sha256
```
(Або відразу з авто-синком у DOCS)
```powershell
.\Verify-AndSync-WorkflowPack.ps1 `
  -ZipPath ".\SCRIPT_WORKFLOW_PACK.zip" `
  -ShaFile ".\SCRIPT_WORKFLOW_PACK.sha256" `
  -SyncRoot "D:\CHECHA_CORE_SYNC" -SubFolder "DOCS" -CreateDatedCopy
```

4) **Зібрати TECH_TOOLS_PACK з інструментами**
```powershell
pwsh -NoProfile -ExecutionPolicy Bypass `
  -File "D:\CHECHA_CORE\TOOLS\Build-TechZip.ps1" `
  -Root "D:\CHECHA_CORE" `
  -OutArchive "D:\CHECHA_CORE\ARCHIVE" `
  -SyncRoot "D:\CHECHA_CORE_SYNC" `
  -SyncSubFolder "TOOLS" `
  -CreateDatedCopy -OpenAfter
```

## Примітки
- Ролі гаджетів: **Смартфон — чернетки**, **Ноутбук — збірка/тест**, **Планшет — документація/візуал**.
- Стандарти шрифтів для документів: використовуй кириличні (напр. *DejaVu Sans*, *Arial Unicode*).
- Ведеться лог у `D:\CHECHA_CORE_SYNC\TOOLS\TOOLS_LOG.md` та `D:\CHECHA_CORE_SYNC\DOCS\SCRIPT_LOG.md`.
- За потреби змінюй `-IncludeSubfolders` / `-IncludeExt` у `Build-TechZip.ps1` під конкретні сценарії.

---
С.Ч.


# CHECHA_TOOLS_ONECLICK_v2.1 — Оновлений пакет (із перевіркою Evening Backup)

## Склад
- `Build-TechZip_v2.ps1` — збірка TECH_TOOLS_PACK (повний/HOT, аналіз, VERSION.txt, CHANGELOG).
- `Start-of-Day_v2.1.ps1` — ранковий цикл із перевіркою **вчорашнього Evening Backup** та прапорцями `-Hot`, `-RunPSAnalysis`, `-StrictBackupCheck`.
- `README_Start-of-Day_v2.1.md` — інструкція для v2.1.

## Запуск (приклади)
### Повна збірка з аналізом
```powershell
pwsh -NoProfile -ExecutionPolicy Bypass `
  -File "D:\CHECHA_CORE\TOOLS\Build-TechZip_v2.ps1" `
  -Root "D:\CHECHA_CORE" -OutArchive "D:\CHECHA_CORE\ARCHIVE" `
  -SyncRoot "D:\CHECHA_CORE_SYNC" -SyncSubFolder "TOOLS" `
  -RunPSAnalysis -CreateDatedCopy -OpenAfter
```

### HOT-режим
```powershell
pwsh -NoProfile -ExecutionPolicy Bypass `
  -File "D:\CHECHA_CORE\TOOLS\Build-TechZip_v2.ps1" `
  -Root "D:\CHECHA_CORE" -OutArchive "D:\CHECHA_CORE\ARCHIVE" `
  -SyncRoot "D:\CHECHA_CORE_SYNC" -SyncSubFolder "TOOLS" `
  -Hot -CreateDatedCopy
```

### Ранковий цикл v2.1 (з перевіркою Evening Backup)
```powershell
pwsh -NoProfile -ExecutionPolicy Bypass `
  -File "D:\CHECHA_CORE\TOOLS\Start-of-Day_v2.1.ps1" `
  -CoreRoot "D:\CHECHA_CORE" -SyncRoot "D:\CHECHA_CORE_SYNC" `
  -ArchiveDir "D:\CHECHA_CORE\ARCHIVE" -BackupDailyRoot "D:\CHECHA_BACKUP\DAILY" `
  -BuildDatedCopy -Hot -RunPSAnalysis
```

### Строгий режим (зупинка, якщо немає учорашнього бекапу)
```powershell
pwsh -NoProfile -ExecutionPolicy Bypass `
  -File "D:\CHECHA_CORE\TOOLS\Start-of-Day_v2.1.ps1" -StrictBackupCheck
```

## Логи
- `SYNC\DOCS\SOD_LOG.md` — ранкові цикли.
- `SYNC\TOOLS\TOOLS_LOG.md` — збірки інструментів.
- `SYNC\TOOLS\TOOLS_CHANGELOG.md` — історія версій пакетів.

---
С.Ч.

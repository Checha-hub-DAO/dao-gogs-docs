
# RHYTHM — Mermaid схема

Вставка для GitBook / Markdown-сторінок.

```mermaid
flowchart LR
    A[APPLY — Оновлення] --> B[DAILY — Щоденний контроль]
    B --> C[WEEKLY — Щотижневий аудит]
    C --> D[MONTHLY — Повний аудит]
    D --> A

    subgraph APPLY
      A1[Apply-Update.ps1]
      A2[MASTER_UPDATE_APPLY]
      A --> A1 --> A2
    end

    subgraph AUDIT
      B1[DAILY_CHECKLIST]
      C1[WEEKLY_CHECKLIST]
      D1[MONTHLY_AUDIT]
      B --> B1
      C --> C1
      D --> D1
    end
```

# TECH_REPORT.md — Ритм-пакети

Технічний огляд ZIPів і пов’язаних файлів.

## 📊 Таблиця файлів

| Файл                         |   Розмір (байт) | SHA256                                                           |
|:-----------------------------|----------------:|:-----------------------------------------------------------------|
| RHYTHM_GUIDE-stable.zip      |            2075 | 65533faa085f35555dc3c2a5a052815a953ec2f745ddff895a55361f7b538a8b |
| RHYTHM_GUIDE-stable.sha256   |              90 | 7bbbe477ba23fe264242c8d1844ff52a06556bf5afff7fef30464c5eb859bffe |
| RHYTHM_VISUAL_PACK.zip       |          119460 | 9abfff631075fb4517c3d4b0a8f5946c7cd7a7fc667da8f5fd2657af5587faaf |
| RHYTHM_VISUAL_PACK.sha256    |              89 | 8bc018c32c08c60ad1fff30227c55144ec6bffb62ce25f71a649cb544baaf6f9 |
| RHYTHM_GUIDE.pdf             |            2375 | e8d2f607d41356eacea139885ba4a6f0ae414f816f95ee23fbbdb13174b8bc2d |
| RHYTHM_POSTER.pdf            |            2375 | 4e11580d70dc0abc2831e50b42044efdd60cc61692704d0ac1da2b434673b901 |
| RHYTHM_FULL_PACK_v1.1.zip    |          249005 | d25a683db58551e3cf9a8b997eaeab072d6c0f6bc85c5a9fc2f7bc096d33656d |
| RHYTHM_FULL_PACK_v1.1.sha256 |              92 | b3841339c8dd1de807f11a82b0986d6115417d8980dd9aa76171501e6832a26d |
| RHYTHM_MERMAID.md            |             583 | 651029fe3929c3e6b81a44ee0bde68ec7872bb77a37610b9fea7c2f9c5b93550 |
| README_RHYTHM_FULL_PACK.md   |            2239 | c39244fe81d635de4af9550df64ede65d05a47509a16e117e2d393dd85e9b397 |

## 📌 Коментарі
- Основний робочий пакет: **RHYTHM_FULL_PACK_v1.1.zip**
- Резерв: GUIDE-stable, VISUAL_PACK
- Додатково: PDF/POSTER для друку, MERMAID для GitBook

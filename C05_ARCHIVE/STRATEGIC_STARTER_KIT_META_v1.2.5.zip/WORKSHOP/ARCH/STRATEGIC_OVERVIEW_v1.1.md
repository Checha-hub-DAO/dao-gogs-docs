# 🗺️ STRATEGIC_OVERVIEW v1.1 — Єдина стратегічна мапа (з G-модулями)

*Оновлення: додано явні вузли G-модулів і їхні виходи.*

```mermaid
flowchart TD
    subgraph L1[Вхід]
      A[Інформаційний хаос буття] --> A1[MOC: лог-рядок / CSV]
    end

    subgraph L2[Майстерні — кузні артефактів]
      C1[Творча]:::w
      C2[Ідей]:::w
      C3[Просвітництво]:::w
      C4[Арсенал]:::w
      C5[Організація]:::w
      C6[Інструменти]:::w
      C7[Каталог]:::w
      C8[Культурні вузли]:::w
    end

    subgraph L3[Вихід — цифрові артефакти]
      E1[README / Карти / Візуали / Скрипти / ZIP]
      E2[(ARTIFACT_ID)]
    end

    subgraph L4[DAO-GOGS — G-модулі]
      G1[G-01 GUIDES_CORE]
      G2[G-02 MEDIA_PIPE]
      G3[G-03 KNOWLEDGE_HOUSE]
      G4[G-04 NATIONAL_LIBRARY]
      G5[G-05 RESILIENCE_INSTITUTE]
      G6[G-06 ODESSA_SHIELD]
      G7[G-07 ANALYTICS_CORE]
      G8[G-08 ARCHIVE_GATE]
    end

    subgraph L5[Вузли/виходи]
      F1[DAO-GUIDES]
      F2[DAO-MEDIA]
      F3[Дім Знань]
      F4[Нац. бібліотека]
      F5[Програми/Протоколи]
      F6[Події/Партнерства]
      F7[C07 Аналітика]
      F8[C05 Архів]
    end

    subgraph L6[Ритми та Звітність]
      R1[Добовий/Тижневий/Місячний/Стратегічний]
      Z1[STRATEGIC_REPORTS]
    end

    A1 --> C1 & C2 & C3 & C4 & C5 & C6 & C7 & C8
    C1 --> E1 --> E2
    C2 --> E1
    C3 --> E1
    C4 --> E1
    C5 --> E1
    C6 --> E1
    C7 --> E1
    C8 --> E1

    E2 --> G1 & G2 & G3 & G4 & G5 & G6 & G7 & G8
    G1 --> F1
    G2 --> F2
    G3 --> F3
    G4 --> F4
    G5 --> F5
    G6 --> F6
    G7 --> F7
    G8 --> F8

    R1 --> A
    Z1 --> F1 & F2 & F3 & F4 & F5 & F6 & F7 & F8

    classDef w fill:#222,stroke:#0f0,color:#fff;
```

# 🗺️ STRATEGIC_OVERVIEW v1.0 — Єдина мапа

*Архітектура → Ритми → Звітність (єдиний погляд).*

## Mermaid — Unified Map
```mermaid
flowchart TD
  subgraph L1[Вхід]
    A[Інформаційний хаос] --> A1[MOC: лог / CSV]
  end
  subgraph L2[Майстерні]
    C1[Творча]; C2[Ідей]; C3[Просвітництво]; C4[Арсенал]
    C5[Організація]; C6[Інструменти]; C7[Каталог]; C8[Культурні вузли]
  end
  subgraph L3[Артефакти]
    E1[README/Карти/Візуали/Скрипти/ZIP] --> E2[(ARTIFACT_ID)]
  end
  subgraph L4[DAO-GOGS]
    F1[DAO-GUIDES]; F2[DAO-MEDIA]; F3[DAO-модулі]; F4[Дім Знань]; F5[Нац. бібліотека]; F6[Щит-4 Одеса]
  end
  subgraph L5[Ритми]
    R1[Day]; R2[Week]; R3[Month]; R4[Strategic]
  end
  subgraph L6[Звітність]
    Z1[REPORT_TEMPLATE]; Z2[WEEK/MONTH Reports]
  end

  A1 --> C1 & C2 & C3 & C4 & C5 & C6 & C7 & C8
  C1 --> E1; C2 --> E1; C3 --> E1; C4 --> E1; C5 --> E1; C6 --> E1; C7 --> E1; C8 --> E1
  E2 --> F1 & F2 & F3 & F4 & F5 & F6

  R1 --> A
  R2 --> C5
  R3 --> F3
  R4 --> F4

  Z1 --> F1 & F2 & F3 & F4 & F5 & F6
```
✍️ *Автор: С.Ч.*

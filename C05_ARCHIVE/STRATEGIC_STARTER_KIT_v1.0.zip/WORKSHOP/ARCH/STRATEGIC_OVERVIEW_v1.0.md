# 🗺️ STRATEGIC_OVERVIEW v1.0 — Єдина стратегічна мапа

*Огляд стратегічного режиму: Архітектура → Ритми → Звітність. Для швидкої навігації та синхронізації.*

---

## 🌐 Mermaid — Unified Map

```mermaid
flowchart TD
    %% Layers
    subgraph L1[Вхід]
      A[Інформаційний хаос буття]
      A --> A1[MOC: лог-рядок / CSV]
    end

    subgraph L2[Майстерні — кузні артефактів]
      C1[Творча]:::w
      C2[Ідей]:::w
      C3[Просвітництво]:::w
      C4[Арсенал]:::w
      C5[Організація]:::w
      C6[Інструменти]:::w
      C7[Каталог]:::w
      C8[Культурні вузли]:::w
    end

    subgraph L3[Вихід — цифрові артефакти]
      E1[README / Карти / Візуали / Скрипти / ZIP]
      E2[(ARTIFACT_ID)]
    end

    subgraph L4[DAO-GOGS інтеграція]
      F1[DAO-GUIDES]
      F2[DAO-MEDIA]
      F3[DAO-модулі]
      F4[Дім Знань]
      F5[Нац. бібліотека]
      F6[Щит-4 Одеса]
    end

    subgraph L5[Стратегічні ритми]
      R1[Добовий цикл]
      R2[Тижневий цикл]
      R3[Місячний цикл]
      R4[Стратегічний цикл]
    end

    subgraph L6[Звітність]
      Z1[STRATEGIC_REPORT_TEMPLATE]
      Z2[WEEK/MONTH reports]
    end

    %% Flows
    A1 --> C1
    A1 --> C2
    A1 --> C3
    A1 --> C4
    A1 --> C5
    A1 --> C6
    A1 --> C7
    A1 --> C8

    C1 --> E1 --> E2
    C2 --> E1
    C3 --> E1
    C4 --> E1
    C5 --> E1
    C6 --> E1
    C7 --> E1
    C8 --> E1

    E2 --> F1
    E2 --> F2
    E2 --> F3
    E2 --> F4
    E2 --> F5
    E2 --> F6

    %% Rhythms driving everything
    R1 --> A
    R2 --> C5
    R3 --> F3
    R4 --> F4

    %% Reporting taps each layer
    Z1 --> F1
    Z1 --> F2
    Z1 --> F3
    Z1 --> F4
    Z1 --> F5
    Z1 --> F6
    Z2 --> R2
    Z2 --> R3
    Z2 --> R4

    classDef w fill:#222,stroke:#0f0,color:#fff;
```

---

## 🔎 Як читати карту
- **L1–L4** — архітектурний каркас (див. `STRATEGIC_FRAME_v1.0.md`).  
- **L5** — ритми, що керують потоком (див. `STRATEGIC_RHYTHM.md`).  
- **L6** — звітність, яка заміряє прогрес (див. `STRATEGIC_REPORT_TEMPLATE.md`).

---

✍️ *Автор: С.Ч.*

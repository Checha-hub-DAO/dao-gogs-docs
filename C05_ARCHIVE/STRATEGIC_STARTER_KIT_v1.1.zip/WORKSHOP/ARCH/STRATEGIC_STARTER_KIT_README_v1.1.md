# STRATEGIC_STARTER_KIT v1.1

Дата збирання: 2025-09-27 05:24:35

**Склад:**
- `STRATEGIC_FRAME_v1.0.md` (+ CHANGELOG) — архітектура стратегічного рівня.
- `STRATEGIC_RHYTHM.md` (+ CHANGELOG) — ритми (доба/тиждень/місяць/стратегія).
- `STRATEGIC_REPORT_TEMPLATE.md` (+ CHANGELOG) — шаблон стратегічного звіту.
- `STRATEGIC_OVERVIEW_v1.0.md` — єдина мапа.
- `WEEK_REPORT_TEMPLATE.md` — щотижневий звіт.
- `MONTH_SUMMARY_TEMPLATE.md` — щомісячний звіт.

**Рекомендований порядок:**
1) Розмістити у `CHECHA_CORE/WORKSHOP/ARCH/`.
2) Використовувати WEEK_REPORT_TEMPLATE щонеділі.  
3) Використовувати MONTH_SUMMARY_TEMPLATE в кінці кожного місяця.  
4) Раз на 3–6 місяців проводити стратегічну сесію за FRAME + RHYTHM.

*Підпис: С.Ч.*

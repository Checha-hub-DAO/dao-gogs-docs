# STRATEGIC_STARTER_KIT v1.2

Дата збирання: 2025-09-27 05:32:38

**Що нового у v1.2**
- Додано `AUTO_SCRIPT.ps1` для автогенерації WEEK/MONTH-звітів.
- Додано `AUTO_SCRIPT_README.md` з прикладами.
- Збережено весь вміст v1.1 (FRAME, RHYTHM, REPORT_TEMPLATE, OVERVIEW, WEEK/MONTH шаблони).

**Склад:**
- Архітектура: `STRATEGIC_FRAME_v1.0.md` (+ CHANGELOG)
- Ритми: `STRATEGIC_RHYTHM.md` (+ CHANGELOG)
- Шаблони звітів: `STRATEGIC_REPORT_TEMPLATE.md` (+ CHANGELOG), `WEEK_REPORT_TEMPLATE.md`, `MONTH_SUMMARY_TEMPLATE.md`
- Оглядова мапа: `STRATEGIC_OVERVIEW_v1.0.md`
- Автоматизація: `AUTO_SCRIPT.ps1` + `AUTO_SCRIPT_README.md`

**Порядок запуску:**
1) Розмістити папку `WORKSHOP/ARCH/` у `CHECHA_CORE`.
2) Запустити щотижневий ритм:  
   ```powershell
   cd WORKSHOP\ARCH
   .\AUTO_SCRIPT.ps1 -Mode Week
   ```
3) Наприкінці місяця:  
   ```powershell
   .\AUTO_SCRIPT.ps1 -Mode Month
   ```

*Підпис: С.Ч.*

# STRATEGIC_STARTER_KIT v1.4

Дата збирання: 2025-09-27 05:36:32

**Що нового у v1.4**
- Додано **вузлові KPI** у `WEEK_REPORT_TEMPLATE.md` для:
  - **DAO-GUIDES**
  - **DAO-MEDIA**
  - **Щит-4 Одеса**

**Склад (основне):**
- FRAME / RHYTHM / REPORT_TEMPLATE / OVERVIEW
- WEEK_REPORT_TEMPLATE (оновлено вузлові KPI), MONTH_SUMMARY_TEMPLATE
- AUTO_SCRIPT.ps1 + README

**Використання вузлових KPI:**
- Після генерації щотижневого звіту через `AUTO_SCRIPT.ps1 -Mode Week` заповни секцію **“KPI — Вузлові”**.

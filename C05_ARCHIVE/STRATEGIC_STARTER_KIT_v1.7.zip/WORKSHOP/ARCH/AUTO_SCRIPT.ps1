<# Updated script content with Week/Month/Quarter/Year support (see previous cell) #>

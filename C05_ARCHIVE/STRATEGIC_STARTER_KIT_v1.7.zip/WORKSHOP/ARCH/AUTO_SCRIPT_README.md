# AUTO_SCRIPT README (supports Week/Month/Quarter/Year)

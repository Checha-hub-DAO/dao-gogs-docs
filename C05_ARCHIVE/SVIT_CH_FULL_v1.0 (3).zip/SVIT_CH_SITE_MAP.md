# 🗺️ SITE MAP — «Світ Ч» у GitBook

## 📂 DAO-ETNO (G31 — Етнокод Нації)
- **README.md** — вступ до блоку «Світ Ч».  
- **/svit-ch/**  
  - `README.md` — огляд пакета (FULL v1.0).  
  - **/cards/**  
    - `README.md` — опис карток.  
    - `SVIT_CH_CARDS_v1.2.pdf`  
    - `SVIT_CH_CARDS_Booklet.png`  
  - **/matrix/**  
    - `README.md` — пояснення матриці.  
    - `SVIT_CH_Matrix_Stylized.svg`  
    - `SVIT_CH_Matrix.png`  
  - **/legend/**  
    - `README.md` — розшифровка символів.  
    - `SVIT_CH_Legend_Plain.svg`  
    - `SVIT_CH_Legend.png`  
  - **/docs/**  
    - `SVIT_CH_FULL_README.md`  
    - `SVIT_CH_CHANGELOG.md`  
    - `SVIT_CH_GITBOOK_PAGE.md`  

---

## 📂 CheCha CORE (C12 Knowledge Vault)
- **/svit-ch/**  
  - `README.md` — інтегрований опис для архіву знань.  
  - Посилання на DAO-ETNO версію.  
  - Дублікати ключових артефактів (матриця, легенда).  

---

## 🧭 Призначення мапи
- **DAO-ETNO (G31)** — офіційний публічний простір у GitBook.  
- **CheCha CORE (C12)** — внутрішнє сховище знань і синхронізація для робочої структури.  
- Усі файли пакета «Світ Ч» будуть доступні як у **публічній версії DAO**, так і у **локальному CORE-сховищі**.  

✍ Автор: **С.Ч.**

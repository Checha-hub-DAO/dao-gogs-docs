# 🚀 План розгортання — «Світ Ч — FULL v1.0» (GitBook + CheCha CORE)
Дата: 22.09.2025
Автор: С.Ч.

---

## 0) Мета та результат
**Мета:** опублікувати пакет «Світ Ч — FULL v1.0» у GitBook (DAO-ETNO/G31) та синхронізувати копію в CheCha CORE (C12).  
**Результат:** доступна публічна сторінка з посиланнями на артефакти (PDF, матриці, легенди, буклет) + внутрішня копія в C12.

---

## 1) Передумови
- ✅ Актуальні файли (з цього чату):
  - `SVIT_CH_FULL_v1.0.zip`
  - `SVIT_CH_CARDS_v1.2.pdf`
  - `SVIT_CH_CARDS_Booklet.png`
  - `SVIT_CH_Matrix.png/.svg`, `SVIT_CH_Matrix_Stylized.png/.svg`
  - `SVIT_CH_Legend.png/.svg`, `SVIT_CH_Legend_Plain.png/.svg`
  - `SVIT_CH_CHANGELOG.md`, `SVIT_CH_FULL_README.md`, `SVIT_CH_GITBOOK_PAGE.md`, `SVIT_CH_SITE_MAP.md`
- 🛡 GitBook:
  - Доступ до Space (DAO-GOGS MAIN або DAO-ETNO).
  - **GITBOOK_TOKEN** дійсний (Bearer).
  - Заздалегідь створена структура розділів або дозвіл на її створення.
- 💾 CheCha CORE:
  - Локальний шлях (рекомендовано): `D:\CHECHA_CORE\C12\SVIT_CH\FULL_v1.0\`

---

## 2) Структура розміщення (SITE MAP)
Використати файл `SVIT_CH_SITE_MAP.md` (вже зібраний у FULL-пакеті) як еталон:
- DAO-ETNO/G31 → `/svit-ch/` з підрозділами: `/cards/`, `/matrix/`, `/legend/`, `/docs/`.
- CheCha CORE/C12 → `D:\CHECHA_CORE\C12\SVIT_CH\FULL_v1.0\` з дзеркалом ключових артефактів.

---

## 3) Розгортання у GitBook — Автоматичний шлях (PowerShell)
> Підходить, якщо вже налаштований інструмент `Push-GitBook.ps1` і середовище з env-параметрами.

### 3.1 Налаштування змінних середовища (приклад)
```powershell
# ❗ Заповнити власними значеннями
$env:GITBOOK_TOKEN    = "<YOUR_GITBOOK_TOKEN>"
$env:GITBOOK_SPACE_ID = "<YOUR_SPACE_ID>"

# Локальні шляхи до пакетів/файлів (приклад)
$BaseDir = "D:\CHECHA_CORE\PUBLISH\SVIT_CH_FULL_v1.0"
New-Item -Type Directory -Force $BaseDir | Out-Null

# Скопіювати файли з джерела (де завантажено з чату) у $BaseDir перед пушем
```

### 3.2 Публікація сторінки (Markdown)
```powershell
$PageMd = Join-Path $BaseDir "SVIT_CH_GITBOOK_PAGE.md"
pwsh -NoProfile -ExecutionPolicy Bypass -File "D:\CHECHA_CORE\DAO-GOGS-MAIN\C11\tools\Push-GitBook.ps1" `
  -Mode PageImport `
  -File $PageMd `
  -PagePath "dao-etno/svit-ch/readme"  # шлях у просторі
```

### 3.3 Завантаження артефактів (вкладення)
```powershell
$Files = @(
  "SVIT_CH_CARDS_v1.2.pdf",
  "SVIT_CH_CARDS_Booklet.png",
  "SVIT_CH_Matrix.png",
  "SVIT_CH_Matrix.svg",
  "SVIT_CH_Matrix_Stylized.png",
  "SVIT_CH_Matrix_Stylized.svg",
  "SVIT_CH_Legend.png",
  "SVIT_CH_Legend.svg",
  "SVIT_CH_Legend_Plain.png",
  "SVIT_CH_Legend_Plain.svg",
  "SVIT_CH_CHANGELOG.md",
  "SVIT_CH_FULL_README.md",
  "SVIT_CH_SITE_MAP.md"
) | ForEach-Object { Join-Path $BaseDir $_ }

foreach ($f in $Files) { 
  pwsh -NoProfile -ExecutionPolicy Bypass -File "D:\CHECHA_CORE\DAO-GOGS-MAIN\C11\tools\Push-GitBook.ps1" `
    -Mode AssetUpload `
    -File $f `
    -PagePath "dao-etno/svit-ch/readme"
}
```

### 3.4 Створення підсторінок (за бажанням)
```powershell
# /matrix/
pwsh -NoProfile -File "D:\CHECHA_CORE\DAO-GOGS-MAIN\C11\tools\Push-GitBook.ps1" `
  -Mode PageImport -File (Join-Path $BaseDir "SVIT_CH_FULL_README.md") `
  -PagePath "dao-etno/svit-ch/matrix/readme"

# Аналогічно для /cards/, /legend/, /docs/
```

---

## 4) Розгортання у GitBook — Ручний шлях
1. Зайти в GitBook → Space DAO-ETNO (G31) → розділ **Світ Ч**.  
2. Створити сторінку «Світ Ч — FULL v1.0», вставити вміст `SVIT_CH_GITBOOK_PAGE.md`.  
3. Завантажити як вкладення: PDF, PNG/SVG, README, CHANGELOG.  
4. Додати підсторінки `/cards/`, `/matrix/`, `/legend/`, `/docs/` та розмістити відповідні файли.  

---

## 5) Синхронізація з CheCha CORE
```powershell
$dst = "D:\CHECHA_CORE\C12\SVIT_CH\FULL_v1.0"
New-Item -Type Directory -Force $dst | Out-Null

# Копія ключових артефактів
Copy-Item "$BaseDir\SVIT_CH_CARDS_v1.2.pdf"        $dst -Force
Copy-Item "$BaseDir\SVIT_CH_CARDS_Booklet.png"     $dst -Force
Copy-Item "$BaseDir\SVIT_CH_Matrix*.png"           $dst -Force
Copy-Item "$BaseDir\SVIT_CH_Matrix*.svg"           $dst -Force
Copy-Item "$BaseDir\SVIT_CH_Legend*.png"           $dst -Force
Copy-Item "$BaseDir\SVIT_CH_Legend*.svg"           $dst -Force
Copy-Item "$BaseDir\SVIT_CH_*README*.md"           $dst -Force
Copy-Item "$BaseDir\SVIT_CH_CHANGELOG.md"          $dst -Force
Copy-Item "$BaseDir\SVIT_CH_SITE_MAP.md"           $dst -Force
```

---

## 6) Перевірка якості (QA Checklist)
- [ ] Посилання в сторінці GitBook ведуть на коректні вкладення.  
- [ ] Усі SVG/PNG рендеряться коректно на мобільних.  
- [ ] PDF відкривається, шрифти читабельні.  
- [ ] Є сторінки `/cards/`, `/matrix/`, `/legend/`, `/docs/`.  
- [ ] CHANGELOG та README доступні та з лінками.  
- [ ] Дзеркальна копія у `C12\SVIT_CH\FULL_v1.0` повна.  

---

## 7) Версіонування та оновлення
- Наступні зміни фіксуємо як `FULL v1.1`, `FULL v1.2`…  
- Для кожної версії:
  1) Оновити артефакти →  
  2) Оновити `SVIT_CH_CHANGELOG.md` →  
  3) Перезібрати `SVIT_CH_FULL_README.md` →  
  4) Опублікувати в GitBook (оновити сторінку та вкладення).  

---

## 8) Ролі та відповідальність
- **Owner:** С.Ч.  
- **Maintainer (GitBook/DAO):** G31 (DAO-ETNO) редактор.  
- **QA:** Аналітик/Редактор контенту.  

---

## 9) План відкату (Rollback)
- Зберегти попередню робочу версію сторінки як `archive/` у GitBook.  
- У разі збоїв — повернути попередній commit/версію сторінки та вкладень.  
- Локальна копія в `C12` зберігає попередній комплект артефактів.  

---

## 10) Критерії приймання (DoD)
- Публічна сторінка доступна за прямим лінком.  
- Усі вкладення відкриваються.  
- Структура `/cards/`, `/matrix/`, `/legend/`, `/docs/` на місці.  
- CHANGELOG і README з актуальною інформацією.  

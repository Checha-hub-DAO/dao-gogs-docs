# Summary

* [🌌 Світ Ч](README.md)
* [🗺 Карта сайту](site-map.md)
* [📜 Журнал змін](changelog.md)
* [🚀 План розгортання](deploy-plan.md)

## 📚 Картки
* [Вступ](cards/README.md)
  * [Потоки](cards/flows/README.md)
    * [Артефакти](cards/flows/artifacts.md)
  * [Герої](cards/heroes/README.md)
    * [Артефакти](cards/heroes/artifacts.md)
  * [Символи](cards/symbols/README.md)
    * [Артефакти](cards/symbols/artifacts.md)

## 🎨 Візуали
* [Матриця](visuals/matrix.md)
* [Легенда](visuals/legend.md)
* [Буклет](visuals/booklet.md)

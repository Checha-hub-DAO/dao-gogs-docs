# 🌌 Світ Ч

Ласкаво просимо у простір «Світ Ч» — систему карт, героїв та символів.  
Це навігатор для дослідження, творчості та стратегій.

---

## 📚 Картки
- [Потоки](cards/flows/README.md)
- [Герої](cards/heroes/README.md)
- [Символи](cards/symbols/README.md)

## 🎨 Візуали
- [Матриця](visuals/matrix.md)
- [Легенда](visuals/legend.md)
- [Буклет](visuals/booklet.md)

## 📑 Документація
- [Журнал змін](changelog.md)
- [План розгортання](deploy-plan.md)
- [Карта сайту](site-map.md)

✍ Автор: **С.Ч.**

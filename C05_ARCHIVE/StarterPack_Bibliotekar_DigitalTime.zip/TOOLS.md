## 🔧 Інструменти

- Telegram-канал
- GitBook / сайт
- Google Forms
- Canva / Figma
- Kahoot / Quizizz
- Trello / Notion
- Looker Studio

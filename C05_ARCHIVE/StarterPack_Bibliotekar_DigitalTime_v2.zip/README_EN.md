# 📚 StarterPack: Digital-Time Librarian

This package was created to support modern libraries and school knowledge centers.
It contains tools, ideas, visuals, and scenarios for launching a renewed approach to libraries.

---
© DAO-GOGS | S.Ch.

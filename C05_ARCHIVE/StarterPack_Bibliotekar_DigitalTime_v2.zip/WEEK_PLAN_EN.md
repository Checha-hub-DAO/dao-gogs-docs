# 📅 Magical Library Week

**Day 1.** Opening. Why the library is a garden of knowledge.  
**Day 2.** Game "Find your book".  
**Day 3.** Digital tools day.  
**Day 4.** Storytelling circle.  
**Day 5.** Exhibition of student works.  
**Day 6.** Common game/quest.  
**Day 7.** Summary + awards.  

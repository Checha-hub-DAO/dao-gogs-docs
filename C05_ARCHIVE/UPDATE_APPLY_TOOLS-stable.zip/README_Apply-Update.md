
# Apply-Update.ps1 — Централізоване застосування оновлень (_INBOX)

## Призначення
- Забирає ZIP-пакети з `D:\CHECHA_CORE\_INBOX`
- Враховує рівень зрілості **-stable** / **-draft**
- Перевіряє **SHA256** (якщо є `.sha256` поруч)
- Розкладає файли по потрібних блоках:
  - `CHECHA_TOOLS_ONECLICK*` → `D:\CHECHA_CORE\TOOLS\`
  - `AUTO-SCHEDULE*` → `D:\CHECHA_CORE\TOOLS\ScheduleProfiles\` (+ README → `C01_PARAMETERS`)
  - `EVENING_BACKUP*` → `D:\CHECHA_CORE\TOOLS\`
  - `PARAMETERS_UPDATE*` → `D:\CHECHA_CORE\C01_PARAMETERS\`
  - інші → `D:\CHECHA_CORE\WORKSHOP\INBOX_EXTRACTS\<ім'я>`

## Логіка зрілості
- `*-draft.zip` → переносить у `D:\CHECHA_CORE\WORKSHOP\DRAFTS\` (якщо **не** задано `-ApplyDraft`)
- `*-stable.zip` або без суфіксу → застосовує

## Використання
```powershell
pwsh -NoProfile -ExecutionPolicy Bypass `
  -File "D:\CHECHA_CORE\TOOLS\Apply-Update.ps1"
```
Опції:
- `-ApplyDraft` — дозволити застосування draft-пакетів
- `-WhatIf` — сухий прогін (нічого не змінює)

## Логи й архіви
- Лог: `D:\CHECHA_CORE\_INBOX\UPDATES_LOG.md`
- Використані пакети: `D:\CHECHA_CORE\ARCHIVE\UPDATES\YYYYMMDD\`

## Рекомендований цикл
1. Завантажити STABLE-пакети → покласти у `_INBOX`
2. Запустити `Apply-Update.ps1`
3. Перевірити логи: `_INBOX\UPDATES_LOG.md`

# 🗂️ Архів версій і релізів майстерень

## 🔹 Призначення
Цей документ зберігає історію релізів майстерень у межах CheCha Core.  
Він дозволяє відстежувати розвиток і порівнювати версії між собою.

---

## 📌 Версії

### v0.1 — Стартовий каркас (2025-09-23)
- Створено базові README.md у 14 майстернях.  
- Ініціалізовано TASKS.md, NOTES.md, JOURNAL.md, ARTIFACTS.md.  
- Сформовано перший ZIP-пакет.  

### v0.2 — Контроль і GitBook інтеграція (2025-09-24)
- Додано MASTER_CONTROL.md, MASTER_CHECKLIST.md, MASTER_SYNC.md.  
- Додано MASTER_SCRIPT.ps1 + MASTER_RELEASE.ps1 + master_release.sh.  
- Додано GitBook-сторінки (14 майстерень + INDEX_PAGE.md).  
- Додано SUMMARY.md, OVERVIEW.md, FLOW.md, METRICS.md, ROADMAP.md.  
- Почато формування архіву релізів.  

---

## 🔹 План архівування
- Кожен реліз зберігається у форматі ZIP (`WORKSHOPS_README_PACK_vX.X.zip`).  
- До кожного релізу додається SHA-256 хеш.  
- Архів містить CHANGELOG.md, VERSION_LOG.md і цю сторінку.  

---

✍ Автор: Сергій ЧеЧа (С.Ч.)  
Версія: v0.2  
Дата: 2025-09-24

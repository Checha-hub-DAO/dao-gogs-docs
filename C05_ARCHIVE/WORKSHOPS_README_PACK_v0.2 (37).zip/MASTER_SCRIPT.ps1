<#
.SYNOPSIS
  MASTER_SCRIPT.ps1 — автоматизація оновлення пакета майстерень CheCha Core.

.DESCRIPTION
  Скрипт виконує рутинні дії: оновлює версію, синхронізує контрольні файли,
  збирає ZIP-архів, рахує хеш і логуює зміни.

.NOTES
  Автор: Сергій ЧеЧа (С.Ч.)
  Дата: 2025-09-24
#>

param(
  [string]$Root = (Join-Path $PSScriptRoot "."),
  [string]$Version = "0.2",
  [string]$Stage = "draft" # draft | release
)

$ErrorActionPreference = "Stop"

# -----------------------------
# Конфіг
# -----------------------------
$Date = Get-Date -Format "yyyy-MM-dd"
$ZipName = "WORKSHOPS_README_PACK_v$($Version).zip"
$ZipPath = Join-Path $Root $ZipName
$HashPath = Join-Path $Root ("WORKSHOPS_README_PACK_v0.1_v$($Version)_SHA256.txt")

# Майстерні (підпапки)
$Workshops = @(
  "CREATOR","ARCHITECT","SMITH","ANALYST","CHRONIST","STRATEGIST",
  "PHILOSOPHER","MEDIA","TEACHER","RITUAL","ENGINEER","RESEARCHER",
  "PSYCHOLOGIST","COMMUNITY"
)

# Обов'язкові файли в кожній майстерні
$WorkshopFiles = @("README.md","ARTIFACTS.md","JOURNAL.md","TASKS.md","NOTES.md","MASTER_DOC.md")

# -----------------------------
function Update-ControlFiles {
# -----------------------------
  Write-Host "→ Оновлюю CONTROL_PANEL.md / VERSION_LOG.md / CHANGELOG.md ..." -ForegroundColor Cyan

  $control = Join-Path $Root "CONTROL_PANEL.md"
  if (Test-Path $control) {
    (Get-Content $control -Raw) -replace "Версія пакета: v[0-9\.\(\)a-z ]+", ("Версія пакета: v0 (1)" -f $Version,$Stage) |
      Set-Content -Encoding UTF8 $control
  }

  $versionLog = Join-Path $Root "VERSION_LOG.md"
  if (Test-Path $versionLog) {
    $entry = @"
### v$Version — $Date
- Оновлення контрольних файлів та архіву.
- Статус: $Stage

"@
    Add-Content -Encoding UTF8 $versionLog $entry
  }

  $changelog = Join-Path $Root "CHANGELOG.md"
  if (Test-Path $changelog) {
    $entry = @"
## v$Version ($Date)
- Рефреш індексів і контрольних документів.
- Ребілд ZIP, оновлення хешу.
- Статус: $Stage

"@
    Add-Content -Encoding UTF8 $changelog $entry
  }
}

# -----------------------------
function Validate-Workshops {
# -----------------------------
  Write-Host "→ Перевіряю структуру майстерень ..." -ForegroundColor Cyan
  foreach ($w in $Workshops) {
    $path = Join-Path $Root $w
    if (!(Test-Path $path)) { New-Item -Type Directory -Path $path | Out-Null }
    foreach ($f in $WorkshopFiles) {
      $fp = Join-Path $path $f
      if (!(Test-Path $fp)) {
        "# Авто-створено $Date" | Set-Content -Encoding UTF8 $fp
      }
    }
  }
}

# -----------------------------
function Touch-MasterDocs {
# -----------------------------
  Write-Host "→ Оновлюю штампи дат у MASTER_DOC.md ..." -ForegroundColor Cyan
  foreach ($w in $Workshops) {
    $md = Join-Path (Join-Path $Root $w) "MASTER_DOC.md"
    if (Test-Path $md) {
      (Get-Content $md -Raw) -replace "Дата:\s*\d{4}-\d{2}-\d{2}", ("Дата: 2025-09-24") |
        Set-Content -Encoding UTF8 $md
    }
  }
}

# -----------------------------
function Build-Zip {
# -----------------------------
  Write-Host "→ Збираю ZIP: $ZipPath ..." -ForegroundColor Cyan
  if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }
  Add-Type -Assembly 'System.IO.Compression.FileSystem'
  [System.IO.Compression.ZipFile]::CreateFromDirectory($Root, $ZipPath)
}

# -----------------------------
function Write-Hash {
# -----------------------------
  Write-Host "→ Рахую SHA-256 ..." -ForegroundColor Cyan
  $sha256 = [System.Security.Cryptography.SHA256]::Create()
  $fs = [System.IO.File]::OpenRead($ZipPath)
  try {
    $hash = ($sha256.ComputeHash($fs) | ForEach-Object { $_.ToString("x2") }) -join ""
  } finally {
    $fs.Dispose()
  }
  $line = "SHA256  $hash  $ZipName  ($Date)"
  Set-Content -Encoding UTF8 -Path $HashPath -Value $line
  Write-Host $line
}

# -----------------------------
function Main {
# -----------------------------
  Validate-Workshops
  Update-ControlFiles
  Touch-MasterDocs
  Build-Zip
  Write-Hash
  Write-Host "Готово ✅" -ForegroundColor Green
}

Main

# 🎛️ Панель управління майстернями (Control Panel)

## 🔹 Призначення
Цей документ є центральною панеллю управління для системи майстерень CheCha Core.  
Він містить усі основні посилання та "кнопки" для швидкого доступу.

---

## 📚 Основні документи
- [MASTER_OVERVIEW.md](MASTER_OVERVIEW.md) — головний маніфест системи.  
- [INDEX_PAGE.md](INDEX_PAGE.md) — стартова сторінка GitBook.  
- [SUMMARY_PAGE.md](SUMMARY_PAGE.md) — зміст.  
- [OVERVIEW_PAGE.md](OVERVIEW_PAGE.md) — огляд.  

---

## ⚡ Контроль і синхронізація
- [MASTER_CONTROL.md](MASTER_CONTROL.md) — контрольні точки.  
- [MASTER_CHECKLIST.md](MASTER_CHECKLIST.md) — чек-лист.  
- [MASTER_SYNC.md](MASTER_SYNC.md) — синхронізація.  

---

## 📊 Аналітика та прогрес
- [GITBOOK_METRICS.md](GITBOOK_METRICS.md) — KPI.  
- [GITBOOK_DASHBOARD.md](GITBOOK_DASHBOARD.md) — панель прогресу.  
- [GITBOOK_TIMELINE.md](GITBOOK_TIMELINE.md) — хронологія.  
- [GITBOOK_CHANGELOG.md](GITBOOK_CHANGELOG.md) — список змін.  
- [GITBOOK_VERSION_LOG.md](GITBOOK_VERSION_LOG.md) — журнал версій.  
- [GITBOOK_ARCHIVE.md](GITBOOK_ARCHIVE.md) — архів релізів.  

---

## 🛣️ Стратегії та правила
- [GITBOOK_FLOW.md](GITBOOK_FLOW.md) — потоки взаємодії.  
- [GITBOOK_ROADMAP.md](GITBOOK_ROADMAP.md) — дорожня карта.  
- [GITBOOK_GUIDELINES.md](GITBOOK_GUIDELINES.md) — правила та етика.  
- [GITBOOK_NAVIGATOR.md](GITBOOK_NAVIGATOR.md) — інтеграційний навігатор.  

---

## ⚙️ Автоматизація
- `MASTER_SCRIPT.ps1` — головний скрипт для оновлень.  
- `MASTER_RELEASE.ps1` — скрипт релізів.  
- `master_release.sh` — скрипт для Linux/Mac.  

---

✍ Автор: Сергій ЧеЧа (С.Ч.)  
Версія: v0.2  
Дата: 2025-09-24

# 📑 INDEX_MASTERDOCS — Каталог головних документів майстерень

Цей файл містить посилання на всі **MASTER_DOC.md** для швидкої навігації.

---

## 🎨 Творча майстерня
👉 [CREATOR/MASTER_DOC.md](CREATOR/MASTER_DOC.md)

## 🏗️ Майстерня Архітектора
👉 [ARCHITECT/MASTER_DOC.md](ARCHITECT/MASTER_DOC.md)

## ⚒️ Майстерня Коваля
👉 [SMITH/MASTER_DOC.md](SMITH/MASTER_DOC.md)

## 📊 Майстерня Аналітика
👉 [ANALYST/MASTER_DOC.md](ANALYST/MASTER_DOC.md)

## 📜 Майстерня Хроніста
👉 [CHRONIST/MASTER_DOC.md](CHRONIST/MASTER_DOC.md)

## 🧭 Майстерня Стратега
👉 [STRATEGIST/MASTER_DOC.md](STRATEGIST/MASTER_DOC.md)

## 📖 Майстерня Філософа
👉 [PHILOSOPHER/MASTER_DOC.md](PHILOSOPHER/MASTER_DOC.md)

## 📺 Майстерня Медіа
👉 [MEDIA/MASTER_DOC.md](MEDIA/MASTER_DOC.md)

## 🎓 Майстерня Педагога
👉 [TEACHER/MASTER_DOC.md](TEACHER/MASTER_DOC.md)

## 🔥 Майстерня Обрядодіяча
👉 [RITUAL/MASTER_DOC.md](RITUAL/MASTER_DOC.md)

## 🔧 Майстерня Інженера
👉 [ENGINEER/MASTER_DOC.md](ENGINEER/MASTER_DOC.md)

## 🔬 Майстерня Дослідника
👉 [RESEARCHER/MASTER_DOC.md](RESEARCHER/MASTER_DOC.md)

## 🧠 Майстерня Психолога
👉 [PSYCHOLOGIST/MASTER_DOC.md](PSYCHOLOGIST/MASTER_DOC.md)

## 🤝 Майстерня Спільнотника
👉 [COMMUNITY/MASTER_DOC.md](COMMUNITY/MASTER_DOC.md)

---

✍ Автор: Сергій ЧеЧа (С.Ч.)  
Версія: v0.2  
Дата: 2025-09-24

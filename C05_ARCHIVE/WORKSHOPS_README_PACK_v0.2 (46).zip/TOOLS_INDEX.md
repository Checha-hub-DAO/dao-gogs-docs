# 🔧 Каталог інструментів майстерень

Цей документ містить перелік ключових інструментів, згрупованих за майстернями.

---

## 🎨 Творча майстерня
- Карти-символи (MAP_SYMBOLS)
- Карти-герої (MAP_HEROES)
- Генератори візуалів (AI/PNG/SVG)
- Легенди й міфи (MYTHS_COLLECTION)

## 🏗️ Майстерня архітектора
- MAP_MODULES
- MAP_NODES
- StructureMap.ps1
- GitBook-структури
- Архітектурні схеми

## ⚒️ Майстерня коваля
- Психологічний арсенал
- Тренажери стійкості
- Символи-щити
- Chaos_Tools.md

## 📊 Майстерня аналітика
- Дашборди Looker Studio
- Google Sheets (ANALYTICS.csv)
- PowerShell/Python скрипти
- KPI агентів (agent_kpi.csv)
- MODEL_REPORTS.md

## 📜 Майстерня хроніста
- Логи (C03_LOG)
- Шаблони звітів
- Щотижневі дайджести
- Архівні пакети
- LOG_TIMELINE.md

## ♟️ Майстерня стратега
- ROADMAP.md
- FUTURE_SCENARIOS.md
- MATRIX_GROWTH.xlsx
- Карти ризиків і можливостей
- Аналітика ITETA

## 🧭 Майстерня філософа
- MORAL_COMPASS.md
- VALUES_MATRIX.md
- QUOTES.md
- Філософські есе й нотатки

## 📺 Майстерня медіа-майстра
- Медіа-пакети (банери, логотипи)
- GitBook DAO-Media
- Соцмережеві шаблони
- DAO-GALLERY
- Медіа-фідбек форма

## 📚 Майстерня педагога
- EDU_PROGRAMS.md
- COURSE_OUTLINES
- WORKSHEETS.md
- Матеріали для дітей/підлітків
- DAO-FORMS для учнів

## 🔮 Майстерня обрядодіяча
- RITUALS.md
- Символічні карти (7+1)
- INIT_PACK_vX.zip
- SYMBOLS_VISUALS.md
- TECHNOSOUL.md

## 🛠️ Майстерня інженера
- PowerShell скрипти (*.ps1)
- Docker-compose конфігурації
- C11_AUTOMATION
- Artifact Pipeline
- МінІО / Архівні сервіси

## 🔬 Майстерня дослідника
- FIELD_NOTES.md
- EXPERIMENTS.md
- HYPOTHESES.md
- Карти трендів
- ITETA дослідження

## 🧠 Майстерня психолога
- MAT_RESTORE.csv
- RESILIENCE_TOOLS.md
- ENERGY_CYCLE_MAP
- Survival Protocols
- MOOD_LOG.md

## 🤝 Майстерня спільнотника
- DAO-FORM-CONTRIBUTE
- COMMUNITY_MAPS.md
- Фасилітаційні інструменти
- DAO-JOURNAL
- EVENTS_SCHEDULE.md

---

✍ Автор: Сергій ЧеЧа (С.Ч.)  
Версія пакета: v0.1  
Дата: 2025-09-24

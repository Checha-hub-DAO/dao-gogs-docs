
param(
  [string]$Root = "D:\CHECHA_CORE"
)
$ws = Join-Path $Root "WORKSHOP_CREATOR\VISUALS\slideshow.html"
if (-not (Test-Path $ws)) {
  Write-Error "slideshow.html не знайдено: $ws"
  exit 1
}
Start-Process -FilePath $ws | Out-Null
Write-Host "Відкриваю слайдшоу у браузері: $ws" -ForegroundColor Green

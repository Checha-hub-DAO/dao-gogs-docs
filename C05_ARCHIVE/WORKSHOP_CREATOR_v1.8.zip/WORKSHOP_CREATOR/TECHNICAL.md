<!-- Package: WORKSHOP_CREATOR | Generated: 2025-09-21 22:37:09 -->

# Технічна Кузня

## Інструменти
- PowerShell-скрипти (архів, push, revizor)
- Git / GitBook інтеграції
- Docker / MinIO контейнери
- Google Forms / Looker Studio

## Активні процеси (поточний цикл)
- [ ] Архівація CHECHA_CORE
- [ ] Push до GitBook (DAO-GOGS MAIN)
- [ ] Синхронізація з DAO-модулями
- [ ] Перевірка `Revizor` + звіт

## Швидкий старт (PowerShell)
```powershell
# Запуск архівації (приклад):
& "D:\CHECHA_CORE\C11\tools\Archive-Core.ps1" -Root "D:\CHECHA_CORE"

# Push сторінки до GitBook (приклад):
pwsh -NoProfile -ExecutionPolicy Bypass -File "D:\CHECHA_CORE\DAO-GOGS-MAIN\C11\tools\Push-GitBook.ps1" `
  -Mode PageImport -File "<path-to-md>" -Token "$env:GITBOOK_TOKEN" -SpaceId "$env:GITBOOK_SPACE_ID"
```


[CmdletBinding()]
param(
  [string]$Root = "D:\CHECHA_CORE",
  [Parameter(Mandatory=$true)][string]$Id,
  [switch]$PublishToGitBook,
  [switch]$UpdateStatus
)

$ErrorActionPreference = "Stop"
function Info { param([string]$m,[string]$c="") if ($c){ Microsoft.PowerShell.Utility\Write-Host $m -ForegroundColor $c } else { Microsoft.PowerShell.Utility\Write-Host $m } }

$ws = Join-Path $Root "WORKSHOP_CREATOR"
$reg = Join-Path $ws "ARTIFACTS.md"
$artDir = Join-Path $ws ("ARTIFACTS\" + $Id)
if (-not (Test-Path $artDir)) { throw "Артефакт не знайдено: $artDir" }

# Manifest + checksums
$manifest = [ordered]@{
  id = $Id
  date = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
  files = @()
}
$checksums = @()

Get-ChildItem -Path $artDir -File -Recurse | ForEach-Object {
  $rel = $_.FullName.Substring($artDir.Length+1)
  $sha = (Get-FileHash -Path $_.FullName -Algorithm SHA256).Hash
  $manifest.files += [ordered]@{ path = $rel; sha256 = $sha }
  $checksums += ("{0}  {1}" -f $sha, $rel)
}

$manifestPath = Join-Path $artDir "manifest.json"
$checksPath   = Join-Path $artDir "CHECKSUMS.txt"
$manifest | ConvertTo-Json -Depth 5 | Set-Content -Path $manifestPath -Encoding UTF8
$checksums | Set-Content -Path $checksPath -Encoding UTF8

# Zip out to C03_LOG\ARTIFACT_PACKS
$packDir = Join-Path $Root "C03_LOG\ARTIFACT_PACKS"
if (-not (Test-Path $packDir)) { New-Item -ItemType Directory -Path $packDir | Out-Null }
$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$zipPath = Join-Path $packDir ("{0}_package_{1}.zip" -f $Id, $ts))

Add-Type -AssemblyName System.IO.Compression.FileSystem
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
[System.IO.Compression.ZipFile]::CreateFromDirectory($artDir, $zipPath)

Info ("Пакет створено: " + $zipPath) "Green"

# Optional: update ARTIFACTS.md status
if ($UpdateStatus -and (Test-Path $reg)) {
  $lines = Get-Content -Path $reg -Encoding UTF8
  $out = @()
  foreach ($ln in $lines) {
    if ($ln -match "^\|\s*{0}\s*\|" -f [regex]::Escape($Id)) {
      # split on pipe safely (ignore leading/ending bars)
      $parts = $ln.Trim('|').Split('|').ForEach{ $_.Trim() }
      if ($parts.Length -ge 10) {
        if ($PublishToGitBook) { $parts[3] = "published" } else { if ($parts[3] -in @("draft","ritual")) { $parts[3] = "artifact" } }
        $ln = "| " + ($parts -join " | ") + " |"
      }
    }
    $out += $ln
  }
  Set-Content -Path $reg -Value $out -Encoding UTF8
  Info "ARTIFACTS.md оновлено (статус)." "Yellow"
}

# Optional: GitBook publish (README.md)
$publishResult = "skip"
if ($PublishToGitBook) {
  $tools = Join-Path $Root "DAO-GOGS-MAIN\C11\tools"
  $push  = Join-Path $tools "Push-GitBook.ps1"
  $readme = Join-Path $artDir "README.md"
  if (-not (Test-Path $push)) { Write-Warning "Publish: не знайдено Push-GitBook.ps1 ($push)" }
  elseif (-not (Test-Path $readme)) { Write-Warning "Publish: не знайдено README.md в артефакті" }
  elseif (-not $env:GITBOOK_TOKEN -or -not $env:GITBOOK_SPACE_ID) { Write-Warning "Publish: немає GITBOOK_TOKEN/SPACE_ID"; }
  else {
    Info ("GitBookPush: " + $readme) "Cyan"
    try {
      pwsh -NoProfile -ExecutionPolicy Bypass -File $push `
        -Mode PageImport `
        -File $readme `
        -Token $env:GITBOOK_TOKEN `
        -SpaceId $env:GITBOOK_SPACE_ID
      $publishResult = "ok"
      Info "Опубліковано в GitBook." "Green"
    } catch {
      $publishResult = "warn"
      Write-Warning ("GitBookPush: помилка — " + $_.Exception.Message)
    }
  }
}

# Output object for callers
[pscustomobject]@{
  Id = $Id
  Zip = $zipPath
  Publish = $publishResult
} | ConvertTo-Json -Depth 5 | Write-Output

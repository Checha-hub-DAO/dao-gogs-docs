# Changelog — G35 DAO-MEDIA

## [1.0.0] — 2025-09-09
- Initial stable structure
- MANIFEST + exports + checksums
- Docs: overview, campaigns, digest, feedback, playbooks, tech
- Public page linkage (`/dao-media`)

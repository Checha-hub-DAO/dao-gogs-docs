# G35 — DAO-MEDIA

Модуль медіа-системи DAO-GOGS: кампанії, дайджести, фідбек, плейбуки, технічний контур.
Документація: `docs/_index.md` • MANIFEST: `MANIFEST.yaml` • Експорти: `export.yaml` • Версія: `VERSION.txt`

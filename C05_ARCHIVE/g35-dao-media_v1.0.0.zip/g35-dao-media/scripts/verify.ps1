Param([string]$Root = (Resolve-Path ".").Path)
$ErrorActionPreference = "Stop"; Set-StrictMode -Version Latest

$need = @("MANIFEST.yaml","VERSION.txt","export.yaml","docs/_index.md","CHECKSUMS.txt")
$miss = $need | Where-Object { -not (Test-Path (Join-Path $Root $_)) }
if($miss){ $miss | ForEach-Object { "❌ Missing: $_" }; exit 2 }

$ver = Get-Content (Join-Path $Root "VERSION.txt") -Raw
if($ver -notmatch 'version:\s*\d+\.\d+\.\d+'){ "❌ VERSION.txt: semver missing"; exit 3 }

# Перевірка контрольних сум
$lines = Get-Content (Join-Path $Root "CHECKSUMS.txt") | Where-Object {$_ -notmatch '^\s*#|^\s*$'}
$bad = $false
foreach($line in $lines){
  if($line -match '([A-Fa-f0-9]{64})\s+(.+)$'){
    $hash=$matches[1]; $rel=$matches[2]
    $path = Join-Path $Root $rel
    if(-not (Test-Path $path)){ "❌ Missing for checksum: $rel"; $bad=$true; continue }
    $cur=(Get-FileHash -Algorithm SHA256 $path).Hash
    if($cur -ne $hash){ "❌ Hash mismatch: $rel"; $bad=$true }
  }
}
if($bad){ exit 4 }

"✅ verify: OK"; exit 0

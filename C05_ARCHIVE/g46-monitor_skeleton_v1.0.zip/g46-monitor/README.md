# g46-monitor — Podilsk.InfoHub Live

Щоденний моніторинг: **DeepStateMap → Верховна Рада → Локальні апдейти** з автоматичною публікацією в Telegram.

## 🔧 Архітектура
- `ingest/` — збір даних (скріни/парсинг).
- `process/` — побудова дайджесту.
- `publish/` — публікація в Telegram.
- `storage/` — робота з Google Sheets + резервне збереження (CSV/SQLite).
- `ops/` — розклад (cron), контейнеризація.
- `data/` — тимчасові файли, медіа, логи.

## ▶️ Швидкий старт
1. Склонуй репозиторій і створіть файл `.env` на основі `.env.example`.
2. Встанови залежності: `pip install -r requirements.txt`
3. Заповни змінні середовища (Telegram токен, ключі до Google Sheets).
4. Запусти локально по кроках:
   ```bash
   python ingest/deepstate.py
   python ingest/rada_activity.py
   python ingest/local_news.py
   python process/build_digest.py
   python publish/tg_bot.py
   ```
5. Налаштуй `cron` або `docker-compose` (див. `ops/`).

## 📅 Розклад (приклад)
- 08:00 — DeepState (скрін/дані)
- 08:05 — ВРУ (відвідуваність/голосування)
- 08:10 — Локальні джерела
- 08:15 — Збір дайджесту
- 08:20 — Публікація у Telegram

## ⚠️ Принципи
- Поважати **умови використання джерел** (ToS).
- Давати джерела/лінки у кожному дайджесті.
- Не робити категоричних висновків за військовими картами; лише факти й посилання.

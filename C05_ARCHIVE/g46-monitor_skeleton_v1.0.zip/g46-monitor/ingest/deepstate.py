# ingest/deepstate.py — витяг DeepState (скріншот або API)
import os, datetime, pathlib
from dotenv import load_dotenv

load_dotenv()
MODE = os.getenv("DEEPSTATE_MODE", "screenshot")
URL = os.getenv("DEEPSTATE_URL")
IMG_TPL = os.getenv("DEEPSTATE_IMAGE_PATH", "data/media/deepstate_{date}.png")

def capture_screenshot(url, out_path):
    # TODO: реалізувати Playwright/Selenium скріншот сторінки DeepStateMap
    # Прикладні кроки:
    #  - headless браузер → відкрити URL → зачекати відмальовування → зробити screenshot(full_page=False)
    pathlib.Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    open(out_path, "wb").write(b"")  # заглушка, щоб пайплайн не падав
    return out_path

def main():
    date = datetime.date.today().isoformat()
    out = IMG_TPL.format(date=date)
    if MODE == "screenshot":
        path = capture_screenshot(URL, out)
        print("DeepState screenshot saved:", path)
    else:
        # TODO: API mode (якщо з'явиться офіційний публічний API і це відповідає ToS)
        print("API mode not implemented; switch to screenshot")

if __name__ == "__main__":
    main()

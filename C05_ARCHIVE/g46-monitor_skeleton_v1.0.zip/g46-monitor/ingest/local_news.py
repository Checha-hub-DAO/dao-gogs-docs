# ingest/local_news.py — локальні джерела Подільська/Поділля
import os, datetime
from dotenv import load_dotenv
from storage.sheets_client import append_rows

load_dotenv()
LOCAL = (os.getenv("LOCAL_SOURCES") or "").split(",")

def fetch_local_sample():
    # TODO: парсинг сайтів/FB (з урахуванням ToS); тут демо-рядки
    today = datetime.date.today().isoformat()
    return [
        [today, "Подільськ", "Анонс події в бібліотеці", "Лекція + виставка", "https://example.com"],
        [today, "Подільський район", "Суботник", "Прибирання історичної локації", "https://example.com/subotnyk"]
    ]

def main():
    rows = fetch_local_sample()
    append_rows("Local", rows)
    print(f"Appended {len(rows)} rows to Local")

if __name__ == "__main__":
    main()

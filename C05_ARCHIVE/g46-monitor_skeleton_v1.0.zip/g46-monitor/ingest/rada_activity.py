# ingest/rada_activity.py — відвідуваність/голосування ВРУ
import os, datetime
import pandas as pd
from dotenv import load_dotenv
from storage.sheets_client import append_rows

load_dotenv()
SOURCES = (os.getenv("RADA_SOURCES") or "").split(",")

def fetch_rada_sample():
    # TODO: додати реальний парсинг з офіційних/відкритих джерел
    today = datetime.date.today().isoformat()
    rows = [
        [today, "Депутат Іваненко", "Фракція X", "vote", "yea", "Законопроєкт №1234", "https://rada.gov.ua/"],
        [today, "Депутат Петренко", "Фракція Y", "visit", "", "Відвідування засідання", "https://rada.gov.ua/"],
    ]
    return rows

def main():
    rows = fetch_rada_sample()
    append_rows("Rada", rows)
    print(f"Appended {len(rows)} rows to Rada")

if __name__ == "__main__":
    main()

# ops/runner.py — послідовний раннер (для docker-compose)
import subprocess, sys

STEPS = [
    ["python", "ingest/deepstate.py"],
    ["python", "ingest/rada_activity.py"],
    ["python", "ingest/local_news.py"],
    ["python", "process/build_digest.py"],
    ["python", "publish/tg_bot.py"],
]

for cmd in STEPS:
    print(">> RUN:", " ".join(cmd), flush=True)
    code = subprocess.call(cmd)
    if code != 0:
        print("Step failed with code", code, file=sys.stderr)

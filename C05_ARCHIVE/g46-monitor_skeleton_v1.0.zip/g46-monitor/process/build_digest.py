# process/build_digest.py — формує текст дайджесту
import datetime, os, pandas as pd
from dotenv import load_dotenv
from storage.sheets_client import read_sheet

load_dotenv()

def safe_read(sheet, limit=5):
    try:
        df = read_sheet(sheet)
        return df.tail(limit)
    except Exception as e:
        return pd.DataFrame()

def make_block(title, lines):
    if not lines:
        return f"{title}\n— джерело тимчасово недоступне"
    body = "\n".join([f"— {ln}" for ln in lines])
    return f"{title}\n{body}"

def main():
    today = datetime.date.today().strftime("%d.%m.%Y")
    deepstate = safe_read("DeepState", 1)
    rada = safe_read("Rada", 4)
    local = safe_read("Local", 3)

    ds_lines = []
    if not deepstate.empty:
        row = deepstate.iloc[-1]
        note = row.get("notes", "")
        ds_lines.append(str(note or "Оновлення карти (див. зображення)."))

    rada_lines = []
    for _, r in rada.iterrows():
        rada_lines.append(f"{r.get('mp_name','—')} • {r.get('event_type','')} {r.get('vote','')} — {r.get('title','')}")

    local_lines = []
    for _, r in local.iterrows():
        local_lines.append(f"{r.get('city','')} — {r.get('title','')} ({r.get('source_url','')})")

    text = f"""#МоніторДня • {today}

🗺️ DeepState:
{make_block('', ds_lines)}

🏛️ Верховна Рада:
{make_block('', rada_lines)}

📰 Подільськ / Поділля:
{make_block('', local_lines)}

Повна добірка: (додай посилання на GitBook або Google Sheets)
""".strip()

    out_path = "data/monitor_text.txt"
    os.makedirs("data", exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(text)
    print(out_path)

if __name__ == "__main__":
    main()

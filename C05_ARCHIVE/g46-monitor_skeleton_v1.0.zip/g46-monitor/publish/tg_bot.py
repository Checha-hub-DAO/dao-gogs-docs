# publish/tg_bot.py — публікація у Telegram
import os, io
from dotenv import load_dotenv
from telegram import Bot

load_dotenv()
BOT = Bot(token=os.getenv("TELEGRAM_TOKEN"))
CHANNEL = os.getenv("TELEGRAM_CHANNEL")

def read_text():
    with open("data/monitor_text.txt", "r", encoding="utf-8") as f:
        return f.read()

def maybe_send_photo():
    # Якщо попередній крок зберіг скрін мапи — надішлемо фото
    # За замовчуванням шукаємо останній файл у data/media/ з префіксом deepstate_
    media_dir = "data/media"
    if not os.path.isdir(media_dir):
        return None
    imgs = sorted([p for p in os.listdir(media_dir) if p.startswith("deepstate_") and p.endswith(".png")])
    if not imgs:
        return None
    last = os.path.join(media_dir, imgs[-1])
    with open(last, "rb") as f:
        BOT.send_photo(chat_id=CHANNEL, photo=f)
    return last

def main():
    photo = maybe_send_photo()
    BOT.send_message(chat_id=CHANNEL, text=read_text(), disable_web_page_preview=True)
    print("Published to", CHANNEL, "photo:", bool(photo))

if __name__ == "__main__":
    main()

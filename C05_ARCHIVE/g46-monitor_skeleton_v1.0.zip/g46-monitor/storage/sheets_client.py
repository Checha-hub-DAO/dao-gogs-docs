# storage/sheets_client.py — Google Sheets клієнт (append/read)
import os
import pandas as pd

# ЗАГЛУШКА: підключення до Google Sheets винесене для безпеки.
# Заміни ці функції на реальні виклики gspread з service_account.json.
# Приклад у README та в техплані.

def append_rows(sheet_name, rows):
    # TODO: реалізувати через gspread.authorize(...).worksheet(sheet_name).append_rows(rows)
    # Тимчасово — збереження в CSV (резерв)
    path = f"data/{sheet_name}.csv"
    df_new = pd.DataFrame(rows)
    if os.path.exists(path):
        df = pd.read_csv(path, header=None)
        df = pd.concat([df, df_new], ignore_index=True)
    else:
        df = df_new
    df.to_csv(path, index=False, header=False, encoding="utf-8-sig")

def read_sheet(sheet_name):
    # TODO: реалізувати читання з Google Sheets
    path = f"data/{sheet_name}.csv"
    if os.path.exists(path):
        return pd.read_csv(path, header=None, encoding="utf-8-sig")
    return pd.DataFrame()

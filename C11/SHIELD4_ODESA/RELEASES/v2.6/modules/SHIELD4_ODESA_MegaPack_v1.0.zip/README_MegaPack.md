# 🌍 SHIELD-4 ODESA — MegaPack (v1.0)

Цей архів об'єднує всі ключові візуальні та презентаційні матеріали ініціативи **Щит-4 Одеса**.

## 📂 Вміст

### 1. Mega Visual Pack
`SHIELD4_ODESA_MegaVisualPack_v1.0.zip`  
Містить:  
- PosterPack (Dark, Styled, All-in-One, Light у PDF + PNG)  
- Master PosterBook (повна брошура)  
- Short PosterBook (PDF + PNG)  
**Використання:** візуальна комунікація, друк, соцмережі, інструктаж.

---

### 2. Presentation Pack
`SHIELD4_ODESA_PresentationPack_v1.0.zip`  
Містить:  
- Презентація v1.0 (базова)  
- Презентація v1.1 (стилізована DAO-GOGS)  
- PDF-версії (спрощена + FullRender)  
**Використання:** виступи, захист проекту, архівування.

---

## 📌 Рекомендації
- Для **офіційних заходів** використовуйте Presentation v1.1 (PPTX або FullRender PDF).  
- Для **онлайн-поширення** — PosterPack (Styled або Light).  
- Для **командної роботи** — Short PosterBook як шпаргалка.  

✍️ Автор: Сергій Чеча (С.Ч.)  
Версія пакета: v1.0

# Weekly checklist (2025-10-01 → 2025-10-07)

**Source:** $RestoreLogPath  
**Generated:** 2025-10-07 15:25:55  

## Summary
| Metric | Value |
|---|---:|
| Days | 1 |
| Records | 30 |
| Updated status | 5 |
| Checksums OK | 1 |
| Warnings | 0 |
| Errors | 2 |

## By day
| Date | Count | Status | Checks | Warn | Err |
|---|---:|---:|---:|---:|---:|
| 2025-10-07 | 30 | 5 | 1 | 0 | 2 |

## Last 15 of the week
- [2025-10-07 12:47:25] Weekly index rebuilt with KPI + 4-week digest: WEEKLY_INDEX.md
- [2025-10-07 13:00:45] Weekly index rebuilt with KPI + 4-week digest: WEEKLY_INDEX.md
- [2025-10-07 13:09:52] Weekly report: WEEKLY_CHECKLIST_2025-W41.md | Days=0 | Total= | Done= | Todo= | AvgPct=0% | DoneShare=0% | Median=0% | Streak=0
- [2025-10-07 13:09:52] Weekly index rebuilt with KPI + 4-week digest: WEEKLY_INDEX.md
- [2025-10-07 13:17:02] Weekly index rebuilt with KPI + 4-week digest: WEEKLY_INDEX.md
- [2025-10-07 13:18:04] Weekly index rebuilt with KPI + 4-week digest: WEEKLY_INDEX.md
- [2025-10-07 13:19:11] Weekly index rebuilt with KPI + 4-week digest: WEEKLY_INDEX.md
- [2025-10-07 13:20:17] Weekly index rebuilt with KPI + 4-week digest: WEEKLY_INDEX.md
- [2025-10-07 13:20:50] Weekly index rebuilt with KPI + 4-week digest: WEEKLY_INDEX.md
- [2025-10-07 13:21:53] Weekly report: WEEKLY_CHECKLIST_2025-W41.md | Days=0 | Total= | Done= | Todo= | AvgPct=0% | DoneShare=0% | Median=0% | Streak=0
- [2025-10-07 13:24:20] Weekly report: WEEKLY_CHECKLIST_2025-W41.md | Days=0 | Total= | Done= | Todo= | AvgPct=0% | DoneShare=0% | Median=0% | Streak=0
- [2025-10-07 13:24:20] Weekly index rebuilt with KPI + 4-week digest: WEEKLY_INDEX.md
- [2025-10-07 13:36:59] Weekly index rebuilt with KPI + 4-week digest: WEEKLY_INDEX.md
- [2025-10-07 13:40:14] Weekly index rebuilt with KPI + 4-week digest: WEEKLY_INDEX.md
- [2025-10-07 13:40:28] Weekly index rebuilt with KPI + 4-week digest: WEEKLY_INDEX.md

---
**SHA-256:** 093FC1B4ABB333869F7096DC9B65879F96E7E1B54E381508D893717971F9FC29

